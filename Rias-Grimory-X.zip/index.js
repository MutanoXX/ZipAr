/**
 * RIAS GREMORY X AI - Bot Discord
 * Ponto de entrada principal
 * 
 * VERSÃO 3.0 - Sistema Multi-Agente
 * 
 * @description Bot Discord para análise e reestruturação de servidores usando IA
 * @version 3.0.0
 * @author MutanoX
 * @license MIT
 */

import { Client, GatewayIntentBits, Collection, REST, Routes, ActivityType } from 'discord.js';
import { config } from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import aiService from './src/services/aiService.js';
import { initServerConfig, removeServerConfig } from './src/utils/serverPermissions.js';
import accountManager from './src/utils/accountManager.js';
import { initStorage } from './src/utils/storageManager.js';
import { initAutomationHandler } from './src/events/automationHandler.js';

// Carregar variáveis de ambiente
config();

// Constantes
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Configurações do bot
 * @constant {Object}
 */
const BOT_CONFIG = {
  MAX_RETRIES: 3,
  RETRY_DELAY: 5000,
  COMMANDS_PATH: path.join(__dirname, 'src', 'commands'),
  EVENTS_PATH: path.join(__dirname, 'src', 'events'),
  REQUIRED_ENV_VARS: ['DISCORD_TOKEN', 'DISCORD_CLIENT_ID']
};

/**
 * Valida variáveis de ambiente obrigatórias
 * @throws {Error} Se variável obrigatória estiver faltando
 */
function validateEnvironment() {
  const missing = BOT_CONFIG.REQUIRED_ENV_VARS.filter(key => !process.env[key]);
  
  if (missing.length > 0) {
    console.error('❌ Variáveis de ambiente faltando:', missing.join(', '));
    process.exit(1);
  }
  
  console.log('✅ Variáveis de ambiente validadas');
}

/**
 * Cria e configura o cliente Discord
 * @returns {Client} Cliente Discord configurado
 */
function createDiscordClient() {
  return new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers
    ],
    rest: {
      timeout: 30000,
      retries: 3
    }
  });
}

// Criar cliente Discord
const client = createDiscordClient();

// Coleção para comandos
client.commands = new Collection();

// Armazenamento temporário de planos por servidor
global.mutanoxPlans = {};

// Array para armazenar dados dos comandos para registro
const commandsData = [];

/**
 * Carrega comandos dinamicamente do diretório
 * @async
 * @returns {Promise<number>} Número de comandos carregados
 */
async function loadCommands() {
  const commandsPath = BOT_CONFIG.COMMANDS_PATH;
  
  if (!fs.existsSync(commandsPath)) {
    console.error(`❌ Diretório de comandos não encontrado: ${commandsPath}`);
    return 0;
  }

  const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

  console.log('');
  console.log('📂 Carregando comandos...');

  let loadedCount = 0;
  let errorCount = 0;

  for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    
    try {
      const module = await import(filePath);
      const command = module.default || module;
      
      if (!command.data || !command.execute) {
        console.log(`  ⚠️ ${file} - Formato inválido (falta data ou execute)`);
        errorCount++;
        continue;
      }
      
      client.commands.set(command.data.name, command);
      commandsData.push(command.data.toJSON());
      console.log(`  ✅ /${command.data.name}`);
      loadedCount++;
      
    } catch (error) {
      console.error(`  ❌ Erro ao carregar ${file}:`, error.message);
      errorCount++;
    }
  }
  
  console.log(`  📊 Total: ${loadedCount} comandos carregados, ${errorCount} erros`);
  
  return loadedCount;
}

/**
 * Carrega eventos dinamicamente do diretório
 * @async
 * @returns {Promise<number>} Número de eventos carregados
 */
async function loadEvents() {
  const eventsPath = BOT_CONFIG.EVENTS_PATH;
  
  if (!fs.existsSync(eventsPath)) {
    console.error(`❌ Diretório de eventos não encontrado: ${eventsPath}`);
    return 0;
  }

  const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

  console.log('');
  console.log('🎯 Carregando eventos...');

  let loadedCount = 0;
  let errorCount = 0;

  for (const file of eventFiles) {
    const filePath = path.join(eventsPath, file);
    
    try {
      const event = await import(filePath);
      
      if (!event.name || !event.execute) {
        console.log(`  ⚠️ ${file} - Formato inválido`);
        errorCount++;
        continue;
      }
      
      if (event.once) {
        client.once(event.name, (...args) => event.execute(...args, client));
      } else {
        client.on(event.name, (...args) => event.execute(...args, client));
      }
      
      console.log(`  ✅ ${event.name}`);
      loadedCount++;
      
    } catch (error) {
      console.error(`  ❌ Erro ao carregar ${file}:`, error.message);
      errorCount++;
    }
  }
  
  console.log(`  📊 Total: ${loadedCount} eventos carregados, ${errorCount} erros`);
  
  return loadedCount;
}

/**
 * Registra comandos slash no Discord
 * @async
 * @returns {Promise<boolean>} Sucesso do registro
 */
async function registerCommands() {
  const rest = new REST({ 
    version: '10',
    timeout: 30000,
    retries: BOT_CONFIG.MAX_RETRIES
  }).setToken(process.env.DISCORD_TOKEN);

  console.log('');
  console.log('🔌 Registrando comandos slash...');

  try {
    // 1. Limpar comandos GLOBAIS antigos (para evitar duplicação)
    console.log('  🧹 Limpando comandos globais antigos...');
    
    try {
      await rest.put(
        Routes.applicationCommands(process.env.DISCORD_CLIENT_ID),
        { body: [] }
      );
    } catch (e) {
      // Ignorar se não houver comandos para limpar
    }
    
    // 2. Registrar comandos POR SERVIDOR (instantâneo!)
    const guilds = client.guilds.cache;
    
    if (guilds.size === 0) {
      console.log('  ⚠️ Nenhum servidor para registrar comandos');
      return true;
    }
    
    for (const [guildId, guild] of guilds) {
      try {
        // Limpar comandos antigos do servidor
        try {
          await rest.put(
            Routes.applicationGuildCommands(process.env.DISCORD_CLIENT_ID, guildId),
            { body: [] }
          );
        } catch (e) {}
        
        // Registrar novos comandos no servidor
        await rest.put(
          Routes.applicationGuildCommands(process.env.DISCORD_CLIENT_ID, guildId),
          { body: commandsData }
        );
        
        console.log(`  ✅ Comandos registrados em: ${guild.name}`);
      } catch (error) {
        console.error(`  ❌ Erro ao registrar em ${guild.name}:`, error.message);
      }
    }
    
    console.log('  ⚡ Comandos registrados INSTANTANEAMENTE (por servidor)!');
    
    return true;
    
  } catch (error) {
    console.error('  ❌ Erro ao registrar comandos:', error.message);
    
    if (error.code === 50001) {
      console.error('  💡 Dica: Verifique se o bot tem permissão de aplicações no servidor');
    }
    
    return false;
  }
}

/**
 * Inicializa configurações de todos os servidores
 * @async
 * @returns {Promise<number>} Número de servidores inicializados
 */
async function initializeAllServers() {
  console.log('');
  console.log('📋 Inicializando configurações dos servidores...');
  
  let count = 0;
  const errors = [];
  
  for (const guild of client.guilds.cache.values()) {
    try {
      initServerConfig(guild);
      count++;
    } catch (error) {
      errors.push({ guild: guild.name, error: error.message });
    }
  }
  
  if (errors.length > 0) {
    console.error(`  ⚠️ ${errors.length} erros durante inicialização:`);
    errors.forEach(e => console.error(`    - ${e.guild}: ${e.error}`));
  }
  
  console.log(`  ✅ ${count} servidores inicializados`);
  
  return count;
}

/**
 * Configura os handlers de eventos do cliente
 */
function setupClientHandlers() {
  /**
   * Evento: Bot entrou em um novo servidor
   */
  client.on('guildCreate', async (guild) => {
    console.log('');
    console.log('🆕 [GuildCreate] Bot adicionado a um novo servidor!');
    console.log(`  📍 Nome: ${guild.name}`);
    console.log(`  🆔 ID: ${guild.id}`);
    console.log(`  👥 Membros: ${guild.memberCount}`);
    
    // Inicializar configuração do novo servidor
    try {
      initServerConfig(guild);
    } catch (error) {
      console.error(`  ❌ Erro ao inicializar configuração:`, error.message);
    }
    
    // Registrar comandos no novo servidor (instantâneo!)
    try {
      const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
      
      await rest.put(
        Routes.applicationGuildCommands(process.env.DISCORD_CLIENT_ID, guild.id),
        { body: commandsData }
      );
      
      console.log(`  ⚡ Comandos registrados instantaneamente!`);
    } catch (error) {
      console.error(`  ❌ Erro ao registrar comandos:`, error.message);
    }
    
    // Tentar enviar mensagem de boas-vindas
    await sendWelcomeMessage(guild);
  });

  /**
   * Evento: Bot foi removido de um servidor
   */
  client.on('guildDelete', async (guild) => {
    console.log('');
    console.log('👋 [GuildDelete] Bot removido de um servidor');
    console.log(`  📍 Nome: ${guild.name}`);
    console.log(`  🆔 ID: ${guild.id}`);
    
    // Limpar configurações do servidor
    try {
      removeServerConfig(guild.id);
    } catch (error) {
      console.error(`  ❌ Erro ao limpar configuração:`, error.message);
    }
  });

  /**
   * Evento: Erro no cliente
   */
  client.on('error', (error) => {
    console.error('❌ [Client] Erro no cliente Discord:', error.message);
  });

  /**
   * Evento: Aviso do cliente
   */
  client.on('warn', (warning) => {
    console.warn('⚠️ [Client] Aviso:', warning);
  });

  /**
   * Evento: Rate limit
   */
  client.on('rateLimit', (info) => {
    console.warn(`⏱️ [RateLimit] Limite atingido: ${info.method} ${info.path} - Reset em ${info.timeout}ms`);
  });
}

/**
 * Envia mensagem de boas-vindas ao entrar em um servidor
 * @async
 * @param {Guild} guild - Servidor Discord
 */
async function sendWelcomeMessage(guild) {
  try {
    const channel = guild.channels.cache
      .filter(c => c.type === 0 && c.permissionsFor(guild.members.me).has('SendMessages'))
      .first();
    
    if (!channel) {
      console.log('  ⚠️ Nenhum canal disponível para mensagem de boas-vindas');
      return;
    }
    
    const { EmbedBuilder } = await import('discord.js');
    
    const welcomeEmbed = new EmbedBuilder()
      .setTitle('🌹 Rias Gremory X AI')
      .setDescription('Olá! Sou a **Rias Gremory**, uma IA avançada para gerenciar seu servidor Discord!')
      .addFields(
        { 
          name: '🚀 Primeiros Passos', 
          value: '1. Use `/architect` para criar seu servidor\n2. Use `/ask on` para ativar a IA em um canal\n3. Use `/help` para ver todas as funcionalidades' 
        },
        { 
          name: '🔐 Permissões', 
          value: '• Apenas **Administradores** e o **Dono do servidor** podem usar a IA\n• O comando `/delete-server` é exclusivo do dono do servidor' 
        },
        { 
          name: '✨ O que posso fazer?', 
          value: '• Criar servidores completos com IA\n• Criar canais e categorias\n• Gerenciar cargos\n• Enviar embeds decorados\n• E muito mais!' 
        }
      )
      .setColor('#8B5CF6')
      .setThumbnail(client.user.displayAvatarURL({ size: 256 }))
      .setTimestamp()
      .setFooter({ text: `Versão 3.0 | ${client.guilds.cache.size} servidores` });
    
    await channel.send({ embeds: [welcomeEmbed] });
    console.log(`  ✅ Mensagem de boas-vindas enviada em #${channel.name}`);
    
  } catch (error) {
    console.log(`  ⚠️ Não foi possível enviar mensagem de boas-vindas: ${error.message}`);
  }
}

/**
 * Define o status do bot
 */
function setBotPresence() {
  const activities = [
    { name: '🌹 Rias Gremory | /ask', type: ActivityType.Watching },
    { name: `${client.guilds.cache.size} servidores`, type: ActivityType.Watching },
    { name: 'Construindo servidores perfeitos', type: ActivityType.Playing }
  ];
  
  const activity = activities[Math.floor(Math.random() * activities.length)];
  
  client.user.setPresence({
    activities: [activity],
    status: 'online'
  });
}

/**
 * Configura handlers de processo
 */
function setupProcessHandlers() {
  // Tratamento de erros não capturados
  process.on('unhandledRejection', (reason, promise) => {
    console.error('❌ Promise rejection não tratada:', reason);
    console.error('Promise:', promise);
  });

  process.on('uncaughtException', (error) => {
    console.error('❌ Exceção não capturada:', error);
    // Em produção, você pode querer reiniciar o processo
    process.exit(1);
  });

  // Graceful shutdown
  const gracefulShutdown = (signal) => {
    console.log(`\n👋 Recebido ${signal}, encerrando bot graciosamente...`);
    
    client.destroy()
      .then(() => {
        console.log('✅ Conexão Discord fechada');
        process.exit(0);
      })
      .catch((error) => {
        console.error('❌ Erro ao fechar conexão:', error.message);
        process.exit(1);
      });
  };

  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
}

/**
 * Inicialização do bot
 * @async
 */
async function start() {
  console.log('');
  console.log('═══════════════════════════════════════════');
  console.log('       🌹 RIAS GREMORY X AI 🌹');
  console.log('       Bot Discord - Versão 3.0');
  console.log('       Sistema Multi-Agente');
  console.log('═══════════════════════════════════════════');
  console.log('');

  try {
    // Validar ambiente
    validateEnvironment();
    
    // Configurar handlers de processo
    setupProcessHandlers();
    
    // Configurar handlers do cliente
    setupClientHandlers();

    // Inicializar serviço de IA
    console.log('🤖 Inicializando serviço de IA...');
    await aiService.initialize();
    
    // Inicializar sistema de armazenamento
    console.log('💾 Inicializando sistema de armazenamento...');
    initStorage();

    // Inicializar sistema de contas
    console.log('💰 Inicializando sistema de contas...');
    accountManager.initAccountSystem();

    // Carregar comandos e eventos
    await loadCommands();
    await loadEvents();

    console.log('');
    console.log('🔌 Conectando ao Discord...');

    // Login no Discord
    await client.login(process.env.DISCORD_TOKEN);

    // Registrar comandos após conectar
    await registerCommands();
    
    // Inicializar configurações de todos os servidores
    await initializeAllServers();
    
    // Inicializar handler de automações event-driven
    console.log('🎯 Inicializando sistema de automações...');
    initAutomationHandler(client);
    
    // Definir presença
    setBotPresence();
    
    // Atualizar presença periodicamente
    setInterval(setBotPresence, 300000); // 5 minutos

    console.log('');
    console.log('═══════════════════════════════════════════');
    console.log('       ✅ BOT INICIADO COM SUCESSO!');
    console.log(`       📍 ${client.guilds.cache.size} servidores`);
    console.log(`       👥 ${client.users.cache.size} usuários`);
    console.log(`       ⚡ ${client.ws.ping}ms ping`);
    console.log('═══════════════════════════════════════════');
    console.log('');

  } catch (error) {
    console.error('❌ Erro durante inicialização:', error);
    
    if (error.code === 'TOKEN_INVALID') {
      console.error('💡 Dica: Verifique se o DISCORD_TOKEN está correto');
    }
    
    process.exit(1);
  }
}

// Iniciar o bot
start();

export default client;
