/**
 * RIAS GREMORY X AI - Evento InteractionCreate
 * Gerencia interações com botões, menus e comandos
 * 
 * VERSÃO 3.0 - Sistema Multi-Agente
 */

import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags, ModalBuilder, TextInputBuilder, TextInputStyle } from 'discord.js';
import { applyPlan, checkBotPermissions } from '../utils/serverManager.js';
import { executeDelete } from '../commands/deleteServer.js';
import { createHelpMessage } from '../commands/help.js';
import { 
  checkServerPermission, 
  isServerOwner, 
  isBotOwner,
  canExecuteCritical,
  isAuthorized
} from '../utils/permissions.js';
import paymentManager from '../services/paymentManager.js';
import accountManager from '../utils/accountManager.js';
import { initStorage } from '../utils/storageManager.js';

export const name = 'interactionCreate';

// Inicializar storage
initStorage();

export async function execute(interaction) {
  // Comandos slash
  if (interaction.isChatInputCommand()) {
    const command = interaction.client.commands.get(interaction.commandName);

    if (!command) {
      console.error(`❌ Comando não encontrado: ${interaction.commandName}`);
      return;
    }

    try {
      await command.execute(interaction);
    } catch (error) {
      console.error('❌ Erro ao executar comando:', error);
      
      const errorReply = {
        content: '❌ Ocorreu um erro ao executar este comando.',
        flags: MessageFlags.Ephemeral
      };

      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(errorReply);
      } else {
        await interaction.reply(errorReply);
      }
    }
  }

  // Interações com botões
  if (interaction.isButton()) {
    // Sistema de Enquetes
    if (interaction.customId.startsWith('poll_vote_')) {
      return await handlePollVote(interaction);
    }

    // Botões Genéricos da IA
    if (interaction.customId.startsWith('gen_btn_')) {
      return await handleGenericInteraction(interaction);
    }

    // Especial para o /help (não precisa de autorização especial além de ser o autor)
    if (interaction.customId.startsWith('help_')) {
      const parts = interaction.customId.split('_');
      const action = parts[1]; // next ou prev
      const currentIndex = parseInt(parts[2]);
      const newIndex = action === 'next' ? currentIndex + 1 : currentIndex - 1;
      
      const response = createHelpMessage(newIndex);
      return await interaction.update(response);
    }

    // Botões do Architect
    if (interaction.customId.startsWith('arch_')) {
      return await handleArchitectInteraction(interaction);
    }

    // Botão de adicionar saldo
    if (interaction.customId === 'open_adicionar_saldo') {
      return await handleOpenAdicionarSaldo(interaction);
    }

    await handleButtonInteraction(interaction);
  }

  // Menus de Seleção
  if (interaction.isStringSelectMenu()) {
    // Menu de seleção de plano (assinatura)
    if (interaction.customId === 'select_plan') {
      const { handlePlanSelection } = await import('../commands/assinatura.js');
      return await handlePlanSelection(interaction);
    }
    
    if (interaction.customId.startsWith('gen_sel_')) {
      return await handleGenericInteraction(interaction);
    }
  }

  // Modals
  if (interaction.isModalSubmit()) {
    if (interaction.customId.startsWith('arch_')) {
      return await handleArchitectModal(interaction);
    }
    if (interaction.customId.startsWith('deposit_modal_')) {
      return await handleDepositModal(interaction);
    }
  }
}

/**
 * Handler para interações do Architect
 */
async function handleArchitectInteraction(interaction) {
  const customId = interaction.customId;
  const userId = interaction.user.id;

  // Verificar permissão
  if (!isAuthorized(userId)) {
    return interaction.reply({
      content: '❌ Você não tem permissão para usar este comando.',
      flags: MessageFlags.Ephemeral
    });
  }

  // Voltar ao menu principal
  if (customId === 'arch_back') {
    const { showMainMenu } = await import('../commands/architect.js');
    return await showMainMenu(interaction);
  }

  // Abrir modal de criação
  if (customId === 'arch_open_modal_create') {
    const modal = new ModalBuilder()
      .setCustomId('arch_modal_create')
      .setTitle('🆕 Criar Servidor');

    const goalInput = new TextInputBuilder()
      .setCustomId('arch_goal')
      .setLabel('Descreva o objetivo do servidor')
      .setStyle(TextInputStyle.Paragraph)
      .setPlaceholder('Ex: Uma loja de produtos digitais com suporte e pagamentos')
      .setRequired(true)
      .setMaxLength(500);

    const row = new ActionRowBuilder().addComponents(goalInput);
    modal.addComponents(row);

    return await interaction.showModal(modal);
  }

  // Carregar handlers do architect
  const { handlers } = await import('../commands/architect.js');
  if (handlers?.button) {
    return await handlers.button(interaction);
  }

  return interaction.reply({
    content: '❌ Interação não reconhecida.',
    flags: MessageFlags.Ephemeral
  });
}

/**
 * Handler para modals do Architect
 */
async function handleArchitectModal(interaction) {
  const { handlers } = await import('../commands/architect.js');
  
  if (handlers?.modal) {
    return await handlers.modal(interaction);
  }

  return interaction.reply({
    content: '❌ Modal não reconhecido.',
    flags: MessageFlags.Ephemeral
  });
}

/**
 * Handler para abrir modal de adicionar saldo
 */
async function handleOpenAdicionarSaldo(interaction) {
  const modal = new ModalBuilder()
    .setCustomId(`deposit_modal_${interaction.user.id}`)
    .setTitle('💰 Adicionar Saldo');

  const valueInput = new TextInputBuilder()
    .setCustomId('deposit_value')
    .setLabel('Valor em Reais (mínimo: R$ 5,00)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Ex: 50.00')
    .setRequired(true);

  const row = new ActionRowBuilder().addComponents(valueInput);
  modal.addComponents(row);

  await interaction.showModal(modal);
}

/**
 * Handler para modal de depósito
 */
async function handleDepositModal(interaction) {
  const valueStr = interaction.fields.getTextInputValue('deposit_value');
  const value = parseFloat(valueStr.replace(',', '.'));

  if (isNaN(value) || value < 5) {
    return interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Valor Inválido')
          .setDescription('O valor mínimo é R$ 5,00')
          .setColor('#EF4444')
      ],
      flags: MessageFlags.Ephemeral
    });
  }

  const userId = interaction.user.id;
  const username = interaction.user.username;

  try {
    // Criar pagamento
    const paymentResult = await paymentManager.createDepositPayment(userId, username, value);

    if (!paymentResult.success) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setTitle('❌ Erro ao criar pagamento')
            .setDescription(paymentResult.error)
            .setColor('#EF4444')
        ],
        flags: MessageFlags.Ephemeral
      });
    }

    const payment = paymentResult.payment;

    const embed = new EmbedBuilder()
      .setTitle('💳 Depósito de Saldo')
      .setDescription('Escaneie o QR Code ou use o código PIX')
      .setColor('#8B5CF6')
      .addFields(
        { name: '💰 Valor', value: `R$ ${value.toFixed(2)}`, inline: true },
        { name: '⏰ Expira em', value: new Date(payment.expirationDate).toLocaleString('pt-BR'), inline: true },
        { name: '📋 Código PIX', value: `\`\`\`${payment.copyPaste}\`\`\``, inline: false }
      )
      .setImage(`https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(payment.copyPaste)}`)
      .setTimestamp();

    const confirmBtn = new ButtonBuilder()
      .setCustomId(`confirm_payment_${payment.transactionId}`)
      .setLabel('✅ Paguei')
      .setStyle(ButtonStyle.Success);

    const cancelBtn = new ButtonBuilder()
      .setCustomId('cancel_payment')
      .setLabel('❌ Cancelar')
      .setStyle(ButtonStyle.Danger);

    const row = new ActionRowBuilder().addComponents(confirmBtn, cancelBtn);

    await interaction.reply({
      embeds: [embed],
      components: [row],
      flags: MessageFlags.Ephemeral
    });

  } catch (error) {
    console.error('❌ Erro ao processar depósito:', error.message);
    
    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Erro')
          .setDescription('Erro ao processar solicitação. Tente novamente.')
          .setColor('#EF4444')
      ],
      flags: MessageFlags.Ephemeral
    });
  }
}

/**
 * Gerencia interações com botões
 */
async function handleButtonInteraction(interaction) {
  const customId = interaction.customId;
  const guild = interaction.guild;
  const userId = interaction.user.id;
  const member = interaction.member;

  // Botões de Pagamento
  if (customId.startsWith('confirm_payment_')) {
    return await handleConfirmPayment(interaction);
  }

  if (customId === 'cancel_payment') {
    return await interaction.update({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Pagamento Cancelado')
          .setDescription('A operação foi cancelada.')
          .setColor('#EF4444')
      ],
      components: []
    });
  }

  // Botão de desvincar
  if (customId.startsWith('unlink_to_buy_')) {
    return await handleUnlinkToBuy(interaction);
  }

  // Botão de confirmar desvinculação
  if (customId.startsWith('confirm_unlink_')) {
    return await handleConfirmUnlink(interaction);
  }

  // Botão de confirmar desvinculação da conta própria
  if (customId.startsWith('confirm_self_unlink_')) {
    return await handleConfirmSelfUnlink(interaction);
  }

  // Botão de confirmar renovação automática
  if (customId === 'confirm_auto_renew') {
    return await handleConfirmAutoRenew(interaction);
  }

  // Botão de confirmar renovação automática
  if (customId === 'cancel_action') {
    return await interaction.update({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Ação Cancelada')
          .setDescription('A ação foi cancelada.')
          .setColor('#EF4444')
          .setTimestamp()
      ],
      components: []
    });
  }

  // Botão de confirmar ação do /ask
  if (customId.startsWith('confirm_action_')) {
    return await handleConfirmAskAction(interaction, guild);
  }

  // Botão de cancelar ação
  if (customId === 'cancel_action') {
    return await interaction.update({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Ação Cancelada')
          .setDescription('A ação foi cancelada.')
          .setColor('#EF4444')
          .setTimestamp()
      ],
      components: []
    });
  }

  // Verificar permissão do usuário (exceto para cancelamentos)
  if (!['cancel_plan', 'cancel_delete'].includes(customId)) {
    const permCheck = checkServerPermission(guild, { id: userId }, member);
    
    if (!permCheck.authorized) {
      return interaction.reply({
        content: `❌ ${permCheck.reason}`,
        flags: MessageFlags.Ephemeral
      });
    }
  }

  // Verificar permissões do bot (exceto para cancelamentos)
  if (!['cancel_plan', 'cancel_delete'].includes(customId)) {
    const permCheck = checkBotPermissions(guild);
    if (!permCheck.hasAllPermissions) {
      return interaction.reply({
        content: `❌ O bot não tem permissões suficientes. Faltando: ${permCheck.missingPermissions.join(', ')}`,
        flags: MessageFlags.Ephemeral
      });
    }
  }

  switch (customId) {
    case 'apply_plan':
      await handleApplyPlan(interaction, guild);
      break;
    
    case 'preview_plan':
      await handlePreviewPlan(interaction, guild);
      break;
    
    case 'cancel_plan':
      await handleCancelPlan(interaction, guild);
      break;
    
    case 'confirm_delete':
      // Verificação extra: apenas dono do servidor pode confirmar deleção
      if (!canExecuteCritical(userId, { guild })) {
        return interaction.reply({
          content: '❌ Apenas o **Dono do Servidor** pode confirmar a deleção.',
          flags: MessageFlags.Ephemeral
        });
      }
      await handleConfirmDelete(interaction, guild);
      break;
    
    case 'cancel_delete':
      await handleCancelDelete(interaction, guild);
      break;
    
    default:
      await interaction.reply({
        content: '❌ Interação não reconhecida.',
        flags: MessageFlags.Ephemeral
      });
  }
}

/**
 * Confirma ação do /ask
 */
async function handleConfirmAskAction(interaction, guild) {
  const userId = interaction.user.id;
  const customId = interaction.customId;
  
  // Verificar se é o usuário que solicitou
  if (!customId.includes(userId)) {
    return interaction.reply({
      content: '❌ Essa ação não foi solicitada por você.',
      flags: MessageFlags.Ephemeral
    });
  }

  const pendingActions = global.pendingActions?.[userId];
  
  if (!pendingActions) {
    return interaction.update({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Ação Expirada')
          .setDescription('Solicite a ação novamente.')
          .setColor('#EF4444')
      ],
      components: []
    });
  }

  await interaction.update({
    embeds: [
      new EmbedBuilder()
        .setTitle('⏳ Executando...')
        .setDescription('Aguarde enquanto executo as ações.')
        .setColor('#8B5CF6')
    ],
    components: []
  });

  // Executar ações pendentes
  let executed = 0;
  let errors = [];

  for (const action of pendingActions.actions || []) {
    try {
      await executeAction(action, guild);
      executed++;
      await sleep(300);
    } catch (error) {
      errors.push(error.message);
    }
  }

  // Limpar ações pendentes
  delete global.pendingActions[userId];

  const embed = new EmbedBuilder()
    .setTitle('✅ Ações Executadas!')
    .addFields(
      { name: '📊 Executadas', value: `${executed}`, inline: true },
      { name: '❌ Erros', value: `${errors.length}`, inline: true }
    )
    .setColor('#10B981')
    .setTimestamp();

  if (errors.length > 0) {
    embed.addFields({
      name: 'Detalhes dos Erros',
      value: errors.slice(0, 3).join('\n'),
      inline: false
    });
  }

  await interaction.editReply({ embeds: [embed] });
}

/**
 * Executa uma ação
 */
async function executeAction(action, guild) {
  switch (action.action) {
    case 'create_category': {
      const category = await guild.channels.create({
        name: action.name,
        type: 4,
        reason: 'MutanoX Architect'
      });
      
      if (action.channels) {
        for (const ch of action.channels) {
          await guild.channels.create({
            name: ch.name,
            type: ch.type || 0,
            parent: category.id,
            topic: ch.type !== 2 ? ch.topic : undefined,
            reason: 'MutanoX Architect'
          });
          await sleep(200);
        }
      }
      break;
    }
    
    case 'create_role': {
      const PERMISSION_FLAGS = {
        Administrator: 8n,
        ViewChannel: 1024n,
        SendMessages: 2048n,
        Connect: 1048576n,
        Speak: 2097152n,
      };

      let permissions = 0n;
      if (action.permissions) {
        for (const perm of action.permissions) {
          if (PERMISSION_FLAGS[perm]) permissions |= PERMISSION_FLAGS[perm];
        }
      }

      await guild.roles.create({
        name: action.name,
        color: action.color?.replace('#', '') || null,
        permissions: permissions,
        reason: 'MutanoX Architect'
      });
      break;
    }
    
    default:
      throw new Error(`Ação desconhecida: ${action.action}`);
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Aplica o plano armazenado
 */
async function handleApplyPlan(interaction, guild) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const plan = global.mutanoxPlans?.[guild.id];
  
  if (!plan) {
    return interaction.editReply({
      content: '❌ Nenhum plano encontrado. Use `/architect analyze` primeiro.'
    });
  }

  try {
    await interaction.editReply({
      content: '🏗️ Aplicando plano de reestruturação... Isso pode levar alguns segundos.'
    });

    const result = await applyPlan(guild, plan);

    delete global.mutanoxPlans[guild.id];

    const embed = new EmbedBuilder()
      .setTitle('✅ Plano Aplicado com Sucesso!')
      .setDescription('A nova estrutura foi criada no servidor.')
      .addFields(
        { name: '📁 Categorias', value: `${result.categories} criadas`, inline: true },
        { name: '📝 Canais', value: `${result.channels} criados`, inline: true },
        { name: '👥 Cargos', value: `${result.roles} criados`, inline: true }
      )
      .setColor('#10B981')
      .setTimestamp();

    if (result.errors.length > 0) {
      embed.addFields({
        name: '⚠️ Avisos',
        value: result.errors.slice(0, 5).join('\n').substring(0, 1024),
        inline: false
      });
    }

    await interaction.editReply({ embeds: [embed] });

    try {
      await interaction.message.edit({
        components: [
          new ActionRowBuilder()
            .addComponents(
              new ButtonBuilder()
                .setCustomId('applied')
                .setLabel('✅ Plano Aplicado')
                .setStyle(ButtonStyle.Success)
                .setDisabled(true)
            )
        ]
      });
    } catch (e) {}

  } catch (error) {
    console.error('Erro ao aplicar plano:', error);
    
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Erro ao Aplicar Plano')
          .setDescription(error.message)
          .setColor('#EF4444')
      ]
    });
  }
}

/**
 * Mostra preview detalhado do plano
 */
async function handlePreviewPlan(interaction, guild) {
  const plan = global.mutanoxPlans?.[guild.id];
  
  if (!plan) {
    return interaction.reply({
      content: '❌ Nenhum plano encontrado.',
      flags: MessageFlags.Ephemeral
    });
  }

  const embed = new EmbedBuilder()
    .setTitle('👀 Preview Detalhado do Plano')
    .setColor('#8B5CF6')
    .setTimestamp();

  if (plan.changes?.createRoles?.length > 0) {
    const rolesDetail = plan.changes.createRoles
      .map(r => `**${r.name}**\n• Cor: ${r.color || 'Padrão'}\n• Permissões: ${r.permissions?.join(', ') || 'Nenhuma'}`)
      .join('\n\n');
    
    embed.addFields({
      name: '👥 Cargos a Criar',
      value: rolesDetail.substring(0, 1024),
      inline: false
    });
  }

  if (plan.changes?.createCategories?.length > 0) {
    const categoriesDetail = plan.changes.createCategories
      .map(c => {
        const channels = c.channels?.map(ch => `  → ${ch.type === 2 ? '🔊' : '📝'} ${ch.name}`).join('\n') || 'Nenhum canal';
        return `**${c.name}**\n${channels}`;
      })
      .join('\n\n');
    
    embed.addFields({
      name: '📁 Categorias e Canais',
      value: categoriesDetail.substring(0, 1024),
      inline: false
    });
  }

  await interaction.reply({
    embeds: [embed],
    flags: MessageFlags.Ephemeral
  });
}

/**
 * Cancela o plano atual
 */
async function handleCancelPlan(interaction, guild) {
  delete global.mutanoxPlans[guild.id];

  await interaction.update({
    embeds: [
      new EmbedBuilder()
        .setTitle('❌ Plano Cancelado')
        .setDescription('O plano de reestruturação foi descartado.')
        .setColor('#EF4444')
        .setTimestamp()
    ],
    components: []
  });
}

/**
 * Confirma a deleção do servidor
 */
async function handleConfirmDelete(interaction, guild) {
  // Verificação extra de segurança
  const userId = interaction.user.id;
  
  if (!canExecuteCritical(userId, { guild })) {
    return interaction.reply({
      content: '❌ Apenas o **Dono do Servidor** pode executar esta ação.',
      flags: MessageFlags.Ephemeral
    });
  }

  await executeDelete(interaction, guild);
}

/**
 * Cancela a deleção do servidor
 */
async function handleCancelDelete(interaction, guild) {
  await interaction.update({
    embeds: [
      new EmbedBuilder()
        .setTitle('❌ Deleção Cancelada')
        .setDescription('O servidor não foi modificado.')
        .setColor('#10B981')
        .setTimestamp()
    ],
    components: []
  });
}

async function handlePollVote(interaction) {
  const pollId = interaction.message.id;
  const poll = global.activePolls?.[pollId];
  
  if (!poll) {
    return interaction.reply({ content: '❌ Esta enquete não está mais ativa.', flags: MessageFlags.Ephemeral });
  }

  const optionIndex = parseInt(interaction.customId.split('_')[2]);
  const userId = interaction.user.id;

  // Remover voto anterior se existir
  poll.votes.forEach((voters, i) => {
    const index = voters.indexOf(userId);
    if (index > -1) voters.splice(index, 1);
  });

  // Adicionar novo voto
  poll.votes[optionIndex].push(userId);

  // Atualizar Embed
  const totalVotes = poll.votes.reduce((sum, v) => sum + v.length, 0);
  const description = poll.options.map((opt, i) => {
    const count = poll.votes[i].length;
    const percent = totalVotes > 0 ? Math.round((count / totalVotes) * 100) : 0;
    const bar = '🟩'.repeat(Math.floor(percent / 10)) + '⬜'.repeat(10 - Math.floor(percent / 10));
    return `**${i + 1}.** ${opt}\n${bar} ${count} votos (${percent}%)`;
  }).join('\n\n');

  const embed = EmbedBuilder.from(interaction.message.embeds[0])
    .setDescription(description);

  await interaction.update({ embeds: [embed] });
}

async function handleGenericInteraction(interaction) {
  const value = interaction.isStringSelectMenu() ? interaction.values[0] : interaction.component?.label || 'Interação';
  
  // Notificar a IA sobre a interação simulando uma mensagem do usuário
  const fakeMessage = {
    content: `[Interação: ${value}]`,
    author: interaction.user,
    guild: interaction.guild,
    channel: interaction.channel,
    attachments: new Map(),
    reply: (content) => interaction.reply(content),
    sendTyping: () => interaction.channel.sendTyping()
  };

  const messageEvent = await import('./messageCreat.js');
  
  await interaction.reply({ content: `⏳ Processando sua escolha: **${value}**...`, flags: MessageFlags.Ephemeral });
  await messageEvent.execute(fakeMessage);
}

/**
 * Confirma o pagamento de uma transação
 */
async function handleConfirmPayment(interaction) {
  const customId = interaction.customId;
  const transactionId = customId.replace('confirm_payment_', '');
  const userId = interaction.user.id;

  await interaction.deferUpdate();

  try {
    const result = await paymentManager.confirmPayment(userId, transactionId);

    if (!result.success) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setTitle('❌ Erro ao Confirmar Pagamento')
            .setDescription(result.error)
            .setColor('#EF4444')
        ],
        components: []
      });
    }

    // Sucesso!
    const embed = new EmbedBuilder()
      .setTitle('✅ Pagamento Confirmado!')
      .setDescription(result.message)
      .setColor('#10B981');

    if (result.account) {
      if (result.account.planType) {
        embed.addFields({
          name: '📅 Plano Ativo',
          value: `${result.account.planType === 'semanal' ? '📅 Semanal (7 dias)' : '📅 Mensal (30 dias)'}`,
          inline: true
        });
      }

      embed.addFields({
        name: '💰 Saldo',
        value: `R$ ${result.account.balance.toFixed(2)}`,
        inline: true
      });
    }

    embed.setTimestamp();

    return interaction.editReply({
      embeds: [embed],
      components: []
    });

  } catch (error) {
    console.error('❌ Erro ao processar pagamento:', error.message);

    return interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Erro ao Processar Pagamento')
          .setDescription('Ocorreu um erro ao processar seu pagamento. Tente novamente mais tarde.')
          .setColor('#EF4444')
      ],
      components: []
    });
  }
}

/**
 * Desvincula usuário para comprar seu próprio plano
 */
async function handleUnlinkToBuy(interaction) {
  const userId = interaction.user.id;

  await interaction.deferUpdate();

  try {
    const result = accountManager.unlinkFromOwner(userId);

    if (!result.success) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setTitle('❌ Erro')
            .setDescription(result.message)
            .setColor('#EF4444')
        ],
        components: []
      });
    }

    return interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('✅ Desvinculado com Sucesso!')
          .setDescription('Agora você pode criar sua própria assinatura. Use `/renov` para comprar seu plano.')
          .setColor('#10B981')
      ],
      components: []
    });

  } catch (error) {
    console.error('❌ Erro ao desvincar:', error.message);

    return interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Erro ao Desvincar')
          .setDescription('Ocorreu um erro. Tente novamente mais tarde.')
          .setColor('#EF4444')
      ],
      components: []
    });
  }
}

/**
 * Confirma desvinculação de outro usuário da conta
 */
async function handleConfirmUnlink(interaction) {
  const customId = interaction.customId;
  const linkedUserId = customId.replace('confirm_unlink_', '');
  const userId = interaction.user.id;

  await interaction.deferUpdate();

  try {
    const result = accountManager.unlinkUser(userId, linkedUserId);

    if (!result.success) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setTitle('❌ Erro')
            .setDescription(result.error)
            .setColor('#EF4444')
        ],
        components: []
      });
    }

    return interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('✅ Usuário Desvinculado')
          .setDescription(`<@${linkedUserId}> foi desvinculado de sua conta.`)
          .setColor('#10B981')
      ],
      components: []
    });

  } catch (error) {
    console.error('❌ Erro ao desvincar:', error.message);

    return interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Erro')
          .setDescription('Ocorreu um erro ao desvincar. Tente novamente.')
          .setColor('#EF4444')
      ],
      components: []
    });
  }
}

/**
 * Confirma desvinculação da própria conta
 */
async function handleConfirmSelfUnlink(interaction) {
  const userId = interaction.user.id;

  await interaction.deferUpdate();

  try {
    const result = accountManager.selfUnlink(userId);

    if (!result.success) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setTitle('❌ Erro')
            .setDescription(result.error)
            .setColor('#EF4444')
        ],
        components: []
      });
    }

    return interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('✅ Desvinculado com Sucesso!')
          .setDescription('Você foi desvinculado da conta principal. Agora você pode criar sua própria assinatura.')
          .setColor('#10B981')
      ],
      components: []
    });

  } catch (error) {
    console.error('❌ Erro ao desvincar:', error.message);

    return interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Erro')
          .setDescription('Ocorreu um erro. Tente novamente.')
          .setColor('#EF4444')
      ],
      components: []
    });
  }
}

/**
 * Confirma renovação automática
 */
async function handleConfirmAutoRenew(interaction) {
  const userId = interaction.user.id;

  await interaction.deferUpdate();

  try {
    const result = accountManager.setAutoRenew(userId, true);

    if (!result.success) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setTitle('❌ Erro')
            .setDescription(result.error)
            .setColor('#EF4444')
        ],
        components: []
      });
    }

    return interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('✅ Renovação Automática Ativada!')
          .setDescription('Seu plano será renovado automaticamente quando expirar (se houver saldo suficiente).')
          .setColor('#10B981')
      ],
      components: []
    });

  } catch (error) {
    console.error('❌ Erro ao ativar renovação automática:', error.message);

    return interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Erro')
          .setDescription('Ocorreu um erro. Tente novamente.')
          .setColor('#EF4444')
      ],
      components: []
    });
  }
}

export default { name, execute };
