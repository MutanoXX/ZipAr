/**
 * Rias-Grimory-X - Evento MessageCreate
 * VERSÃO 16.0 - Robusto e Funcional
 * 
 * FOCO:
 * - Parse de resposta mais robusto
 * - Fallback inteligente
 * - Mensagens úteis quando IA falha
 */

import { 
  EmbedBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle,
  StringSelectMenuBuilder,
  ChannelType,
  PermissionFlagsBits
} from 'discord.js';
import OpenAI from 'openai';
import { checkServerPermission } from '../utils/permissions.js';
import accountManager from '../utils/accountManager.js';
import { 
  isChannelActive, 
  getChannelContext, 
  addUserMessage,
  addAIMessage
} from '../utils/activeChannels.js';
import apiService from '../services/apiService.js';
import serverTools from '../utils/serverTools.js';
import automationManager from '../utils/automationManager.js';
import eventAutomationEngine, {
  createEventAutomation,
  listEventAutomations,
  deleteEventAutomation,
  toggleEventAutomation,
  getEventAutomation,
  TRIGGER_TYPES,
  ACTION_TYPES,
  AUTOMATION_TEMPLATES
} from '../utils/eventAutomationEngine.js';

// Módulos V6
import automodManager from '../utils/automodManager.js';
import logsManager from '../utils/logsManager.js';
import welcomeManager from '../utils/welcomeManager.js';
import ticketsManager from '../utils/ticketsManager.js';
import riasImages, { getRiasFooter, detectEmotion } from '../utils/riasImages.js';
import v6Handlers from '../utils/v6Handlers.js';
import warnManager from '../utils/warnManager.js';
import embedTemplates from '../utils/embedTemplates.js';
import logConfigManager, { LOG_TYPES } from '../utils/logConfigManager.js';

// Sistema de Mensagens da Rias
import { getRiasMessage, getRiasErrorMessage, sendRiasFollowUp } from '../utils/riasMessages.js';

// Referência global ao client do Discord
let discordClient = null;

export function setClient(client) {
  discordClient = client;
}

const NVIDIA_KEY = process.env.NVIDIA_API_KEY || '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';

const client = new OpenAI({
  baseURL: 'https://integrate.api.nvidia.com/v1',
  apiKey: NVIDIA_KEY,
  timeout: 45000,
  maxRetries: 2
});

export const name = 'messageCreate';

export async function execute(message) {
  if (message.author.bot || !message.guild) return;

  const guild = message.guild;
  const channel = message.channel;
  const userId = message.author.id;

  if (!isChannelActive(guild.id, channel.id)) return;
  
  // Verificar permissão do usuário (admin ou dono)
  const permCheck = checkServerPermission(guild, { id: userId }, message.member);
  
  if (!permCheck.authorized) {
    // Verificar se tem plano ativo
    if (!accountManager.hasActivePlan(userId)) {
      return; // Sem permissão e sem plano
    }
  }

  channel.sendTyping().catch(() => {});

  let thinkingMsg = null;

  try {
    let userContent = message.content;

    if (message.attachments.size > 0) {
      const attachmentsInfo = [];
      for (const attachment of message.attachments.values()) {
        attachmentsInfo.push(`[ANEXO: ${attachment.name}] - ${attachment.url}`);
      }
      userContent += "\n\nANEXOS:\n" + attachmentsInfo.join("\n");
    }

    addUserMessage(channel.id, userContent, message.author.tag);
    const messages = getChannelContext(channel.id);

    // Verificar se há mensagens de contexto
    if (!messages || messages.length === 0) {
      console.error('❌ [IA] Sem contexto de mensagens!');
      return await sendErrorEmbed(message, null, 'Canal não inicializado. Use /ask on primeiro!');
    }

    console.log(`🚀 [IA] Processando: ${userContent.substring(0, 50)}...`);

    const thinkingEmbed = new EmbedBuilder()
      .setTitle('🤔 Processando...')
      .setDescription('Estou trabalhando nisso! ✨')
      .setColor('#FBBF24')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();

    thinkingMsg = await message.reply({ 
      embeds: [thinkingEmbed], 
      allowedMentions: { repliedUser: false } 
    }).catch(() => null);

    let completion;
    try {
      completion = await client.chat.completions.create({
        model: 'stepfun-ai/step-3.5-flash',
        messages: messages,
        temperature: 0.7,
        max_tokens: 16000,  // Aumentado para permitir JSONs grandes (arquivos, etc)
        stream: false
      });
    } catch (apiError) {
      console.error('❌ [IA] Erro API:', apiError.message);
      return await handleFallback(message, thinkingMsg, userContent);
    }

    const content = completion.choices[0]?.message?.content || '';
    
    console.log(`📝 [IA] Resposta (${content.length} chars):`, content.substring(0, 500));
    
    // Log adicional para debug de JSONs grandes
    if (content.length > 1000) {
      console.log(`📝 [IA] Resposta completa (últimos 300 chars): ...${content.substring(content.length - 300)}`);
    }
    
    if (!content || content.trim() === '') {
      console.error('❌ [IA] Resposta vazia!');
      return await handleFallback(message, thinkingMsg, userContent);
    }
    
    const response = parseResponse(content);
    
    // Log do tipo e conteúdo parseado
    console.log(`📋 [Parse] Tipo: ${response.type}, tem conteúdo: ${!!response.content || !!response.embed}`);
    
    addAIMessage(channel.id, content);

    await handleResponse(message, response, guild, channel, thinkingMsg);

  } catch (error) {
    console.error('❌ [Erro]:', error);
    await sendErrorEmbed(message, thinkingMsg, error.message);
  }
}

/**
 * Parse robusto da resposta - MÚLTIPLAS TENTATIVAS COM RECUPERAÇÃO
 */
function parseResponse(content) {
  if (!content) {
    return { type: 'message', content: 'Desculpe, não consegui processar isso.' };
  }
  
  try {
    // 1. Tentar extrair JSON de bloco de código (GREEDY REAL - pegar tudo entre ```)
    const codeBlockMatch = content.match(/```(?:json)?\s*([\s\S]+?)```/);
    if (codeBlockMatch) {
      let jsonStr = codeBlockMatch[1].trim();
      
      // Tentar parse direto primeiro
      try {
        const parsed = JSON.parse(jsonStr);
        if (parsed && parsed.type) {
          console.log(`📦 [Parse] JSON de bloco de código`);
          return parsed;
        }
      } catch (e) {
        console.log(`⚠️ [Parse] Erro no JSON de bloco: ${e.message}`);
        
        // TENTATIVA DE RECUPERAÇÃO: Fechar JSON truncado
        if (e.message.includes('Unexpected end') || e.message.includes('Unexpected token')) {
          console.log(`🔧 [Parse] Tentando recuperar JSON truncado...`);
          
          // Contar chaves, colchetes e parênteses abertos
          const openBraces = (jsonStr.match(/\{/g) || []).length;
          const closeBraces = (jsonStr.match(/\}/g) || []).length;
          const openBrackets = (jsonStr.match(/\[/g) || []).length;
          const closeBrackets = (jsonStr.match(/\]/g) || []).length;
          
          // Fechar o que está aberto
          let recoveredJson = jsonStr;
          
          // Remover último token incompleto (string sem fechar)
          recoveredJson = recoveredJson.replace(/"[^"]*$/g, '"incompleto"');
          
          // Fechar colchetes
          for (let i = 0; i < openBrackets - closeBrackets; i++) {
            recoveredJson += ']';
          }
          
          // Fechar chaves
          for (let i = 0; i < openBraces - closeBraces; i++) {
            recoveredJson += '}';
          }
          
          try {
            const parsed = JSON.parse(recoveredJson);
            if (parsed && parsed.type) {
              console.log(`✅ [Parse] JSON recuperado com sucesso!`);
              return parsed;
            }
          } catch (e2) {
            console.log(`❌ [Parse] Falha na recuperação: ${e2.message}`);
          }
        }
      }
    }
    
    // 2. Tentar encontrar JSON completo no conteúdo (greedy)
    const fullJsonMatch = content.match(/\{[\s\S]*\}/);
    if (fullJsonMatch) {
      try {
        const parsed = JSON.parse(fullJsonMatch[0]);
        if (parsed && parsed.type) {
          console.log(`📦 [Parse] JSON encontrado no conteúdo`);
          return parsed;
        }
      } catch (e) {
        console.log(`⚠️ [Parse] Erro no JSON completo: ${e.message}`);
      }
    }
    
    // 3. Tentar encontrar múltiplos objetos JSON
    const jsonMatches = content.match(/\{[^{}]*\}/g);
    if (jsonMatches) {
      for (const jsonStr of jsonMatches) {
        try {
          const parsed = JSON.parse(jsonStr);
          if (parsed && parsed.type) {
            console.log(`📦 [Parse] JSON simples encontrado`);
            return parsed;
          }
        } catch (e) {}
      }
    }
    
    // 4. Verificar se é um comando específico conhecido (não apenas palavras aleatórias)
    const knownCommands = [
      'gerar_arquivo', 'criar_canal', 'deletar_canal', 'criar_cargo', 
      'deletar_cargo', 'criar_categoria', 'enviar_embed', 'criar_automacao',
      'google_image', 'dalle', 'server_stats', 'listar_canais', 'listar_cargos',
      'banir', 'expulsar', 'mutar', 'info_membro', 'deletar_mensagens',
      'tarefa_complexa', 'complex_task'
    ];
    
    const lowerContent = content.toLowerCase();
    for (const cmd of knownCommands) {
      if (lowerContent.includes(cmd.replace('_', ' ')) || lowerContent.includes(cmd)) {
        console.log(`⚠️ [Parse] Comando conhecido detectado mas sem JSON: ${cmd}`);
        return { 
          type: 'message', 
          content: `Hmm, parece que você quer usar um comando, mas não consegui processar os detalhes! 🌹\n\nTente ser mais específico com os parâmetros necessários.\n\nExemplo: "Crie um canal de texto chamado chat-geral"` 
        };
      }
    }
    
    // 5. Retornar como mensagem simples
    return { type: 'message', content: content };
    
  } catch (e) {
    console.log('⚠️ [Parse] Erro geral:', e.message);
    return { type: 'message', content: content };
  }
}

/**
 * Processa a resposta baseado no tipo
 */
async function handleResponse(message, response, guild, channel, thinkingMsg) {
  const type = response.type?.toLowerCase() || 'message';
  
  console.log(`📋 [Tipo] ${type}`);

  switch (type) {
    // === FERRAMENTAS EXTERNAS ===
    case 'consultar_cnpj':
    case 'consulta_cnpj':
      await handleCNPJ(message, response, thinkingMsg);
      break;
      
    case 'consultar_cpf':
    case 'consulta_cpf':
      await handleCPF(message, response, thinkingMsg);
      break;
      
    case 'buscar_imagens_google':
    case 'google_image':
    case 'busca_imagem':
      await handleImageSearch(message, response, guild, channel, thinkingMsg);
      break;
      
    case 'video_cosplay_anime':
    case 'cosplay_video':
      await handleCosplayVideo(message, thinkingMsg);
      break;
      
    case 'gerar_imagem':
    case 'dalle_nsfw':
    case 'dalle':
      await handleDalle(message, response, thinkingMsg);
      break;
      
    case 'gerar_arquivo':
    case 'generate_file':
      await handleFileGeneration(message, response, thinkingMsg);
      break;

    // === FERRAMENTAS DE CANAIS ===
    case 'criar_canal':
    case 'create_channel':
      await handleCreateChannel(message, response, guild, channel, thinkingMsg);
      break;
      
    case 'editar_canal':
    case 'edit_channel':
      await handleEditChannel(message, response, guild, thinkingMsg);
      break;
      
    case 'deletar_canal':
    case 'delete_channel':
      await handleDeleteChannel(message, response, guild, thinkingMsg);
      break;
      
    case 'clonar_canal':
    case 'clone_channel':
      await handleCloneChannel(message, response, guild, thinkingMsg);
      break;
      
    case 'trancar_canal':
    case 'lock_channel':
      await handleLockChannel(message, response, guild, thinkingMsg);
      break;
      
    case 'esconder_canal':
    case 'hide_channel':
      await handleHideChannel(message, response, guild, thinkingMsg);
      break;
      
    case 'permissao_canal':
    case 'channel_permission':
      await handleChannelPermission(message, response, guild, thinkingMsg);
      break;
      
    case 'criar_categoria':
    case 'create_category':
      await handleCreateCategory(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_canais':
    case 'list_channels':
      await handleListChannels(message, response, guild, thinkingMsg);
      break;

    // === FERRAMENTAS DE CARGOS ===
    case 'criar_cargo':
    case 'create_role':
      await handleCreateRole(message, response, guild, thinkingMsg);
      break;
      
    case 'editar_cargo':
    case 'edit_role':
      await handleEditRole(message, response, guild, thinkingMsg);
      break;
      
    case 'deletar_cargo':
    case 'delete_role':
      await handleDeleteRole(message, response, guild, thinkingMsg);
      break;
      
    case 'clonar_cargo':
    case 'clone_role':
      await handleCloneRole(message, response, guild, thinkingMsg);
      break;
      
    case 'adicionar_cargo':
    case 'add_role':
      await handleAddRole(message, response, guild, thinkingMsg);
      break;
      
    case 'remover_cargo':
    case 'remove_role':
      await handleRemoveRole(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_cargos':
    case 'list_roles':
      await handleListRoles(message, response, guild, thinkingMsg);
      break;

    // === FERRAMENTAS DE MEMBROS ===
    case 'expulsar':
    case 'kick':
      await handleKick(message, response, guild, thinkingMsg);
      break;
      
    case 'banir':
    case 'ban':
      await handleBan(message, response, guild, thinkingMsg);
      break;
      
    case 'desbanir':
    case 'unban':
      await handleUnban(message, response, guild, thinkingMsg);
      break;
      
    case 'mutar':
    case 'mute':
    case 'timeout':
      await handleMute(message, response, guild, thinkingMsg);
      break;
      
    case 'desmutar':
    case 'unmute':
      await handleUnmute(message, response, guild, thinkingMsg);
      break;
      
    case 'apelido':
    case 'nickname':
    case 'set_nickname':
      await handleNickname(message, response, guild, thinkingMsg);
      break;
      
    case 'info_membro':
    case 'member_info':
      await handleMemberInfo(message, response, guild, thinkingMsg);
      break;
      
    case 'membros_cargo':
    case 'members_by_role':
      await handleMembersByRole(message, response, guild, thinkingMsg);
      break;

    // === FERRAMENTAS DE MENSAGENS ===
    case 'deletar_mensagens':
    case 'bulk_delete':
    case 'clear':
      await handleBulkDelete(message, response, guild, channel, thinkingMsg);
      break;
      
    case 'fixar_mensagem':
    case 'pin_message':
      await handlePinMessage(message, response, channel, thinkingMsg);
      break;
      
    case 'desfixar_mensagem':
    case 'unpin_message':
      await handleUnpinMessage(message, response, channel, thinkingMsg);
      break;

    // === FERRAMENTAS DE WEBHOOKS ===
    case 'criar_webhook':
    case 'create_webhook':
      await handleCreateWebhook(message, response, channel, thinkingMsg);
      break;
      
    case 'listar_webhooks':
    case 'list_webhooks':
      await handleListWebhooks(message, channel, thinkingMsg);
      break;
      
    case 'listar_webhooks_servidor':
    case 'list_guild_webhooks':
      await handleListGuildWebhooks(message, guild, thinkingMsg);
      break;
      
    case 'info_webhook':
    case 'get_webhook':
      await handleGetWebhook(message, response, guild, thinkingMsg);
      break;
      
    case 'editar_webhook':
    case 'edit_webhook':
      await handleEditWebhook(message, response, channel, thinkingMsg);
      break;
      
    case 'deletar_webhook':
    case 'delete_webhook':
      await handleDeleteWebhook(message, response, channel, thinkingMsg);
      break;
      
    case 'enviar_webhook':
    case 'send_webhook':
      await handleSendWebhook(message, response, channel, thinkingMsg);
      break;

    // === FERRAMENTAS DE CONVITES ===
    case 'criar_convite':
    case 'create_invite':
      await handleCreateInvite(message, response, channel, thinkingMsg);
      break;
      
    case 'listar_convites':
    case 'list_invites':
      await handleListInvites(message, guild, thinkingMsg);
      break;
      
    case 'deletar_convite':
    case 'delete_invite':
      await handleDeleteInvite(message, response, guild, thinkingMsg);
      break;

    // === FERRAMENTAS DE EMOJIS ===
    case 'adicionar_emoji':
    case 'add_emoji':
      await handleAddEmoji(message, response, guild, thinkingMsg);
      break;
      
    case 'deletar_emoji':
    case 'delete_emoji':
      await handleDeleteEmoji(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_emojis':
    case 'list_emojis':
      await handleListEmojis(message, guild, thinkingMsg);
      break;

    // === SISTEMA DE AUTOMAÇÃO ===
    case 'criar_automacao':
    case 'create_automation':
      await handleCreateAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_automacoes':
    case 'list_automations':
      await handleListAutomations(message, guild, thinkingMsg);
      break;
      
    case 'pausar_automacao':
    case 'pause_automation':
      await handlePauseAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'retomar_automacao':
    case 'resume_automation':
      await handleResumeAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'deletar_automacao':
    case 'delete_automation':
      await handleDeleteAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'editar_automacao':
    case 'edit_automation':
      await handleEditAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'executar_automacao':
    case 'run_automation':
      await handleRunAutomation(message, response, guild, thinkingMsg);
      break;

    // === EVENT AUTOMATION - NOVO SISTEMA ===
    case 'criar_event_automation':
    case 'create_event_automation':
    case 'criar_automacao_evento':
      await handleCreateEventAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_event_automations':
    case 'list_event_automations':
    case 'listar_automacoes_evento':
      await handleListEventAutomations(message, guild, thinkingMsg);
      break;
      
    case 'toggle_event_automation':
    case 'ativar_event_automation':
    case 'pausar_event_automation':
      await handleToggleEventAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'deletar_event_automation':
    case 'delete_event_automation':
      await handleDeleteEventAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'ver_templates_automation':
    case 'automation_templates':
      await handleShowAutomationTemplates(message, thinkingMsg);
      break;
      
    case 'aplicar_template_automation':
    case 'apply_automation_template':
      await handleApplyAutomationTemplate(message, response, guild, thinkingMsg);
      break;

    // === INFORMAÇÕES DO SERVIDOR ===
    case 'server_stats':
    case 'estatisticas':
    case 'info_servidor':
      await handleServerStats(message, guild, thinkingMsg);
      break;

    // === OUTRAS FERRAMENTAS ===
    case 'enviar_embed':
    case 'send_embed':
    case 'embed':
    case 'criar_embed':
    case 'embed_avancado':
      await handleSendEmbed(message, response, guild, channel, thinkingMsg);
      break;
      
    case 'criar_enquete':
    case 'create_poll':
      await handlePoll(message, response, thinkingMsg);
      break;

    // === SISTEMAS V6.0 ===
    case 'config_automod':
    case 'configurar_automod':
      await v6Handlers.handleConfigAutomod(message, response, guild, thinkingMsg);
      break;
      
    case 'ver_automod':
    case 'listar_automod':
      await v6Handlers.handleVerAutomod(message, guild, thinkingMsg);
      break;
      
    case 'desativar_automod':
      await v6Handlers.handleDesativarAutomod(message, response, guild, thinkingMsg);
      break;
      
    case 'advertir':
    case 'avisar':
    case 'warn':
      await v6Handlers.handleAdvertir(message, response, guild, thinkingMsg);
      break;
      
    case 'ver_advertencias':
    case 'ver_warns':
      await v6Handlers.handleVerAdvertencias(message, response, guild, thinkingMsg);
      break;

    case 'config_logs':
    case 'configurar_logs':
      await v6Handlers.handleConfigLogs(message, response, guild, thinkingMsg);
      break;
      
    case 'ver_logs':
    case 'listar_logs':
      await v6Handlers.handleVerLogs(message, guild, thinkingMsg);
      break;
      
    case 'desativar_logs':
      await v6Handlers.handleDesativarLogs(message, guild, thinkingMsg);
      break;
      
    case 'logs_moderacao':
    case 'logs_mod':
      await v6Handlers.handleLogsModeracao(message, response, guild, thinkingMsg);
      break;
      
    case 'exportar_logs':
      await v6Handlers.handleExportarLogs(message, response, guild, thinkingMsg);
      break;

    case 'config_bemvindo':
    case 'config_welcome':
      await v6Handlers.handleConfigBemvindo(message, response, guild, thinkingMsg);
      break;
      
    case 'config_autorole':
      await v6Handlers.handleConfigAutorole(message, response, guild, thinkingMsg);
      break;
      
    case 'config_saida':
    case 'config_goodbye':
      await v6Handlers.handleConfigSaida(message, response, guild, thinkingMsg);
      break;
      
    case 'ver_bemvindo':
      await v6Handlers.handleVerBemvindo(message, guild, thinkingMsg);
      break;
      
    case 'testar_bemvindo':
      await v6Handlers.handleTestarBemvindo(message, guild, thinkingMsg);
      break;

    case 'criar_painel_tickets':
    case 'criar_painel':
      await v6Handlers.handleCriarPainelTickets(message, response, guild, thinkingMsg);
      break;
      
    case 'criar_ticket':
    case 'abrir_ticket':
      await v6Handlers.handleCriarTicket(message, response, guild, thinkingMsg);
      break;
      
    case 'fechar_ticket':
    case 'close_ticket':
      await v6Handlers.handleFecharTicket(message, response, guild, thinkingMsg);
      break;
      
    case 'adicionar_ticket':
    case 'add_ticket':
      await v6Handlers.handleAdicionarTicket(message, response, guild, thinkingMsg);
      break;
      
    case 'remover_ticket':
      await v6Handlers.handleRemoverTicket(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_tickets':
    case 'ver_tickets':
      await v6Handlers.handleListarTickets(message, guild, thinkingMsg);
      break;

    case 'saldo':
    case 'balance':
      await v6Handlers.handleSaldo(message, response, guild, thinkingMsg);
      break;
      
    case 'adicionar_moedas':
    case 'add_coins':
      await v6Handlers.handleAdicionarMoedas(message, response, guild, thinkingMsg);
      break;
      
    case 'transferir':
    case 'pay':
      await v6Handlers.handleTransferir(message, response, guild, thinkingMsg);
      break;
      
    case 'daily':
      await v6Handlers.handleDaily(message, guild, thinkingMsg);
      break;
      
    case 'trabalhar':
    case 'work':
      await v6Handlers.handleTrabalhar(message, guild, thinkingMsg);
      break;
      
    case 'ver_loja':
    case 'shop':
      await v6Handlers.handleVerLoja(message, guild, thinkingMsg);
      break;
      
    case 'criar_item':
    case 'add_item_loja':
      await v6Handlers.handleCriarItem(message, response, guild, thinkingMsg);
      break;
      
    case 'comprar':
    case 'buy':
      await v6Handlers.handleComprar(message, response, guild, thinkingMsg);
      break;
      
    case 'ranking_economia':
    case 'leaderboard':
      await v6Handlers.handleRankingEconomia(message, guild, thinkingMsg);
      break;

    case 'criar_giveaway':
    case 'sorteio':
      await v6Handlers.handleCriarGiveaway(message, response, guild, thinkingMsg);
      break;
      
    case 'encerrar_giveaway':
    case 'end_giveaway':
      await v6Handlers.handleEncerrarGiveaway(message, response, guild, thinkingMsg);
      break;
      
    case 'rerolar_giveaway':
    case 'reroll':
      await v6Handlers.handleRerolarGiveaway(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_giveaways':
      await v6Handlers.handleListarGiveaways(message, guild, thinkingMsg);
      break;

    case '8ball':
    case 'bola_magica':
      await v6Handlers.handle8ball(message, response, thinkingMsg);
      break;
      
    case 'roleta_russa':
      await v6Handlers.handleRoletaRussa(message, guild, thinkingMsg);
      break;
      
    case 'rps':
    case 'pedra_papel_tesoura':
      await v6Handlers.handleRPS(message, response, thinkingMsg);
      break;
      
    case 'casar':
    case 'marry':
      await v6Handlers.handleCasar(message, response, guild, thinkingMsg);
      break;
      
    case 'divorciar':
    case 'divorce':
      await v6Handlers.handleDivorciar(message, guild, thinkingMsg);
      break;
      
    case 'ship':
      await v6Handlers.handleShip(message, response, guild, thinkingMsg);
      break;
      
    case 'meme':
      await v6Handlers.handleMeme(message, thinkingMsg);
      break;
      
    case 'piada':
    case 'joke':
      await v6Handlers.handlePiada(message, thinkingMsg);
      break;
      
    case 'verdade_desafio':
    case 'truth_dare':
      await v6Handlers.handleVerdadeDesafio(message, response, thinkingMsg);
      break;

    case 'clima':
    case 'weather':
      await v6Handlers.handleClima(message, response, thinkingMsg);
      break;
      
    case 'traduzir':
    case 'translate':
      await v6Handlers.handleTraduzir(message, response, thinkingMsg);
      break;
      
    case 'wiki':
    case 'wikipedia':
      await v6Handlers.handleWiki(message, response, thinkingMsg);
      break;
      
    case 'filme':
    case 'movie':
      await v6Handlers.handleFilme(message, response, thinkingMsg);
      break;
      
    case 'crypto':
    case 'cripto':
      await v6Handlers.handleCrypto(message, response, thinkingMsg);
      break;
      
    case 'qrcode':
      await v6Handlers.handleQRCode(message, response, thinkingMsg);
      break;

    case 'nivel':
    case 'level':
    case 'rank':
      await v6Handlers.handleNivel(message, response, guild, thinkingMsg);
      break;
      
    case 'adicionar_xp':
    case 'add_xp':
      await v6Handlers.handleAdicionarXP(message, response, guild, thinkingMsg);
      break;
      
    case 'ranking_nivel':
    case 'ranking_level':
      await v6Handlers.handleRankingNivel(message, guild, thinkingMsg);
      break;
      
    case 'recompensa_nivel':
      await v6Handlers.handleRecompensaNivel(message, response, guild, thinkingMsg);
      break;

    // === SISTEMA DE AVISOS (WARN) ===
    case 'warn':
    case 'avisar':
    case 'advertir':
      await handleWarn(message, response, guild, thinkingMsg);
      break;
      
    case 'unwarn':
    case 'remover_aviso':
    case 'remover_warn':
      await handleUnwarn(message, response, guild, thinkingMsg);
      break;
      
    case 'ver_avisos':
    case 'ver_warns':
    case 'listar_avisos':
      await handleListWarns(message, response, guild, thinkingMsg);
      break;
      
    case 'limpar_avisos':
    case 'clear_warns':
      await handleClearWarns(message, response, guild, thinkingMsg);
      break;

    // === SISTEMA DE TEMPLATES DE EMBED ===
    case 'salvar_template':
    case 'save_template':
      await handleSaveTemplate(message, response, guild, thinkingMsg);
      break;
      
    case 'usar_template':
    case 'use_template':
      await handleUseTemplate(message, response, guild, channel, thinkingMsg);
      break;
      
    case 'listar_templates':
    case 'list_templates':
      await handleListTemplates(message, thinkingMsg);
      break;
      
    case 'deletar_template':
    case 'delete_template':
      await handleDeleteTemplate(message, response, thinkingMsg);
      break;

    // === SISTEMA DE CONFIGURAÇÃO DE LOGS ===
    case 'configurar_log':
    case 'set_log_channel':
    case 'definir_log':
      await handleConfigLog(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_logs':
    case 'ver_logs':
      await handleListLogTypes(message, guild, thinkingMsg);
      break;
      
    case 'limpar_logs':
    case 'clear_logs_config':
      await handleClearLogsConfig(message, response, guild, thinkingMsg);
      break;

    // === TAREFA COMPLEXA - CORRIGIDO ===
    case 'complex_task':
    case 'tarefa_complexa':
      await handleComplexTask(message, response, guild, channel, thinkingMsg);
      break;

    // === MENSAGEM SIMPLES ===
    case 'message':
    default:
      await handleMessage(message, response, thinkingMsg);
  }
}

// ============================================
// FUNÇÕES AUXILIARES
// ============================================

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function editEmbed(thinkingMsg, titleOrEmbed, description, color) {
  if (!thinkingMsg) return;
  
  try {
    if (typeof titleOrEmbed === 'object' && titleOrEmbed.constructor?.name === 'EmbedBuilder') {
      await thinkingMsg.edit({ embeds: [titleOrEmbed] });
    } else {
      const embed = new EmbedBuilder()
        .setTitle(titleOrEmbed)
        .setDescription((description || '').trim() || 'Sem descrição')
        .setColor(color || '#8B5CF6')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      await thinkingMsg.edit({ embeds: [embed] });
    }
  } catch (e) {
    console.error('Erro ao editar embed:', e.message);
  }
}

async function sendErrorEmbed(message, thinkingMsg, errorText) {
  const embed = new EmbedBuilder()
    .setTitle('❌ Erro!')
    .setDescription(errorText || 'Ocorreu um erro desconhecido')
    .setColor('#EF4444')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  if (thinkingMsg) {
    await editEmbed(thinkingMsg, embed);
  } else {
    await message.reply({ embeds: [embed], allowedMentions: { repliedUser: false } });
  }
}

async function handleFallback(message, thinkingMsg, userContent) {
  const embed = new EmbedBuilder()
    .setTitle('⚠️ Modo Fallback')
    .setDescription('Tive problemas para processar sua solicitação. Pode tentar novamente? 💖')
    .setColor('#F59E0B')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
}

// ============================================
// FERRAMENTAS EXTERNAS - CPF/CNPJ
// ============================================

async function handleCNPJ(message, response, thinkingMsg) {
  const cnpj = response.cnpj || response.value || response.cnpj_number;
  if (!cnpj) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'CNPJ não informado!', '#EF4444');
  }
  
  const result = await apiService.consultaCNPJ(cnpj);
  
  if (result.status === 'success' || result.data) {
    const data = result.data || result;
    
    const embed = new EmbedBuilder()
      .setTitle('📋 Consulta CNPJ - Resultado')
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    if (data.razao_social || data['RAZÃO SOCIAL']) {
      embed.setDescription(`**${data.razao_social || data['RAZÃO SOCIAL']}**`);
    }
    
    const fields = [];
    const campos = {
      'Razão Social': data.razao_social || data['RAZÃO SOCIAL'],
      'Nome Fantasia': data.nome_fantasia || data['NOME FANTASIA'],
      'CNPJ': data.cnpj || data['CNPJ'] || cnpj,
      'Situação': data.situacao || data['SITUAÇÃO'],
      'Data Abertura': data.abertura || data.data_abertura || data['ABERTURA'],
      'Atividade Principal': data.atividade_principal?.[0]?.text || data['ATIVIDADE PRINCIPAL'],
      'Município': data.municipio || data['MUNICÍPIO'],
      'UF': data.uf || data['UF'],
      'Email': data.email || data['EMAIL'],
      'Telefone': data.telefone || data['TELEFONE']
    };
    
    for (const [name, value] of Object.entries(campos)) {
      if (value && value !== 'null' && value !== '') {
        fields.push({ name: `📝 ${name}`, value: String(value).substring(0, 500), inline: true });
      }
    }
    
    embed.addFields(fields.slice(0, 25));
    await editEmbed(thinkingMsg, embed);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', result.error || 'CNPJ não encontrado', '#EF4444');
  }
}

async function handleCPF(message, response, thinkingMsg) {
  const cpf = response.cpf || response.value;
  if (!cpf) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'CPF não informado!', '#EF4444');
  }
  
  const result = await apiService.consultaCPF(cpf);
  
  if (result.status === 'success' || result.nome || result.data) {
    const data = result.data || result;
    
    const embed = new EmbedBuilder()
      .setTitle('👤 Consulta CPF - Resultado')
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    if (result.nome || data.nome || data.NOME) {
      embed.setDescription(`**${result.nome || data.nome || data.NOME}**`);
    }
    
    const fields = [];
    const campos = {
      'Nome': result.nome || data.nome || data.NOME,
      'CPF': data.cpf || data.CPF || cpf,
      'Data de Nascimento': result.data_nascimento || data.data_nascimento,
      'Nome da Mãe': result.nome_mae || data.nome_mae,
      'Cidade': data.cidade || data.municipio,
      'UF': data.uf || data.UF
    };
    
    for (const [name, value] of Object.entries(campos)) {
      if (value && value !== 'null' && value !== '') {
        fields.push({ name: `📝 ${name}`, value: String(value).substring(0, 500), inline: true });
      }
    }
    
    embed.addFields(fields.slice(0, 25));
    await editEmbed(thinkingMsg, embed);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', result.error || 'CPF não encontrado', '#EF4444');
  }
}

// ============================================
// BUSCA DE IMAGENS - CORRIGIDO
// ============================================

async function handleImageSearch(message, response, guild, currentChannel, thinkingMsg) {
  const query = response.query || response.termo || response.busca;
  const quantidade = Math.min(response.quantidade || response.amount || 5, 20);
  const canalDestino = response.canal_destino || response.targetChannel;
  
  if (!query) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'Termo de busca não informado!', '#EF4444');
  }
  
  // Determinar canal de destino
  let targetChannel = currentChannel;
  
  if (canalDestino === 'auto' && global.lastCreatedChannel) {
    targetChannel = global.lastCreatedChannel;
  } else if (canalDestino && canalDestino !== 'auto') {
    const found = guild.channels.cache.find(c => 
      c.name.toLowerCase().includes(canalDestino.toLowerCase()) || c.id === canalDestino
    );
    if (found) targetChannel = found;
  }
  
  console.log(`🖼️ [ImageSearch] Buscando ${quantidade} imagens de: ${query}`);
  console.log(`🖼️ [ImageSearch] Canal de destino: ${targetChannel.name}`);
  
  const result = await apiService.searchGoogleImage(query);
  
  if (result.success && result.data?.result?.length > 0) {
    // ✅ CORREÇÃO: Remover duplicatas usando Set de URLs
    const seenUrls = new Set();
    const uniqueImages = [];
    
    // Pegar mais imagens para compensar possíveis duplicatas
    const allImages = result.data.result.slice(0, Math.min(quantidade * 2, 40));
    
    for (const img of allImages) {
      if (img?.url && !seenUrls.has(img.url)) {
        seenUrls.add(img.url);
        uniqueImages.push(img);
        
        // Parar quando tiver a quantidade desejada
        if (uniqueImages.length >= quantidade) break;
      }
    }
    
    const images = uniqueImages;
    
    if (images.length === 0) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'Nenhuma imagem válida encontrada', '#EF4444');
    }
    
    const embed = new EmbedBuilder()
      .setTitle('🖼️ Imagens Encontradas!')
      .setDescription(`Busca: **${query}**\n\n✨ Encontrei **${images.length}** imagem(ns) única(s)! Enviando em ${targetChannel}...`)
      .setColor('#8B5CF6')
      .setFooter({ text: `💎 Rias-Grimory-X | ${images.length} imagens` })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    // Enviar imagens com numeração correta
    for (let i = 0; i < images.length; i++) {
      if (images[i]?.url) {
        const numEmbed = new EmbedBuilder()
          .setTitle(`🖼️ Imagem ${i + 1}/${images.length}`)
          .setDescription(`**${query}**`)
          .setImage(images[i].url)
          .setColor('#8B5CF6')
          .setFooter({ text: '💎 Rias-Grimory-X' })
          .setTimestamp();
        
        await targetChannel.send({ embeds: [numEmbed] }).catch(e => {
          console.error(`Erro ao enviar imagem ${i + 1}:`, e.message);
        });
        
        await sleep(500); // Delay entre envios
      }
    }
    
    console.log(`✅ [ImageSearch] ${images.length} imagens únicas enviadas para ${targetChannel.name}`);
    
    // 🌹 Enviar mensagem personalizada da Rias no final
    await sendRiasFollowUp(targetChannel, 'google_image', true);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', 'Nenhuma imagem encontrada', '#EF4444');
    // 🌹 Enviar mensagem de erro da Rias
    await sendRiasFollowUp(currentChannel, 'google_image', false);
  }
}

async function handleCosplayVideo(message, thinkingMsg) {
  const result = await apiService.getCosplayVideo();
  
  if (result.status === 'success' && result.media?.url) {
    const embed = new EmbedBuilder()
      .setTitle('🎬 Vídeo de Cosplay!')
      .setDescription(`Aqui está seu vídeo! ✨🔥\n\n[▶️ Assistir Vídeo](${result.media.url})`)
      .setColor('#EC4899')
      .setFooter({ text: `Por: ${result.author || 'Cosplay'}` })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', 'Não foi possível obter o vídeo', '#EF4444');
  }
}

async function handleDalle(message, response, thinkingMsg) {
  const prompt = response.prompt || response.descricao;
  if (!prompt) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'Descrição não informada!', '#EF4444');
  }
  
  const result = await apiService.dalleXlloraText2image(prompt, response.negative || 'low quality');
  
  if (result.success && result.data?.result) {
    const embed = new EmbedBuilder()
      .setTitle('🎨 Imagem Gerada!')
      .setDescription(`Prompt: **${prompt.substring(0, 100)}**\n\nAqui está sua arte! ✨`)
      .setImage(result.data.result)
      .setColor('#F59E0B')
      .setFooter({ text: '💎 Rias-Grimory-X - Dalle' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    // 🌹 Enviar mensagem personalizada da Rias no final
    await sendRiasFollowUp(message.channel, 'dalle', true);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', result.error || 'Falha ao gerar imagem', '#EF4444');
    await sendRiasFollowUp(message.channel, 'dalle', false);
  }
}

async function handleFileGeneration(message, response, thinkingMsg) {
  const fileType = (response.fileType || response.tipo || 'txt').toLowerCase();
  let filename = response.filename || response.nome || `arquivo.${fileType}`;
  const content = response.content || response.conteudo;
  const targetChannelName = response.canal || response.channel;
  
  // Garantir que o filename tenha a extensão correta
  const extensions = { 'txt': '.txt', 'md': '.md', 'markdown': '.md', 'pdf': '.pdf' };
  const ext = extensions[fileType] || '.txt';
  if (!filename.toLowerCase().endsWith(ext)) {
    filename = filename + ext;
  }
  
  if (!content) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'Conteúdo não informado!', '#EF4444');
  }
  
  console.log(`📄 [Arquivo] Gerando: ${filename} (${fileType}, ${content.length} chars)`);
  
  try {
    let filePath;
    if (fileType === 'pdf') {
      filePath = await apiService.generatePDF(filename, content);
    } else {
      // txt, md, markdown todos usam generateTextFile
      filePath = await apiService.generateTextFile(filename, content);
    }
    
    // Verificar se o arquivo foi criado
    if (!filePath) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'Falha ao criar arquivo!', '#EF4444');
    }
    
    console.log(`✅ [Arquivo] Criado: ${filePath}`);
    
    // Tentar fazer upload, mas não é obrigatório
    let uploadResult = { success: false };
    try {
      uploadResult = await apiService.uploadFile(filePath);
      console.log(`📤 [Upload]: ${uploadResult.success ? 'Sucesso' : 'Falhou'}`);
    } catch (uploadError) {
      console.log(`⚠️ [Arquivo] Upload falhou, enviando direto: ${uploadError.message}`);
    }
    
    // Determinar canal de destino
    let targetChannel = message.channel;
    if (targetChannelName && message.guild) {
      const found = message.guild.channels.cache.find(c => 
        c.name.toLowerCase().includes(targetChannelName.toLowerCase()) || 
        c.id === targetChannelName
      );
      if (found) targetChannel = found;
    }
    
    const embed = new EmbedBuilder()
      .setTitle('📄 Arquivo Criado!')
      .setDescription(`✅ Seu arquivo **${filename}** está pronto!\n\n${uploadResult.success ? `📥 [Download](${uploadResult.url})` : 'Arquivo anexado abaixo!'}`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    // Enviar arquivo SEMPRE como anexo
    if (targetChannel.id !== message.channel.id) {
      // Enviar para canal diferente
      await targetChannel.send({ embeds: [embed], files: [filePath] });
      await editEmbed(thinkingMsg, '✅ Arquivo Enviado!', `Arquivo enviado para ${targetChannel}!`, '#10B981');
    } else {
      // Enviar no mesmo canal
      if (thinkingMsg) {
        await thinkingMsg.edit({ embeds: [embed], files: [filePath] }).catch(async () => {
          await message.channel.send({ embeds: [embed], files: [filePath] });
        });
      } else {
        await message.channel.send({ embeds: [embed], files: [filePath] });
      }
    }
    
    console.log(`✅ [Arquivo] Enviado para: ${targetChannel.name}`);
    
  } catch (error) {
    console.error('❌ [Arquivo] Erro:', error);
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao criar arquivo: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE CANAIS - CORRIGIDO
// ============================================

async function handleCreateChannel(message, response, guild, currentChannel, thinkingMsg) {
  try {
    // Verificar se há categoria para passar como parent
    let parentId = null;
    const categoriaNome = response.categoria || response.parent || response.parentId;
    
    if (categoriaNome) {
      // Buscar categoria por nome ou ID
      const category = guild.channels.cache.find(c => 
        c.type === ChannelType.GuildCategory && 
        (c.name.toLowerCase() === categoriaNome.toLowerCase() || 
         c.name.toLowerCase().includes(categoriaNome.toLowerCase()) ||
         c.id === categoriaNome)
      );
      
      if (category) {
        parentId = category.id;
        console.log(`📁 [CreateChannel] Categoria encontrada: ${category.name} (${category.id})`);
      } else {
        console.log(`⚠️ [CreateChannel] Categoria não encontrada: ${categoriaNome}`);
      }
    }
    
    const result = await serverTools.createChannel(guild, {
      name: response.name || response.nome,
      type: response.tipo || response.channelType || 'texto',
      parent: parentId, // Passar o ID da categoria
      topic: response.topico || response.topic,
      slowmode: response.slowmode,
      nsfw: response.nsfw,
      bitrate: response.bitrate,
      userLimit: response.userLimit || response.limite_usuarios,
      permissions: response.permissoes || response.permissions
    });
    
    // Armazenar o canal criado globalmente para tarefas complexas
    global.lastCreatedChannel = result.discordChannel;
    global.lastCreatedChannelId = result.channel.id;
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Canal Criado!')
      .setDescription(`Canal ${result.channel.mention} criado com sucesso! 🎉`)
      .addFields(
        { name: '📝 Nome', value: result.channel.name, inline: true },
        { name: '📁 Tipo', value: result.channel.type, inline: true },
        { name: '🆔 ID', value: result.channel.id, inline: true }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    // 🌹 Enviar mensagem personalizada da Rias no final
    await sendRiasFollowUp(message.channel, 'criar_canal', true);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao criar canal: ${error.message}`, '#EF4444');
    await sendRiasFollowUp(message.channel, 'criar_canal', false);
  }
}

async function handleEditChannel(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.editChannel(guild, {
      channel: response.canal || response.channel || response.channelId,
      name: response.nome || response.name,
      topic: response.topico || response.topic,
      slowmode: response.slowmode,
      nsfw: response.nsfw,
      bitrate: response.bitrate,
      userLimit: response.userLimit || response.limite_usuarios,
      position: response.posicao || response.position
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Canal Editado!')
      .setDescription(`Canal **${result.channel.name}** foi atualizado! 🎉`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao editar canal: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteChannel(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.deleteChannel(
      guild, 
      response.canal || response.channel || response.channelId || response.nome || response.name
    );
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Canal Deletado!')
      .setDescription(`Canal **#${result.name}** foi deletado! 🗑️`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao deletar canal: ${error.message}`, '#EF4444');
  }
}

async function handleCloneChannel(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.cloneChannel(
      guild, 
      response.canal || response.channel || response.channelId,
      response.novo_nome || response.newName
    );
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Canal Clonado!')
      .setDescription(`Canal **#${result.original}** foi clonado!`)
      .addFields({ name: '📝 Novo Canal', value: result.cloned.mention, inline: true })
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao clonar canal: ${error.message}`, '#EF4444');
  }
}

async function handleLockChannel(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.lockChannel(
      guild, 
      response.canal || response.channel || response.channelId,
      response.trancar !== false && response.lock !== false
    );
    
    const embed = new EmbedBuilder()
      .setTitle(result.locked ? '🔒 Canal Trancado!' : '🔓 Canal Destrancado!')
      .setDescription(`Canal **${result.channel}** foi ${result.locked ? 'trancado' : 'destrancado'}!`)
      .setColor(result.locked ? '#F59E0B' : '#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleHideChannel(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.hideChannelFromRole(guild, {
      channel: response.canal || response.channel,
      role: response.cargo || response.role,
      hidden: response.esconder !== false && response.hidden !== false
    });
    
    const embed = new EmbedBuilder()
      .setTitle(result.hidden ? '🙈 Canal Escondido!' : '👁️ Canal Visível!')
      .setDescription(`Canal **${result.channel}** ${result.hidden ? 'escondido de' : 'visível para'} **@${result.role}**!`)
      .setColor(result.hidden ? '#F59E0B' : '#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleChannelPermission(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.setChannelPermissions(guild, {
      channel: response.canal || response.channel,
      role: response.cargo || response.role,
      allow: response.permitir || response.allow || [],
      deny: response.negar || response.deny || []
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Permissões Atualizadas!')
      .setDescription(`Permissões de **@${result.role}** no canal **${result.channel}** foram atualizadas!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// CRIAR CATEGORIA - CORRIGIDO
// ============================================

async function handleCreateCategory(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.createCategory(guild, {
      name: response.nome || response.name,
      channels: response.canais || response.channels || [],
      permissions: response.permissoes || response.permissions || []
    });
    
    // Armazenar a categoria criada globalmente para tarefas complexas
    global.lastCreatedCategory = result.category;
    global.lastCreatedCategoryId = result.category.id;
    global.lastCreatedCategoryName = result.category.name; // Nome para matching parcial
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Categoria Criada!')
      .setDescription(`Categoria ${result.category.mention} criada! 🎉`)
      .addFields(
        { name: '📝 Nome', value: result.category.name, inline: true },
        { name: '🆔 ID', value: result.category.id, inline: true },
        { name: '📁 Canais Criados', value: result.channels.length > 0 ? result.channels.join(', ') : 'Nenhum', inline: false }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    // 🌹 Enviar mensagem personalizada da Rias no final
    await sendRiasFollowUp(message.channel, 'criar_categoria', true);
    
    console.log(`✅ [CreateCategory] Categoria criada: ${result.category.name} (${result.category.id})`);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao criar categoria: ${error.message}`, '#EF4444');
    await sendRiasFollowUp(message.channel, 'criar_categoria', false);
  }
}

async function handleListChannels(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.listChannels(guild, response.tipo || response.type || 'all');
    
    const channelList = result.channels.slice(0, 20).map(c => 
      `• ${c.type === 'categoria' ? '📁' : c.type === 'voz' ? '🔊' : '💬'} **${c.name}**`
    ).join('\n');
    
    const embed = new EmbedBuilder()
      .setTitle('📁 Canais do Servidor')
      .setDescription(channelList || 'Nenhum canal encontrado')
      .addFields({ name: '📊 Total', value: `${result.channels.length} canais`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE CARGOS
// ============================================

async function handleCreateRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.createRole(guild, {
      name: response.nome || response.name,
      color: response.cor || response.color,
      permissions: response.permissoes || response.permissions || [],
      hoist: response.separado || response.hoist,
      mentionable: response.mencionavel || response.mentionable
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Criado!')
      .setDescription(`Cargo ${result.role.mention} criado com sucesso! 🎉`)
      .addFields(
        { name: '📝 Nome', value: result.role.name, inline: true },
        { name: '🎨 Cor', value: result.role.color || 'Padrão', inline: true }
      )
      .setColor(result.role.color || '#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    // 🌹 Enviar mensagem personalizada da Rias no final
    await sendRiasFollowUp(message.channel, 'criar_cargo', true);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao criar cargo: ${error.message}`, '#EF4444');
    await sendRiasFollowUp(message.channel, 'criar_cargo', false);
  }
}

async function handleEditRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.editRole(guild, {
      role: response.cargo || response.role || response.roleId,
      name: response.nome || response.name,
      color: response.cor || response.color,
      permissions: response.permissoes || response.permissions,
      hoist: response.separado || response.hoist,
      mentionable: response.mencionavel || response.mentionable
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Editado!')
      .setDescription(`Cargo **${result.role.name}** foi atualizado!`)
      .setColor(result.role.color || '#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.deleteRole(
      guild, 
      response.cargo || response.role || response.roleId || response.nome || response.name
    );
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Deletado!')
      .setDescription(`Cargo **@${result.name}** foi deletado! 🗑️`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleCloneRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.cloneRole(
      guild, 
      response.cargo || response.role || response.roleId,
      response.novo_nome || response.newName
    );
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Clonado!')
      .setDescription(`Cargo **@${result.original}** foi clonado!`)
      .addFields({ name: '📝 Novo Cargo', value: result.cloned.mention, inline: true })
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleAddRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.addRoleToMember(guild, {
      member: response.membro || response.member || response.userId,
      role: response.cargo || response.role,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Adicionado!')
      .setDescription(`Cargo **@${result.role}** adicionado a **${result.member}**!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleRemoveRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.removeRoleFromMember(guild, {
      member: response.membro || response.member || response.userId,
      role: response.cargo || response.role,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Removido!')
      .setDescription(`Cargo **@${result.role}** removido de **${result.member}**!`)
      .setColor('#F59E0B')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListRoles(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.listRoles(guild);
    
    const roleList = result.roles.slice(0, 20).map(r => 
      `• <@&${r.id}> (${r.members} membros)`
    ).join('\n');
    
    const embed = new EmbedBuilder()
      .setTitle('🎭 Cargos do Servidor')
      .setDescription(roleList || 'Nenhum cargo encontrado')
      .addFields({ name: '📊 Total', value: `${result.roles.length} cargos`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE MEMBROS
// ============================================

async function handleKick(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.kickMember(guild, {
      member: response.membro || response.member || response.userId,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('👢 Membro Expulso!')
      .setDescription(`**${result.tag}** foi expulso do servidor!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleBan(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.banMember(guild, {
      member: response.membro || response.member || response.userId,
      reason: response.motivo || response.reason,
      deleteMessageDays: response.deletar_dias || response.deleteMessageDays || 1
    });
    
    const embed = new EmbedBuilder()
      .setTitle('🔨 Membro Banido!')
      .setDescription(`**${result.tag}** foi banido do servidor!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleUnban(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.unbanMember(guild, {
      userId: response.usuario || response.userId || response.user,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Membro Desbanido!')
      .setDescription(`Usuário **${result.userId}** foi desbanido!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleMute(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.muteMember(guild, {
      member: response.membro || response.member || response.userId,
      duration: response.duracao || response.duration || 60,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('🔇 Membro Mutado!')
      .setDescription(`**${result.tag}** foi mutado por **${result.duration}**!`)
      .setColor('#F59E0B')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleUnmute(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.unmuteMember(guild, {
      member: response.membro || response.member || response.userId,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('🔊 Membro Desmutado!')
      .setDescription(`**${result.tag}** foi desmutado!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleNickname(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.setNickname(guild, {
      member: response.membro || response.member || response.userId,
      nickname: response.apelido || response.nickname,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✏️ Apelido Alterado!')
      .setDescription(`Apelido de **${result.tag}** alterado para **${result.newNickname || 'Sem apelido'}**!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleMemberInfo(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.getMemberInfo(
      guild, 
      response.membro || response.member || response.userId
    );
    
    const m = result.member;
    
    const embed = new EmbedBuilder()
      .setTitle(`👤 Info: ${m.tag}`)
      .setDescription(`${m.isOwner ? '👑 **DONO DO SERVIDOR**' : ''}`)
      .addFields(
        { name: '🆔 ID', value: m.id, inline: true },
        { name: '📝 Apelido', value: m.nickname || 'Nenhum', inline: true },
        { name: '📅 Entrou em', value: `<t:${Math.floor(new Date(m.joinedAt) / 1000)}:d>`, inline: true },
        { name: '🎭 Cargos', value: m.roles.slice(0, 10).join(', ') || 'Nenhum', inline: false },
        { name: '🤖 Bot', value: m.isBot ? 'Sim' : 'Não', inline: true }
      )
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleMembersByRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.listMembersByRole(
      guild, 
      response.cargo || response.role,
      response.limite || response.limit || 20
    );
    
    const memberList = result.members.map(m => 
      `• **${m.tag}** ${m.nickname ? `(${m.nickname})` : ''}`
    ).join('\n');
    
    const embed = new EmbedBuilder()
      .setTitle(`👥 Membros com @${result.role}`)
      .setDescription(memberList || 'Nenhum membro encontrado')
      .addFields({ name: '📊 Total', value: `${result.count} membros`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE MENSAGENS
// ============================================

async function handleBulkDelete(message, response, guild, channel, thinkingMsg) {
  try {
    const result = await serverTools.bulkDeleteMessages(channel, {
      amount: response.quantidade || response.amount || 10,
      userId: response.usuario || response.userId
    });
    
    const embed = new EmbedBuilder()
      .setTitle('🗑️ Mensagens Deletadas!')
      .setDescription(`**${result.deleted}** mensagens foram deletadas!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handlePinMessage(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.pinMessage(
      channel, 
      response.messageId || response.mensagem
    );
    
    const embed = new EmbedBuilder()
      .setTitle('📌 Mensagem Fixada!')
      .setDescription(`[Mensagem](${result.url}) foi fixada!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleUnpinMessage(message, response, channel, thinkingMsg) {
  try {
    await serverTools.unpinMessage(
      channel, 
      response.messageId || response.mensagem
    );
    
    const embed = new EmbedBuilder()
      .setTitle('📌 Mensagem Desfixada!')
      .setDescription('Mensagem foi desfixada!')
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE WEBHOOKS
// ============================================

async function handleCreateWebhook(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.createWebhook(channel, {
      name: response.nome || response.name || 'Rias-Grimory-X Webhook',
      avatar: response.avatar
    });
    
    const w = result.webhook;
    
    const embed = new EmbedBuilder()
      .setTitle('🪝 Webhook Criado!')
      .setDescription(`Webhook **${w.name}** criado com sucesso!`)
      .addFields(
        { name: '🆔 ID', value: w.id, inline: true },
        { name: '📝 Nome', value: w.name, inline: true },
        { name: '📺 Canal', value: w.channel, inline: true },
        { name: '🔗 URL Completa', value: `\`${w.url}\``, inline: false },
        { name: '🔑 Token', value: `\`${w.token}\``, inline: false }
      )
      .setColor('#10B981')
      .setFooter({ text: '⚠️ Guarde a URL com segurança! | 💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListWebhooks(message, channel, thinkingMsg) {
  try {
    const result = await serverTools.listWebhooks(channel);
    
    if (result.webhooks.length === 0) {
      const embed = new EmbedBuilder()
        .setTitle('🪝 Webhooks do Canal')
        .setDescription('Nenhum webhook encontrado neste canal.')
        .setColor('#8B5CF6')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      
      return await editEmbed(thinkingMsg, embed);
    }
    
    const webhookList = result.webhooks.map(w => {
      let desc = `**${w.name}** (ID: ${w.id})\n`;
      desc += `📺 Canal: ${w.channel}\n`;
      if (w.url) desc += `🔗 URL: \`${w.url}\`\n`;
      if (w.owner) desc += `👤 Dono: ${w.owner}`;
      return desc;
    }).join('\n\n');
    
    const embed = new EmbedBuilder()
      .setTitle('🪝 Webhooks do Canal')
      .setDescription(webhookList.substring(0, 2000))
      .addFields({ name: '📊 Total', value: `${result.count} webhook(s)`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListGuildWebhooks(message, guild, thinkingMsg) {
  try {
    const result = await serverTools.listGuildWebhooks(guild);
    
    if (result.webhooks.length === 0) {
      const embed = new EmbedBuilder()
        .setTitle('🪝 Webhooks do Servidor')
        .setDescription('Nenhum webhook encontrado no servidor.')
        .setColor('#8B5CF6')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      
      return await editEmbed(thinkingMsg, embed);
    }
    
    const webhookList = result.webhooks.slice(0, 10).map(w => {
      let desc = `**${w.name}** (ID: ${w.id})\n`;
      desc += `📺 Canal: ${w.channel}\n`;
      if (w.url) desc += `🔗 \`${w.url}\`\n`;
      if (w.owner) desc += `👤 ${w.owner}`;
      return desc;
    }).join('\n\n');
    
    const embed = new EmbedBuilder()
      .setTitle('🪝 Webhooks do Servidor')
      .setDescription(webhookList.substring(0, 2000))
      .addFields({ name: '📊 Total', value: `${result.count} webhook(s)`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleGetWebhook(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.getWebhook(
      guild, 
      response.webhookId || response.webhook || response.id
    );
    
    const w = result.webhook;
    
    const embed = new EmbedBuilder()
      .setTitle('🪝 Informações do Webhook')
      .addFields(
        { name: '🆔 ID', value: w.id, inline: true },
        { name: '📝 Nome', value: w.name, inline: true },
        { name: '📺 Canal', value: w.channel, inline: true },
        { name: '🔗 URL', value: w.url ? `\`${w.url}\`` : 'Indisponível', inline: false },
        { name: '🔑 Token', value: w.token ? `\`${w.token}\`` : 'Indisponível', inline: false },
        { name: '👤 Dono', value: w.owner || 'Desconhecido', inline: true }
      )
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleEditWebhook(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.editWebhook(channel, {
      webhookId: response.webhookId || response.webhook,
      name: response.nome || response.name,
      avatar: response.avatar
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Webhook Editado!')
      .setDescription(`Webhook **${result.webhook.name}** foi atualizado!`)
      .addFields({ name: '🔗 URL', value: result.webhook.url ? `\`${result.webhook.url}\`` : 'Indisponível' })
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteWebhook(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.deleteWebhook(
      channel, 
      response.webhookId || response.webhook
    );
    
    const embed = new EmbedBuilder()
      .setTitle('🗑️ Webhook Deletado!')
      .setDescription(`Webhook **${result.name}** foi deletado!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleSendWebhook(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.sendWebhookMessage(channel, {
      webhookId: response.webhookId || response.webhook,
      content: response.content || response.conteudo,
      username: response.username || response.nome,
      avatarURL: response.avatarURL || response.avatar,
      embeds: response.embeds
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Mensagem Enviada!')
      .setDescription('Mensagem enviada via webhook com sucesso!')
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE CONVITES
// ============================================

async function handleCreateInvite(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.createInvite(channel, {
      maxAge: response.maxAge || response.tempo || 86400,
      maxUses: response.maxUses || response.usos || 0,
      temporary: response.temporary || response.temporario || false,
      unique: response.unique || response.unico || false
    });
    
    const embed = new EmbedBuilder()
      .setTitle('📨 Convite Criado!')
      .setDescription(`**${result.invite.url}**`)
      .addFields({ name: '🔑 Código', value: result.invite.code, inline: true })
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListInvites(message, guild, thinkingMsg) {
  try {
    const result = await serverTools.listInvites(guild);
    
    const inviteList = result.invites.slice(0, 15).map(i => 
      `• **${i.code}** - ${i.channel} (${i.uses}/${i.maxUses || '∞'})`
    ).join('\n') || 'Nenhum convite encontrado';
    
    const embed = new EmbedBuilder()
      .setTitle('📨 Convites do Servidor')
      .setDescription(inviteList)
      .addFields({ name: '📊 Total', value: `${result.invites.length} convites`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteInvite(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.deleteInvite(
      guild, 
      response.codigo || response.code
    );
    
    const embed = new EmbedBuilder()
      .setTitle('🗑️ Convite Deletado!')
      .setDescription(`Convite **${result.code}** foi deletado!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE EMOJIS
// ============================================

async function handleAddEmoji(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.addEmoji(guild, {
      name: response.nome || response.name,
      url: response.url || response.imagem,
      roles: response.cargos || response.roles || []
    });
    
    const embed = new EmbedBuilder()
      .setTitle('😀 Emoji Adicionado!')
      .setDescription(`Emoji ${result.emoji.string} foi adicionado!`)
      .addFields(
        { name: '📝 Nome', value: result.emoji.name, inline: true },
        { name: '🆔 ID', value: result.emoji.id, inline: true }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteEmoji(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.deleteEmoji(
      guild, 
      response.emojiId || response.emoji || response.id
    );
    
    const embed = new EmbedBuilder()
      .setTitle('🗑️ Emoji Deletado!')
      .setDescription(`Emoji **${result.name}** foi deletado!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListEmojis(message, guild, thinkingMsg) {
  try {
    const result = await serverTools.listEmojis(guild);
    
    const emojiList = result.emojis.slice(0, 30).map(e => 
      `${e.string} **${e.name}**`
    ).join(' ') || 'Nenhum emoji encontrado';
    
    const embed = new EmbedBuilder()
      .setTitle('😀 Emojis do Servidor')
      .setDescription(emojiList.substring(0, 2000))
      .addFields({ name: '📊 Total', value: `${result.count} emojis`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// INFORMAÇÕES DO SERVIDOR
// ============================================

async function handleServerStats(message, guild, thinkingMsg) {
  try {
    const result = await serverTools.getServerStats(guild);
    const s = result.server;
    
    const embed = new EmbedBuilder()
      .setTitle(`📊 ${s.name}`)
      .setThumbnail(s.icon)
      .setDescription(`**ID:** ${s.id}\n**Dono:** <@${s.ownerId}>`)
      .addFields(
        { name: '👥 Membros', value: `${s.memberCount} (${s.online} online)`, inline: true },
        { name: '🤖 Bots', value: `${s.bots}`, inline: true },
        { name: '📁 Canais', value: `${s.channels.total} (${s.channels.text} texto, ${s.channels.voice} voz)`, inline: true },
        { name: '🎭 Cargos', value: `${s.roles}`, inline: true },
        { name: '😀 Emojis', value: `${s.emojis}`, inline: true },
        { name: '💎 Boost', value: `Nível ${s.boost.level} (${s.boost.count} boosts)`, inline: true },
        { name: '📅 Criado em', value: `<t:${Math.floor(new Date(s.createdAt) / 1000)}:d>`, inline: true }
      )
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X v7.0' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// OUTRAS FERRAMENTAS
// ============================================

async function handleSendEmbed(message, response, guild, channel, thinkingMsg) {
  // 🐛 CORREÇÃO: Pegar dados do embed se existir
  const data = response.embed || response;
  
  console.log(`📊 [Embed] Dados recebidos:`, JSON.stringify(data).substring(0, 300));
  
  // ============================================
  // FUNÇÃO: Processar quebras de linha literais
  // ============================================
  function processText(text) {
    if (!text) return text;
    // Converter \\n para \n (quebras de linha reais)
    let processed = text.replace(/\\n/g, '\n');
    return processed;
  }
  
  // ============================================
  // FUNÇÃO: Resolver placeholders dinâmicos
  // ============================================
  function resolvePlaceholders(text, guild, user, channel) {
    if (!text || typeof text !== 'string') return text;
    
    const now = new Date();
    const placeholders = {
      '{server}': guild?.name || 'Servidor',
      '{server.name}': guild?.name || 'Servidor',
      '{server.id}': guild?.id || '',
      '{server.icon}': guild?.iconURL ? guild.iconURL({ dynamic: true, size: 256 }) : 'https://i.imgur.com/eEsH9NF.jpeg',
      '{server.members}': guild?.memberCount?.toString() || '0',
      '{user}': user ? `<@${user.id}>` : 'Usuário',
      '{user.name}': user?.username || 'Usuário',
      '{user.id}': user?.id || '',
      '{user.avatar}': user?.avatarURL ? user.avatarURL({ dynamic: true, size: 256 }) : 'https://i.imgur.com/eEsH9NF.jpeg',
      '{channel}': channel ? `<#${channel.id}>` : 'Canal',
      '{channel.name}': channel?.name || 'canal',
      '{date}': now.toLocaleDateString('pt-BR'),
      '{time}': now.toLocaleTimeString('pt-BR'),
      '{timestamp}': `<t:${Math.floor(now.getTime() / 1000)}:R>`,
      '{year}': now.getFullYear().toString(),
      '{month}': (now.getMonth() + 1).toString().padStart(2, '0'),
      '{day}': now.getDate().toString().padStart(2, '0')
    };
    
    let resolved = text;
    for (const [placeholder, value] of Object.entries(placeholders)) {
      resolved = resolved.replace(new RegExp(placeholder.replace(/[{}]/g, '\\$&'), 'gi'), value);
    }
    
    return resolved;
  }
  
  // ============================================
  // PROCESSAR TEXTO COMPLETO
  // ============================================
  function processAll(text) {
    return resolvePlaceholders(processText(text), guild, message?.author, channel);
  }
  
  // Mapa de cores expandido
  const colorMap = {
    'roxo': '#8B5CF6', 'purple': '#8B5CF6', 'violeta': '#8B5CF6',
    'vermelho': '#EF4444', 'red': '#EF4444', 'crimson': '#DC143C',
    'verde': '#10B981', 'green': '#10B981', 'esmeralda': '#10B981',
    'azul': '#3B82F6', 'blue': '#3B82F6', 'ciano': '#06B6D4',
    'amarelo': '#F59E0B', 'yellow': '#F59E0B', 'amber': '#F59E0B',
    'laranja': '#F97316', 'orange': '#F97316',
    'rosa': '#EC4899', 'pink': '#EC4899',
    'dourado': '#FFD700', 'gold': '#FFD700', 'amarelo_ouro': '#FFD700',
    'branco': '#FFFFFF', 'white': '#FFFFFF',
    'preto': '#000000', 'black': '#000000',
    'magia': '#9400D3', 'magic': '#9400D3',
    'amor': '#FF69B4', 'love': '#FF69B4',
    'sucesso': '#10B981', 'success': '#10B981',
    'erro': '#EF4444', 'error': '#EF4444',
    'info': '#3B82F6', 'informação': '#3B82F6',
    'aviso': '#F59E0B', 'warning': '#F59E0B'
  };
  
  // Resolver cor
  let color = data.color || data.cor || '#8B5CF6';
  if (typeof color === 'string' && colorMap[color.toLowerCase()]) {
    color = colorMap[color.toLowerCase()];
  }
  
  // Criar embed avançado
  const embed = new EmbedBuilder()
    .setColor(color)
    .setTimestamp();
  
  // Título
  const title = data.title || data.titulo;
  if (title) {
    embed.setTitle(processAll(title).substring(0, 256));
  }
  
  // Descrição - PROCESSAR \n CORRETAMENTE
  const description = data.description || data.descricao;
  if (description) {
    embed.setDescription(processAll(description).substring(0, 4096));
  }
  
  // URL do título
  if (data.url) {
    embed.setURL(data.url);
  }
  
  // Autor
  if (data.author || data.autor) {
    const author = data.author || data.autor;
    embed.setAuthor({
      name: processAll(author.name || author).substring(0, 256),
      iconURL: author.icon || author.iconURL || author.avatar,
      url: author.url
    });
  }
  
  // Thumbnail
  let thumbnail = data.thumbnail || data.miniatura;
  if (thumbnail) {
    // Resolver placeholder no thumbnail
    thumbnail = processAll(thumbnail);
    // Se ainda for placeholder, usar imagem padrão
    if (thumbnail.includes('{') || thumbnail === 'https://i.imgur.com/placeholder.png') {
      thumbnail = 'https://i.imgur.com/eEsH9NF.jpeg';
    }
    embed.setThumbnail(thumbnail);
  }
  
  // Imagem principal
  let image = data.image || data.imagem || data.image_url;
  if (image) {
    image = processAll(image);
    if (image.includes('{')) {
      image = null;
    }
    if (image) {
      embed.setImage(image);
    }
  }
  
  // Fields/Campos - PROCESSAR \n CORRETAMENTE
  const fields = data.fields || data.campos || [];
  if (fields && Array.isArray(fields) && fields.length > 0) {
    fields.forEach(field => {
      if (field.name && field.value) {
        embed.addFields({
          name: processAll(String(field.name)).substring(0, 256),
          value: processAll(String(field.value)).substring(0, 1024),
          inline: field.inline !== false
        });
      }
    });
  }
  
  // Footer/Rodapé
  const footer = data.footer || data.rodape;
  if (footer) {
    embed.setFooter({
      text: processAll(typeof footer === 'string' ? footer : footer.text || '🌹 Rias Gremory').substring(0, 2048),
      iconURL: typeof footer === 'object' ? processAll(footer.icon || footer.iconURL) : undefined
    });
  } else {
    embed.setFooter({ text: '🌹 Rias Gremory • Power of Destruction', iconURL: 'https://i.imgur.com/eEsH9NF.jpeg' });
  }
  
  // Resolver canal de destino
  let targetChannel = channel;
  const targetChannelName = response.channel || response.canal || response.targetChannel || data.channel;
  if (targetChannelName) {
    const found = guild.channels.cache.find(c => 
      c.name.toLowerCase().includes(targetChannelName.toLowerCase()) || 
      c.id === targetChannelName
    );
    if (found) targetChannel = found;
  }
  
  // Enviar
  try {
    if (targetChannel.id !== channel.id) {
      await targetChannel.send({ embeds: [embed] });
      await editEmbed(thinkingMsg, '✅ Embed Enviado!', `Embed enviado para ${targetChannel}!`, '#10B981');
    } else {
      await channel.send({ embeds: [embed] });
      if (thinkingMsg) {
        await thinkingMsg.delete().catch(() => {});
      }
    }
  } catch (err) {
    console.error('Erro ao enviar embed:', err.message);
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao enviar embed: ${err.message}`, '#EF4444');
  }
}

async function handlePoll(message, response, thinkingMsg) {
  const question = response.question || response.pergunta || 'Enquete';
  const options = response.options || response.opcoes || ['Sim', 'Não'];
  
  const embed = new EmbedBuilder()
    .setTitle(`📊 ${question}`)
    .setDescription(options.map((opt, i) => `**${i + 1}.** ${opt}`).join('\n'))
    .setColor('#8B5CF6')
    .setFooter({ text: 'Clique para votar! | 💎 Rias-Grimory-X' })
    .setTimestamp();
  
  const row = new ActionRowBuilder();
  options.forEach((_, i) => {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(`poll_${i}`)
        .setLabel(`${i + 1}`)
        .setStyle(ButtonStyle.Primary)
    );
  });
  
  await message.channel.send({ embeds: [embed], components: [row] });
  await editEmbed(thinkingMsg, '✅ Enquete Criada!', 'A enquete foi enviada!', '#10B981');
}

// ============================================
// TAREFA COMPLEXA - CORRIGIDO COM CONTEXTO
// ============================================

async function handleComplexTask(message, response, guild, channel, thinkingMsg) {
  const steps = response.steps || response.etapas || [];
  
  if (!steps || steps.length === 0) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'Nenhuma etapa definida!', '#EF4444');
  }
  
  // ============================================
  // DETECÇÃO DE PROBLEMA: múltiplos google_image
  // ============================================
  const googleImageSteps = steps.filter(s => 
    (s.type || s.tipo || '').toLowerCase().includes('google_image') ||
    (s.type || s.tipo || '').toLowerCase().includes('busca_imagem')
  );
  
  if (googleImageSteps.length > 1) {
    console.log(`⚠️ [ComplexTask] Detectado ${googleImageSteps.length} chamadas google_image - consolidando...`);
    
    // Consolidar todas as chamadas em uma única com quantidade total
    const totalQuantidade = googleImageSteps.reduce((sum, s) => 
      sum + (s.quantidade || s.amount || 1), 0
    );
    const query = googleImageSteps[0].query || googleImageSteps[0].termo || 'imagens';
    
    // Remover todas as chamadas google_image duplicadas
    const consolidatedSteps = steps.filter(s => 
      !(s.type || s.tipo || '').toLowerCase().includes('google_image') &&
      !(s.type || s.tipo || '').toLowerCase().includes('busca_imagem')
    );
    
    // Adicionar única chamada consolidada
    consolidatedSteps.push({
      type: 'google_image',
      query: query,
      quantidade: Math.min(totalQuantidade, 20),
      canal_destino: googleImageSteps[0].canal_destino || 'auto'
    });
    
    console.log(`✅ [ComplexTask] Consolidado: 1 chamada com quantidade ${Math.min(totalQuantidade, 20)}`);
    steps.length = 0;
    steps.push(...consolidatedSteps);
  }
  
  // ============================================
  // CONTEXTO ENTRE ETAPAS
  // ============================================
  global.lastCreatedChannel = null;
  global.lastCreatedChannelId = null;
  global.lastCreatedCategory = null;
  global.lastCreatedCategoryId = null;
  global.lastCreatedCategoryName = null;
  
  const embed = new EmbedBuilder()
    .setTitle('🧠 Tarefa Complexa')
    .setDescription(`⚙️ Executando **${steps.length}** etapas...\n\n*Vou fazer tudo certinho para você!* 💖`)
    .setColor('#FBBF24')
    .setFooter({ text: '💎 Rias-Grimory-X v8.0' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
  
  let successCount = 0;
  let errorCount = 0;
  const errors = [];
  
  for (let i = 0; i < steps.length; i++) {
    const step = steps[i];
    const stepType = (step.type || step.tipo || 'desconhecido').toLowerCase();
    
    // Embed de progresso
    const stepEmbed = new EmbedBuilder()
      .setTitle(`⚙️ Etapa ${i + 1}/${steps.length}`)
      .setDescription(`Executando: **${stepType}**...`)
      .setColor('#FBBF24')
      .setTimestamp();
    
    await editEmbed(thinkingMsg, stepEmbed);
    
    try {
      console.log(`📋 [ComplexTask] Etapa ${i + 1}/${steps.length}: ${stepType}`);
      
      // ============================================
      // INJEÇÃO DE CONTEXTO AUTOMÁTICA
      // ============================================
      
      // Para criar_canal: usar categoria criada anteriormente
      if (stepType === 'criar_canal' || stepType === 'create_channel') {
        // Se mencionou categoria pelo nome parcial, buscar pelo nome salvo
        if (step.categoria && global.lastCreatedCategoryName) {
          const catName = step.categoria.toLowerCase();
          const lastCatName = global.lastCreatedCategoryName.toLowerCase();
          if (catName.includes(lastCatName) || lastCatName.includes(catName)) {
            step.categoria = global.lastCreatedCategoryId;
            console.log(`📁 [ComplexTask] Categoria encontrada por nome: ${global.lastCreatedCategoryName}`);
          }
        }
        // Se não tem categoria mas existe uma criada
        if (!step.categoria && !step.parent && global.lastCreatedCategoryId) {
          step.categoria = global.lastCreatedCategoryId;
          console.log(`📁 [ComplexTask] Auto-injetando categoria: ${global.lastCreatedCategoryId}`);
        }
      }
      
      // Para google_image: verificar canal_destino
      if (stepType === 'google_image' || stepType === 'busca_imagem' || stepType === 'buscar_imagens_google') {
        // Garantir que quantidade está definido
        if (!step.quantidade && !step.amount) {
          step.quantidade = 5;
          console.log(`🖼️ [ComplexTask] Quantidade padrão: 5`);
        }
        
        // Log do canal de destino
        if (step.canal_destino === 'auto' && global.lastCreatedChannel) {
          console.log(`🖼️ [ComplexTask] Imagens vão para: ${global.lastCreatedChannel.name}`);
        }
      }
      
      // ✅ CORREÇÃO: Para criar_automacao: injetar ID do canal criado anteriormente
      if (stepType === 'criar_automacao' || stepType === 'create_automation') {
        // Se não tem canal definido ou é "auto", usar o último canal criado
        if ((!step.canal && !step.channel) || step.canal === 'auto' || step.channel === 'auto') {
          if (global.lastCreatedChannelId) {
            step.canal = global.lastCreatedChannelId;
            console.log(`🤖 [ComplexTask] Auto-injetando canal na automação: ${global.lastCreatedChannelId}`);
          }
        }
      }
      
      // Executar etapa
      await handleResponse(message, step, guild, channel, null);
      successCount++;
      
      // Delay inteligente baseado no tipo de operação
      const delayMap = {
        'criar_categoria': 1200,
        'criar_canal': 1000,
        'google_image': 500,
        'create_channel': 1000,
        'create_category': 1200
      };
      const delay = delayMap[stepType] || 600;
      await sleep(delay);
      
      console.log(`✅ [ComplexTask] Etapa ${i + 1} OK`);
    } catch (error) {
      errorCount++;
      errors.push(`Etapa ${i + 1}: ${error.message.substring(0, 100)}`);
      console.error(`❌ [ComplexTask] Erro etapa ${i + 1}:`, error.message);
      
      // Continuar executando próximas etapas mesmo com erro
    }
  }
  
  // Embed final
  const finalEmbed = new EmbedBuilder()
    .setTitle(errorCount > 0 ? '⚠️ Tarefa Parcialmente Concluída' : '🎉 Tarefa Concluída!')
    .setDescription(
      `✅ **${successCount}** etapas executadas!\n` +
      (errorCount > 0 ? `❌ **${errorCount}** etapas falharam.` : '*Tudo pronto para você, amor!* 💖')
    )
    .setColor(errorCount > 0 ? '#F59E0B' : '#10B981')
    .setFooter({ text: '💎 Rias-Grimory-X v8.0' })
    .setTimestamp();
  
  if (errors.length > 0) {
    finalEmbed.addFields({
      name: '⚠️ Erros',
      value: errors.slice(0, 3).join('\n').substring(0, 900)
    });
  }
  
  await editEmbed(thinkingMsg, finalEmbed);
  
  // Limpar contexto após conclusão
  global.lastCreatedChannel = null;
  global.lastCreatedChannelId = null;
  global.lastCreatedCategory = null;
  global.lastCreatedCategoryId = null;
  global.lastCreatedCategoryName = null;
}

// ============================================
// MENSAGEM SIMPLES
// ============================================

async function handleMessage(message, response, thinkingMsg) {
  let content = response.content || response.mensagem || response.text || '';
  
  // Se conteúdo vazio, dar resposta útil
  if (!content || content.trim() === '') {
    content = `Não entendi muito bem o que você quis dizer! 😅 Pode reformular? 🌹

**Coisas que posso fazer:**
• Criar/editar/deletar canais e categorias
• Criar/editar/deletar cargos  
• Buscar imagens no Google
• Criar automações
• Moderar membros

**Exemplo:** "Crie um canal chamado memes"`;
  }
  
  const embed = new EmbedBuilder()
    .setDescription(content.substring(0, 4000))
    .setColor('#DC143C')
    .setFooter({ text: '🌹 Rias Gremory', iconURL: 'https://i.imgur.com/eEsH9NF.jpeg' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
}

// ============================================
// AUTOMAÇÃO
// ============================================

async function handleCreateAutomation(message, response, guild, thinkingMsg) {
  try {
    let channelId = response.canal || response.channel;
    
    // ✅ CORREÇÃO: Usar lastCreatedChannelId se canal for "auto" ou se não encontrar por nome
    if (channelId === 'auto' || !channelId) {
      if (global.lastCreatedChannelId) {
        channelId = global.lastCreatedChannelId;
        console.log(`🤖 [Automação] Usando canal criado anteriormente: ${global.lastCreatedChannelId}`);
      }
    }
    
    // Resolver ID do canal se for nome
    let resolvedChannelId = channelId;
    if (channelId && !/^\d+$/.test(channelId)) {
      const foundChannel = guild.channels.cache.find(c => 
        c.name.toLowerCase().includes(channelId.toLowerCase())
      );
      if (foundChannel) {
        resolvedChannelId = foundChannel.id;
      } else if (global.lastCreatedChannelId) {
        // ✅ CORREÇÃO: Se não encontrou por nome, usar o último canal criado
        resolvedChannelId = global.lastCreatedChannelId;
        console.log(`🤖 [Automação] Canal não encontrado por nome, usando último criado: ${global.lastCreatedChannelId}`);
      }
    }
    
    const result = automationManager.createAutomation(guild.id, {
      name: response.nome || response.name,
      description: response.descricao || response.description,
      channelId: resolvedChannelId,
      interval: response.intervalo || response.interval || 60,
      task: response.tarefa || response.task
    });
    
    // 🚀 INICIAR A AUTOMAÇÃO IMEDIATAMENTE!
    if (discordClient && result.active !== false) {
      result.start(discordClient);
      console.log(`🚀 [Automação] Iniciada imediatamente: ${result.name}`);
    }
    
    const embed = new EmbedBuilder()
      .setTitle('🤖 Automação Criada e Iniciada!')
      .setDescription(`Script **${result.name}** criado com sucesso e já está rodando! 🚀`)
      .addFields(
        { name: '📝 Nome', value: result.name, inline: true },
        { name: '⏱️ Intervalo', value: `${result.interval} minutos`, inline: true },
        { name: '🆔 ID', value: `\`${result.id}\``, inline: true },
        { name: '📺 Canal', value: `<#${resolvedChannelId}>`, inline: true },
        { name: '📋 Tarefa', value: result.task || 'Não definida', inline: false }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X | Automação ativa!' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    // 🌹 Enviar mensagem personalizada da Rias
    await sendRiasFollowUp(message.channel, 'criar_automacao', true);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
    await sendRiasFollowUp(message.channel, 'criar_automacao', false);
  }
}

async function handleListAutomations(message, guild, thinkingMsg) {
  const automations = automationManager.listAutomations(guild.id);
  
  if (automations.length === 0) {
    const embed = new EmbedBuilder()
      .setTitle('🤖 Automações')
      .setDescription('Nenhuma automação configurada.')
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    return await editEmbed(thinkingMsg, embed);
  }
  
  const list = automations.map(a => 
    `• **${a.name}** (${a.id})\n  ⏱️ ${a.interval}min | ${a.active ? '✅ Ativo' : '⏸️ Pausado'}`
  ).join('\n');
  
  const embed = new EmbedBuilder()
    .setTitle('🤖 Automações')
    .setDescription(list)
    .addFields({ name: '📊 Total', value: `${automations.length} scripts`, inline: true })
    .setColor('#8B5CF6')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
}

async function handlePauseAutomation(message, response, guild, thinkingMsg) {
  try {
    automationManager.pauseAutomation(guild.id, response.id);
    
    const embed = new EmbedBuilder()
      .setTitle('⏸️ Automação Pausada!')
      .setDescription(`A automação foi pausada.`)
      .setColor('#F59E0B')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleResumeAutomation(message, response, guild, thinkingMsg) {
  try {
    // Passar discordClient para reiniciar a automação
    automationManager.resumeAutomation(guild.id, response.id, discordClient);
    
    const embed = new EmbedBuilder()
      .setTitle('▶️ Automação Retomada!')
      .setDescription(`A automação foi retomada e está rodando novamente! 🚀`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    await sendRiasFollowUp(message.channel, 'retomar_automacao', true);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteAutomation(message, response, guild, thinkingMsg) {
  try {
    automationManager.deleteAutomation(guild.id, response.id);
    
    const embed = new EmbedBuilder()
      .setTitle('🗑️ Automação Deletada!')
      .setDescription(`A automação foi removida.`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleEditAutomation(message, response, guild, thinkingMsg) {
  try {
    const scriptId = response.id || response.automacao_id || response.automation_id;
    
    if (!scriptId) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'ID da automação não informado! Use `listar_automacoes` para ver os IDs.', '#EF4444');
    }
    
    const newConfig = {
      name: response.nome || response.name,
      description: response.descricao || response.description,
      interval: response.intervalo || response.interval,
      task: response.tarefa || response.task,
      channelId: response.canal || response.channel
    };
    
    // Remover propriedades undefined
    Object.keys(newConfig).forEach(key => {
      if (newConfig[key] === undefined) delete newConfig[key];
    });
    
    // Passar client para reiniciar automação após edição
    const result = automationManager.editAutomation(guild.id, scriptId, newConfig, discordClient);
    
    if (!result) {
      return await editEmbed(thinkingMsg, '❌ Erro', `Automação com ID "${scriptId}" não encontrada!`, '#EF4444');
    }
    
    const embed = new EmbedBuilder()
      .setTitle('✏️ Automação Editada e Reiniciada!')
      .setDescription(`Script **${result.name}** foi atualizado e reiniciado! 🔄`)
      .addFields(
        { name: '📝 Nome', value: result.name, inline: true },
        { name: '⏱️ Intervalo', value: `${result.interval} minutos`, inline: true },
        { name: '🆔 ID', value: `\`${result.id}\``, inline: true },
        { name: '📺 Canal', value: result.channelMention || 'Não alterado', inline: true },
        { name: '📊 Execuções', value: `${result.runCount || 0}`, inline: true },
        { name: '🔄 Status', value: result.active ? '✅ Ativo' : '⏸️ Pausado', inline: true }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X | Automação atualizada!' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    // 🌹 Enviar mensagem personalizada da Rias
    await sendRiasFollowUp(message.channel, 'editar_automacao', true);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao editar automação: ${error.message}`, '#EF4444');
    await sendRiasFollowUp(message.channel, 'editar_automacao', false);
  }
}

async function handleRunAutomation(message, response, guild, thinkingMsg) {
  try {
    // Usar runAutomationNow que é a função correta
    await automationManager.runAutomationNow(guild.id, response.id, discordClient);
    
    const embed = new EmbedBuilder()
      .setTitle('⚡ Automação Executada!')
      .setDescription(`A automação foi executada manualmente com sucesso! 🚀`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    await sendRiasFollowUp(message.channel, 'executar_automacao', true);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// EVENT AUTOMATION HANDLERS - NOVO SISTEMA
// ============================================

async function handleCreateEventAutomation(message, response, guild, thinkingMsg) {
  try {
    const { 
      name, nome, 
      trigger, 
      triggerConfig, 
      actions,
      description,
      enabled 
    } = response;
    
    if (!trigger) {
      return await editEmbed(thinkingMsg, '❌ Erro', 
        'Você precisa especificar um trigger! Exemplos:\n• `message_in_channel` - Quando mensagem em canal\n• `member_join` - Quando membro entra\n• `reaction_add` - Quando reage a mensagem', 
        '#EF4444');
    }
    
    if (!actions || !Array.isArray(actions) || actions.length === 0) {
      return await editEmbed(thinkingMsg, '❌ Erro', 
        'Você precisa especificar as ações! Exemplo:\n```json\n"actions": [\n  { "type": "delete_message" },\n  { "type": "send_dm", "embed": { "title": "Aviso", "description": "Mensagem removida!" } }\n]', 
        '#EF4444');
    }
    
    const automation = createEventAutomation(guild.id, {
      name: name || nome || `Automação ${trigger}`,
      description: description || '',
      trigger: trigger,
      triggerConfig: triggerConfig || {},
      actions: actions,
      enabled: enabled !== false,
      createdBy: message.author.id
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Automação Event-Driven Criada!')
      .setDescription(`**${automation.name}** foi criada e está ativa! 🎯`)
      .addFields(
        { name: '🎯 Trigger', value: TRIGGER_TYPES[trigger]?.name || trigger, inline: true },
        { name: '⚡ Ações', value: `${actions.length} ação(ões)`, inline: true },
        { name: '📊 Status', value: automation.enabled ? '✅ Ativa' : '⏸️ Pausada', inline: true },
        { name: '🆔 ID', value: `\`${automation.id}\``, inline: true }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X | Event Automation' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    // 🌹 Enviar mensagem personalizada da Rias
    await sendRiasFollowUp(message.channel, 'criar_automacao', true);
  } catch (error) {
    console.error('❌ [EventAutomation] Erro ao criar:', error);
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao criar automação: ${error.message}`, '#EF4444');
    await sendRiasFollowUp(message.channel, 'criar_automacao', false);
  }
}

async function handleListEventAutomations(message, guild, thinkingMsg) {
  const automations = listEventAutomations(guild.id);
  
  if (automations.length === 0) {
    const embed = new EmbedBuilder()
      .setTitle('🎯 Automações Event-Driven')
      .setDescription('Nenhuma automação configurada.\n\nUse os templates prontos ou peça para eu criar uma!')
      .addFields({
        name: '💡 Templates Disponíveis',
        value: '• Anti-Spam\n• Boas-vindas\n• Despedida\n• Reaction Role\n• Log de Mensagens\n• Recompensa de Boost'
      })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    return await editEmbed(thinkingMsg, embed);
  }
  
  const active = automations.filter(a => a.enabled);
  const inactive = automations.filter(a => !a.enabled);
  
  const embed = new EmbedBuilder()
    .setTitle('🎯 Automações Event-Driven')
    .setDescription(`Total: **${automations.length}** automação(ões)`)
    .setColor('#8B5CF6')
    .setTimestamp();
  
  if (active.length > 0) {
    const activeList = active.slice(0, 10).map(a => 
      `• **${a.name}**\n  └ ${TRIGGER_TYPES[a.trigger]?.name || a.trigger} | ${a.triggerCount} execuções`
    ).join('\n');
    
    embed.addFields({ name: `✅ Ativas (${active.length})`, value: activeList.substring(0, 1024), inline: false });
  }
  
  if (inactive.length > 0) {
    const inactiveList = inactive.slice(0, 5).map(a => 
      `• **${a.name}** (${TRIGGER_TYPES[a.trigger]?.name || a.trigger})`
    ).join('\n');
    
    embed.addFields({ name: `⏸️ Pausadas (${inactive.length})`, value: inactiveList.substring(0, 512), inline: false });
  }
  
  embed.setFooter({ text: '💡 Use /automations info [id] para detalhes' });
  
  await editEmbed(thinkingMsg, embed);
}

async function handleToggleEventAutomation(message, response, guild, thinkingMsg) {
  try {
    const automationId = response.id || response.automationId;
    
    if (!automationId) {
      return await editEmbed(thinkingMsg, '❌ Erro', 
        'Especifique o ID da automação! Use `listar_event_automations` para ver os IDs.', 
        '#EF4444');
    }
    
    const automation = toggleEventAutomation(guild.id, automationId);
    
    if (!automation) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'Automação não encontrada!', '#EF4444');
    }
    
    const embed = new EmbedBuilder()
      .setTitle(automation.enabled ? '✅ Automação Ativada' : '⏸️ Automação Pausada')
      .setDescription(`**${automation.name}** foi ${automation.enabled ? 'ativada' : 'pausada'}.`)
      .setColor(automation.enabled ? '#10B981' : '#F59E0B')
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteEventAutomation(message, response, guild, thinkingMsg) {
  try {
    const automationId = response.id || response.automationId;
    
    if (!automationId) {
      return await editEmbed(thinkingMsg, '❌ Erro', 
        'Especifique o ID da automação!', 
        '#EF4444');
    }
    
    // Buscar antes de deletar
    const automation = getEventAutomation(guild.id, automationId);
    
    if (!automation) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'Automação não encontrada!', '#EF4444');
    }
    
    const name = automation.name;
    deleteEventAutomation(guild.id, automationId);
    
    const embed = new EmbedBuilder()
      .setTitle('🗑️ Automação Deletada')
      .setDescription(`**${name}** foi removida permanentemente.`)
      .setColor('#EF4444')
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleShowAutomationTemplates(message, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('📚 Templates de Automações Event-Driven')
    .setDescription('Escolha um template para criar rapidamente!')
    .addFields(
      { 
        name: '🛡️ Anti-Spam', 
        value: 'Deleta mensagens com links e avisa o usuário por DM.\n`trigger: message_in_channel`', 
        inline: false 
      },
      { 
        name: '👋 Boas-vindas', 
        value: 'Envia mensagem de boas-vindas quando alguém entra.\n`trigger: member_join`', 
        inline: false 
      },
      { 
        name: '🚪 Despedida', 
        value: 'Envia mensagem quando alguém sai do servidor.\n`trigger: member_leave`', 
        inline: false 
      },
      { 
        name: '💎 Recompensa de Boost', 
        value: 'Dá cargo especial quando alguém da boost.\n`trigger: boost_add`', 
        inline: false 
      },
      { 
        name: '🎭 Reaction Role', 
        value: 'Dá cargo quando alguém reage a uma mensagem.\n`trigger: reaction_add`', 
        inline: false 
      },
      { 
        name: '📋 Log de Mensagens', 
        value: 'Registra mensagens editadas/deletadas.\n`trigger: message_delete / message_edit`', 
        inline: false 
      }
    )
    .setColor('#8B5CF6')
    .setFooter({ text: '💎 Use "aplicar_template_automation" para criar!' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
}

async function handleApplyAutomationTemplate(message, response, guild, thinkingMsg) {
  try {
    const templateKey = response.template || response.templateName;
    
    if (!templateKey || !AUTOMATION_TEMPLATES[templateKey]) {
      return await editEmbed(thinkingMsg, '❌ Erro', 
        'Template não encontrado! Templates disponíveis:\n• `antiSpam`\n• `welcomeMessage`\n• `farewellMessage`\n• `boosterReward`\n• `reactionRole`\n• `logEdit`\n• `logDelete`', 
        '#EF4444');
    }
    
    const template = AUTOMATION_TEMPLATES[templateKey];
    
    // Aplicar personalizações
    const config = {
      ...template,
      createdBy: message.author.id
    };
    
    // Substituir canal se especificado
    if (response.channelId || response.canal) {
      const channelId = response.channelId || response.canal;
      config.triggerConfig = config.triggerConfig || {};
      if (template.trigger === 'message_in_channel') {
        config.triggerConfig.channelId = channelId;
      }
      config.actions = config.actions?.map(action => {
        if (action.channelId) return { ...action, channelId };
        if (action.logChannelId) return { ...action, logChannelId: channelId };
        return action;
      });
    }
    
    // Substituir cargo se especificado
    if (response.roleId || response.cargo) {
      const roleId = response.roleId || response.cargo;
      config.actions = config.actions?.map(action => {
        if (action.roleId) return { ...action, roleId };
        return action;
      });
    }
    
    const automation = createEventAutomation(guild.id, config);
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Template Aplicado!')
      .setDescription(`**${automation.name}** foi criado e está ativo! 🎯`)
      .addFields(
        { name: '🎯 Trigger', value: TRIGGER_TYPES[automation.trigger]?.name || automation.trigger, inline: true },
        { name: '📊 Status', value: '✅ Ativa', inline: true },
        { name: '🆔 ID', value: `\`${automation.id}\``, inline: true }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    await sendRiasFollowUp(message.channel, 'criar_automacao', true);
  } catch (error) {
    console.error('❌ [EventAutomation] Erro ao aplicar template:', error);
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// SISTEMA DE AVISOS (WARN)
// ============================================

async function handleWarn(message, response, guild, thinkingMsg) {
  try {
    const memberIdentifier = response.membro || response.member || response.usuario || response.user;
    const reason = response.motivo || response.reason || 'Não especificado';
    
    if (!memberIdentifier) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'Membro não especificado! Use: warn @usuario motivo', '#EF4444');
    }
    
    // Buscar membro
    const member = await serverTools.findMember(guild, memberIdentifier);
    if (!member) {
      return await editEmbed(thinkingMsg, '❌ Erro', `Membro "${memberIdentifier}" não encontrado!`, '#EF4444');
    }
    
    // Adicionar aviso
    const result = warnManager.addWarn(guild.id, member.id, message.author.id, reason);
    
    // Verificar ação automática
    const autoAction = warnManager.checkAutoAction(guild.id, member.id);
    
    const embed = new EmbedBuilder()
      .setTitle('⚠️ Aviso Registrado!')
      .setDescription(`${member} recebeu um aviso!`)
      .addFields(
        { name: '📝 Motivo', value: reason.substring(0, 500), inline: false },
        { name: '👮 Moderador', value: `<@${message.author.id}>`, inline: true },
        { name: '📊 Total de Avisos', value: `${result.totalWarns}`, inline: true }
      )
      .setColor('#F59E0B')
      .setFooter({ text: '⚠️ 3 avisos = mute | 5 avisos = kick | 10 avisos = ban' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    // Se atingiu limite, avisar sobre ação automática
    if (autoAction) {
      const actionEmbed = new EmbedBuilder()
        .setTitle('🚨 Ação Automática Disparada!')
        .setDescription(`${member} atingiu ${autoAction.warnCount} avisos e deve receber: **${autoAction.action}**`)
        .setColor('#EF4444')
        .setTimestamp();
      
      await message.channel.send({ embeds: [actionEmbed] });
    }
    
  } catch (error) {
    console.error('Erro no warn:', error);
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao registrar aviso: ${error.message}`, '#EF4444');
  }
}

async function handleUnwarn(message, response, guild, thinkingMsg) {
  try {
    const memberIdentifier = response.membro || response.member || response.usuario;
    const warnId = response.warn_id || response.warnId || response.id;
    
    if (!memberIdentifier) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'Membro não especificado!', '#EF4444');
    }
    
    const member = await serverTools.findMember(guild, memberIdentifier);
    if (!member) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'Membro não encontrado!', '#EF4444');
    }
    
    let result;
    
    if (warnId) {
      result = warnManager.removeWarn(guild.id, member.id, warnId);
    } else {
      // Remove o último aviso
      const warns = warnManager.getMemberWarns(guild.id, member.id);
      if (warns.length === 0) {
        return await editEmbed(thinkingMsg, '⚠️ Aviso', `${member} não possui avisos!`, '#F59E0B');
      }
      result = warnManager.removeWarn(guild.id, member.id, warns[warns.length - 1].id);
    }
    
    if (!result.success) {
      return await editEmbed(thinkingMsg, '❌ Erro', result.error, '#EF4444');
    }
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Aviso Removido!')
      .setDescription(`Um aviso foi removido de ${member}!`)
      .addFields(
        { name: '📊 Avisos Restantes', value: `${result.remainingWarns}`, inline: true }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
  } catch (error) {
    console.error('Erro no unwarn:', error);
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao remover aviso: ${error.message}`, '#EF4444');
  }
}

async function handleListWarns(message, response, guild, thinkingMsg) {
  try {
    const memberIdentifier = response.membro || response.member || response.usuario;
    
    let warns;
    let targetUser;
    
    if (memberIdentifier) {
      const member = await serverTools.findMember(guild, memberIdentifier);
      if (!member) {
        return await editEmbed(thinkingMsg, '❌ Erro', 'Membro não encontrado!', '#EF4444');
      }
      warns = warnManager.getMemberWarns(guild.id, member.id);
      targetUser = member;
    } else {
      // Lista todos os avisos do servidor
      warns = warnManager.getGuildWarns(guild.id);
    }
    
    if (!warns || warns.length === 0 || (Array.isArray(warns) && warns.every(w => !w.warns?.length))) {
      return await editEmbed(thinkingMsg, '📋 Avisos', 'Nenhum aviso registrado!', '#8B5CF6');
    }
    
    const embed = new EmbedBuilder()
      .setTitle('📋 Lista de Avisos')
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    if (targetUser) {
      // Mostrar avisos de um usuário específico
      embed.setDescription(`Avisos de ${targetUser}: **${warns.length}**`);
      
      warns.slice(0, 10).forEach((warn, i) => {
        embed.addFields({
          name: `#${i + 1} - ${new Date(warn.timestamp).toLocaleDateString('pt-BR')}`,
          value: `**Motivo:** ${warn.reason}\n**ID:** \`${warn.id}\``,
          inline: false
        });
      });
    } else {
      // Mostrar todos os usuários com avisos
      embed.setDescription('Membros com avisos ativos:');
      
      warns.slice(0, 15).forEach(item => {
        embed.addFields({
          name: `<@${item.userId}>`,
          value: `${item.count} aviso(s)`,
          inline: true
        });
      });
    }
    
    await editEmbed(thinkingMsg, embed);
    
  } catch (error) {
    console.error('Erro ao listar avisos:', error);
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao listar avisos: ${error.message}`, '#EF4444');
  }
}

async function handleClearWarns(message, response, guild, thinkingMsg) {
  try {
    const memberIdentifier = response.membro || response.member || response.usuario;
    
    if (!memberIdentifier) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'Membro não especificado!', '#EF4444');
    }
    
    const member = await serverTools.findMember(guild, memberIdentifier);
    if (!member) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'Membro não encontrado!', '#EF4444');
    }
    
    const result = warnManager.clearWarns(guild.id, member.id);
    
    if (!result.success) {
      return await editEmbed(thinkingMsg, '⚠️ Aviso', result.error, '#F59E0B');
    }
    
    const embed = new EmbedBuilder()
      .setTitle('🧹 Avisos Limpos!')
      .setDescription(`${result.removedCount} aviso(s) removido(s) de ${member}!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
  } catch (error) {
    console.error('Erro ao limpar avisos:', error);
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// SISTEMA DE TEMPLATES DE EMBED
// ============================================

async function handleSaveTemplate(message, response, guild, thinkingMsg) {
  try {
    const id = response.id || response.template_id || response.nome;
    const name = response.name || response.nome || id;
    const description = response.description || response.descricao || 'Template personalizado';
    const template = response.template || response.embed;
    
    if (!id || !template) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'ID e template são obrigatórios!', '#EF4444');
    }
    
    const result = embedTemplates.saveTemplate(id, name, description, template);
    
    const embed = new EmbedBuilder()
      .setTitle('💾 Template Salvo!')
      .setDescription(`Template **${name}** foi salvo com sucesso!`)
      .addFields(
        { name: '🆔 ID', value: `\`${id}\``, inline: true },
        { name: '📝 Descrição', value: description, inline: false }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
  } catch (error) {
    console.error('Erro ao salvar template:', error);
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleUseTemplate(message, response, guild, channel, thinkingMsg) {
  try {
    const templateId = response.template || response.template_id || response.id;
    const placeholders = response.placeholders || response.valores || {};
    
    if (!templateId) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'ID do template não especificado!', '#EF4444');
    }
    
    // Adicionar contexto do servidor/usuário
    placeholders.server = guild;
    placeholders.user = message.author;
    placeholders.userId = message.author.id;
    
    const processed = embedTemplates.processTemplate(templateId, placeholders);
    
    if (!processed) {
      return await editEmbed(thinkingMsg, '❌ Erro', `Template "${templateId}" não encontrado!`, '#EF4444');
    }
    
    // Usar handleSendEmbed para enviar
    await handleSendEmbed(message, { embed: processed, ...response }, guild, channel, thinkingMsg);
    
  } catch (error) {
    console.error('Erro ao usar template:', error);
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListTemplates(message, thinkingMsg) {
  try {
    const templates = embedTemplates.listTemplates();
    
    const embed = new EmbedBuilder()
      .setTitle('📚 Templates Disponíveis')
      .setDescription(`${templates.length} templates disponíveis:`)
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    templates.slice(0, 15).forEach(t => {
      embed.addFields({
        name: `${t.name}`,
        value: `🆔 \`${t.id}\`\n${t.description}`,
        inline: true
      });
    });
    
    await editEmbed(thinkingMsg, embed);
    
  } catch (error) {
    console.error('Erro ao listar templates:', error);
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteTemplate(message, response, thinkingMsg) {
  try {
    const templateId = response.id || response.template_id || response.template;
    
    if (!templateId) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'ID do template não especificado!', '#EF4444');
    }
    
    const result = embedTemplates.deleteTemplate(templateId);
    
    if (!result.success) {
      return await editEmbed(thinkingMsg, '❌ Erro', result.error, '#EF4444');
    }
    
    await editEmbed(thinkingMsg, '🗑️ Template Deletado!', `Template \`${templateId}\` foi removido!`, '#10B981');
    
  } catch (error) {
    console.error('Erro ao deletar template:', error);
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// SISTEMA DE CONFIGURAÇÃO DE LOGS
// ============================================

async function handleConfigLog(message, response, guild, thinkingMsg) {
  try {
    // Verificar se é o dono do bot
    const botOwnerId = process.env.BOT_OWNER_ID;
    
    if (message.author.id !== botOwnerId) {
      return await editEmbed(thinkingMsg, '❌ Acesso Negado', 'Apenas o **dono do bot** pode configurar os logs!', '#EF4444');
    }
    
    const logType = response.log_type || response.tipo_log || response.logType;
    const channelId = response.canal || response.channel_id || response.channelId;
    
    // Se for only listing available types
    if (!logType && !channelId) {
      return await handleListLogTypes(message, guild, thinkingMsg);
    }
    
    if (!logType) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'Especifique o tipo de log! Use: `configurar_log tipo_log canal`', '#EF4444');
    }
    
    if (!channelId) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'Especifique o canal! Use: `configurar_log tipo_log #canal`', '#EF4444');
    }
    
    // Buscar canal
    const targetChannel = guild.channels.cache.find(c => 
      c.id === channelId || 
      c.name.toLowerCase() === channelId.toLowerCase() ||
      c.toString() === channelId
    );
    
    if (!targetChannel) {
      return await editEmbed(thinkingMsg, '❌ Erro', `Canal "${channelId}" não encontrado!`, '#EF4444');
    }
    
    // Set log channel
    const result = logConfigManager.setLogChannel(guild.id, logType, targetChannel.id);
    
    if (!result.success) {
      return await editEmbed(thinkingMsg, '❌ Erro', result.error, '#EF4444');
    }
    
    const logInfo = LOG_TYPES[logType];
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Log Configurado!')
      .setDescription(`Logs de **${result.logName}** serão enviados para ${targetChannel}!`)
      .addFields(
        { name: '📝 Tipo', value: `${logInfo.emoji} ${logInfo.name}`, inline: true },
        { name: '📺 Canal', value: `<#${targetChannel.id}>`, inline: true },
        { name: '📋 Descrição', value: logInfo.description, inline: false }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X • Sistema de Logs' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
  } catch (error) {
    console.error('Erro ao configurar log:', error);
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListLogTypes(message, guild, thinkingMsg) {
  try {
    const types = logConfigManager.listLogTypes();
    const currentConfig = logConfigManager.showGuildConfig(guild.id);
    
    const embed = new EmbedBuilder()
      .setTitle('📚 Tipos de Logs Disponíveis')
      .setDescription('Selecione um tipo para configurar o canal de destino:')
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X • Sistema de Logs' })
      .setTimestamp();
    
    // Add available types
    const fields = [];
    types.forEach(t => {
      const isActive = currentConfig.some(c => c.type === t.id);
      fields.push({
        name: `${t.emoji} ${t.name}`,
        value: isActive 
          ? `✅ Configurado` 
          : `${t.description}`,
        inline: true
      });
    });
    
    if (fields.length > 0) {
      embed.addFields(fields);
    }
    
    embed.addFields(
      { name: '💡 Como usar', value: 'Diga: `configurar_log [tipo] #canal`', inline: false }
    );
    
    await editEmbed(thinkingMsg, embed);
    
  } catch (error) {
    console.error('Erro ao listar tipos de log:', error);
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleClearLogsConfig(message, response, guild, thinkingMsg) {
  try {
    // Verificar se é o dono do bot
    const botOwnerId = process.env.BOT_OWNER_ID;
    
    if (message.author.id !== botOwnerId) {
      return await editEmbed(thinkingMsg, '❌ Acesso Negado', 'Apenas  **dono do bot** pode limpar configurações de logs!', '#EF4444');
    }
    
    const logType = response.log_type || response.tipo_log || response.logType;
    
    if (logType) {
    // Remove specific log type
    const result = logConfigManager.removeLogChannel(guild.id, logType);
    
    if (!result.success) {
      return await editEmbed(thinkingMsg, '❌ Erro', result.error, '#EF4444');
    }
    
    const logInfo = LOG_TYPES[logType];
    return await editEmbed(thinkingMsg, '🗑️ Log Removido', `Logs de **${logInfo.name}** foram desativados!`, '#10B981');
  }
    
  // Clear all logs
  const result = logConfigManager.clearAllLogs(guild.id);
  
  const embed = new EmbedBuilder()
    .setTitle('🧹 Configuração Limpa!')
    .setDescription(`${result.removedCount} tipo(s) de log foram limpos!`)
    .setColor('#10B981')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
  
  } catch (error) {
    console.error('Erro ao limpar config:', error);
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// LOG AUTOMÁTICO (chamado por outras funções)
// ============================================

async function sendLogToConfig(guild, logType, data) {
  try {
    await logConfigManager.sendLog(guild.id, logType, data);
  } catch (error) {
    console.error(`Erro ao enviar log ${logType}:`, error.message);
  }
}

export default { name, execute, setClient };
