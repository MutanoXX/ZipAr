/**
 * RIAS GREMORY X AI - Serviço de IA Multi-Provider
 * Suporta: NVIDIA, Pollinations, Modal GLM-5
 * 
 * @version 4.0.0
 * @author MutanoX
 */

import https from 'https';

/**
 * Configurações dos provedores de IA
 */
const PROVIDERS = {
  // Provedor 1: NVIDIA API
  NVIDIA: {
    name: 'NVIDIA API',
    url: 'https://integrate.api.nvidia.com/v1/chat/completions',
    model: 'z-ai/glm5',
    timeout: 120000,
    maxTokens: 16384
  },
  
  // Provedor 2: Pollinations AI (Gratuito)
  POLLINATIONS: {
    name: 'Pollinations AI',
    url: 'https://text.pollinations.ai/openai',
    model: 'openai',
    timeout: 120000,
    maxTokens: 8000
  },
  
  // Provedor 3: Modal GLM-5 (Gratuito)
  MODAL: {
    name: 'Modal GLM-5',
    url: 'https://api.us-west-2.modal.direct/v1/chat/completions',
    model: 'zai-org/GLM-5-FP8',
    timeout: 90000,
    maxTokens: 8000,
    apiKey: 'modalresearch_Vynt1-qxKyqOhJ5sWW90ORHfdISA2ZBNUKOT6UZsxZY'
  }
};

/**
 * Classe AIService - Gerencia múltiplos provedores de IA
 */
class AIService {
  constructor() {
    this.initialized = false;
    this.requestCount = 0;
    this.errorCount = 0;
    this.provider = null;
    this.providerKey = null;
  }

  /**
   * Inicializa o serviço com o provedor configurado
   */
  async initialize() {
    if (this.initialized) return;
    
    const providerId = parseInt(process.env.IA_PROVIDER) || 2;
    
    switch (providerId) {
      case 1:
        this.provider = PROVIDERS.NVIDIA;
        this.providerKey = process.env.NVIDIA_API_KEY;
        console.log('🤖 [AI] Provedor: NVIDIA API (z-ai/glm5)');
        break;
      case 2:
        this.provider = PROVIDERS.POLLINATIONS;
        this.providerKey = null;
        console.log('🤖 [AI] Provedor: Pollinations AI (GPT-OSS 20B)');
        break;
      case 3:
        this.provider = PROVIDERS.MODAL;
        this.providerKey = PROVIDERS.MODAL.apiKey;
        console.log('🤖 [AI] Provedor: Modal GLM-5-FP8');
        break;
      default:
        this.provider = PROVIDERS.POLLINATIONS;
        this.providerKey = null;
        console.log('🤖 [AI] Provedor padrão: Pollinations AI');
    }
    
    this.initialized = true;
  }

  isReady() {
    return this.initialized;
  }

  async ensureInitialized() {
    if (!this.isReady()) {
      await this.initialize();
    }
  }

  /**
   * Analisa e cria estrutura do servidor
   */
  async analyzeServer(serverContext) {
    await this.ensureInitialized();

    const { guildName, userGoal, channels = [], roles = [], mode = 'fresh' } = serverContext;

    console.log(`🔄 [AI] Enviando requisição para ${this.provider.name}...`);
    console.log(`📊 [AI] Contexto: ${channels.length} canais, ${roles.length} cargos`);

    try {
      const startTime = Date.now();
      
      const content = await this.makeRequest(guildName, userGoal, channels, roles, mode);

      const elapsed = Date.now() - startTime;
      console.log(`✅ [AI] Resposta recebida em ${elapsed}ms`);

      if (!content || content.trim() === '') {
        console.error('❌ [AI] Resposta vazia');
        return this.getDefaultPlan(guildName, userGoal);
      }

      console.log(`📝 [AI] Resposta (${content.length} chars)`);

      const jsonResult = this.parseJSONResponse(content);
      
      this.requestCount++;
      console.log('✅ [AI] Análise concluída');
      
      return jsonResult;

    } catch (error) {
      this.errorCount++;
      console.error('❌ [AI] Erro:', error.message);
      
      // Tentar fallback para Pollinations se não for o provedor atual
      if (this.provider !== PROVIDERS.POLLINATIONS) {
        console.log('🔄 [AI] Tentando fallback para Pollinations...');
        this.provider = PROVIDERS.POLLINATIONS;
        this.providerKey = null;
        
        try {
          const content = await this.makeRequest(guildName, userGoal, channels, roles, mode);
          if (content && content.trim()) {
            return this.parseJSONResponse(content);
          }
        } catch (fallbackError) {
          console.error('❌ [AI] Fallback falhou:', fallbackError.message);
        }
      }
      
      return this.getDefaultPlan(guildName, userGoal);
    }
  }

  /**
   * Faz requisição para o provedor atual
   */
  async makeRequest(guildName, userGoal, channels, roles, mode) {
    const prompt = this.buildPrompt(guildName, userGoal, channels, roles, mode);
    
    if (this.provider === PROVIDERS.NVIDIA) {
      return await this.nvidiaRequest(prompt);
    } else if (this.provider === PROVIDERS.POLLINATIONS) {
      return await this.pollinationsRequest(prompt);
    } else if (this.provider === PROVIDERS.MODAL) {
      return await this.modalRequest(prompt);
    }
    
    throw new Error('Provedor não suportado');
  }

  /**
   * Constrói o prompt para geração
   */
  buildPrompt(guildName, userGoal, channels, roles, mode) {
    return `Crie estrutura JSON para servidor Discord.
Nome: ${guildName}
Objetivo: ${userGoal}

Crie 5+ categorias com canais e 5+ cargos. Use emojis em todos os nomes. Use fontes especiais para cargos (𝐀𝐃𝐌𝐈𝐍, 𝐕𝐈𝐏).

Formato JSON obrigatorio:
{"plan":{"name":"","description":""},"changes":{"createRoles":[{"name":"emoji Nome","color":"#FF0000"}],"createCategories":[{"name":"emoji CAT","channels":[{"name":"emoji canal","type":0}]}]},"ai_analysis":{"strengths":[],"suggestions":[]}}

Responda APENAS o JSON completo sem markdown:`;
  }

  /**
   * Requisição para NVIDIA API
   */
  async nvidiaRequest(prompt) {
    const OpenAI = (await import('openai')).default;
    
    const client = new OpenAI({
      baseURL: 'https://integrate.api.nvidia.com/v1',
      apiKey: this.providerKey,
      timeout: PROVIDERS.NVIDIA.timeout
    });
    
    const completion = await client.chat.completions.create({
      model: PROVIDERS.NVIDIA.model,
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.7,
      max_tokens: PROVIDERS.NVIDIA.maxTokens
    });
    
    return completion.choices[0]?.message?.content || '';
  }

  /**
   * Requisição para Pollinations AI (Gratuito)
   */
  async pollinationsRequest(prompt) {
    const body = JSON.stringify({
      messages: [{ role: 'user', content: prompt }],
      seed: Math.floor(Math.random() * 1000000)
    });

    return new Promise((resolve, reject) => {
      const url = new URL(PROVIDERS.POLLINATIONS.url);
      
      const reqOptions = {
        hostname: url.hostname,
        port: 443,
        path: url.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(body)
        },
        timeout: PROVIDERS.POLLINATIONS.timeout
      };
      
      const req = https.request(reqOptions, (res) => {
        let data = '';
        res.on('data', (chunk) => { data += chunk; });
        res.on('end', () => {
          try {
            const parsed = JSON.parse(data);
            const msg = parsed.choices?.[0]?.message;
            let content = msg?.content || msg?.reasoning_content || '';
            content = content.replace(/```json\n?/g, '').replace(/```/g, '').trim();
            resolve(content);
          } catch (e) {
            const jsonMatch = data.match(/\{[\s\S]*"plan"[\s\S]*\}/);
            if (jsonMatch) {
              resolve(jsonMatch[0].replace(/```json\n?/g, '').replace(/```/g, '').trim());
            } else {
              reject(new Error('Falha ao parsear resposta'));
            }
          }
        });
      });
      
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
      req.write(body);
      req.end();
    });
  }

  /**
   * Requisição para Modal GLM-5 (Gratuito)
   */
  async modalRequest(prompt) {
    const body = JSON.stringify({
      model: PROVIDERS.MODAL.model,
      messages: [{ role: 'user', content: prompt }],
      max_tokens: PROVIDERS.MODAL.maxTokens
    });

    return new Promise((resolve, reject) => {
      const url = new URL(PROVIDERS.MODAL.url);
      
      const reqOptions = {
        hostname: url.hostname,
        port: 443,
        path: url.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${PROVIDERS.MODAL.apiKey}`,
          'Content-Length': Buffer.byteLength(body)
        },
        timeout: PROVIDERS.MODAL.timeout
      };
      
      const req = https.request(reqOptions, (res) => {
        let data = '';
        res.on('data', (chunk) => { data += chunk; });
        res.on('end', () => {
          if (res.statusCode !== 200) {
            reject(new Error(`HTTP ${res.statusCode}`));
            return;
          }
          
          try {
            const parsed = JSON.parse(data);
            const msg = parsed.choices?.[0]?.message;
            // Modal usa reasoning_content para o raciocínio e content para a resposta
            let content = msg?.content || msg?.reasoning_content || '';
            content = content.replace(/```json\n?/g, '').replace(/```/g, '').trim();
            
            if (!content) {
              reject(new Error('Resposta vazia do Modal'));
              return;
            }
            
            resolve(content);
          } catch (e) {
            reject(new Error('Falha ao parsear resposta do Modal'));
          }
        });
      });
      
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
      req.write(body);
      req.end();
    });
  }

  /**
   * Retorna plano padrão profissional
   */
  getDefaultPlan(guildName, userGoal) {
    console.log('📋 [AI] Usando plano padrão profissional');
    
    return {
      plan: {
        name: guildName || "Servidor Discord",
        description: `Servidor profissional para: ${userGoal}`,
        themeColor: "#8B5CF6"
      },
      changes: {
        createRoles: [
          { name: "👑 𝐀𝐃𝐌𝐈𝐍", color: "#FF0000", permissions: ["Administrator"], reason: "Administrador" },
          { name: "🛡️ 𝐌𝐎𝐃𝐄𝐑𝐀𝐃𝐎𝐑", color: "#3498DB", permissions: ["ManageMessages", "ManageChannels", "KickMembers", "BanMembers"], reason: "Moderador" },
          { name: "💎 𝐕𝐈𝐏", color: "#FFD700", permissions: ["ViewChannel", "SendMessages", "Connect", "Speak"], reason: "VIP" },
          { name: "🛒 𝐂𝐋𝐈𝐄𝐍𝐓𝐄", color: "#2ECC71", permissions: ["ViewChannel", "SendMessages"], reason: "Cliente" },
          { name: "🤝 𝐏𝐀𝐑𝐂𝐄𝐈𝐑𝐎", color: "#9B59B6", permissions: ["ViewChannel", "SendMessages"], reason: "Parceiro" },
          { name: "⭐ 𝐌𝐄𝐌𝐁𝐑𝐎", color: "#95A5A6", permissions: ["ViewChannel", "SendMessages"], reason: "Membro" }
        ],
        createCategories: [
          {
            name: "📢 │ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐂̧𝐎̃𝐄𝐒",
            channels: [
              { name: "📜・regras", type: 0, topic: "📜 Regras do servidor" },
              { name: "📢・anuncios", type: 0, topic: "📢 Anúncios oficiais" },
              { name: "ℹ️・informacoes", type: 0, topic: "ℹ️ Informações" },
              { name: "🏆・cargos", type: 0, topic: "🏆 Cargos e benefícios" }
            ]
          },
          {
            name: "🛒 │ 𝐕𝐄𝐍𝐃𝐀𝐒",
            channels: [
              { name: "📦・produtos", type: 0, topic: "📦 Produtos disponíveis" },
              { name: "📋・pedidos", type: 0, topic: "📋 Faça seu pedido" },
              { name: "💳・pagamentos", type: 0, topic: "💳 Pagamentos" },
              { name: "⭐・avaliacoes", type: 0, topic: "⭐ Avaliações" }
            ]
          },
          {
            name: "💬 │ 𝐂𝐎𝐌𝐔𝐍𝐈𝐃𝐀𝐃𝐄",
            channels: [
              { name: "💬・chat-geral", type: 0, topic: "💬 Chat geral" },
              { name: "📸・galeria", type: 0, topic: "📸 Galeria de mídias" },
              { name: "🎮・jogos", type: 0, topic: "🎮 Jogos" },
              { name: "🎤・voz-geral", type: 2 }
            ]
          },
          {
            name: "🎫 │ 𝐒𝐔𝐏𝐎𝐑𝐓𝐄",
            channels: [
              { name: "🎫・tickets", type: 0, topic: "🎫 Suporte via ticket" },
              { name: "❓・duvidas", type: 0, topic: "❓ Dúvidas frequentes" },
              { name: "📞・voz-suporte", type: 2 }
            ]
          },
          {
            name: "⚡ │ 𝐀𝐃𝐌𝐈𝐍",
            channels: [
              { name: "🔐・staff-chat", type: 0, topic: "🔐 Chat da staff" },
              { name: "📊・logs", type: 0, topic: "📊 Logs do servidor" },
              { name: "🎙️・voz-staff", type: 2 }
            ]
          },
          {
            name: "🤝 │ 𝐏𝐀𝐑𝐂𝐄𝐈𝐑𝐎𝐒",
            channels: [
              { name: "📢・parcerias", type: 0, topic: "📢 Parceiros" },
              { name: "💬・chat-parceiros", type: 0, topic: "💬 Chat parceiros" }
            ]
          }
        ]
      },
      ai_analysis: {
        strengths: [
          "Estrutura completa com 6 categorias",
          "6 cargos com hierarquia definida",
          "Organização profissional"
        ],
        suggestions: [
          "Configure permissões específicas",
          "Adicione bots de moderação"
        ]
      }
    };
  }

  /**
   * Parse JSON da resposta
   */
  parseJSONResponse(response) {
    if (!response || typeof response !== 'string') {
      throw new Error('Resposta inválida');
    }

    let cleanResponse = response
      .replace(/```json\n?/g, '')
      .replace(/```/g, '')
      .trim();

    const jsonMatch = cleanResponse.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      cleanResponse = jsonMatch[0];
    }

    try {
      const parsed = JSON.parse(cleanResponse);
      return this.validateAndFixStructure(parsed);
    } catch (error) {
      console.log('⚠️ [AI] Tentando corrigir JSON...');
      
      try {
        let fixed = cleanResponse
          .replace(/,\s*]/g, ']')
          .replace(/,\s*}/g, '}');
        
        const parsed = JSON.parse(fixed);
        return this.validateAndFixStructure(parsed);
      } catch (e2) {
        console.error('❌ [AI] Erro no parse:', error.message);
        throw new Error('Falha ao processar JSON');
      }
    }
  }

  /**
   * Valida e corrige a estrutura
   */
  validateAndFixStructure(parsed) {
    if (!parsed.plan) {
      parsed.plan = { name: 'Servidor', description: '', themeColor: '#8B5CF6' };
    }
    
    if (!parsed.changes) {
      parsed.changes = {};
    }
    
    if (!parsed.changes.createRoles || parsed.changes.createRoles.length < 3) {
      console.log('⚠️ [AI] Expandindo cargos...');
      const defaultPlan = this.getDefaultPlan(parsed.plan.name || 'Servidor', '');
      parsed.changes.createRoles = defaultPlan.changes.createRoles;
    }
    
    if (!parsed.changes.createCategories || parsed.changes.createCategories.length < 3) {
      console.log('⚠️ [AI] Expandindo categorias...');
      const defaultPlan = this.getDefaultPlan(parsed.plan.name || 'Servidor', '');
      parsed.changes.createCategories = defaultPlan.changes.createCategories;
    }
    
    if (!parsed.ai_analysis) {
      parsed.ai_analysis = {
        strengths: ['Estrutura gerada pela IA'],
        suggestions: ['Personalize conforme necessário']
      };
    }
    
    return parsed;
  }

  getStats() {
    return {
      initialized: this.initialized,
      provider: this.provider?.name || 'Nenhum',
      requestCount: this.requestCount,
      errorCount: this.errorCount,
      successRate: this.requestCount > 0 
        ? ((this.requestCount - this.errorCount) / this.requestCount * 100).toFixed(2) + '%'
        : 'N/A'
    };
  }

  reset() {
    this.initialized = false;
    this.requestCount = 0;
    this.errorCount = 0;
    console.log('🔄 [AI] Serviço resetado');
  }
}

// Singleton
const aiService = new AIService();

export default aiService;
