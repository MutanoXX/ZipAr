/**
 * MutanoX API Service - VERSÃO 3.0
 * APIs testadas e funcionando
 * 
 * @description Gerencia comunicação com APIs externas
 * @version 3.0.0
 * @author MutanoX Team
 * 
 * @requires Node.js 18+ (fetch nativo)
 */

import fs from 'fs';
import path from 'path';
import { PDFDocument, rgb } from 'pdf-lib';
import { getSecureFilePath, initCache } from '../utils/cacheManager.js';

// fetch e FormData são nativos no Node.js 18+

// ============================================
// CONSTANTES
// ============================================

/** Timeout padrão para requisições (ms) */
const DEFAULT_TIMEOUT = 20000;

/** Timeout para geração de imagem (ms) */
const IMAGE_GEN_TIMEOUT = 60000;

/** Timeout para upload de arquivo (ms) */
const UPLOAD_TIMEOUT = 30000;

/** Máximo de tentativas de retry */
const MAX_RETRIES = 2;

/** URLs das APIs */
const API_URLS = {
  CONSULTAS: 'https://mutano-x-v2.discloud.app/api/consultas',
  IMAGE_SEARCH: 'https://anabot.my.id/api/search/gimage',
  DALLE: 'https://anabot.my.id/api/ai/dalle3',
  COSPLAY: 'https://iyusztempest.my.id/api/anime',
  UPLOAD: 'https://tmpfiles.org/api/v1/upload'
};

/** API Key padrão para APIs públicas */
const DEFAULT_API_KEY = 'freeApikey';

// ============================================
// CLASSE PRINCIPAL
// ============================================

/**
 * Classe de serviço para comunicação com APIs externas
 * @class APIService
 */
class APIService {
  /**
   * Construtor do serviço de API
   */
  constructor() {
    /** Timeout padrão */
    this.timeout = DEFAULT_TIMEOUT;
    
    /** Cache inicializado */
    this.cacheInitialized = false;
    
    /** Estatísticas */
    this.stats = {
      totalRequests: 0,
      successfulRequests: 0,
      failedRequests: 0
    };
    
    // Inicializar cache
    this.initCacheSafely();
  }

  /**
   * Inicializa o cache de forma segura
   * @private
   */
  initCacheSafely() {
    try {
      initCache();
      this.cacheInitialized = true;
    } catch (error) {
      console.warn('⚠️ [APIService] Erro ao inicializar cache:', error.message);
    }
  }

  /**
   * Faz uma requisição com timeout
   * @async
   * @param {string} url - URL da requisição
   * @param {Object} [options={}] - Opções do fetch
   * @param {number} [timeout] - Timeout personalizado
   * @returns {Promise<Response>} Resposta do fetch
   * @throws {Error} Se timeout ou erro de rede
   */
  async fetchWithTimeout(url, options = {}, timeout = this.timeout) {
    // Validação de URL
    if (!url || typeof url !== 'string') {
      throw new Error('URL inválida');
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);
    
    try {
      const response = await fetch(url, { 
        ...options, 
        signal: controller.signal 
      });
      
      clearTimeout(timeoutId);
      this.stats.totalRequests++;
      
      return response;
    } catch (error) {
      clearTimeout(timeoutId);
      
      this.stats.failedRequests++;
      
      if (error.name === 'AbortError') {
        throw new Error(`Timeout: API demorou mais que ${timeout}ms`);
      }
      
      throw error;
    }
  }

  /**
   * Faz uma requisição com retry automático
   * @async
   * @param {string} url - URL da requisição
   * @param {Object} [options={}] - Opções do fetch
   * @param {number} [timeout] - Timeout personalizado
   * @param {number} [retries=MAX_RETRIES] - Número de tentativas
   * @returns {Promise<Response>} Resposta do fetch
   */
  async fetchWithRetry(url, options = {}, timeout = this.timeout, retries = MAX_RETRIES) {
    let lastError;

    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        return await this.fetchWithTimeout(url, options, timeout);
      } catch (error) {
        lastError = error;
        
        console.warn(`⚠️ [API] Tentativa ${attempt}/${retries} falhou para ${url}:`, error.message);
        
        if (attempt < retries) {
          await this.sleep(1000 * attempt);
        }
      }
    }

    throw lastError;
  }

  // ============================================
  // CONSULTAS
  // ============================================

  /**
   * Consulta dados de CNPJ
   * @async
   * @param {string} cnpj - Número do CNPJ
   * @returns {Promise<Object>} Dados do CNPJ
   */
  async consultaCNPJ(cnpj) {
    console.log(`🔍 [CNPJ] Consultando: ${cnpj}`);
    
    // Validar input
    if (!cnpj || typeof cnpj !== 'string') {
      return { status: 'error', error: 'CNPJ inválido ou não informado' };
    }

    try {
      // Sanitizar CNPJ (apenas números)
      const cnpjLimpo = cnpj.replace(/\D/g, '');
      
      if (cnpjLimpo.length !== 14) {
        return { status: 'error', error: 'CNPJ deve ter 14 dígitos' };
      }

      const response = await this.fetchWithRetry(
        `${API_URLS.CONSULTAS}?type=cnpj&value=${cnpjLimpo}`
      );

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      this.stats.successfulRequests++;
      console.log(`✅ [CNPJ] Resposta recebida`);
      
      return data;

    } catch (error) {
      console.error('❌ [CNPJ]:', error.message);
      return { status: 'error', error: error.message };
    }
  }

  /**
   * Consulta dados de CPF
   * @async
   * @param {string} cpf - Número do CPF
   * @returns {Promise<Object>} Dados do CPF
   */
  async consultaCPF(cpf) {
    console.log(`🔍 [CPF] Consultando: ${cpf}`);
    
    // Validar input
    if (!cpf || typeof cpf !== 'string') {
      return { status: 'error', error: 'CPF inválido ou não informado' };
    }

    try {
      // Sanitizar CPF (apenas números)
      const cpfLimpo = cpf.replace(/\D/g, '');
      
      if (cpfLimpo.length !== 11) {
        return { status: 'error', error: 'CPF deve ter 11 dígitos' };
      }

      const response = await this.fetchWithRetry(
        `${API_URLS.CONSULTAS}?type=cpf&value=${cpfLimpo}&base=credlink`
      );

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      this.stats.successfulRequests++;
      console.log(`✅ [CPF] Resposta recebida`);
      
      return data;

    } catch (error) {
      console.error('❌ [CPF]:', error.message);
      return { status: 'error', error: error.message };
    }
  }

  // ============================================
  // IMAGENS
  // ============================================

  /**
   * Busca imagens no Google
   * @async
   * @param {string} query - Termo de busca
   * @param {number} [timeout=25000] - Timeout da requisição
   * @returns {Promise<Object>} Resultado da busca
   */
  async searchGoogleImage(query, timeout = 25000) {
    console.log(`🖼️ [Imagem] Buscando: ${query}`);
    
    // Validar input
    if (!query || typeof query !== 'string') {
      return { success: false, error: 'Termo de busca inválido ou não informado' };
    }

    // Sanitizar query
    const safeQuery = query.trim().substring(0, 200);

    try {
      const url = `${API_URLS.IMAGE_SEARCH}?query=${encodeURIComponent(safeQuery)}&apikey=${DEFAULT_API_KEY}`;
      
      const response = await this.fetchWithRetry(url, {}, timeout);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      if (data.success && data.data?.result?.length > 0) {
        this.stats.successfulRequests++;
        console.log(`✅ [Imagem] ${data.data.result.length} imagens encontradas`);
        return { success: true, data: data.data };
      }
      
      return { success: false, error: 'Nenhuma imagem encontrada' };

    } catch (error) {
      console.error('❌ [Imagem]:', error.message);
      return { success: false, error: error.message };
    }
  }

  /**
   * Busca vídeo de cosplay anime
   * @async
   * @param {number} [timeout=25000] - Timeout da requisição
   * @returns {Promise<Object>} Dados do vídeo
   */
  async getCosplayVideo(timeout = 25000) {
    console.log(`🎬 [Cosplay] Buscando vídeo...`);

    try {
      const response = await this.fetchWithRetry(
        `${API_URLS.COSPLAY}?feature=jjcosplay`,
        {},
        timeout
      );

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      if (data.status === 'success' && data.media?.url) {
        this.stats.successfulRequests++;
        console.log(`✅ [Cosplay] Vídeo encontrado`);
        return data;
      }
      
      return { status: 'error', error: 'Vídeo não encontrado' };

    } catch (error) {
      console.error('❌ [Cosplay]:', error.message);
      return { status: 'error', error: error.message };
    }
  }

  /**
   * Gera imagem com DALL-E
   * @async
   * @param {string} prompt - Descrição da imagem
   * @param {string} [negative='low quality'] - Prompt negativo
   * @param {string} [apikey=DEFAULT_API_KEY] - API Key
   * @returns {Promise<Object>} Resultado da geração
   */
  async dalleXlloraText2image(prompt, negative = 'low quality', apikey = DEFAULT_API_KEY) {
    console.log(`🎨 [Dalle] Gerando: ${prompt?.substring(0, 30)}...`);
    
    // Validar input
    if (!prompt || typeof prompt !== 'string') {
      return { success: false, error: 'Prompt inválido ou não informado' };
    }

    // Sanitizar inputs
    const safePrompt = prompt.trim().substring(0, 1000);
    const safeNegative = (negative || 'low quality').trim().substring(0, 200);

    try {
      const url = `${API_URLS.DALLE}?prompt=${encodeURIComponent(safePrompt)}&negative=${encodeURIComponent(safeNegative)}&apikey=${apikey}`;
      
      const response = await this.fetchWithRetry(url, {}, IMAGE_GEN_TIMEOUT);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      if (data.success !== false && (data.result || data.data?.result)) {
        this.stats.successfulRequests++;
        console.log(`✅ [Dalle] Imagem gerada`);
        return { success: true, data: { result: data.result || data.data?.result } };
      }
      
      return { success: false, error: data.error || 'Falha na geração' };

    } catch (error) {
      console.error('❌ [Dalle]:', error.message);
      return { success: false, error: error.message };
    }
  }

  // ============================================
  // ARQUIVOS
  // ============================================

  /**
   * Faz upload de arquivo para tmpfiles.org
   * @async
   * @param {string} filePath - Caminho do arquivo
   * @returns {Promise<Object>} Resultado do upload
   */
  async uploadFile(filePath) {
    console.log(`📤 [Upload] Enviando arquivo...`);
    
    // Validar input
    if (!filePath || typeof filePath !== 'string') {
      return { success: false, error: 'Caminho de arquivo inválido' };
    }

    try {
      // Verificar se arquivo existe
      if (!fs.existsSync(filePath)) {
        return { success: false, error: 'Arquivo não encontrado' };
      }

      // Verificar tamanho do arquivo (máximo 10MB)
      const stats = fs.statSync(filePath);
      const maxSize = 10 * 1024 * 1024; // 10MB
      if (stats.size > maxSize) {
        return { success: false, error: 'Arquivo muito grande (máximo 10MB)' };
      }

      // Usar FormData nativo do Node.js 18+
      const fileBuffer = fs.readFileSync(filePath);
      let filename = path.basename(filePath);
      
      // tmpfiles.org não aceita .md, .json, etc - converter para .txt
      const ext = path.extname(filename).toLowerCase();
      const blockedExtensions = ['.md', '.json', '.js', '.ts', '.jsx', '.tsx', '.css', '.html', '.xml', '.yaml', '.yml'];
      if (blockedExtensions.includes(ext)) {
        filename = filename.replace(ext, '.txt');
        console.log(`📤 [Upload] Extensão ${ext} → .txt para compatibilidade`);
      }
      
      const form = new FormData();
      form.append('file', new Blob([fileBuffer]), filename);

      const response = await this.fetchWithTimeout(API_URLS.UPLOAD, {
        method: 'POST',
        body: form,
      }, UPLOAD_TIMEOUT);

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const data = await response.json();
      
      if (data.status === 'success') {
        // Converter URL para download direto
        const downloadUrl = data.data.url.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
        
        this.stats.successfulRequests++;
        console.log(`✅ [Upload] ${downloadUrl}`);
        
        return { success: true, url: downloadUrl };
      }
      
      return { success: false, error: data.message || 'Falha no upload' };

    } catch (error) {
      console.error('❌ [Upload]:', error.message);
      return { success: false, error: error.message };
    }
  }

  /**
   * Gera um arquivo PDF
   * @async
   * @param {string} filename - Nome do arquivo
   * @param {string} content - Conteúdo do PDF
   * @returns {Promise<string>} Caminho do arquivo gerado
   * @throws {Error} Se a geração falhar
   */
  async generatePDF(filename, content) {
    console.log(`📄 [PDF] Gerando: ${filename}`);
    
    // Validar inputs
    if (!filename || typeof filename !== 'string') {
      throw new Error('Nome de arquivo inválido');
    }

    if (!content || typeof content !== 'string') {
      throw new Error('Conteúdo inválido');
    }

    // Garantir inicialização do cache
    if (!this.cacheInitialized) {
      this.initCacheSafely();
    }

    try {
      const pdfDoc = await PDFDocument.create();
      let page = pdfDoc.addPage();
      const { width, height } = page.getSize();
      
      const fontSize = 11;
      const margin = 50;
      const lineHeight = fontSize + 4;
      
      const lines = content.split('\n');
      let y = height - margin;

      for (const line of lines) {
        // Verificar se precisa de nova página
        if (y < margin + lineHeight) {
          page = pdfDoc.addPage();
          y = height - margin;
        }
        
        // Truncar linha se muito longa
        const safeLine = line.substring(0, 100);
        
        try {
          page.drawText(safeLine, { 
            x: margin, 
            y, 
            size: fontSize, 
            color: rgb(0, 0, 0) 
          });
        } catch (textError) {
          // Ignorar caracteres inválidos
          const cleanLine = safeLine.replace(/[^\x00-\x7F]/g, '?');
          page.drawText(cleanLine, { 
            x: margin, 
            y, 
            size: fontSize, 
            color: rgb(0, 0, 0) 
          });
        }
        
        y -= lineHeight;
      }

      const pdfBytes = await pdfDoc.save();
      
      // Sanitizar nome do arquivo
      const safeFilename = filename.endsWith('.pdf') ? filename : `${filename}.pdf`;
      const filePath = getSecureFilePath(safeFilename);
      
      fs.writeFileSync(filePath, pdfBytes);
      
      console.log(`✅ [PDF] Criado: ${filePath}`);
      return filePath;

    } catch (error) {
      console.error('❌ [PDF]:', error.message);
      
      // Fallback: criar PDF simples
      try {
        const fallbackPath = path.join('/tmp', filename.endsWith('.pdf') ? filename : `${filename}.pdf`);
        const pdfDoc = await PDFDocument.create();
        const page = pdfDoc.addPage();
        
        // Limitar conteúdo
        const safeContent = content.substring(0, 2000).replace(/[^\x00-\x7F]/g, '?');
        
        page.drawText(safeContent, { 
          x: 50, 
          y: 750, 
          size: 10, 
          color: rgb(0, 0, 0) 
        });
        
        fs.writeFileSync(fallbackPath, await pdfDoc.save());
        
        console.log(`✅ [PDF] Fallback criado: ${fallbackPath}`);
        return fallbackPath;
        
      } catch (fallbackError) {
        throw new Error(`Falha ao criar PDF: ${error.message}`);
      }
    }
  }

  /**
   * Gera um arquivo de texto
   * @async
   * @param {string} filename - Nome do arquivo
   * @param {string} content - Conteúdo do arquivo
   * @returns {Promise<string>} Caminho do arquivo gerado
   */
  async generateTextFile(filename, content) {
    console.log(`📝 [Arquivo] Gerando: ${filename}`);
    
    // Validar inputs
    if (!filename || typeof filename !== 'string') {
      throw new Error('Nome de arquivo inválido');
    }

    if (!content || typeof content !== 'string') {
      throw new Error('Conteúdo inválido');
    }

    // Garantir inicialização do cache
    if (!this.cacheInitialized) {
      this.initCacheSafely();
    }

    try {
      const filePath = getSecureFilePath(filename);
      fs.writeFileSync(filePath, content);
      
      console.log(`✅ [Arquivo] Criado: ${filePath}`);
      return filePath;

    } catch (error) {
      console.error('❌ [Arquivo]:', error.message);
      
      // Fallback: usar /tmp
      try {
        const fallbackPath = path.join('/tmp', filename);
        fs.writeFileSync(fallbackPath, content);
        return fallbackPath;
      } catch (fallbackError) {
        throw new Error(`Falha ao criar arquivo: ${error.message}`);
      }
    }
  }

  // ============================================
  // UTILITÁRIOS
  // ============================================

  /**
   * Obtém estatísticas do serviço
   * @returns {Object} Estatísticas
   */
  getStats() {
    return {
      ...this.stats,
      cacheInitialized: this.cacheInitialized
    };
  }

  /**
   * Função auxiliar para sleep
   * @param {number} ms - Milissegundos
   * @returns {Promise<void>}
   */
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ============================================
// EXPORT
// ============================================
export default new APIService();
