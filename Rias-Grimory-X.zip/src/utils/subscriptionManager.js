/**
 * RIAS GREMORY X AI - Subscription & Tier Management System
 * Sistema de Gerenciamento de Assinaturas e Tiers
 * 
 * @version 1.0.0
 * @description Gerencia assinaturas, benefícios e limites por tier
 */

import fs from 'fs';
import path from 'path';

// Diretório para dados de assinatura - usa process.cwd() para compatibilidade com deploy
const SUBSCRIPTION_DIR = path.join(process.cwd(), 'Storage', 'subscriptions');

// Garantir diretório
function ensureDir(dir) {
  try {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  } catch (e) {
    console.error('Erro ao criar diretório:', e.message);
  }
}

ensureDir(SUBSCRIPTION_DIR);

/**
 * Configurações de Tiers
 */
const TIER_CONFIGS = {
  free: {
    id: 'free',
    name: 'Gratuito',
    emoji: '🆓',
    color: '#808080',
    price: 0,
    
    // Limites de uso
    limits: {
      requestsPerDay: 50,
      requestsPerHour: 10,
      requestsPerMinute: 3,
      cooldownMs: 5000, // 5 segundos entre requisições
      
      // Ferramentas
      eventAutomations: 3,
      scheduledAutomations: 0,
      imageGenerations: 5,
      dalleGenerations: 2,
      embeds: 'basic',
      webhooks: 0,
      
      // IA
      maxTokens: 4096,
      maxContextMessages: 5,
      priorityQueue: false,
      streaming: false,
      
      // Recursos
      advancedAgents: false,
      customPrompts: false,
      analytics: false,
      backup: false,
      
      // Suporte
      supportPriority: 'low',
      supportChannels: 1
    },
    
    // Provedores de IA disponíveis
    providers: ['g4f'], // Apenas G4F para gratuitos
    
    // Features habilitadas
    features: {
      basicChannels: true,
      basicRoles: true,
      basicModeration: true,
      basicEmbeds: true,
      googleImages: true,
      
      // Desabilitados
      eventAutomations: 'limited',
      dalleHD: false,
      webhooks: false,
      customBot: false,
      analytics: false,
      prioritySupport: false,
      api: false,
      whiteLabel: false
    },
    
    // Mensagem motivacional
    upgradeMessage: '✨ Desbloqueie mais recursos com uma assinatura! Use `/premium` para saber mais.'
  },
  
  basic: {
    id: 'basic',
    name: 'Básico',
    emoji: '⭐',
    color: '#10B981',
    price: 9.90,
    priceYearly: 99.90,
    
    limits: {
      requestsPerDay: 500,
      requestsPerHour: 50,
      requestsPerMinute: 10,
      cooldownMs: 1000,
      
      eventAutomations: 15,
      scheduledAutomations: 5,
      imageGenerations: 50,
      dalleGenerations: 20,
      embeds: 'advanced',
      webhooks: 3,
      
      maxTokens: 8192,
      maxContextMessages: 10,
      priorityQueue: true,
      streaming: true,
      
      advancedAgents: true,
      customPrompts: false,
      analytics: true,
      backup: false,
      
      supportPriority: 'medium',
      supportChannels: 3
    },
    
    providers: ['nvidia', 'g4f'],
    
    features: {
      basicChannels: true,
      basicRoles: true,
      basicModeration: true,
      basicEmbeds: true,
      googleImages: true,
      eventAutomations: true,
      dalleHD: false,
      webhooks: true,
      customBot: false,
      analytics: true,
      prioritySupport: false,
      api: false,
      whiteLabel: false
    },
    
    upgradeMessage: '🚀 Upgrade para Premium e desbloqueie recursos ilimitados!'
  },
  
  premium: {
    id: 'premium',
    name: 'Premium',
    emoji: '💎',
    color: '#8B5CF6',
    price: 29.90,
    priceYearly: 299.90,
    
    limits: {
      requestsPerDay: 2000,
      requestsPerHour: 200,
      requestsPerMinute: 30,
      cooldownMs: 500,
      
      eventAutomations: 100,
      scheduledAutomations: 20,
      imageGenerations: 200,
      dalleGenerations: 100,
      embeds: 'full',
      webhooks: 10,
      
      maxTokens: 16384,
      maxContextMessages: 20,
      priorityQueue: true,
      streaming: true,
      
      advancedAgents: true,
      customPrompts: true,
      analytics: true,
      backup: true,
      
      supportPriority: 'high',
      supportChannels: -1 // Ilimitado
    },
    
    providers: ['nvidia', 'g4f'],
    
    features: {
      basicChannels: true,
      basicRoles: true,
      basicModeration: true,
      basicEmbeds: true,
      googleImages: true,
      eventAutomations: true,
      dalleHD: true,
      webhooks: true,
      customBot: true,
      analytics: true,
      prioritySupport: true,
      api: true,
      whiteLabel: false
    },
    
    upgradeMessage: '👑 Upgrade para Ultimate e tenha tudo ilimitado!'
  },
  
  ultimate: {
    id: 'ultimate',
    name: 'Ultimate',
    emoji: '👑',
    color: '#F59E0B',
    price: 99.90,
    priceYearly: 999.90,
    
    limits: {
      requestsPerDay: -1, // Ilimitado
      requestsPerHour: -1,
      requestsPerMinute: -1,
      cooldownMs: 0,
      
      eventAutomations: -1,
      scheduledAutomations: -1,
      imageGenerations: -1,
      dalleGenerations: -1,
      embeds: 'full',
      webhooks: -1,
      
      maxTokens: 32768,
      maxContextMessages: 50,
      priorityQueue: true,
      streaming: true,
      
      advancedAgents: true,
      customPrompts: true,
      analytics: true,
      backup: true,
      
      supportPriority: 'highest',
      supportChannels: -1
    },
    
    providers: ['nvidia', 'g4f'],
    
    features: {
      basicChannels: true,
      basicRoles: true,
      basicModeration: true,
      basicEmbeds: true,
      googleImages: true,
      eventAutomations: true,
      dalleHD: true,
      webhooks: true,
      customBot: true,
      analytics: true,
      prioritySupport: true,
      api: true,
      whiteLabel: true
    },
    
    upgradeMessage: null // Não há upgrade
  }
};

/**
 * Classe de Gerenciamento de Assinaturas
 */
class SubscriptionManager {
  constructor() {
    this.subscriptions = new Map(); // userId -> subscription data
    this.usage = new Map(); // userId -> usage data
    this.cache = new Map(); // Cache de verificações
  }

  /**
   * Obtém o tier de um usuário
   */
  getUserTier(userId, guildId = null) {
    const subscription = this.getSubscription(userId);
    
    if (subscription && subscription.active && this.isSubscriptionValid(subscription)) {
      return subscription.tier;
    }
    
    return 'free';
  }

  /**
   * Obtém a assinatura de um usuário
   */
  getSubscription(userId) {
    // Verificar cache
    if (this.subscriptions.has(userId)) {
      return this.subscriptions.get(userId);
    }
    
    // Carregar do disco
    const filePath = path.join(SUBSCRIPTION_DIR, `${userId}.json`);
    
    if (fs.existsSync(filePath)) {
      try {
        const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        this.subscriptions.set(userId, data);
        return data;
      } catch (e) {
        console.error('Erro ao carregar assinatura:', e);
      }
    }
    
    return null;
  }

  /**
   * Cria ou atualiza assinatura
   */
  setSubscription(userId, tier, options = {}) {
    const tierConfig = TIER_CONFIGS[tier];
    
    if (!tierConfig) {
      throw new Error(`Tier inválido: ${tier}`);
    }
    
    const now = new Date();
    const expiresAt = options.expiresAt || new Date(now.getTime() + (options.durationDays || 30) * 24 * 60 * 60 * 1000);
    
    const subscription = {
      userId,
      tier,
      active: true,
      createdAt: now.toISOString(),
      expiresAt: expiresAt.toISOString(),
      paymentId: options.paymentId || null,
      guildId: options.guildId || null,
      metadata: options.metadata || {}
    };
    
    // Salvar
    this.subscriptions.set(userId, subscription);
    this.saveSubscription(userId);
    
    console.log(`✅ [Subscription] ${userId} agora é ${tierConfig.emoji} ${tierConfig.name}`);
    
    return subscription;
  }

  /**
   * Salva assinatura no disco
   */
  saveSubscription(userId) {
    const subscription = this.subscriptions.get(userId);
    
    if (subscription) {
      const filePath = path.join(SUBSCRIPTION_DIR, `${userId}.json`);
      fs.writeFileSync(filePath, JSON.stringify(subscription, null, 2));
    }
  }

  /**
   * Verifica se a assinatura é válida
   */
  isSubscriptionValid(subscription) {
    if (!subscription || !subscription.active) {
      return false;
    }
    
    const expiresAt = new Date(subscription.expiresAt);
    
    return expiresAt > new Date();
  }

  /**
   * Cancela assinatura
   */
  cancelSubscription(userId) {
    const subscription = this.subscriptions.get(userId);
    
    if (subscription) {
      subscription.active = false;
      subscription.canceledAt = new Date().toISOString();
      this.saveSubscription(userId);
      
      console.log(`❌ [Subscription] ${userId} cancelou a assinatura`);
      return true;
    }
    
    return false;
  }

  /**
   * Verifica limite de uso
   */
  checkLimit(userId, limitType) {
    const tier = this.getUserTier(userId);
    const tierConfig = TIER_CONFIGS[tier];
    const limit = tierConfig.limits[limitType];
    
    // -1 = ilimitado
    if (limit === -1) {
      return { allowed: true, remaining: -1 };
    }
    
    // Obter uso atual
    const usage = this.getUsage(userId, limitType);
    
    if (usage >= limit) {
      return {
        allowed: false,
        remaining: 0,
        limit,
        used: usage,
        resetAt: this.getResetTime(limitType),
        upgradeMessage: tierConfig.upgradeMessage
      };
    }
    
    return {
      allowed: true,
      remaining: limit - usage,
      limit,
      used: usage
    };
  }

  /**
   * Registra uso
   */
  recordUsage(userId, usageType, amount = 1) {
    const key = `${userId}_${usageType}`;
    const now = new Date();
    const today = now.toISOString().split('T')[0];
    
    if (!this.usage.has(key)) {
      this.usage.set(key, {
        daily: {},
        hourly: {},
        total: 0
      });
    }
    
    const usage = this.usage.get(key);
    
    // Incrementar diário
    usage.daily[today] = (usage.daily[today] || 0) + amount;
    
    // Incrementar total
    usage.total += amount;
    
    // Limpar dados antigos
    const daysToKeep = 30;
    const cutoffDate = new Date(now.getTime() - daysToKeep * 24 * 60 * 60 * 1000);
    
    for (const date of Object.keys(usage.daily)) {
      if (new Date(date) < cutoffDate) {
        delete usage.daily[date];
      }
    }
    
    return usage;
  }

  /**
   * Obtém uso atual
   */
  getUsage(userId, usageType) {
    const key = `${userId}_${usageType}`;
    const usage = this.usage.get(key);
    
    if (!usage) {
      return 0;
    }
    
    const today = new Date().toISOString().split('T')[0];
    return usage.daily[today] || 0;
  }

  /**
   * Obtém tempo de reset do limite
   */
  getResetTime(limitType) {
    const now = new Date();
    
    if (limitType.includes('Hour')) {
      // Reset na próxima hora
      return new Date(now.getTime() + (60 - now.getMinutes()) * 60 * 1000);
    }
    
    // Reset à meia-noite
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    
    return tomorrow;
  }

  /**
   * Obtém configuração completa do tier
   */
  getTierConfig(tier) {
    return TIER_CONFIGS[tier] || TIER_CONFIGS.free;
  }

  /**
   * Obtém todos os tiers disponíveis
   */
  getAllTiers() {
    return Object.values(TIER_CONFIGS).map(t => ({
      id: t.id,
      name: t.name,
      emoji: t.emoji,
      color: t.color,
      price: t.price,
      priceYearly: t.priceYearly,
      features: t.features,
      limits: t.limits
    }));
  }

  /**
   * Verifica se feature está disponível
   */
  hasFeature(userId, feature) {
    const tier = this.getUserTier(userId);
    const tierConfig = TIER_CONFIGS[tier];
    
    const featureValue = tierConfig.features[feature];
    
    if (typeof featureValue === 'boolean') {
      return featureValue;
    }
    
    if (featureValue === 'limited') {
      // Verificar se ainda tem uso disponível
      const limitCheck = this.checkLimit(userId, feature);
      return limitCheck.allowed;
    }
    
    return !!featureValue;
  }

  /**
   * Obtém mensagem de upgrade
   */
  getUpgradeMessage(userId) {
    const tier = this.getUserTier(userId);
    const tierConfig = TIER_CONFIGS[tier];
    
    return tierConfig.upgradeMessage;
  }

  /**
   * Incrementa uso e verifica se pode continuar
   */
  async useFeature(userId, feature, amount = 1) {
    // Verificar se pode usar
    const limitCheck = this.checkLimit(userId, feature);
    
    if (!limitCheck.allowed) {
      return {
        success: false,
        ...limitCheck
      };
    }
    
    // Registrar uso
    this.recordUsage(userId, feature, amount);
    
    return {
      success: true,
      ...limitCheck,
      remaining: limitCheck.remaining - amount
    };
  }

  /**
   * Estatísticas de assinatura
   */
  getSubscriptionStats(userId) {
    const subscription = this.getSubscription(userId);
    const tier = this.getUserTier(userId);
    const tierConfig = TIER_CONFIGS[tier];
    
    return {
      tier,
      tierName: tierConfig.name,
      tierEmoji: tierConfig.emoji,
      active: subscription?.active || false,
      expiresAt: subscription?.expiresAt || null,
      daysRemaining: subscription ?
        Math.max(0, Math.ceil((new Date(subscription.expiresAt) - new Date()) / (24 * 60 * 60 * 1000))) : 0,
      usage: {
        requestsToday: this.getUsage(userId, 'requestsPerDay'),
        requestsLimit: tierConfig.limits.requestsPerDay
      }
    };
  }
}

// Singleton
const subscriptionManager = new SubscriptionManager();

export { TIER_CONFIGS, SubscriptionManager };
export default subscriptionManager;
