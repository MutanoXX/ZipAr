/**
 * Rias-Grimory-X - Sistema de Configuração de Logs
 * VERSÃO 1.0 - Gerenciamento de canais de log por servidor
 * 
 * Funcionalidades:
 * - Dono do bot define canais para cada tipo de log
 * - Logs automáticos para eventos
 * - Configuração por servidor
 * 
 * Tipos de Log:
 * - novos_assinantes - Novos assinantes/planos ativados
 * - avisos - Sistema de warn (avisos dados/removidos)
 * - punicoes - Ban, kick, mute aplicados
 * - automacoes - Automações executadas
 * - moderação - Ações de moderação em geral
 * - entrada_saida - Membros entrando/saindo
 * - comandos - Comandos usados
 * - erros - Erros do sistema
 */

import fs from 'fs';
import path from 'path';
import { EmbedBuilder } from 'discord.js';

// Diretório para salvar configurações - usa process.cwd() para compatibilidade com deploy
const LOGS_CONFIG_DIR = path.join(process.cwd(), 'Storage', 'logs-config');

// Garantir que o diretório existe
try {
  if (!fs.existsSync(LOGS_CONFIG_DIR)) {
    fs.mkdirSync(LOGS_CONFIG_DIR, { recursive: true });
  }
} catch (e) {
  console.error('Erro ao criar diretório de logs-config:', e.message);
}

// Tipos de log disponíveis
const LOG_TYPES = {
  'novos_assinantes': {
    name: 'Novos Assinantes',
    description: 'Quando alguém ativa um plano/assinatura',
    emoji: '💎',
    color: '#FFD700'
  },
  'avisos': {
    name: 'Avisos (Warn)',
    description: 'Avisos dados e removidos de membros',
    emoji: '⚠️',
    color: '#F59E0B'
  },
  'punicoes': {
    name: 'Punições',
    description: 'Ban, kick, mute aplicados',
    emoji: '🔨',
    color: '#EF4444'
  },
  'automacoes': {
    name: 'Automações',
    description: 'Automações executadas automaticamente',
    emoji: '🤖',
    color: '#8B5CF6'
  },
  'moderacao': {
    name: 'Moderação',
    description: 'Ações de moderação em geral',
    emoji: '🛡️',
    color: '#3B82F6'
  },
  'entrada_saida': {
    name: 'Entrada/Saída',
    description: 'Membros entrando e saindo do servidor',
    emoji: '👋',
    color: '#10B981'
  },
  'comandos': {
    name: 'Comandos',
    description: 'Comandos slash usados no servidor',
    emoji: '⚡',
    color: '#06B6D4'
  },
  'erros': {
    name: 'Erros',
    description: 'Erros e problemas do sistema',
    emoji: '❌',
    color: '#DC2626'
  }
};

/**
 * Classe para gerenciar configurações de logs
 */
class LogConfigManager {
  constructor() {
    this.configs = new Map();
    this.client = null;
    this.botOwnerId = null;
    this.loadAllConfigs();
  }

  /**
   * Define o client do Discord
   */
  setClient(client) {
    this.client = client;
    this.botOwnerId = process.env.BOT_OWNER_ID;
  }

  /**
   * Carrega todas as configurações salvas
   */
  loadAllConfigs() {
    try {
      const files = fs.readdirSync(LOGS_CONFIG_DIR).filter(f => f.endsWith('.json'));
      
      for (const file of files) {
        try {
          const data = JSON.parse(fs.readFileSync(path.join(LOGS_CONFIG_DIR, file), 'utf8'));
          const guildId = file.replace('.json', '');
          this.configs.set(guildId, data);
        } catch (e) {
          console.error(`Erro ao carregar config de logs ${file}:`, e.message);
        }
      }
      
      console.log(`✅ [LogConfig] ${this.configs.size} configurações de logs carregadas`);
    } catch (e) {
      console.error('Erro ao carregar configurações de logs:', e.message);
    }
  }

  /**
   * Verifica se o usuário é o dono do bot
   */
  isBotOwner(userId) {
    return userId === this.botOwnerId;
  }

  /**
   * Obtém a configuração de logs de um servidor
   */
  getGuildConfig(guildId) {
    if (!this.configs.has(guildId)) {
      // Criar configuração padrão vazia
      this.configs.set(guildId, {
        guildId,
        channels: {},
        enabled: true,
        createdAt: Date.now()
      });
    }
    return this.configs.get(guildId);
  }

  /**
   * Define o canal para um tipo de log
   */
  setLogChannel(guildId, logType, channelId) {
    if (!LOG_TYPES[logType]) {
      return { success: false, error: `Tipo de log inválido. Tipos disponíveis: ${Object.keys(LOG_TYPES).join(', ')}` };
    }
    
    const config = this.getGuildConfig(guildId);
    config.channels[logType] = channelId;
    config.updatedAt = Date.now();
    
    this.saveGuildConfig(guildId);
    
    return { 
      success: true, 
      logType,
      channelId,
      logName: LOG_TYPES[logType].name
    };
  }

  /**
   * Remove o canal de um tipo de log
   */
  removeLogChannel(guildId, logType) {
    const config = this.getGuildConfig(guildId);
    
    if (!config.channels[logType]) {
      return { success: false, error: 'Este tipo de log não está configurado' };
    }
    
    delete config.channels[logType];
    config.updatedAt = Date.now();
    
    this.saveGuildConfig(guildId);
    
    return { success: true, logType };
  }

  /**
   * Limpa todas as configurações de log de um servidor
   */
  clearAllLogs(guildId) {
    const config = this.getGuildConfig(guildId);
    const count = Object.keys(config.channels).length;
    
    config.channels = {};
    config.updatedAt = Date.now();
    
    this.saveGuildConfig(guildId);
    
    return { success: true, removedCount: count };
  }

  /**
   * Obtém o canal de um tipo de log
   */
  getLogChannel(guildId, logType) {
    const config = this.getGuildConfig(guildId);
    return config.channels[logType] || null;
  }

  /**
   * Salva a configuração de um servidor
   */
  saveGuildConfig(guildId) {
    const config = this.configs.get(guildId);
    const filePath = path.join(LOGS_CONFIG_DIR, `${guildId}.json`);
    
    try {
      fs.writeFileSync(filePath, JSON.stringify(config, null, 2));
    } catch (e) {
      console.error(`Erro ao salvar config de logs ${guildId}:`, e.message);
    }
  }

  /**
   * Envia um log para o canal configurado
   */
  async sendLog(guildId, logType, embedOrData) {
    const channelId = this.getLogChannel(guildId, logType);
    
    if (!channelId || !this.client) {
      return { sent: false, reason: 'Canal não configurado ou client não definido' };
    }
    
    try {
      const guild = this.client.guilds.cache.get(guildId);
      if (!guild) {
        return { sent: false, reason: 'Servidor não encontrado' };
      }
      
      const channel = guild.channels.cache.get(channelId);
      if (!channel) {
        return { sent: false, reason: 'Canal não encontrado' };
      }
      
      // Criar embed se for dados simples
      let embed;
      if (embedOrData instanceof EmbedBuilder) {
        embed = embedOrData;
      } else {
        const logInfo = LOG_TYPES[logType];
        embed = new EmbedBuilder()
          .setTitle(`${logInfo.emoji} ${logInfo.name}`)
          .setDescription(embedOrData.description || embedOrData.message || 'Log registrado')
          .setColor(logInfo.color)
          .setTimestamp();
        
        // Adicionar fields se existirem
        if (embedOrData.fields) {
          embed.addFields(embedOrData.fields);
        }
        
        // Adicionar footer
        if (embedOrData.footer !== false) {
          embed.setFooter({ text: '💎 Rias-Grimory-X • Logs' });
        }
      }
      
      await channel.send({ embeds: [embed] });
      
      return { sent: true, channelId };
      
    } catch (e) {
      console.error(`Erro ao enviar log ${logType} para ${guildId}:`, e.message);
      return { sent: false, reason: e.message };
    }
  }

  /**
   * Lista todos os tipos de log disponíveis
   */
  listLogTypes() {
    return Object.entries(LOG_TYPES).map(([id, info]) => ({
      id,
      name: info.name,
      description: info.description,
      emoji: info.emoji
    }));
  }

  /**
   * Mostra a configuração atual de um servidor
   */
  showGuildConfig(guildId) {
    const config = this.getGuildConfig(guildId);
    const result = [];
    
    for (const [logType, channelId] of Object.entries(config.channels)) {
      const logInfo = LOG_TYPES[logType];
      if (logInfo) {
        result.push({
          type: logType,
          name: logInfo.name,
          emoji: logInfo.emoji,
          channelId
        });
      }
    }
    
    return result;
  }

  /**
   * Log rápido para novos assinantes
   */
  async logNewSubscriber(guildId, userId, planName, duration) {
    return await this.sendLog(guildId, 'novos_assinantes', {
      description: `**Novo assinante!** 🎉`,
      fields: [
        { name: '👤 Usuário', value: `<@${userId}>`, inline: true },
        { name: '💎 Plano', value: planName, inline: true },
        { name: '⏰ Duração', value: duration, inline: true }
      ]
    });
  }

  /**
   * Log rápido para avisos
   */
  async logWarn(guildId, userId, moderatorId, reason, totalWarns) {
    return await this.sendLog(guildId, 'avisos', {
      description: `**Aviso registrado!** ⚠️`,
      fields: [
        { name: '👤 Usuário', value: `<@${userId}>`, inline: true },
        { name: '👮 Moderador', value: `<@${moderatorId}>`, inline: true },
        { name: '📊 Total', value: `${totalWarns} aviso(s)`, inline: true },
        { name: '📝 Motivo', value: reason.substring(0, 500), inline: false }
      ]
    });
  }

  /**
   * Log rápido para punições
   */
  async logPunishment(guildId, userId, moderatorId, type, reason) {
    const typeNames = {
      'ban': 'Banimento',
      'kick': 'Expulsão',
      'mute': 'Silenciamento',
      'unban': 'Desbanimento',
      'unmute': 'Desmutamento'
    };
    
    return await this.sendLog(guildId, 'punicoes', {
      description: `**${typeNames[type] || type} aplicado!** 🔨`,
      fields: [
        { name: '👤 Usuário', value: `<@${userId}>`, inline: true },
        { name: '👮 Moderador', value: `<@${moderatorId}>`, inline: true },
        { name: '⚖️ Tipo', value: typeNames[type] || type, inline: true },
        { name: '📝 Motivo', value: reason || 'Não especificado', inline: false }
      ]
    });
  }

  /**
   * Log para entrada/saída de membros
   */
  async logMemberEvent(guildId, userId, event, memberCount) {
    const isJoin = event === 'join';
    
    return await this.sendLog(guildId, 'entrada_saida', {
      description: isJoin ? '**Novo membro!** 👋' : '**Membro saiu** 👋',
      fields: [
        { name: '👤 Usuário', value: `<@${userId}>`, inline: true },
        { name: '👥 Total de membros', value: `${memberCount}`, inline: true }
      ]
    });
  }

  /**
   * Log para erros
   */
  async logError(guildId, error, context) {
    return await this.sendLog(guildId, 'erros', {
      description: `**Erro detectado!** ❌`,
      fields: [
        { name: '📝 Contexto', value: context || 'Desconhecido', inline: false },
        { name: '⚠️ Erro', value: `\`\`\`${error.substring(0, 1000)}\`\`\``, inline: false }
      ]
    });
  }
}

// Singleton
const logConfigManager = new LogConfigManager();
export default logConfigManager;
export { LOG_TYPES };
