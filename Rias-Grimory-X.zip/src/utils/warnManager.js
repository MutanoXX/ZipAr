/**
 * Rias-Grimory-X - Sistema de Avisos (Warn System)
 * VERSÃO 1.0 - Gerenciamento de avisos para membros
 * 
 * Funcionalidades:
 * - Adicionar avisos (warn)
 * - Remover avisos (unwarn)
 * - Ver histórico de avisos
 * - Ações automáticas por quantidade de avisos
 */

import fs from 'fs';
import path from 'path';

// Diretório para salvar avisos - usa process.cwd() para compatibilidade com deploy
const WARNS_DIR = path.join(process.cwd(), 'Storage', 'warns');

// Garantir que o diretório existe
try {
  if (!fs.existsSync(WARNS_DIR)) {
    fs.mkdirSync(WARNS_DIR, { recursive: true });
  }
} catch (e) {
  console.error('Erro ao criar diretório de warns:', e.message);
}

/**
 * Classe para gerenciar avisos
 */
class WarnManager {
  constructor() {
    this.warns = new Map();
    this.loadAllWarns();
  }

  /**
   * Carrega todos os avisos salvos
   */
  loadAllWarns() {
    try {
      const files = fs.readdirSync(WARNS_DIR).filter(f => f.endsWith('.json'));
      
      for (const file of files) {
        try {
          const data = JSON.parse(fs.readFileSync(path.join(WARNS_DIR, file), 'utf8'));
          this.warns.set(file.replace('.json', ''), data);
        } catch (e) {
          console.error(`Erro ao carregar ${file}:`, e.message);
        }
      }
      
      console.log(`✅ [WarnManager] ${this.warns.size} arquivos de avisos carregados`);
    } catch (e) {
      console.error('Erro ao carregar avisos:', e.message);
    }
  }

  /**
   * Obtém a chave do arquivo para um servidor
   */
  getGuildKey(guildId) {
    return `guild_${guildId}`;
  }

  /**
   * Salva os avisos de um servidor
   */
  saveGuildWarns(guildId) {
    const key = this.getGuildKey(guildId);
    const filePath = path.join(WARNS_DIR, `${key}.json`);
    
    try {
      fs.writeFileSync(filePath, JSON.stringify(this.warns.get(key) || {}, null, 2));
    } catch (e) {
      console.error(`Erro ao salvar avisos de ${guildId}:`, e.message);
    }
  }

  /**
   * Adiciona um aviso a um membro
   */
  addWarn(guildId, userId, moderatorId, reason, expiresInDays = null) {
    const key = this.getGuildKey(guildId);
    
    if (!this.warns.has(key)) {
      this.warns.set(key, {});
    }
    
    const guildWarns = this.warns.get(key);
    
    if (!guildWarns[userId]) {
      guildWarns[userId] = [];
    }
    
    const warn = {
      id: Date.now().toString(),
      moderatorId,
      reason,
      timestamp: Date.now(),
      expiresAt: expiresInDays ? Date.now() + (expiresInDays * 24 * 60 * 60 * 1000) : null
    };
    
    guildWarns[userId].push(warn);
    this.saveGuildWarns(guildId);
    
    return {
      success: true,
      warnId: warn.id,
      totalWarns: guildWarns[userId].length,
      warn
    };
  }

  /**
   * Remove um aviso específico
   */
  removeWarn(guildId, userId, warnId) {
    const key = this.getGuildKey(guildId);
    const guildWarns = this.warns.get(key);
    
    if (!guildWarns || !guildWarns[userId]) {
      return { success: false, error: 'Nenhum aviso encontrado' };
    }
    
    const index = guildWarns[userId].findIndex(w => w.id === warnId);
    
    if (index === -1) {
      return { success: false, error: 'Aviso não encontrado' };
    }
    
    guildWarns[userId].splice(index, 1);
    
    if (guildWarns[userId].length === 0) {
      delete guildWarns[userId];
    }
    
    this.saveGuildWarns(guildId);
    
    return { success: true, remainingWarns: guildWarns[userId]?.length || 0 };
  }

  /**
   * Remove todos os avisos de um membro
   */
  clearWarns(guildId, userId) {
    const key = this.getGuildKey(guildId);
    const guildWarns = this.warns.get(key);
    
    if (!guildWarns || !guildWarns[userId]) {
      return { success: false, error: 'Nenhum aviso encontrado' };
    }
    
    const count = guildWarns[userId].length;
    delete guildWarns[userId];
    this.saveGuildWarns(guildId);
    
    return { success: true, removedCount: count };
  }

  /**
   * Obtém todos os avisos de um membro
   */
  getMemberWarns(guildId, userId) {
    const key = this.getGuildKey(guildId);
    const guildWarns = this.warns.get(key);
    
    if (!guildWarns || !guildWarns[userId]) {
      return [];
    }
    
    // Filtrar avisos expirados
    const now = Date.now();
    const activeWarns = guildWarns[userId].filter(w => !w.expiresAt || w.expiresAt > now);
    
    // Se houve remoção de expirados, salvar
    if (activeWarns.length !== guildWarns[userId].length) {
      guildWarns[userId] = activeWarns;
      this.saveGuildWarns(guildId);
    }
    
    return activeWarns;
  }

  /**
   * Obtém contagem de avisos de um membro
   */
  getWarnCount(guildId, userId) {
    return this.getMemberWarns(guildId, userId).length;
  }

  /**
   * Obtém todos os avisos de um servidor
   */
  getGuildWarns(guildId) {
    const key = this.getGuildKey(guildId);
    const guildWarns = this.warns.get(key) || {};
    
    const result = [];
    for (const [userId, warns] of Object.entries(guildWarns)) {
      if (warns.length > 0) {
        result.push({ userId, warns, count: warns.length });
      }
    }
    
    return result;
  }

  /**
   * Verifica se deve executar ação automática
   */
  checkAutoAction(guildId, userId, actions = {}) {
    const count = this.getWarnCount(guildId, userId);
    
    // Default actions: 3 warns = mute, 5 warns = kick, 10 warns = ban
    const defaultActions = {
      3: 'mute',
      5: 'kick',
      10: 'ban'
    };
    
    const autoActions = { ...defaultActions, ...actions };
    
    if (autoActions[count]) {
      return { action: autoActions[count], warnCount: count };
    }
    
    return null;
  }
}

// Singleton
const warnManager = new WarnManager();
export default warnManager;
