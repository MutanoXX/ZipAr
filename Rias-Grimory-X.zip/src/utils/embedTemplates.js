/**
 * Rias-Grimory-X - Sistema de Templates de Embed TURBINADO
 * VERSÃO 2.0 - Embeds profissionais e decorados
 * 
 * Funcionalidades:
 * - Templates pré-configurados lindos
 * - Salvar embeds como templates
 * - Carregar templates salvos
 * - Placeholders dinâmicos
 */

import fs from 'fs';
import path from 'path';

// Diretório para salvar templates - usa process.cwd() para compatibilidade com deploy
const TEMPLATES_DIR = path.join(process.cwd(), 'Storage', 'embed-templates');

// Garantir que o diretório existe
try {
  if (!fs.existsSync(TEMPLATES_DIR)) {
    fs.mkdirSync(TEMPLATES_DIR, { recursive: true });
  }
} catch (e) {
  console.error('Erro ao criar diretório de templates:', e.message);
}

// RIAS IMAGE DEFAULT
const RIAS_THUMBNAIL = 'https://i.imgur.com/eEsH9NF.jpeg';
const RIAS_FOOTER = '🌹 Rias Gremory • Power of Destruction';

// Templates padrão do sistema - TURBINADOS
const DEFAULT_TEMPLATES = {
  'boas-vindas': {
    name: '🌟 Boas-vindas Premium',
    description: 'Embed de boas-vindas elegante para novos membros',
    template: {
      title: '✨ Bem-vindo(a) ao {server}!',
      description: 'Olá {user}! Seja muito bem-vindo(a) à nossa família! 🎉\n\n💎 Aqui você encontrará uma comunidade incrível cheia de oportunidades!',
      color: '#9333EA',
      thumbnail: '{user.avatar}',
      image: 'https://i.imgur.com/eEsH9NF.jpeg',
      fields: [
        { name: '📋 Leia as Regras', value: 'Confira nosso canal de regras para uma boa convivência!', inline: true },
        { name: '💬 Participe dos Chats', value: 'Converse com outros membros em nossos canais!', inline: true },
        { name: '👥 Membros Ativos', value: '{server.members} membros na comunidade!', inline: true },
        { name: '🎁 Benefícios Exclusivos', value: 'Cargos especiais • Eventos • Muito mais!', inline: false }
      ],
      footer: { text: RIAS_FOOTER, icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  },
  
  'anuncio': {
    name: '📢 Anúncio Importante',
    description: 'Embed profissional para anúncios oficiais',
    template: {
      title: '📢 ANÚNCIO OFICIAL',
      description: '{content}',
      color: '#F59E0B',
      thumbnail: RIAS_THUMBNAIL,
      fields: [
        { name: '📅 Publicado em', value: '{date}', inline: true },
        { name: '⏰ Horário', value: '{time}', inline: true },
        { name: '👤 Por', value: '{author}', inline: true }
      ],
      footer: { text: '📢 Equipe de Administração • {server}', icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  },
  
  'regras': {
    name: '📜 Regras do Servidor',
    description: 'Embed completo para exibir regras',
    template: {
      title: '📜 REGRAS DO SERVIDOR',
      description: '⚠️ **Leia atentamente todas as regras abaixo!**\nViolações podem resultar em punições severas.',
      color: '#DC2626',
      thumbnail: RIAS_THUMBNAIL,
      fields: [
        { name: '1️⃣ Respeito Mútuo', value: 'Trate todos com educação e respeito. Ofensas, discriminação e assédio não serão tolerados.', inline: false },
        { name: '2️⃣ Sem Spam/Flood', value: 'Não envie mensagens repetitivas, links suspeitos ou faça flood nos canais.', inline: false },
        { name: '3️⃣ Sem Divulgação', value: 'Não divulgue outros servidores, produtos ou serviços sem autorização prévia.', inline: false },
        { name: '4️⃣ Conteúdo Apropriado', value: 'Mantenha conteúdo adequado para todos os públicos. NSFW apenas em canais específicos.', inline: false },
        { name: '5️⃣ Uso Correto dos Canais', value: 'Utilize cada canal para seu propósito específico. Leia as descrições!', inline: false },
        { name: '6️⃣ Contas Alternativas', value: 'Contas secundárias sem autorização resultarão em ban permanente.', inline: false }
      ],
      footer: { text: '⚖️ Violações resultarão em: Warn → Mute → Kick → Ban', icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  },
  
  'punicao': {
    name: '⚔️ Punição Aplicada',
    description: 'Embed para anunciar punições de forma clara',
    template: {
      title: '⚔️ {punishment_type}',
      description: 'Uma punição foi aplicada com sucesso!',
      color: '#DC2626',
      thumbnail: RIAS_THUMBNAIL,
      fields: [
        { name: '👤 Usuário Punido', value: '{user}', inline: true },
        { name: '🔨 Tipo de Punição', value: '{punishment_type}', inline: true },
        { name: '📝 Motivo', value: '{reason}', inline: false },
        { name: '👮 Moderador Responsável', value: '{moderator}', inline: true },
        { name: '📅 Data', value: '{date} às {time}', inline: true }
      ],
      footer: { text: '⚖️ Justiça foi aplicada • {server}', icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  },
  
  'aviso': {
    name: '⚠️ Aviso (Warn)',
    description: 'Embed para registrar avisos a membros',
    template: {
      title: '⚠️ AVISO REGISTRADO',
      description: '{user} recebeu uma advertência!',
      color: '#F59E0B',
      thumbnail: RIAS_THUMBNAIL,
      fields: [
        { name: '📝 Motivo do Aviso', value: '{reason}', inline: false },
        { name: '👮 Moderador', value: '{moderator}', inline: true },
        { name: '📊 Total de Avisos', value: '{warn_count}/10', inline: true },
        { name: '⚠️ Ações Automáticas', value: '**3 avisos** = Mute\n**5 avisos** = Kick\n**10 avisos** = Ban', inline: false }
      ],
      footer: { text: RIAS_FOOTER, icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  },
  
  'sucesso': {
    name: '✅ Operação Bem-sucedida',
    description: 'Embed para confirmar operações com estilo',
    template: {
      title: '✅ {title}',
      description: '{content}',
      color: '#10B981',
      thumbnail: RIAS_THUMBNAIL,
      fields: [
        { name: '⏰ Concluído em', value: '{timestamp}', inline: true }
      ],
      footer: { text: '✨ Operação realizada com sucesso!', icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  },
  
  'erro': {
    name: '❌ Erro',
    description: 'Embed para exibir mensagens de erro',
    template: {
      title: '❌ Ocorreu um Erro!',
      description: '{error_message}',
      color: '#DC2626',
      thumbnail: RIAS_THUMBNAIL,
      fields: [
        { name: '💡 O que fazer?', value: '• Tente novamente em alguns segundos\n• Verifique se você tem permissão\n• Contate um administrador se persistir', inline: false }
      ],
      footer: { text: RIAS_FOOTER, icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  },
  
  'info': {
    name: 'ℹ️ Informação',
    description: 'Embed para informações gerais',
    template: {
      title: 'ℹ️ {title}',
      description: '{content}',
      color: '#3B82F6',
      thumbnail: RIAS_THUMBNAIL,
      footer: { text: RIAS_FOOTER, icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  },
  
  'ticket': {
    name: '🎫 Sistema de Tickets',
    description: 'Embed para criação de tickets',
    template: {
      title: '🎫 TICKET CRIADO',
      description: 'Seu ticket foi aberto com sucesso!',
      color: '#8B5CF6',
      thumbnail: RIAS_THUMBNAIL,
      fields: [
        { name: '📋 ID do Ticket', value: '`{ticket_id}`', inline: true },
        { name: '📌 Categoria', value: '{category}', inline: true },
        { name: '👥 Acesso', value: 'Apenas você e a equipe podem ver este canal', inline: false },
        { name: '⚠️ Atenção', value: '• Não abuse do sistema\n• Seja claro em sua solicitação\n• Aguarde pacientemente o atendimento', inline: false }
      ],
      footer: { text: '🎫 Aguarde o atendimento • {server}', icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  },
  
  'giveaway': {
    name: '🎉 Sorteio Premium',
    description: 'Embed profissional para sorteios',
    template: {
      title: '🎉 GIVEAWAY!',
      description: '### Prêmio: **{prize}**\n\nReaja com 🎉 para participar!',
      color: '#FFD700',
      thumbnail: RIAS_THUMBNAIL,
      image: 'https://i.imgur.com/eEsH9NF.jpeg',
      fields: [
        { name: '⏰ Termina em', value: '{duration}', inline: true },
        { name: '👥 Participantes', value: '{participants}', inline: true },
        { name: '👤 Organizado por', value: '{organizer}', inline: true },
        { name: '🎁 Número de Ganhadores', value: '{winners}', inline: true }
      ],
      footer: { text: '🎉 Boa sorte a todos!', icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  },
  
  'assinatura': {
    name: '💎 Assinatura',
    description: 'Embed para exibir planos de assinatura',
    template: {
      title: '💎 SISTEMA DE ASSINATURA',
      description: 'Escolha o plano ideal para você e tenha acesso completo ao bot!',
      color: '#8B5CF6',
      thumbnail: RIAS_THUMBNAIL,
      fields: [
        { name: '📅 Plano Semanal', value: '**R$ 20,00**\n7 dias de acesso completo', inline: true },
        { name: '⭐ Plano Mensal', value: '**R$ 29,59**\n30 dias de acesso\n_Melhor custo-benefício!_', inline: true },
        { name: '🔄 Renovação Automática', value: 'Ative para nunca perder o acesso!\nRenova automaticamente 1h antes de expirar.', inline: false }
      ],
      footer: { text: '💎 Rias Gremory • Sistema Premium', icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  },
  
  'cobranca': {
    name: '💳 Cobrança/Pagamento',
    description: 'Embed para enviar dados de pagamento',
    template: {
      title: '💳 Pagamento Solicitado',
      description: 'Segue abaixo os dados para pagamento via PIX:',
      color: '#10B981',
      thumbnail: RIAS_THUMBNAIL,
      fields: [
        { name: '💰 Valor', value: '**R$ {valor}**', inline: true },
        { name: '📋 Descrição', value: '{descricao}', inline: true },
        { name: '🔐 Código PIX', value: '```\n{pix_code}\n```', inline: false },
        { name: '⏰ Expira em', value: '{expiracao}', inline: true }
      ],
      footer: { text: '💎 Após o pagamento, seu acesso será liberado!', icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  },
  
  'nivel': {
    name: '🏆 Nível/XP',
    description: 'Embed para exibir progresso de nível',
    template: {
      title: '🏆 Card de Nível',
      description: '### {user}',
      color: '#8B5CF6',
      thumbnail: '{user.avatar}',
      fields: [
        { name: '📊 Nível Atual', value: '**{nivel}**', inline: true },
        { name: '⭐ XP Total', value: '{xp_total}', inline: true },
        { name: '📈 Progresso', value: '{xp_atual}/{xp_proximo} XP', inline: false },
        { name: '🏅 Rank no Servidor', value: '#{rank}', inline: true }
      ],
      footer: { text: '🏆 Continue interagindo para subir de nível!', icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  },
  
  'economia': {
    name: '💰 Economia/Saldo',
    description: 'Embed para exibir saldo e transações',
    template: {
      title: '💰 Carteira Digital',
      description: '### {user}',
      color: '#10B981',
      thumbnail: '{user.avatar}',
      fields: [
        { name: '💵 Saldo Disponível', value: '**R$ {saldo}**', inline: true },
        { name: '🏦 Saldo Bancário', value: 'R$ {banco}', inline: true },
        { name: '📊 Total', value: 'R$ {total}', inline: true }
      ],
      footer: { text: '💰 Sistema de Economia • {server}', icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  },
  
  'moderacao': {
    name: '🛡️ Ação de Moderação',
    description: 'Embed para logs de moderação',
    template: {
      title: '🛡️ LOG DE MODERAÇÃO',
      description: 'Uma ação de moderação foi executada.',
      color: '#DC2626',
      thumbnail: RIAS_THUMBNAIL,
      fields: [
        { name: '👤 Usuário', value: '{user}', inline: true },
        { name: '🆔 ID', value: '{user_id}', inline: true },
        { name: '⚖️ Ação', value: '{acao}', inline: true },
        { name: '📝 Motivo', value: '{motivo}', inline: false },
        { name: '👮 Moderador', value: '{moderator}', inline: true },
        { name: '📅 Data', value: '{date} às {time}', inline: true }
      ],
      footer: { text: '🛡️ Sistema de Moderação • {server}', icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  },
  
  'comando': {
    name: '⚡ Comando Executado',
    description: 'Embed para confirmar execução de comandos',
    template: {
      title: '⚡ {comando}',
      description: '{descricao}',
      color: '#8B5CF6',
      thumbnail: RIAS_THUMBNAIL,
      fields: [
        { name: '📊 Resultado', value: '{resultado}', inline: false },
        { name: '👤 Executado por', value: '{user}', inline: true },
        { name: '⏱️ Tempo', value: '{tempo}s', inline: true }
      ],
      footer: { text: RIAS_FOOTER, icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  },
  
  'staff': {
    name: '🔐 Aviso da Staff',
    description: 'Embed para comunicados oficiais da equipe',
    template: {
      title: '🔐 COMUNICADO DA STAFF',
      description: '{mensagem}',
      color: '#DC143C',
      thumbnail: RIAS_THUMBNAIL,
      image: 'https://i.imgur.com/eEsH9NF.jpeg',
      fields: [
        { name: '📢 Enviado por', value: '{author}', inline: true },
        { name: '📅 Data', value: '{date}', inline: true },
        { name: '⚠️ Importância', value: '{importancia}', inline: true }
      ],
      footer: { text: '🔐 Equipe de Administração • {server}', icon_url: RIAS_THUMBNAIL },
      timestamp: true
    }
  }
};

/**
 * Classe para gerenciar templates
 */
class EmbedTemplates {
  constructor() {
    this.templates = new Map();
    this.loadTemplates();
  }

  /**
   * Carrega templates salvos e padrões
   */
  loadTemplates() {
    // Carregar templates padrão
    for (const [id, template] of Object.entries(DEFAULT_TEMPLATES)) {
      this.templates.set(id, template);
    }
    
    // Carregar templates personalizados
    try {
      const files = fs.readdirSync(TEMPLATES_DIR).filter(f => f.endsWith('.json'));
      
      for (const file of files) {
        try {
          const data = JSON.parse(fs.readFileSync(path.join(TEMPLATES_DIR, file), 'utf8'));
          this.templates.set(data.id || file.replace('.json', ''), data);
        } catch (e) {
          console.error(`Erro ao carregar template ${file}:`, e.message);
        }
      }
      
      console.log(`✅ [EmbedTemplates] ${this.templates.size} templates carregados`);
    } catch (e) {
      console.error('Erro ao carregar templates:', e.message);
    }
  }

  /**
   * Obtém um template por ID
   */
  getTemplate(id) {
    return this.templates.get(id);
  }

  /**
   * Lista todos os templates
   */
  listTemplates() {
    const list = [];
    for (const [id, template] of this.templates) {
      list.push({
        id,
        name: template.name || id,
        description: template.description || 'Sem descrição'
      });
    }
    return list;
  }

  /**
   * Salva um novo template personalizado
   */
  saveTemplate(id, name, description, template) {
    const data = {
      id,
      name,
      description,
      template,
      createdAt: Date.now(),
      isCustom: true
    };
    
    this.templates.set(id, data);
    
    const filePath = path.join(TEMPLATES_DIR, `${id}.json`);
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    
    return data;
  }

  /**
   * Deleta um template personalizado
   */
  deleteTemplate(id) {
    // Não pode deletar templates padrão
    if (DEFAULT_TEMPLATES[id]) {
      return { success: false, error: 'Não é possível deletar templates padrão' };
    }
    
    if (!this.templates.has(id)) {
      return { success: false, error: 'Template não encontrado' };
    }
    
    this.templates.delete(id);
    
    const filePath = path.join(TEMPLATES_DIR, `${id}.json`);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
    
    return { success: true };
  }

  /**
   * Processa placeholders em um template
   */
  processTemplate(templateId, placeholders = {}) {
    const templateData = this.templates.get(templateId);
    
    if (!templateData) {
      return null;
    }
    
    const template = templateData.template || templateData;
    
    // Processar placeholders
    const processString = (str, data) => {
      if (!str || typeof str !== 'string') return str;
      
      let result = str;
      
      // Placeholders padrão
      const now = new Date();
      const defaultPlaceholders = {
        '{date}': now.toLocaleDateString('pt-BR'),
        '{time}': now.toLocaleTimeString('pt-BR'),
        '{timestamp}': `<t:${Math.floor(now.getTime() / 1000)}:R>`,
        '{server.members}': data.server?.memberCount?.toString() || 'N/A',
        '{server.name}': data.server?.name || 'Servidor',
        '{server}': data.server?.name || 'Servidor',
        '{server.icon}': data.server?.iconURL?.({ dynamic: true, size: 256 }) || RIAS_THUMBNAIL,
        '{user.tag}': data.user?.tag || 'Usuário',
        '{user.name}': data.user?.username || 'Usuário',
        '{user.avatar}': data.user?.displayAvatarURL?.({ dynamic: true, size: 256 }) || RIAS_THUMBNAIL,
        '{user.id}': data.user?.id || data.userId || '',
        '{user}': data.user?.toString?.() || `<@${data.userId}>` || 'Usuário'
      };
      
      const allPlaceholders = { ...defaultPlaceholders, ...placeholders };
      
      for (const [key, value] of Object.entries(allPlaceholders)) {
        // Converter para string se necessário
        const strValue = String(value);
        result = result.replace(new RegExp(key.replace(/[{}]/g, '\\$&'), 'g'), strValue);
      }
      
      return result;
    };
    
    // Processar template inteiro
    const processed = {
      ...template,
      title: processString(template.title, placeholders),
      description: processString(template.description, placeholders)
    };
    
    // Processar fields
    if (template.fields && Array.isArray(template.fields)) {
      processed.fields = template.fields.map(field => ({
        ...field,
        name: processString(field.name, placeholders),
        value: processString(field.value, placeholders)
      }));
    }
    
    // Processar footer
    if (template.footer) {
      processed.footer = {
        ...template.footer,
        text: processString(template.footer.text, placeholders)
      };
      if (template.footer.icon_url) {
        processed.footer.iconURL = processString(template.footer.icon_url, placeholders);
      }
    }
    
    // Processar thumbnail
    if (template.thumbnail) {
      processed.thumbnail = processString(template.thumbnail, placeholders);
    }
    
    // Processar image
    if (template.image) {
      processed.image = processString(template.image, placeholders);
    }
    
    // Processar author
    if (template.author) {
      processed.author = {
        ...template.author,
        name: processString(template.author.name, placeholders)
      };
    }
    
    return processed;
  }
}

// Singleton
const embedTemplates = new EmbedTemplates();
export default embedTemplates;
