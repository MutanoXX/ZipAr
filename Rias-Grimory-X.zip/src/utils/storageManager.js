/**
 * RIAS GREMORY X AI - Storage Manager
 * Sistema de armazenamento em arquivos JSON
 * 
 * @version 1.0.0
 * @author MutanoX
 * 
 * Estrutura:
 * Storage/
 * ├── usage.json          - Controle de uso por servidor
 * ├── webhooks.json       - Webhooks registrados
 * ├── updates.json        - Sistema de updates
 * ├── plans.json          - Planos salvos
 * ├── automations.json    - Automações ativas
 * └── settings.json       - Configurações gerais
 */

import fs from 'fs';
import path from 'path';

// Caminho base para Storage - usa process.cwd() para compatibilidade com deploy
const STORAGE_PATH = path.join(process.cwd(), 'Storage');

// Arquivos de dados
const FILES = {
  USAGE: 'usage.json',
  WEBHOOKS: 'webhooks.json',
  UPDATES: 'updates.json',
  PLANS: 'plans.json',
  AUTOMATIONS: 'automations.json',
  SETTINGS: 'settings.json',
  SERVERS: 'servers.json'
};

// Cache em memória
const cache = new Map();

/**
 * Garante que o diretório Storage existe
 */
function ensureStorageDir() {
  if (!fs.existsSync(STORAGE_PATH)) {
    fs.mkdirSync(STORAGE_PATH, { recursive: true });
    console.log('✅ [Storage] Diretório criado:', STORAGE_PATH);
  }
}

/**
 * Obtém o caminho completo do arquivo
 */
function getFilePath(filename) {
  return path.join(STORAGE_PATH, filename);
}

/**
 * Lê um arquivo JSON
 */
function readJSON(filename) {
  const filePath = getFilePath(filename);
  
  // Verificar cache primeiro
  if (cache.has(filename)) {
    return cache.get(filename);
  }
  
  try {
    if (fs.existsSync(filePath)) {
      const data = fs.readFileSync(filePath, 'utf8');
      const parsed = JSON.parse(data);
      cache.set(filename, parsed);
      return parsed;
    }
  } catch (error) {
    console.error(`❌ [Storage] Erro ao ler ${filename}:`, error.message);
  }
  
  return null;
}

/**
 * Escreve em um arquivo JSON
 */
function writeJSON(filename, data) {
  ensureStorageDir();
  const filePath = getFilePath(filename);
  
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    cache.set(filename, data);
    return true;
  } catch (error) {
    console.error(`❌ [Storage] Erro ao escrever ${filename}:`, error.message);
    return false;
  }
}

// =====================================================
// SISTEMA DE USO (Usage)
// =====================================================

/**
 * Obtém dados de uso
 */
export function getUsageData() {
  return readJSON(FILES.USAGE) || {
    servers: {},
    lastUpdated: Date.now()
  };
}

/**
 * Salva dados de uso
 */
export function saveUsageData(data) {
  data.lastUpdated = Date.now();
  return writeJSON(FILES.USAGE, data);
}

/**
 * Obtém uso de um servidor específico
 */
export function getServerUsage(guildId) {
  const data = getUsageData();
  return data.servers[guildId] || {
    freeUses: 0,
    maxFreeUses: 3,
    usedByUsers: {},
    createdAt: Date.now()
  };
}

/**
 * Incrementa uso de um servidor
 * @returns {{ success: boolean, usesLeft: number, message: string }}
 */
export function incrementServerUsage(guildId, userId, isPremium = false) {
  const data = getUsageData();
  
  if (!data.servers[guildId]) {
    data.servers[guildId] = {
      freeUses: 0,
      maxFreeUses: 3,
      usedByUsers: {},
      createdAt: Date.now()
    };
  }
  
  const server = data.servers[guildId];
  
  // Premium tem uso ilimitado
  if (isPremium) {
    // Registrar uso mas não limitar
    if (!server.usedByUsers[userId]) {
      server.usedByUsers[userId] = { uses: 0, lastUse: null };
    }
    server.usedByUsers[userId].uses++;
    server.usedByUsers[userId].lastUse = Date.now();
    saveUsageData(data);
    return { success: true, usesLeft: Infinity, message: 'Uso premium ilimitado' };
  }
  
  // Verificar limite gratuito
  if (server.freeUses >= server.maxFreeUses) {
    return { 
      success: false, 
      usesLeft: 0, 
      message: 'Limite de 3 usos gratuitos atingido para este servidor. Assine para uso ilimitado!' 
    };
  }
  
  // Verificar limite por usuário (1 uso por usuário por servidor no plano free)
  if (!server.usedByUsers[userId]) {
    server.usedByUsers[userId] = { uses: 0, lastUse: null };
  }
  
  if (server.usedByUsers[userId].uses >= 1) {
    return {
      success: false,
      usesLeft: 0,
      message: 'Você já usou seu 1 uso gratuito neste servidor. Assine para mais!'
    };
  }
  
  // Incrementar uso
  server.freeUses++;
  server.usedByUsers[userId].uses++;
  server.usedByUsers[userId].lastUse = Date.now();
  
  saveUsageData(data);
  
  const usesLeft = server.maxFreeUses - server.freeUses;
  return { 
    success: true, 
    usesLeft, 
    message: `Uso registrado. Restam ${usesLeft} usos gratuitos neste servidor.` 
  };
}

/**
 * Verifica se servidor pode usar (sem incrementar)
 */
export function canUseServer(guildId, userId, isPremium = false) {
  if (isPremium) return { canUse: true, usesLeft: Infinity };
  
  const server = getServerUsage(guildId);
  
  if (server.freeUses >= server.maxFreeUses) {
    return { canUse: false, usesLeft: 0 };
  }
  
  if (server.usedByUsers[userId]?.uses >= 1) {
    return { canUse: false, usesLeft: 0 };
  }
  
  return { canUse: true, usesLeft: server.maxFreeUses - server.freeUses };
}

// =====================================================
// SISTEMA DE WEBHOOKS
// =====================================================

/**
 * Obtém dados de webhooks
 */
export function getWebhooksData() {
  return readJSON(FILES.WEBHOOKS) || {
    webhooks: {},
    lastUpdated: Date.now()
  };
}

/**
 * Salva dados de webhooks
 */
export function saveWebhooksData(data) {
  data.lastUpdated = Date.now();
  return writeJSON(FILES.WEBHOOKS, data);
}

/**
 * Registra um webhook
 */
export function registerWebhook(guildId, channelId, webhookUrl, type = 'updates') {
  const data = getWebhooksData();
  
  if (!data.webhooks[guildId]) {
    data.webhooks[guildId] = {};
  }
  
  data.webhooks[guildId][channelId] = {
    url: webhookUrl,
    type: type,
    createdAt: Date.now()
  };
  
  return saveWebhooksData(data);
}

/**
 * Obtém webhook de um servidor
 */
export function getGuildWebhook(guildId, type = 'updates') {
  const data = getWebhooksData();
  
  if (!data.webhooks[guildId]) return null;
  
  for (const [channelId, webhook] of Object.entries(data.webhooks[guildId])) {
    if (webhook.type === type) {
      return { channelId, ...webhook };
    }
  }
  
  return null;
}

/**
 * Remove webhook
 */
export function removeWebhook(guildId, channelId) {
  const data = getWebhooksData();
  
  if (data.webhooks[guildId]?.[channelId]) {
    delete data.webhooks[guildId][channelId];
    return saveWebhooksData(data);
  }
  
  return false;
}

// =====================================================
// SISTEMA DE UPDATES
// =====================================================

/**
 * Obtém dados de updates
 */
export function getUpdatesData() {
  return readJSON(FILES.UPDATES) || {
    updates: [],
    lastUpdated: Date.now()
  };
}

/**
 * Salva dados de updates
 */
export function saveUpdatesData(data) {
  data.lastUpdated = Date.now();
  return writeJSON(FILES.UPDATES, data);
}

/**
 * Adiciona um update ao histórico
 */
export function addUpdate(update) {
  const data = getUpdatesData();
  
  data.updates.unshift({
    id: `update_${Date.now()}`,
    ...update,
    createdAt: Date.now()
  });
  
  // Manter apenas os últimos 50 updates
  if (data.updates.length > 50) {
    data.updates = data.updates.slice(0, 50);
  }
  
  return saveUpdatesData(data);
}

/**
 * Obtém updates recentes
 */
export function getRecentUpdates(limit = 10) {
  const data = getUpdatesData();
  return data.updates.slice(0, limit);
}

// =====================================================
// SISTEMA DE PLANOS ARQUITETADOS
// =====================================================

/**
 * Obtém planos salvos
 */
export function getPlansData() {
  return readJSON(FILES.PLANS) || {
    plans: {},
    lastUpdated: Date.now()
  };
}

/**
 * Salva dados de planos
 */
export function savePlansData(data) {
  data.lastUpdated = Date.now();
  return writeJSON(FILES.PLANS, data);
}

/**
 * Salva um plano para um servidor
 */
export function savePlan(guildId, plan) {
  const data = getPlansData();
  
  data.plans[guildId] = {
    ...plan,
    savedAt: Date.now()
  };
  
  return savePlansData(data);
}

/**
 * Obtém plano de um servidor
 */
export function getPlan(guildId) {
  const data = getPlansData();
  return data.plans[guildId] || null;
}

/**
 * Remove plano
 */
export function removePlan(guildId) {
  const data = getPlansData();
  
  if (data.plans[guildId]) {
    delete data.plans[guildId];
    return savePlansData(data);
  }
  
  return false;
}

// =====================================================
// SISTEMA DE CONFIGURAÇÕES
// =====================================================

/**
 * Obtém configurações
 */
export function getSettings() {
  return readJSON(FILES.SETTINGS) || {
    botOwnerId: '1387242867700924568',
    version: '3.0.0',
    lastUpdated: Date.now()
  };
}

/**
 * Salva configurações
 */
export function saveSettings(settings) {
  settings.lastUpdated = Date.now();
  return writeJSON(FILES.SETTINGS, settings);
}

// =====================================================
// SISTEMA DE SERVIDORES
// =====================================================

/**
 * Obtém dados de servidores
 */
export function getServersData() {
  return readJSON(FILES.SERVERS) || {
    servers: {},
    lastUpdated: Date.now()
  };
}

/**
 * Salva dados de servidores
 */
export function saveServersData(data) {
  data.lastUpdated = Date.now();
  return writeJSON(FILES.SERVERS, data);
}

/**
 * Registra informações de um servidor
 */
export function registerServer(guildId, data) {
  const serversData = getServersData();
  
  serversData.servers[guildId] = {
    ...serversData.servers[guildId],
    ...data,
    updatedAt: Date.now()
  };
  
  return saveServersData(serversData);
}

/**
 * Obtém informações de um servidor
 */
export function getServerInfo(guildId) {
  const data = getServersData();
  return data.servers[guildId] || null;
}

// =====================================================
// INICIALIZAÇÃO
// =====================================================

/**
 * Inicializa o sistema de storage
 */
export function initStorage() {
  ensureStorageDir();
  
  // Inicializar arquivos se não existirem
  const defaults = {
    [FILES.USAGE]: { servers: {}, lastUpdated: Date.now() },
    [FILES.WEBHOOKS]: { webhooks: {}, lastUpdated: Date.now() },
    [FILES.UPDATES]: { updates: [], lastUpdated: Date.now() },
    [FILES.PLANS]: { plans: {}, lastUpdated: Date.now() },
    [FILES.AUTOMATIONS]: { automations: {}, lastUpdated: Date.now() },
    [FILES.SETTINGS]: { botOwnerId: '1387242867700924568', version: '3.0.0', lastUpdated: Date.now() },
    [FILES.SERVERS]: { servers: {}, lastUpdated: Date.now() }
  };
  
  for (const [filename, defaultData] of Object.entries(defaults)) {
    const filePath = getFilePath(filename);
    if (!fs.existsSync(filePath)) {
      writeJSON(filename, defaultData);
      console.log(`✅ [Storage] Arquivo criado: ${filename}`);
    }
  }
  
  console.log('✅ [Storage] Sistema de armazenamento inicializado');
}

// Exportar caminho do Storage
export { STORAGE_PATH, FILES };

// Export default
export default {
  initStorage,
  // Usage
  getUsageData,
  saveUsageData,
  getServerUsage,
  incrementServerUsage,
  canUseServer,
  // Webhooks
  getWebhooksData,
  saveWebhooksData,
  registerWebhook,
  getGuildWebhook,
  removeWebhook,
  // Updates
  getUpdatesData,
  saveUpdatesData,
  addUpdate,
  getRecentUpdates,
  // Plans
  getPlansData,
  savePlansData,
  savePlan,
  getPlan,
  removePlan,
  // Settings
  getSettings,
  saveSettings,
  // Servers
  getServersData,
  saveServersData,
  registerServer,
  getServerInfo,
  // Constants
  STORAGE_PATH,
  FILES
};
