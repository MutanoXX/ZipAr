/**
 * Rias-Grimory-X - Comando de Assinatura
 * Permite ao usuário escolher e pagar planos
 * 
 * Planos:
 * - Semanal: R$20,00 (7 dias)
 * - Mensal: R$29,59 (30 dias)
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType
} from 'discord.js';
import { createPlanPayment, checkTransactionPaid } from '../services/cashinPayService.js';
import accountManager, { 
  getOrCreateAccount, 
  activatePlanAfterPayment, 
  addBalance,
  getPlanTimeRemaining,
  setAutoRenew,
  getPricingInfo,
  CONFIG
} from '../utils/accountManager.js';

export const data = new SlashCommandBuilder()
  .setName('assinatura')
  .setDescription(' 💎 Gerencie sua assinatura do bot')
  .addSubcommand(sub =>
    sub.setName('ver')
      .setDescription('📅 Veja informações do seu plano atual')
  )
  .addSubcommand(sub =>
    sub.setName('comprar')
      .setDescription('💳 Compre um novo plano')
  )
  .addSubcommand(sub =>
    sub.setName('renovar')
      .setDescription('🔄 Ative/desative renovação automática')
      .addBooleanOption(opt =>
        opt.setName('ativa')
          .setDescription('Ativar ou desativar renovação automática')
          .setRequired(true)
      )
  );

export async function execute(interaction) {
  const subcommand = interaction.options.getSubcommand();
  const userId = interaction.user.id;
  const username = interaction.user.username;

  switch (subcommand) {
    case 'ver':
      await handleVerPlano(interaction, userId);
      break;
    case 'comprar':
      await handleComprarPlano(interaction, userId, username);
      break;
    case 'renovar':
      await handleRenovarAuto(interaction, userId);
      break;
    default:
      await interaction.reply({
        content: '❌ Subcomando inválido!',
        ephemeral: true
      });
  }
}

/**
 * Mostra informações do plano atual
 */
async function handleVerPlano(interaction, userId) {
  const account = getOrCreateAccount(userId, interaction.user.username);
  const planInfo = getPlanTimeRemaining(userId);
  const pricing = getPricingInfo();

  const embed = new EmbedBuilder()
    .setTitle('💎 Minha Assinatura')
    .setColor(planInfo.valid ? '#10B981' : '#EF4444')
    .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true, size: 256 }))
    .addFields(
      {
        name: '📊 Status do Plano',
        value: planInfo.valid ? `✅ **Ativo**\n⏱️ Tempo restante: **${planInfo.formatted}**` : '❌ **Inativo**',
        inline: false
      },
      {
        name: '💰 Saldo Disponível',
        value: `R$ ${account.balance.toFixed(2)}`,
        inline: true
      },
      {
        name: '🔄 Renovação Automática',
        value: account.autoRenew ? '✅ Ativada' : '❌ Desativada',
        inline: true
      }
    )
    .addFields(
      {
        name: '📋 Planos Disponíveis',
        value: `**Semanal:** R$ ${pricing.semanal.price.toFixed(2)} (${pricing.semanal.days} dias)\n**Mensal:** R$ ${pricing.mensal.price.toFixed(2)} (${pricing.mensal.days} dias)`,
        inline: false
      }
    )
    .setFooter({ text: '💎 Rias Gremory • Sistema de Assinatura', iconURL: 'https://i.imgur.com/eEsH9NF.jpeg' })
    .setTimestamp();

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('assinar_plano')
        .setLabel('💳 Assinar Plano')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('adicionar_saldo')
        .setLabel('💰 Adicionar Saldo')
        .setStyle(ButtonStyle.Primary)
    );

  await interaction.reply({
    embeds: [embed],
    components: [row],
    ephemeral: true
  });
}

/**
 * Comprar plano - envia menu de seleção
 */
async function handleComprarPlano(interaction, userId, username) {
  const embed = new EmbedBuilder()
    .setTitle('💳 Escolha seu Plano')
    .setDescription('Selecione abaixo o plano que deseja assinar.\n\nApós a seleção, enviarei os dados de pagamento para sua DM!')
    .setColor('#8B5CF6')
    .addFields(
      {
        name: '📅 Plano Semanal',
        value: '**R$ 20,00**\n7 dias de acesso completo',
        inline: true
      },
      {
        name: '📅 Plano Mensal',
        value: '**R$ 29,59**\n30 dias de acesso\n⭐ *Melhor custo-benefício*',
        inline: true
      }
    )
    .setFooter({ text: '💎 Rias Gremory • Sistema de Assinatura', iconURL: 'https://i.imgur.com/eEsH9NF.jpeg' })
    .setTimestamp();

  const row = new ActionRowBuilder()
    .addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('select_plan')
        .setPlaceholder('Selecione um plano...')
        .addOptions(
          {
            label: 'Plano Semanal',
            description: 'R$ 20,00 - 7 dias de acesso',
            value: 'semanal',
            emoji: '📅'
          },
          {
            label: 'Plano Mensal',
            description: 'R$ 29,59 - 30 dias de acesso (Melhor custo-benefício)',
            value: 'mensal',
            emoji: '⭐'
          }
        )
    );

  await interaction.reply({
    embeds: [embed],
    components: [row],
    ephemeral: true
  });
}

/**
 * Gerencia renovação automática
 */
async function handleRenovarAuto(interaction, userId) {
  const ativa = interaction.options.getBoolean('ativa');
  const account = getOrCreateAccount(userId, interaction.user.username);

  // Verificar se tem plano ativo para ativar renovação
  if (ativa && (!account.planExpiresAt || account.planExpiresAt <= Date.now())) {
    return await interaction.reply({
      content: '❌ Você precisa ter um plano ativo para ativar a renovação automática!',
      ephemeral: true
    });
  }

  // Verificar saldo se for ativar
  if (ativa) {
    const planType = account.planType || 'semanal';
    const price = CONFIG.PLAN_PRICES[planType];

    if (account.balance < price) {
      return await interaction.reply({
        content: `❌ Saldo insuficiente para renovação automática!\n\nNecessário: **R$ ${price.toFixed(2)}**\nDisponível: **R$ ${account.balance.toFixed(2)}**`,
        ephemeral: true
      });
    }
  }

  const result = setAutoRenew(userId, ativa);

  const embed = new EmbedBuilder()
    .setTitle('🔄 Renovação Automática')
    .setDescription(result.success
      ? `${ativa ? '✅ Renovação automática **ATIVADA**!' : '❌ Renovação automática **DESATIVADA**!'}\n\n${ativa ? 'Seu plano será renovado automaticamente 1 hora antes de expirar, se houver saldo suficiente.' : 'Você não receberá renovações automáticas.'}`
      : `❌ Erro: ${result.error}`
    )
    .setColor(result.success ? (ativa ? '#10B981' : '#F59E0B') : '#EF4444')
    .setFooter({ text: '💎 Rias Gremory', iconURL: 'https://i.imgur.com/eEsH9NF.jpeg' })
    .setTimestamp();

  await interaction.reply({
    embeds: [embed],
    ephemeral: true
  });
}

/**
 * Processa seleção de plano (chamado pelo interactionCreate)
 */
export async function handlePlanSelection(interaction) {
  const planType = interaction.values[0];
  const userId = interaction.user.id;
  const username = interaction.user.username;

  await interaction.deferUpdate();

  // Criar transação de pagamento
  const result = await createPlanPayment(userId, username, planType, 1);

  if (!result.success) {
    return await interaction.editReply({
      content: `❌ Erro ao criar pagamento: ${result.error}`,
      components: [],
      embeds: []
    });
  }

  const txn = result.transaction;
  const pricing = getPricingInfo();

  // Embed de confirmação (no canal)
  const confirmEmbed = new EmbedBuilder()
    .setTitle('✅ Plano Selecionado!')
    .setDescription(`Você escolheu o **Plano ${planType === 'mensal' ? 'Mensal' : 'Semanal'}**!\n\n📩 **Enviei os dados de pagamento para sua DM!**\n\n⏰ O pagamento expira em 30 minutos.`)
    .setColor('#10B981')
    .setFooter({ text: '💎 Rias Gremory • Sistema de Assinatura', iconURL: 'https://i.imgur.com/eEsH9NF.jpeg' })
    .setTimestamp();

  await interaction.editReply({
    embeds: [confirmEmbed],
    components: []
  });

  // Enviar dados de pagamento na DM
  const dmEmbed = new EmbedBuilder()
    .setTitle('💳 Pagamento do Plano')
    .setDescription(`**Plano ${planType === 'mensal' ? 'Mensal (30 dias)' : 'Semanal (7 dias)'}**\n💰 **Valor:** R$ ${txn.amount.toFixed(2)}`)
    .setColor('#8B5CF6')
    .addFields(
      {
        name: '📋 Código PIX Copia e Cola',
        value: `\`\`\`${txn.copyPaste}\`\`\`\n*Clique para copiar*`,
        inline: false
      },
      {
        name: '🔗 QR Code',
        value: txn.qrcode ? `[Clique aqui para ver o QR Code](${txn.qrcode})` : 'Não disponível',
        inline: false
      },
      {
        name: '⏰ Expira em',
        value: txn.expirationDate ? `<t:${Math.floor(new Date(txn.expirationDate).getTime() / 1000)}:R>` : '30 minutos',
        inline: true
      },
      {
        name: '🔖 ID da Transação',
        value: `\`${txn.id}\``,
        inline: true
      }
    )
    .setFooter({ text: '💎 Após o pagamento, seu plano será ativado automaticamente!', iconURL: 'https://i.imgur.com/eEsH9NF.jpeg' })
    .setTimestamp();

  // Botões na DM
  const dmRow = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId(`check_payment_${txn.id}`)
        .setLabel('✅ Já Paguei')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`cancel_payment_${txn.id}`)
        .setLabel('❌ Cancelar')
        .setStyle(ButtonStyle.Danger)
    );

  try {
    await interaction.user.send({
      embeds: [dmEmbed],
      components: [dmRow]
    });

    // Registrar transação pendente
    const { registerPendingTransaction } = await import('../utils/accountManager.js');
    registerPendingTransaction(userId, txn.id, {
      planType: planType,
      amount: txn.amount,
      createdAt: Date.now()
    });

    // Iniciar verificação de pagamento
    startPaymentCheck(interaction, userId, txn.id, planType);
  } catch (dmError) {
    console.error('❌ Erro ao enviar DM:', dmError.message);
    await interaction.followUp({
      content: '❌ Não consegui enviar mensagem para sua DM! Verifique suas configurações de privacidade.',
      ephemeral: true
    });
  }
}

/**
 * Verifica pagamento periodicamente
 */
function startPaymentCheck(interaction, userId, transactionId, planType) {
  let checks = 0;
  const maxChecks = 60; // 30 minutos (verifica a cada 30s)

  const interval = setInterval(async () => {
    checks++;

    if (checks > maxChecks) {
      clearInterval(interval);
      return;
    }

    try {
      const result = await checkTransactionPaid(transactionId);

      if (result.paid) {
        clearInterval(interval);

        // Ativar plano
        activatePlanAfterPayment(userId, planType, 1);

        // Notificar usuário
        try {
          const user = await interaction.client.users.fetch(userId);
          const successEmbed = new EmbedBuilder()
            .setTitle('🎉 Pagamento Confirmado!')
            .setDescription(`Seu **Plano ${planType === 'mensal' ? 'Mensal' : 'Semanal'}** foi ativado com sucesso!`)
            .setColor('#10B981')
            .addFields(
              {
                name: '⏱️ Válido até',
                value: `<t:${Math.floor((Date.now() + (planType === 'mensal' ? 30 : 7) * 24 * 60 * 60 * 1000) / 1000)}:F>`,
                inline: true
              }
            )
            .setFooter({ text: '💎 Obrigado por assinar!', iconURL: 'https://i.imgur.com/eEsH9NF.jpeg' })
            .setTimestamp();

          await user.send({ embeds: [successEmbed] });
        } catch (e) {
          console.error('Erro ao notificar usuário:', e.message);
        }

        // Remover transação pendente
        const { removePendingTransaction } = await import('../utils/accountManager.js');
        removePendingTransaction(transactionId);

        console.log(`✅ [Assinatura] Plano ${planType} ativado para ${userId}`);
      }
    } catch (error) {
      console.error('Erro ao verificar pagamento:', error.message);
    }
  }, 30000); // Verificar a cada 30 segundos
}

/**
 * Handler para botão de verificar pagamento
 */
export async function handleCheckPayment(interaction, transactionId) {
  await interaction.deferUpdate();

  const result = await checkTransactionPaid(transactionId);

  if (result.paid) {
    // Obter dados da transação pendente
    const { getPendingTransaction, removePendingTransaction } = await import('../utils/accountManager.js');
    const pendingTxn = getPendingTransaction(transactionId);

    if (pendingTxn) {
      activatePlanAfterPayment(interaction.user.id, pendingTxn.planType, 1);
      removePendingTransaction(transactionId);

      const successEmbed = new EmbedBuilder()
        .setTitle('🎉 Pagamento Confirmado!')
        .setDescription(`Seu plano foi ativado com sucesso!`)
        .setColor('#10B981')
        .setFooter({ text: '💎 Obrigado por assinar!', iconURL: 'https://i.imgur.com/eEsH9NF.jpeg' })
        .setTimestamp();

      await interaction.editReply({
        embeds: [successEmbed],
        components: []
      });
    }
  } else {
    await interaction.followUp({
      content: '⏳ Ainda não detectamos o pagamento. Aguarde alguns segundos e tente novamente.',
      ephemeral: true
    });
  }
}

export default {
  data,
  execute,
  handlePlanSelection,
  handleCheckPayment
};
