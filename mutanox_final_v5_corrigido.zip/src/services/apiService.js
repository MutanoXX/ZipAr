import fetch from 'node-fetch';
import FormData from 'form-data';
import fs from 'fs';
import path from 'path';
import { PDFDocument, rgb } from 'pdf-lib';

/**
 * MutanoX API Service - Handles external API calls
 */
class APIService {
  constructor() {
    this.baseUrl = 'https://mutano-x-v2.discloud.app/api/consultas';
    this.cosplayUrl = 'https://iyusztempest.my.id/api/anime?feature=jjcosplay';
    this.googleImageUrl = 'https://anabot.my.id/api/search/gimage';
    this.googleApiKey = 'freeApikey';
    this.dalleUrl = 'https://anabot.my.id/api/ai/dalle3';
  }

  /**
   * Consulta CNPJ
   */
  async consultaCNPJ(cnpj) {
    try {
      const response = await fetch(`${this.baseUrl}?type=cnpj&value=${cnpj.replace(/\D/g, '')}`);
      return await response.json();
    } catch (error) {
      console.error('Erro ao consultar CNPJ:', error);
      throw error;
    }
  }

  /**
   * Consulta CPF
   */
  async consultaCPF(cpf) {
    try {
      const response = await fetch(`${this.baseUrl}?type=cpf&value=${cpf.replace(/\D/g, '')}&base=credlink`);
      return await response.json();
    } catch (error) {
      console.error('Erro ao consultar CPF:', error);
      throw error;
    }
  }

  /**
   * Cosplay Anime Video
   */
  async getCosplayVideo() {
    try {
      const response = await fetch(this.cosplayUrl);
      return await response.json();
    } catch (error) {
      console.error('Erro ao buscar vídeo de cosplay:', error);
      throw error;
    }
  }

  /**
   * Google Image Search - Optimized to find direct image links
   */
  async searchGoogleImage(query) {
    try {
      const url = `${this.googleImageUrl}?query=${encodeURIComponent(query)}&apikey=${this.googleApiKey}`;
      const response = await fetch(url);
      const data = await response.json();
      
      if (data.success && Array.isArray(data.data)) {
        // Filter for direct image extensions as requested
        const directImages = data.data.filter(img => 
          img.url && (img.url.endsWith('.png') || img.url.endsWith('.jpg') || img.url.endsWith('.jpeg') || img.url.endsWith('.gif'))
        );
        
        if (directImages.length > 0) {
          // Return a random one from the filtered list
          const randomImg = directImages[Math.floor(Math.random() * directImages.length)];
          return { success: true, data: randomImg };
        }
      }
      return data;
    } catch (error) {
      console.error('Erro ao buscar imagem no Google:', error);
      throw error;
    }
  }

  /**
   * Dalle NSFW Image Generation
   */
  async dalleXlloraText2image(prompt, negative, apikey = 'freeApikey') {
    try {
      const url = `${this.dalleUrl}?prompt=${encodeURIComponent(prompt)}&negative=${encodeURIComponent(negative)}&apikey=${apikey}`;
      const response = await fetch(url);
      return await response.json();
    } catch (error) {
      console.error('Erro ao gerar imagem Dalle:', error);
      throw error;
    }
  }

  /**
   * Upload file to tmpfiles.org
   */
  async uploadFile(filePath) {
    try {
      const form = new FormData();
      form.append('file', fs.createReadStream(filePath));

      const response = await fetch('https://tmpfiles.org/api/v1/upload', {
        method: 'POST',
        body: form,
        headers: form.getHeaders(),
      });

      const data = await response.json();
      if (data.status === 'success') {
        // Transform https://tmpfiles.org/123/file.ext to https://tmpfiles.org/dl/123/file.ext for direct download
        const downloadUrl = data.data.url.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
        return { success: true, url: downloadUrl };
      }
      return { success: false, error: data.message };
    } catch (error) {
      console.error('Erro no upload:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Generate a PDF file with multi-line support
   */
  async generatePDF(filename, content) {
    try {
      const pdfDoc = await PDFDocument.create();
      let page = pdfDoc.addPage();
      const { width, height } = page.getSize();
      const fontSize = 12;
      const margin = 50;
      const maxWidth = width - (margin * 2);
      
      const lines = content.split('\n');
      let y = height - margin;

      for (const line of lines) {
        if (y < margin + fontSize) {
          page = pdfDoc.addPage();
          y = height - margin;
        }
        
        // Simple line wrapping if line is too long
        if (line.length * (fontSize * 0.5) > maxWidth) {
          const words = line.split(' ');
          let currentLine = '';
          for (const word of words) {
            if ((currentLine + word).length * (fontSize * 0.5) > maxWidth) {
              page.drawText(currentLine, { x: margin, y, size: fontSize, color: rgb(0, 0, 0) });
              y -= fontSize + 5;
              currentLine = word + ' ';
              if (y < margin + fontSize) {
                page = pdfDoc.addPage();
                y = height - margin;
              }
            } else {
              currentLine += word + ' ';
            }
          }
          page.drawText(currentLine, { x: margin, y, size: fontSize, color: rgb(0, 0, 0) });
        } else {
          page.drawText(line, { x: margin, y, size: fontSize, color: rgb(0, 0, 0) });
        }
        y -= fontSize + 5;
      }

      const pdfBytes = await pdfDoc.save();
      const filePath = path.join('/tmp', filename.endsWith('.pdf') ? filename : `${filename}.pdf`);
      fs.writeFileSync(filePath, pdfBytes);
      return filePath;
    } catch (error) {
      console.error('Erro ao gerar PDF:', error);
      throw error;
    }
  }

  /**
   * Generate a text/markdown file
   */
  async generateTextFile(filename, content) {
    try {
      const filePath = path.join('/tmp', filename);
      fs.writeFileSync(filePath, content);
      return filePath;
    } catch (error) {
      console.error('Erro ao gerar arquivo de texto:', error);
      throw error;
    }
  }
}

export default new APIService();
