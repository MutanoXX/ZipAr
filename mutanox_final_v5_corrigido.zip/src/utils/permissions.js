/**
 * MutanoX Architect - Sistema de Permissões
 * Gerencia usuários autorizados a usar os comandos
 */

// ID do dono do bot
const OWNER_ID = '1387242867700924568';

// Lista de usuários autorizados (além do dono)
const authorizedUsers = new Set();

/**
 * Verifica se um usuário tem permissão para usar comandos
 * @param {string} userId - ID do usuário
 * @returns {boolean}
 */
export function isAuthorized(userId) {
  // O dono sempre tem permissão
  if (userId === OWNER_ID) return true;
  
  // Verifica se está na lista de autorizados
  return authorizedUsers.has(userId);
}

/**
 * Adiciona um usuário à lista de autorizados
 * @param {string} userId - ID do usuário
 * @returns {boolean} - True se adicionou, false se já existia
 */
export function addAuthorizedUser(userId) {
  if (userId === OWNER_ID) return false; // Dono não precisa ser adicionado
  if (authorizedUsers.has(userId)) return false;
  
  authorizedUsers.add(userId);
  return true;
}

/**
 * Remove um usuário da lista de autorizados
 * @param {string} userId - ID do usuário
 * @returns {boolean} - True se removeu, false se não existia
 */
export function removeAuthorizedUser(userId) {
  if (userId === OWNER_ID) return false; // Dono não pode ser removido
  
  return authorizedUsers.delete(userId);
}

/**
 * Retorna a lista de usuários autorizados
 * @returns {string[]} - Array de IDs
 */
export function getAuthorizedUsers() {
  return [OWNER_ID, ...Array.from(authorizedUsers)];
}

/**
 * Verifica se o usuário é o dono
 * @param {string} userId - ID do usuário
 * @returns {boolean}
 */
export function isOwner(userId) {
  return userId === OWNER_ID;
}

/**
 * Retorna o ID do dono
 * @returns {string}
 */
export function getOwnerId() {
  return OWNER_ID;
}

export default {
  isAuthorized,
  addAuthorizedUser,
  removeAuthorizedUser,
  getAuthorizedUsers,
  isOwner,
  getOwnerId
};
