/**
 * MutanoX Architect - Gerenciador de Canais Ativos
 * Controla quais canais a IA está monitorando para conversa
 */

// Canais ativos por servidor: { guildId: Set<channelId> }
const activeChannels = new Map();

// Contexto de conversa por canal: { channelId: { messages: [], lastActivity: timestamp, prompt_Default: string } }
const channelContexts = new Map();

// Limite de mensagens no contexto (60 mensagens)
const MAX_CONTEXT_MESSAGES = 60;

// Tempo de expiração do contexto (2 horas)
const CONTEXT_EXPIRE = 2 * 60 * 60 * 1000;

/**
 * Ativa um canal para conversa com a IA
 */
export function activateChannel(guildId, channelId) {
  if (!activeChannels.has(guildId)) {
    activeChannels.set(guildId, new Set());
  }
  
  const guildChannels = activeChannels.get(guildId);
  
  if (guildChannels.has(channelId)) {
    return false;
  }
  
  guildChannels.add(channelId);
  
  // Inicializar contexto do canal se não existir
  if (!channelContexts.has(channelId)) {
    channelContexts.set(channelId, {
      messages: [],
      lastActivity: Date.now(),
      guildId: guildId,
      prompt_Default: null
    });
  }
  
  return true;
}

/**
 * Desativa um canal
 */
export function deactivateChannel(guildId, channelId) {
  const guildChannels = activeChannels.get(guildId);
  
  if (!guildChannels || !guildChannels.has(channelId)) {
    return false;
  }
  
  guildChannels.delete(channelId);
  channelContexts.delete(channelId);
  
  if (guildChannels.size === 0) {
    activeChannels.delete(guildId);
  }
  
  return true;
}

/**
 * Verifica se um canal está ativo
 */
export function isChannelActive(guildId, channelId) {
  const guildChannels = activeChannels.get(guildId);
  return guildChannels ? guildChannels.has(channelId) : false;
}

/**
 * Obtém canais ativos de um servidor
 */
export function getActiveChannels(guildId) {
  const guildChannels = activeChannels.get(guildId);
  return guildChannels ? Array.from(guildChannels) : [];
}

/**
 * Adiciona mensagem do USUÁRIO ao contexto
 */
export function addUserMessage(channelId, content, author) {
  let context = channelContexts.get(channelId);
  
  if (!context) {
    context = { messages: [], lastActivity: Date.now(), prompt_Default: null };
    channelContexts.set(channelId, context);
  }
  
  context.messages.push({
    role: 'user',
    content: content,
    author: author,
    timestamp: Date.now()
  });
  
  context.lastActivity = Date.now();
  trimContext(context);
}

/**
 * Adiciona mensagem da IA ao contexto
 */
export function addAIMessage(channelId, content) {
  let context = channelContexts.get(channelId);
  
  if (!context) {
    context = { messages: [], lastActivity: Date.now(), prompt_Default: null };
    channelContexts.set(channelId, context);
  }
  
  context.messages.push({
    role: 'assistant',
    content: content,
    timestamp: Date.now()
  });
  
  context.lastActivity = Date.now();
  trimContext(context);
}

/**
 * Limita o contexto mantendo mensagens recentes
 */
function trimContext(context) {
  // Mantemos apenas mensagens de conversa no array 'messages'
  if (context.messages.length > MAX_CONTEXT_MESSAGES) {
    context.messages = context.messages.slice(-MAX_CONTEXT_MESSAGES);
  }
}

/**
 * Obtém contexto do canal formatado para a API
 * Garante que o prompt_Default seja SEMPRE o primeiro item da lista
 */
export function getChannelContext(channelId) {
  const context = channelContexts.get(channelId);
  
  if (!context) {
    return [];
  }
  
  // Verificar expiração
  if (Date.now() - context.lastActivity > CONTEXT_EXPIRE) {
    channelContexts.delete(channelId);
    return [];
  }
  
  // Formatar histórico de mensagens
  const history = context.messages.map(m => ({
    role: m.role,
    content: m.content
  }));

  // Construir a lista final: [System Prompt, ...Histórico]
  // Isso garante que tudo vá na mesma requisição
  const result = [];
  
  if (context.prompt_Default) {
    result.push({ role: 'system', content: context.prompt_Default });
  } else {
    console.error(`⚠️ [Context] Canal ${channelId} sem prompt_Default!`);
  }
  
  return [...result, ...history];
}

/**
 * Limpa contexto de um canal
 */
export function clearChannelContext(channelId, guildId) {
  const context = channelContexts.get(channelId);
  if (context) {
    context.messages = [];
    context.lastActivity = Date.now();
  }
}

/**
 * Define prompt_Default do canal
 */
export function setChannelPrompt_Default(channelId, prompt_Default, guildId) {
  let context = channelContexts.get(channelId);
  if (!context) {
    context = { messages: [], guildId: guildId };
    channelContexts.set(channelId, context);
  }
  context.prompt_Default = prompt_Default;
  context.lastActivity = Date.now();
}

/**
 * Obtém info do contexto
 */
export function getChannelContextInfo(channelId) {
  const context = channelContexts.get(channelId);
  
  if (!context) {
    return { exists: false, messages: 0, userMessages: 0, aiMessages: 0 };
  }
  
  const userMessages = context.messages.filter(m => m.role === 'user').length;
  const aiMessages = context.messages.filter(m => m.role === 'assistant').length;
  
  return {
    exists: true,
    messages: context.messages.length,
    userMessages: userMessages,
    aiMessages: aiMessages,
    lastActivity: context.lastActivity,
    guildId: context.guildId,
    hasPrompt: !!context.prompt_Default
  };
}

export default {
  activateChannel,
  deactivateChannel,
  isChannelActive,
  getActiveChannels,
  addUserMessage,
  addAIMessage,
  getChannelContext,
  clearChannelContext,
  setChannelPrompt_Default,
  getChannelContextInfo
};
