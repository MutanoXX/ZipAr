/**
 * MutanoX Architect - Evento MessageCreate
 * Fluxo Otimizado: IA1 (Contexto Full) -> Ferramenta -> IA2 (Contexto Zero/Instruções)
 * Modelo: step-3.5-flash (Alta velocidade)
 * VERSÃO: 2.0 - Com correções de embeds e canais
 */

import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } from 'discord.js';
import OpenAI from 'openai';
import { isAuthorized } from '../utils/permissions.js';
import { 
  isChannelActive, 
  getChannelContext, 
  addUserMessage,
  addAIMessage
} from '../utils/activeChannels.js';
import apiService from '../services/apiService.js';

const NVIDIA_KEY = process.env.NVIDIA_API_KEY || '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';

// Cliente Step-3.5-Flash (Usado para IA1 e IA2)
const client = new OpenAI({
  baseURL: 'https://integrate.api.nvidia.com/v1',
  apiKey: NVIDIA_KEY,
});

export const name = 'messageCreate';

export async function execute(message) {
  if (message.author.bot || !message.guild) return;

  const guild = message.guild;
  const channel = message.channel;

  if (!isChannelActive(guild.id, channel.id)) return;
  if (!isAuthorized(message.author.id)) return;

  channel.sendTyping().catch(() => {});

  try {
    let userContent = message.content;

    // --- Suporte a Arquivos (PDF/Imagens) Otimizado ---
    if (message.attachments.size > 0) {
      const attachmentsInfo = [];
      for (const attachment of message.attachments.values()) {
        const isImage = attachment.contentType?.startsWith('image/');
        attachmentsInfo.push(`[ANEXO DETECTADO: ${attachment.name}]\nTipo: ${attachment.contentType}\nURL: ${attachment.url}\n${isImage ? 'Este anexo é uma imagem. Analise o conteúdo visual se possível ou use a URL para referências.' : 'Este anexo é um arquivo. Analise o nome e tipo para entender o contexto.'}`);
      }
      userContent += "\n\nINFORMAÇÕES DE ANEXOS:\n" + attachmentsInfo.join("\n---\n") + "\n\nPOR FAVOR, ANALISE REALMENTE OS ANEXOS ACIMA E NÃO GERE RESPOSTAS ALEATÓRIAS.";
    }

    addUserMessage(channel.id, userContent, message.author.tag);
    const messages = getChannelContext(channel.id);

    // 1. IA1: Step-3.5-Flash com Contexto Completo
    console.log(`🚀 [IA1] Processando com Step-3.5-Flash (Contexto Full)`);
      const completion1 = await client.chat.completions.create({
        model: 'stepfun-ai/step-3.5-flash',
        messages: messages,
        temperature: 0.7,
        max_tokens: 4000,
        stream: false
      });

    let content1 = completion1.choices[0]?.message?.content || '';
    let response1 = parseResponse(content1);

    // 2. Verificar Task Complexa ou Ferramenta Externa
    if (response1.type === 'complex_task') {
      await handleComplexTask(message, response1, guild, channel);
    } else if (isExternalTool(response1.type)) {
      const startTime = Date.now();
      console.log(`🛠️ [Ferramenta] Executando ${response1.type}...`);
      
      let toolResult;
      try {
        toolResult = await executeExternalTool(response1, message);
      } catch (err) {
        toolResult = { error: err.message };
      }
      const duration = ((Date.now() - startTime) / 1000).toFixed(2);

      console.log(`✅ [Ferramenta] Concluída em ${duration}s. Chamando IA2 (Contexto Zero)`);

      // 3. IA2: Step-3.5-Flash com Contexto Zero (Apenas instruções e dados)
      const nextSteps = response1.next_steps || "Finalize a resposta para o usuário de forma amigável e decorada.";
      
      // Extrair URL de imagem se for busca do Google ou Dalle
      let imageUrl = null;
      if (response1.type === 'google_image' && toolResult.success && toolResult.data) {
        imageUrl = toolResult.data.url;
      } else if (response1.type === 'dalle_nsfw' && toolResult.success && toolResult.data) {
        imageUrl = toolResult.data.result;
      }

      const completion2 = await client.chat.completions.create({
        model: 'stepfun-ai/step-3.5-flash',
        messages: [
          { 
            role: 'system', 
            content: `Você é o finalizador do MutanoX. Sua tarefa é formatar a resposta final para o usuário com base nos dados da ferramenta e nas instruções da IA principal.
            
Instruções da IA principal: "${nextSteps}"
Dados da ferramenta: ${JSON.stringify(toolResult)}
Tempo de resposta da ferramenta: ${duration}s
${imageUrl ? `URL da Imagem Encontrada: ${imageUrl}` : ''}

IMPORTANTE:
- Responda SEMPRE em JSON válido seguindo o formato de ações do MutanoX.
- Se a ferramenta retornou uma URL de vídeo (como cosplay), use {"type":"message","content":"Sua mensagem aqui \\nURL_DO_VIDEO"} para garantir a prévia no Discord.
- Se a ferramenta retornou imagens (Google/Dalle), use {"type":"send_embed","title":"...","description":"...","image":"${imageUrl || ''}"}.
- Se a ferramenta gerou um arquivo (generate_file), você DEVE OBRIGATORIAMENTE usar {"type":"send_file","content":"Sua mensagem","filePath":"${toolResult.localPath || ''}","downloadUrl":"${toolResult.downloadUrl || ''}"}. NUNCA envie o conteúdo do arquivo no chat, apenas a confirmação e o arquivo.
- Se for imagem NSFW, use frases engraçadas como "cara você é safado demais, kkkk", "tome essa imagem de uma gostosa aí, kkkk".
- O limite do Discord é 2000 caracteres para a mensagem de texto, mas o conteúdo do arquivo pode ser maior.` 
          }
        ],
        temperature: 0.7,
        max_tokens: 1000,
        stream: false
      });

      let content2 = completion2.choices[0]?.message?.content || '';
      let response2 = parseResponse(content2);
      
      // Adicionar a resposta final ao contexto e executar
      addAIMessage(channel.id, content2);
      await executeAction(response2, message, guild, channel);
    } else {
      addAIMessage(channel.id, content1);
      await executeAction(response1, message, guild, channel);
    }

  } catch (error) {
    console.error('❌ [Erro] MessageCreate:', error.message);
    await message.reply({ content: '❌ Ocorreu um erro ao processar sua mensagem.' }).catch(() => {});
  }
}

function isExternalTool(type) {
  return ['consulta_cnpj', 'consulta_cpf', 'cosplay_video', 'google_image', 'server_stats', 'dalle_nsfw', 'generate_file'].includes(type);
}

async function executeExternalTool(action, message) {
  // Notificar execução da ferramenta como solicitado
  const toolNames = {
    'consulta_cnpj': '🔍 Consultando CNPJ',
    'consulta_cpf': '🔍 Consultando CPF',
    'cosplay_video': '🎬 Buscando Vídeo Cosplay',
    'google_image': '🖼️ Buscando Imagem no Google',
    'server_stats': '📊 Coletando Estatísticas do Servidor',
    'dalle_nsfw': '🎨 Gerando Imagem IA',
    'generate_file': '📄 Gerando Arquivo'
  };
  
  if (toolNames[action.type]) {
    await message.channel.send({ 
      embeds: [createLoadingEmbed(`${toolNames[action.type]}...`)] 
    }).catch(() => {});
  }

  switch (action.type) {
    case 'consulta_cnpj': return await apiService.consultaCNPJ(action.value);
    case 'consulta_cpf': return await apiService.consultaCPF(action.value);
    case 'cosplay_video': return await apiService.getCosplayVideo();
    case 'google_image': return await apiService.searchGoogleImage(action.query);
    case 'server_stats': return await getServerStats(message.guild);
    case 'dalle_nsfw': return await apiService.dalleXlloraText2image(action.prompt, action.negative || 'low quality, blurry', action.apikey || 'freeApikey');
    case 'generate_file': return await handleFileGeneration(action);
    default: return { error: 'Ferramenta não reconhecida' };
  }
}

async function handleFileGeneration(action) {
  try {
    let filePath;
    if (action.fileType === 'pdf') {
      filePath = await apiService.generatePDF(action.filename, action.content);
    } else {
      filePath = await apiService.generateTextFile(action.filename, action.content);
    }

    const uploadResult = await apiService.uploadFile(filePath);
    return { 
      success: true, 
      filename: action.filename, 
      downloadUrl: uploadResult.success ? uploadResult.url : null,
      localPath: filePath 
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function getServerStats(guild) {
  try {
    await guild.fetch();
    const categories = guild.channels.cache.filter(c => c.type === 4);
    const textChannels = guild.channels.cache.filter(c => c.type === 0);
    const voiceChannels = guild.channels.cache.filter(c => c.type === 2);
    const roles = guild.roles.cache.filter(r => !r.managed);
    
    return {
      name: guild.name,
      memberCount: guild.memberCount,
      categories: categories.map(c => ({ name: c.name, id: c.id })),
      textChannelsCount: textChannels.size,
      voiceChannelsCount: voiceChannels.size,
      rolesCount: roles.size,
      ownerId: guild.ownerId
    };
  } catch (error) {
    return { error: error.message };
  }
}

function parseResponse(content) {
  try {
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) return JSON.parse(jsonMatch[0]);
  } catch (e) {}
  return { type: 'message', content: content };
}

/**
 * Cria um embed profissional decorado com todas as opções
 */
function createProfessionalEmbed(data, guild) {
  const embed = new EmbedBuilder();
  
  // Título com emoji se não tiver
  if (data.title) {
    embed.setTitle(data.title);
  }
  
  // Descrição
  if (data.description || data.content) {
    embed.setDescription(data.description || data.content);
  }
  
  // Cor - suporte a nomes de cores também
  let color = data.color || '#8B5CF6';
  const colorMap = {
    'roxo': '#8B5CF6',
    'purple': '#8B5CF6',
    'vermelho': '#EF4444',
    'red': '#EF4444',
    'verde': '#10B981',
    'green': '#10B981',
    'azul': '#3B82F6',
    'blue': '#3B82F6',
    'amarelo': '#F59E0B',
    'yellow': '#F59E0B',
    'laranja': '#F97316',
    'orange': '#F97316',
    'rosa': '#EC4899',
    'pink': '#EC4899',
    'dourado': '#FFD700',
    'gold': '#FFD700',
    'branco': '#FFFFFF',
    'white': '#FFFFFF',
    'preto': '#000000',
    'black': '#000000'
  };
  
  if (colorMap[data.color?.toLowerCase()]) {
    color = colorMap[data.color.toLowerCase()];
  }
  embed.setColor(color);
  
  // Imagem principal
  if (data.image) {
    embed.setImage(data.image);
  }
  
  // Thumbnail
  if (data.thumbnail) {
    embed.setThumbnail(data.thumbnail);
  }
  
  // Author com ícone
  if (data.author || data.authorName) {
    embed.setAuthor({
      name: data.author || data.authorName,
      iconURL: data.authorIcon || (guild?.iconURL ? guild.iconURL() : null),
      url: data.authorUrl
    });
  }
  
  // Footer com timestamp
  const footerText = data.footer || '💎 MutanoX Architect AI • Servidor de Elite';
  embed.setFooter({
    text: footerText,
    iconURL: data.footerIcon || (guild?.iconURL ? guild.iconURL() : 'https://i.imgur.com/placeholder.png')
  });
  
  // Timestamp
  embed.setTimestamp();
  
  // Campos
  if (data.fields && Array.isArray(data.fields)) {
    data.fields.forEach(field => {
      embed.addFields({
        name: field.name || 'Campo',
        value: field.value || 'Valor',
        inline: field.inline !== undefined ? field.inline : false
      });
    });
  }
  
  // URL
  if (data.url) {
    embed.setURL(data.url);
  }
  
  return embed;
}

/**
 * Cria embed de carregamento
 */
function createLoadingEmbed(text) {
  return new EmbedBuilder()
    .setDescription(`⏳ ${text}`)
    .setColor('#FBBF24')
    .setTimestamp();
}

/**
 * Resolve o canal de destino para envio
 */
async function resolveTargetChannel(guild, targetChannel, currentChannel) {
  if (!targetChannel) return currentChannel;
  
  // Se for um ID direto
  if (/^\d+$/.test(targetChannel)) {
    const channel = guild.channels.cache.get(targetChannel);
    if (channel) return channel;
  }
  
  // Se for uma menção de canal <#123456789>
  const mentionMatch = targetChannel.match(/<#(\d+)>/);
  if (mentionMatch) {
    const channel = guild.channels.cache.get(mentionMatch[1]);
    if (channel) return channel;
  }
  
  // Se for um nome de canal, tentar buscar
  const channelByName = guild.channels.cache.find(c => 
    c.name.toLowerCase() === targetChannel.toLowerCase().replace(/[^\w\s]/g, '').trim() ||
    c.name.toLowerCase().includes(targetChannel.toLowerCase().replace(/[^\w\s]/g, '').trim())
  );
  if (channelByName) return channelByName;
  
  return currentChannel;
}

async function executeAction(response, message, guild, channel) {
  // Fallback para campos comuns de ferramentas que a IA2 pode gerar
  if (response.url && (response.url.endsWith('.mp4') || response.type === 'cosplay_video')) {
    return await sendSplitMessage(message, `${response.content || '✨ Aqui está o seu vídeo!'} \n${response.url}`);
  }

  // Ações padrão
  switch (response.type) {
    case 'message':
      await sendSplitMessage(message, response.content);
      break;

    case 'multiple':
      for (const action of response.actions || []) {
        await executeSingleAction(action, guild, channel, message);
        await sleep(300);
      }
      break;

    case 'send_embed':
      await handleSendEmbed(message, response, guild, channel);
      break;

    case 'create_poll':
      await handleCreatePoll(message, response);
      break;

    case 'create_components':
      await handleCreateComponents(message, response);
      break;

    case 'send_file':
      await handleSendFile(message, response);
      break;

    default:
      await executeSingleAction(response, guild, channel, message);
  }
}

/**
 * Handler para envio de embed decorado - VERSÃO CORRIGIDA
 */
async function handleSendEmbed(message, response, guild, currentChannel) {
  try {
    // Resolver canal de destino
    const targetChannel = await resolveTargetChannel(guild, response.targetChannel || response.channel, currentChannel);
    
    // Criar embed profissional
    const embed = createProfessionalEmbed(response, guild);
    
    // Verificar se é para enviar no canal atual ou canal específico
    const isDifferentChannel = targetChannel.id !== currentChannel.id;
    
    if (isDifferentChannel) {
      // Enviar no canal especificado
      await targetChannel.send({ embeds: [embed] });
      
      // Confirmar envio no canal atual
      await message.reply({ 
        content: `✅ Embed enviado para ${targetChannel} com sucesso!`,
        allowedMentions: { repliedUser: false }
      });
    } else {
      // Responder no mesmo canal
      await message.reply({ embeds: [embed], allowedMentions: { repliedUser: false } });
    }
    
    console.log(`✅ [Embed] Enviado para canal: ${targetChannel.name} (${targetChannel.id})`);
  } catch (error) {
    console.error('❌ [Embed] Erro ao enviar:', error.message);
    await message.reply(`❌ Erro ao enviar embed: ${error.message}`);
  }
}

async function handleSendFile(message, data) {
  try {
    const options = { content: data.content || 'Aqui está o seu arquivo!' };
    const files = [];

    if (data.filePath && fs.existsSync(data.filePath)) {
      files.push(data.filePath);
    }
    
    if (data.downloadUrl) {
      options.content += `\n\n📥 **Link para Download:** ${data.downloadUrl}\n*(O link expira em 60 minutos)*`;
    }

    if (files.length > 0) {
      options.files = files;
    }

    await message.reply(options);
  } catch (error) {
    console.error('Erro ao enviar arquivo:', error);
    await message.reply(`❌ Erro ao enviar arquivo: ${error.message}`);
  }
}

async function handleCreatePoll(message, data) {
  const embed = createProfessionalEmbed({
    title: `📊 Enquete: ${data.question}`,
    description: data.options.map((opt, i) => `**${i + 1}.** ${opt} (0 votos)`).join('\n'),
    color: '#8B5CF6',
    footer: 'Clique nos botões abaixo para votar!'
  }, message.guild);

  const row = new ActionRowBuilder();
  data.options.forEach((opt, i) => {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(`poll_vote_${i}`)
        .setLabel(`${i + 1}`)
        .setStyle(ButtonStyle.Primary)
    );
  });

  const pollMsg = await message.channel.send({ embeds: [embed], components: [row] });
  
  // Armazenar dados da enquete globalmente para atualização
  if (!global.activePolls) global.activePolls = {};
  global.activePolls[pollMsg.id] = {
    question: data.question,
    options: data.options,
    votes: data.options.map(() => []),
    creatorId: message.author.id
  };
}

async function handleCreateComponents(message, data) {
  const rows = [];
  let currentRow = new ActionRowBuilder();
  
  for (const comp of data.components) {
    if (comp.type === 'button') {
      if (currentRow.components.length >= 5) {
        rows.push(currentRow);
        currentRow = new ActionRowBuilder();
      }
      currentRow.addComponents(
        new ButtonBuilder()
          .setCustomId(comp.customId || `gen_btn_${Math.random().toString(36).substr(2, 9)}`)
          .setLabel(comp.label)
          .setStyle(ButtonStyle[comp.style] || ButtonStyle.Primary)
      );
    } else if (comp.type === 'select') {
      if (currentRow.components.length > 0) {
        rows.push(currentRow);
        currentRow = new ActionRowBuilder();
      }
      const select = new StringSelectMenuBuilder()
        .setCustomId(comp.customId || `gen_sel_${Math.random().toString(36).substr(2, 9)}`)
        .setPlaceholder(comp.placeholder || 'Selecione uma opção')
        .addOptions(comp.options.map(opt => ({
          label: opt.label,
          value: opt.value,
          description: opt.description
        })));
      currentRow.addComponents(select);
      rows.push(currentRow);
      currentRow = new ActionRowBuilder();
    }
  }
  
  if (currentRow.components.length > 0) rows.push(currentRow);

  const msgOptions = { content: data.content };
  if (data.embed) {
    msgOptions.embeds = [createProfessionalEmbed(data.embed, message.guild)];
  }
  msgOptions.components = rows;

  await message.channel.send(msgOptions);
}

async function handleComplexTask(message, data, guild, channel) {
  const totalStartTime = Date.now();
  const steps = data.steps || [];
  const results = [];

  await message.channel.send({
    embeds: [createProfessionalEmbed({
      title: '🧠 Task Complexa Ativada',
      description: `Iniciando execução de **${steps.length} etapas**...`,
      color: '#8B5CF6'
    }, guild)]
  });

  for (let i = 0; i < steps.length; i++) {
    const step = steps[i];
    const stepStartTime = Date.now();
    
    await message.channel.send({
      embeds: [createProfessionalEmbed({
        title: `⚙️ Etapa ${i + 1}/${steps.length}`,
        description: `Executando: **${step.action || step.type}**...`,
        color: '#FBBF24'
      }, guild)]
    });

    let stepResult;
    try {
      if (isExternalTool(step.action || step.type)) {
        stepResult = await executeExternalTool({ type: step.action || step.type, ...step }, message);
      } else {
        // Ações internas
        stepResult = await executeSingleAction(step, guild, channel, message);
      }
    } catch (err) {
      stepResult = { error: err.message };
    }

    const stepDuration = ((Date.now() - stepStartTime) / 1000).toFixed(2);
    results.push({ step: i + 1, action: step.action || step.type, duration: stepDuration, result: stepResult });

    await message.channel.send({
      embeds: [createProfessionalEmbed({
        title: `✅ Etapa ${i + 1} Concluída`,
        description: `Tempo: **${stepDuration}s**`,
        color: '#10B981'
      }, guild)]
    });
    
    await sleep(500);
  }

  const totalDuration = ((Date.now() - totalStartTime) / 1000).toFixed(2);

  // IA Finalizadora para Task Complexa
  const completion = await client.chat.completions.create({
    model: 'stepfun-ai/step-3.5-flash',
    messages: [
      { 
        role: 'system', 
        content: `Você é o finalizador do MutanoX para Tasks Complexas.
        
Sua tarefa é apresentar o resultado final de todas as etapas executadas.
Tempo Total: ${totalDuration}s
Resultados: ${JSON.stringify(results)}

IMPORTANTE:
- Diga que a Task Complexa terminou.
- Apresente o resultado final de forma decorada e amigável.
- Mostre o tempo total e o tempo de cada etapa.` 
      }
    ],
    temperature: 0.7
  });

  const finalContent = completion.choices[0]?.message?.content || 'Task Complexa finalizada!';
  const finalResponse = parseResponse(finalContent);
  
  addAIMMessage(channel.id, finalContent);
  await executeAction(finalResponse, message, guild, channel);
}

async function sendSplitMessage(message, content) {
  if (!content) return;
  const limit = 1950;
  if (content.length <= limit) {
    return await message.reply({ content, allowedMentions: { repliedUser: false } });
  }

  const chunks = [];
  for (let i = 0; i < content.length; i += limit) {
    chunks.push(content.substring(i, i + limit));
  }

  for (const chunk of chunks) {
    await message.channel.send({ content: chunk });
    await sleep(200);
  }
}

async function executeSingleAction(action, guild, channel, message) {
  try {
    switch (action.type) {
      case 'create_category':
        const category = await guild.channels.create({ name: action.name, type: 4 });
        if (action.channels) {
          for (const ch of action.channels) {
            await guild.channels.create({ name: ch.name, type: ch.type || 0, parent: category.id, topic: ch.topic });
            await sleep(200);
          }
        }
        await message.channel.send(`✅ Categoria "${action.name}" criada!`);
        break;
        
      case 'send_embed':
        await handleSendEmbed(message, action, guild, channel);
        break;
    }
  } catch (error) {
    console.error('Erro na ação:', error);
  }
}

function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
export default { name, execute };
