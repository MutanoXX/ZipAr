/**
 * MutanoX Architect - Comando /delete-server
 * Comando perigoso que deleta toda a estrutura do servidor
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags
} from 'discord.js';
import { isAuthorized } from '../utils/permissions.js';

export const data = new SlashCommandBuilder()
  .setName('delete-server')
  .setDescription('⚠️ COMANDO PERIGOSO - Deleta toda estrutura do servidor');

export async function execute(interaction) {
  // Verificar permissão
  if (!isAuthorized(interaction.user.id)) {
    return interaction.reply({
      content: '❌ Você não tem permissão para usar este comando.',
      flags: MessageFlags.Ephemeral
    });
  }

  const guild = interaction.guild;

  // Mostrar aviso e pedir confirmação
  const warningEmbed = new EmbedBuilder()
    .setTitle('⚠️ ATENÇÃO: COMANDO PERIGOSO')
    .setDescription('Este comando irá **DELETAR TODA A ESTRUTURA** do servidor!')
    .addFields(
      { name: '📁 Canais', value: `${guild.channels.cache.size} serão deletados`, inline: true },
      { name: '👥 Cargos', value: `${guild.roles.cache.size} serão deletados`, inline: true },
      { name: '📍 Preservado', value: `Este canal será mantido`, inline: true }
    )
    .setColor('#FF0000')
    .setFooter({ text: 'Esta ação é IRREVERSÍVEL!' })
    .setTimestamp();

  const confirmRow = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('confirm_delete')
        .setLabel('🗑️ CONFIRMAR DELEÇÃO')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('cancel_delete')
        .setLabel('❌ Cancelar')
        .setStyle(ButtonStyle.Secondary)
    );

  await interaction.reply({
    embeds: [warningEmbed],
    components: [confirmRow],
    flags: MessageFlags.Ephemeral
  });
}

/**
 * Executa a deleção do servidor
 */
export async function executeDelete(interaction, guild) {
  const currentChannel = interaction.channel;
  
  await interaction.update({
    embeds: [
      new EmbedBuilder()
        .setTitle('🗑️ Deletando servidor...')
        .setDescription('Por favor, aguarde. Esta operação pode levar alguns segundos.')
        .setColor('#FF0000')
    ],
    components: []
  });

  const result = {
    channelsDeleted: 0,
    rolesDeleted: 0,
    errors: []
  };

  console.log(`🗑️ [DeleteServer] Iniciando deleção em: ${guild.name}`);

  try {
    // 1. Deletar todos os canais EXCETO o canal atual
    const channelsToDelete = guild.channels.cache.filter(c => c.id !== currentChannel.id);
    
    console.log(`📁 [DeleteServer] Deletando ${channelsToDelete.size} canais...`);
    
    for (const [id, channel] of channelsToDelete) {
      try {
        await channel.delete('MutanoX Architect - Limpeza de servidor');
        result.channelsDeleted++;
        await sleep(200);
      } catch (error) {
        console.error(`Erro ao deletar canal ${channel.name}:`, error.message);
        result.errors.push(`Canal "${channel.name}": ${error.message}`);
      }
    }

    // 2. Deletar todos os cargos EXCETO @everyone e cargos de bots
    const rolesToDelete = guild.roles.cache.filter(r => 
      !r.managed && // Não deletar cargos de bots
      r.id !== guild.roles.everyone.id && // Não deletar @everyone
      r.position < guild.members.me.roles.highest.position // Apenas cargos abaixo do bot
    );
    
    console.log(`👥 [DeleteServer] Deletando ${rolesToDelete.size} cargos...`);
    
    for (const [id, role] of rolesToDelete) {
      try {
        await role.delete('MutanoX Architect - Limpeza de servidor');
        result.rolesDeleted++;
        await sleep(200);
      } catch (error) {
        console.error(`Erro ao deletar cargo ${role.name}:`, error.message);
        result.errors.push(`Cargo "${role.name}": ${error.message}`);
      }
    }

    console.log(`✅ [DeleteServer] Deleção concluída: ${result.channelsDeleted} canais, ${result.rolesDeleted} cargos`);

    // Resultado final
    const successEmbed = new EmbedBuilder()
      .setTitle('✅ Servidor Limpo!')
      .setDescription('A estrutura do servidor foi completamente removida.')
      .addFields(
        { name: '📁 Canais Deletados', value: `${result.channelsDeleted}`, inline: true },
        { name: '👥 Cargos Deletados', value: `${result.rolesDeleted}`, inline: true },
        { name: '📍 Canal Preservado', value: `<#${currentChannel.id}>`, inline: true }
      )
      .setColor('#10B981')
      .setTimestamp();

    if (result.errors.length > 0) {
      successEmbed.addFields({
        name: '⚠️ Erros',
        value: result.errors.slice(0, 3).join('\n'),
        inline: false
      });
    }

    await currentChannel.send({ embeds: [successEmbed] });

  } catch (error) {
    console.error('❌ [DeleteServer] Erro crítico:', error);
    
    await currentChannel.send({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Erro na Deleção')
          .setDescription(error.message)
          .setColor('#FF0000')
      ]
    });
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export default { data, execute, executeDelete };
