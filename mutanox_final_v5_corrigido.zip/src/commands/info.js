/**
 * MutanoX Architect - Comando /info
 * Mostra informações sobre o bot
 */

import { SlashCommandBuilder, EmbedBuilder, MessageFlags } from 'discord.js';
import { isAuthorized } from '../utils/permissions.js';
import { getActiveChannels } from '../utils/activeChannels.js';

export const data = new SlashCommandBuilder()
  .setName('info')
  .setDescription('ℹ️ Mostra informações sobre o MutanoX Architect');

export async function execute(interaction) {
  // Verificar permissão
  if (!isAuthorized(interaction.user.id)) {
    return interaction.reply({
      content: '❌ Você não tem permissão para usar este comando.',
      flags: MessageFlags.Ephemeral
    });
  }

  const client = interaction.client;
  const activeChannels = getActiveChannels(interaction.guild.id);

  const embed = new EmbedBuilder()
    .setTitle('🏗️ MutanoX Architect AI')
    .setDescription('Bot Discord inteligente para análise e reestruturação de servidores')
    .setColor('#8B5CF6')
    .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 256 }))
    .addFields(
      {
        name: '📊 Estatísticas',
        value: `• **Servidores:** ${client.guilds.cache.size}\n• **Usuários:** ${client.users.cache.size}\n• **Latência:** ${client.ws.ping}ms`,
        inline: true
      },
      {
        name: '💬 Canais Ativos',
        value: activeChannels.length > 0 
          ? activeChannels.map(id => `<#${id}>`).join('\n')
          : 'Nenhum canal ativo',
        inline: true
      },
      {
        name: '🛠️ Comandos',
        value: '• `/architect analyze` - Gera estrutura completa\n• `/architect quick` - Estrutura por tema\n• `/ask on` - Ativa IA em um canal\n• `/ask off` - Desativa IA\n• `/ask list` - Lista canais ativos\n• `/delete-server` - Limpa o servidor\n• `/info` - Esta mensagem',
        inline: false
      },
      {
        name: '🤖 Como Usar a IA',
        value: '1. Use `/ask on` para ativar a IA em um canal\n2. Converse naturalmente com ela!\n3. Ela pode criar canais, cargos, enviar embeds, e muito mais!',
        inline: false
      }
    )
    .setFooter({
      text: `Solicitado por ${interaction.user.tag}`,
      iconURL: interaction.user.displayAvatarURL({ dynamic: true })
    })
    .setTimestamp();

  await interaction.reply({
    embeds: [embed],
    flags: MessageFlags.Ephemeral
  });
}

export default { data, execute };
