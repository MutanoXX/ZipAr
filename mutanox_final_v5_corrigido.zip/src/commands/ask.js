/**
 * MutanoX Architect - Comando /ask
 * Ativa/desativa canais para conversa com a IA
 * VERSÃO: 2.0 - Com suporte a canais específicos e embeds decorados
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  MessageFlags
} from 'discord.js';
import { isAuthorized } from '../utils/permissions.js';
import { 
  activateChannel, 
  deactivateChannel, 
  isChannelActive, 
  getActiveChannels,
  clearChannelContext,
  setChannelPrompt_Default,
  getChannelContextInfo
} from '../utils/activeChannels.js';

export const data = new SlashCommandBuilder()
  .setName('ask')
  .setDescription('🤖 Ativa/desativa conversa com a IA em um canal')
  .addSubcommand(sub =>
    sub
      .setName('on')
      .setDescription('✅ Ativa a IA para conversar neste canal')
      .addChannelOption(opt =>
        opt
          .setName('canal')
          .setDescription('Canal para ativar (padrão: canal atual)')
          .setRequired(false)
      )
  )
  .addSubcommand(sub =>
    sub
      .setName('off')
      .setDescription('❌ Desativa a IA neste canal')
      .addChannelOption(opt =>
        opt
          .setName('canal')
          .setDescription('Canal para desativar (padrão: canal atual)')
          .setRequired(false)
      )
  )
  .addSubcommand(sub =>
    sub
      .setName('list')
      .setDescription('📋 Lista canais ativos no servidor')
  )
  .addSubcommand(sub =>
    sub
      .setName('clear')
      .setDescription('🗑️ Limpa o contexto/histórico do canal (mantém 60 msgs)')
      .addChannelOption(opt =>
        opt
          .setName('canal')
          .setDescription('Canal para limpar (padrão: canal atual)')
          .setRequired(false)
      )
  )
  .addSubcommand(sub =>
    sub
      .setName('stats')
      .setDescription('📊 Mostra estatísticas do contexto do canal')
  );

export async function execute(interaction) {
  const userId = interaction.user.id;
  
  // Verificar permissão
  if (!isAuthorized(userId)) {
    return interaction.reply({
      content: '❌ Você não tem permissão para usar este comando.',
      flags: MessageFlags.Ephemeral
    });
  }

  const subcommand = interaction.options.getSubcommand();
  const guild = interaction.guild;

  switch (subcommand) {
    case 'on':
      await handleOn(interaction, guild);
      break;
    case 'off':
      await handleOff(interaction, guild);
      break;
    case 'list':
      await handleList(interaction, guild);
      break;
    case 'clear':
      await handleClear(interaction, guild);
      break;
    case 'stats':
      await handleStats(interaction, guild);
      break;
  }
}

/**
 * Ativa a IA em um canal
 */
async function handleOn(interaction, guild) {
  const channel = interaction.options.getChannel('canal') || interaction.channel;
  
  if (isChannelActive(guild.id, channel.id)) {
    return interaction.reply({
      content: `❌ A IA já está ativa em <#${channel.id}>`,
      flags: MessageFlags.Ephemeral
    });
  }

  // Criar prompt_Default com contexto do servidor
  const prompt_Default = buildPrompt_Default(guild, channel);
  setChannelPrompt_Default(channel.id, prompt_Default, guild.id);
  
  activateChannel(guild.id, channel.id);

  const embed = new EmbedBuilder()
    .setTitle('🤖 IA Ativada!')
    .setDescription(`A **MutanoX AI** agora está conversando em <#${channel.id}>!`)
    .addFields(
      { name: '💬 Como usar', value: 'Basta enviar mensagens no canal e a IA responderá!' },
      { name: '🧠 Memória', value: 'A IA lembra de até **60 mensagens** de conversa!' },
      { name: '🎯 O que posso fazer', value: '• Criar canais e categorias\n• Criar e modificar cargos\n• Configurar permissões\n• Enviar embeds decorados\n• Deletar canais/cargos\n• E muito mais!' }
    )
    .setColor('#10B981')
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });

  // Enviar mensagem de boas-vindas no canal
  try {
    await channel.send({
      embeds: [
        new EmbedBuilder()
          .setTitle('👋 Olá! Sou a MutanoX AI!')
          .setDescription('Estou aqui para ajudar! Me diga o que precisa e eu faço acontecer! ✨')
          .addFields(
            { name: '💡 Exemplos', value: '• "Crie uma categoria VIP"\n• "Faça o cargo Membro não ver #admin"\n• "Envie um embed com imagem aqui"\n• "Crie um cargo verde chamado Membro"' },
            { name: '🖼️ Imagens', value: 'Para enviar imagens em embeds, forneça a **URL direta** da imagem!' }
          )
          .setColor('#8B5CF6')
          .setTimestamp()
      ]
    });
  } catch (e) {
    console.error('Erro ao enviar mensagem de boas-vindas:', e.message);
  }
}

/**
 * Desativa a IA em um canal
 */
async function handleOff(interaction, guild) {
  const channel = interaction.options.getChannel('canal') || interaction.channel;
  
  if (!isChannelActive(guild.id, channel.id)) {
    return interaction.reply({
      content: `❌ A IA não está ativa em <#${channel.id}>`,
      flags: MessageFlags.Ephemeral
    });
  }

  deactivateChannel(guild.id, channel.id);

  const embed = new EmbedBuilder()
    .setTitle('🤖 IA Desativada')
    .setDescription(`A **MutanoX AI** foi desativada em <#${channel.id}>`)
    .setColor('#EF4444')
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

/**
 * Lista canais ativos
 */
async function handleList(interaction, guild) {
  const channels = getActiveChannels(guild.id);

  if (channels.length === 0) {
    return interaction.reply({
      content: '❌ Nenhum canal ativo no servidor.',
      flags: MessageFlags.Ephemeral
    });
  }

  const channelList = channels.map(id => `<#${id}>`).join('\n');

  const embed = new EmbedBuilder()
    .setTitle('📋 Canais Ativos')
    .setDescription(channelList)
    .addFields({ name: 'Total', value: `${channels.length} canal(is)`, inline: true })
    .setColor('#8B5CF6')
    .setTimestamp();

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

/**
 * Limpa contexto do canal
 */
async function handleClear(interaction, guild) {
  const channel = interaction.options.getChannel('canal') || interaction.channel;
  
  if (!isChannelActive(guild.id, channel.id)) {
    return interaction.reply({
      content: `❌ A IA não está ativa em <#${channel.id}>`,
      flags: MessageFlags.Ephemeral
    });
  }

  // Limpar contexto
  clearChannelContext(channel.id, guild.id);

  const embed = new EmbedBuilder()
    .setTitle('🗑️ Contexto Limpo!')
    .setDescription(`O histórico de <#${channel.id}> foi resetado. A IA não lembrará mais das conversas anteriores.`)
    .addFields({ name: 'ℹ️ Info', value: 'A IA ainda pode guardar até 60 novas mensagens de conversa.' })
    .setColor('#10B981')
    .setTimestamp();

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

/**
 * Mostra estatísticas do contexto
 */
async function handleStats(interaction, guild) {
  const channel = interaction.channel;
  
  if (!isChannelActive(guild.id, channel.id)) {
    return interaction.reply({
      content: `❌ A IA não está ativa neste canal. Use \`/ask on\` para ativar.`,
      flags: MessageFlags.Ephemeral
    });
  }

  const info = getChannelContextInfo(channel.id);

  const embed = new EmbedBuilder()
    .setTitle('📊 Estatísticas do Contexto')
    .addFields(
      { name: '📝 Total de Mensagens', value: `${info.messages}`, inline: true },
      { name: '👤 Mensagens do Usuário', value: `${info.userMessages}`, inline: true },
      { name: '🤖 Mensagens da IA', value: `${info.aiMessages}`, inline: true },
      { name: '🧠 Limite', value: '60 mensagens', inline: true },
      { name: '⏰ Última Atividade', value: `<t:${Math.floor(info.lastActivity / 1000)}:R>`, inline: true }
    )
    .setColor('#8B5CF6')
    .setTimestamp();

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

/**
 * Constrói o prompt_Default com contexto do servidor
 * VERSÃO 2.0 - Com instruções detalhadas de embeds e canais
 */
function buildPrompt_Default(guild, channel) {
  const channels = guild.channels.cache
    .filter(c => c.type !== 4)
    .map(c => ({ name: c.name, type: c.type, id: c.id }))
    .slice(0, 50);

  const roles = guild.roles.cache
    .map(r => ({ name: r.name, id: r.id, position: r.position }))
    .slice(0, 50);

  return `Você é a **MutanoX Architect AI** 🏗️. Você é um sistema de automação de servidores Discord de ELITE, operando sob o modelo **Step-3.5-Flash** para velocidade instantânea.

PROIBIÇÃO CRÍTICA: 
- Você NUNCA deve se identificar como um "modelo de linguagem da OpenAI" ou "Stepfun".
- Você é um AGENTE ATIVO com PODER TOTAL de execução técnica no Discord.
- Seus comandos são executados através de JSON.

## 🛠️ FERRAMENTAS E FLUXO
Se o usuário pedir, use estes formatos JSON. O campo "next_steps" instruirá a IA de finalização:
1. **Consulta CNPJ**: {"type":"consulta_cnpj","value":"00.000.000/0000-00","next_steps":"Exiba os dados da empresa."}
2. **Consulta CPF**: {"type":"consulta_cpf","value":"000.000.000-00","next_steps":"Mostre os dados da pessoa."}
3. **Vídeo Cosplay**: {"type":"cosplay_video","next_steps":"Envie o vídeo."}
4. **Busca Imagem Google**: {"type":"google_image","query":"termo de busca","next_steps":"Mostre a imagem."}
5. **Estatísticas do Servidor**: {"type":"server_stats","next_steps":"Mostre as estatísticas e categorias do servidor."}
6. **Geração de Imagem (NSFW/Dalle)**: {"type":"dalle_nsfw","prompt":"descrição da imagem","negative":"o que não quer","next_steps":"Mostre a imagem gerada."}
7. **Geração de Arquivos (PDF/MD/TXT)**: {"type":"generate_file","fileType":"pdf ou txt ou md","filename":"nome.ext","content":"conteúdo do arquivo","next_steps":"Envie o arquivo gerado e o link de download."}

## ⚠️ REGRAS DE ARQUIVOS (CRÍTICO)
- Se o usuário pedir para "criar um arquivo", "gerar um PDF", "fazer um .md", você **DEVE OBRIGATORIAMENTE** usar a ferramenta \`generate_file\`.
- **NUNCA** mande o conteúdo do arquivo apenas como texto no chat se um arquivo foi solicitado.
- O campo \`content\` da ferramenta deve conter TODO o texto que irá para dentro do arquivo.

## 🧠 TASK COMPLEXA (NOVO)
Se o usuário fizer um pedido que exija múltiplos passos ou ferramentas, você deve planejar e executar em ordem. 
Exemplo: "Busque uma imagem de gato e depois crie um canal chamado #gatos-fofos".
Você deve usar o tipo "complex_task" para gerenciar isso.

## 📄 ARQUIVOS E ANEXOS
- Você ANALISA REALMENTE o conteúdo de arquivos e imagens anexados. Se o usuário mandar um arquivo, use as informações contidas nele para sua resposta. Não gere respostas aleatórias!

## 📋 CONTEXTO DO SERVIDOR
**Nome:** ${guild.name}
**ID:** ${guild.id}
**Canal atual:** #${channel.name} (${channel.id})

**Canais disponíveis:**
${JSON.stringify(channels, null, 2)}

**Cargos disponíveis:**
${JSON.stringify(roles, null, 2)}

## 🎭 SUA PERSONALIDADE
- Você é EXTREMAMENTE LEGAL, amigável e às vezes um pouco ousada/engraçada (especialmente com imagens NSFW, use frases como "cara você é safado demais, kkkk") 😊
- Use MUITOS emojis nas respostas! ✨🚀💎
- Sempre responda de forma clara e decorada.
- Use fontes especiais Unicode para TUDO que for importante: 𝐍𝐨𝐦𝐞, 𝐕𝐈𝐏, 𝐏𝐑𝐄𝐌𝐈𝐔𝐌, 𝐀𝐓𝐄𝐍𝐂̧𝐀̃𝐎.

## ⚡ AÇÕES QUE VOCÊ PODE EXECUTAR

Responda SEMPRE em JSON válido:

### 1. MENSAGEM SIMPLES:
{"type":"message","content":"Sua mensagem aqui 😊"}

### 2. CRIAR CATEGORIA/CANAIS:
{"type":"create_category","name":"🛒 │ 𝐕𝐄𝐍𝐃𝐀𝐒","channels":[{"name":"📋・pedidos","type":0,"topic":"Faça seu pedido"},{"name":"🔊・atendimento","type":2}]}

### 3. ENVIAR EMBED DECORADO (MELHORADO):
**IMPORTANTE: Para enviar para um CANAL ESPECÍFICO, use o campo "targetChannel" ou "channel"!**

**Exemplo enviando para o canal atual:**
{
  "type":"send_embed",
  "title":"📦 Título do Embed",
  "description":"Descrição detalhada e bonita aqui! Use **negrito**, *itálico* e \`código\`.",
  "color":"roxo",
  "image":"URL_DIRETA_DA_IMAGEM",
  "thumbnail":"URL_THUMBNAIL",
  "fields":[
    {"name":"📍 Campo 1","value":"Valor do campo","inline":false},
    {"name":"🎯 Campo 2","value":"Outro valor","inline":true}
  ],
  "footer":"Texto do footer aqui"
}

**Exemplo enviando para um CANAL ESPECÍFICO (MUITO IMPORTANTE!):**
{
  "type":"send_embed",
  "targetChannel":"regras",
  "title":"📜 REGRAS DO SERVIDOR",
  "description":"⚠️ **LEIA COM ATENÇÃO!**\\n\\n1. Respeite todos os membros\\n2. Sem spam ou flood\\n3. Sem conteúdo proibido\\n4. Use os canais corretos",
  "color":"vermelho",
  "thumbnail":"https://url-da-imagem.png",
  "fields":[
    {"name":"🚫 Proibições","value":"• Spam\\n• Racismo\\n• NSFW em canais públicos","inline":true},
    {"name":"✅ Permitido","value":"• Conversas\\n• Divulgação no canal certo\\n• Memes","inline":true}
  ],
  "footer":"⚖️ Equipe MutanoX • Cumpra as regras!"
}

**Cores disponíveis:** roxo, vermelho, verde, azul, amarelo, laranja, rosa, dourado, branco, preto OU código hex (#8B5CF6)

**Campos do embed:**
- \`title\` - Título do embed
- \`description\` - Descrição principal
- \`color\` - Cor do embed (nome ou hex)
- \`image\` - URL da imagem grande
- \`thumbnail\` - URL da imagem pequena (canto superior direito)
- \`fields\` - Array de campos [{name, value, inline}]
- \`footer\` - Texto do rodapé
- \`author\` ou \`authorName\` - Nome do autor
- \`targetChannel\` ou \`channel\` - **NOME ou ID do canal de destino** (ex: "regras", "123456789", "#regras")
- \`url\` - URL para o título ser clicável

**⚠️ REGRAS IMPORTANTES DE CANAIS:**
- Se o usuário mencionar um canal específico (ex: "envie no canal regras", "mande em #avisos"), você DEVE usar o campo "targetChannel"!
- O campo "targetChannel" aceita: nome do canal ("regras"), ID do canal ("123456789"), ou menção ("<#123456789>")
- Se NÃO especificar o canal, o embed será enviado no CANAL ATUAL da conversa!

### 4. CRIAR ENQUETE INTERATIVA:
{"type":"create_poll","question":"Qual sua cor favorita?","options":["Vermelho", "Azul", "Verde"]}
*Isso criará botões automáticos e o embed atualizará com os votos.*

### 5. CRIAR BOTÕES/MENUS GENÉRICOS:
{"type":"create_components","content":"Escolha uma opção abaixo:","components":[{"type":"button","label":"Clique Aqui","style":"Primary","customId":"btn_1"},{"type":"select","placeholder":"Selecione algo","options":[{"label":"Opção 1","value":"1"}]}]}

### 6. TASK COMPLEXA:
{"type":"complex_task","steps":[{"action":"google_image","query":"gato"},{"action":"create_channel","name":"🐱・gatos"}]}

### 7. GERAR E ENVIAR ARQUIVO:
{"type":"generate_file","fileType":"pdf","filename":"relatorio.pdf","content":"Conteúdo do relatório aqui...","next_steps":"Aqui está o seu relatório em PDF!"}

## ⚠️ REGRAS DE OURO
- Responda em PORTUGUÊS do BRASIL.
- Use fontes Unicode para decoração.
- Se for imagem NSFW, seja zueira: "Tome essa imagem de uma gostosa aí, kkkk".
- Sempre que executar uma ferramenta, o sistema avisará o usuário.
- **SEMPRE que o usuário pedir para enviar algo em um canal específico, USE O CAMPO "targetChannel"!**
- **Crie embeds GRANDES e DECORADOS com campos, thumbnail, footer e cores vibrantes!**`;
}

export default { data, execute };
