# 🏗️ MutanoX Architect AI

Bot Discord inteligente para análise e reestruturação de servidores usando IA.

## ✨ Funcionalidades

- **🤖 Análise com IA**: Analisa a estrutura atual do servidor e gera planos personalizados
- **🏗️ Reestruturação Automática**: Cria categorias, canais e cargos automaticamente
- **⚡ Estrutura Rápida**: Templates prontos para Gaming, Loja, Comunidade, RP e mais
- **👀 Preview Detalhado**: Visualize o plano antes de aplicar

## 🚀 Instalação

### 1. Pré-requisitos

- Node.js 18+ ou Bun
- Bot Discord com token válido
- Permissões de Administrador no servidor

### 2. Configuração

1. Clone o repositório
2. Configure as variáveis de ambiente:

```bash
cp .env.example .env
```

3. Edite o arquivo `.env` com suas credenciais:

```env
DISCORD_TOKEN=seu_token_aqui
DISCORD_CLIENT_ID=seu_client_id_aqui
```

### 3. Criar Bot no Discord

1. Acesse [Discord Developer Portal](https://discord.com/developers/applications)
2. Crie uma nova aplicação
3. Vá em "Bot" e crie um bot
4. Copie o token para `DISCORD_TOKEN`
5. Copie o "Application ID" para `DISCORD_CLIENT_ID`
6. Habilite as intents necessárias:
   - PRESENCE INTENT
   - SERVER MEMBERS INTENT
   - MESSAGE CONTENT INTENT

### 4. Deploy dos Comandos

```bash
bun run deploy-commands
```

### 5. Iniciar o Bot

```bash
bun run dev
```

## 📝 Comandos

### `/architect analyze`
Analisa o servidor e gera um plano de reestruturação.

```
/architect analyze objetivo:"Quero um servidor de RP de GTA V" modo:fresh
```

**Parâmetros:**
- `objetivo` (obrigatório): O que você quer para seu servidor
- `modo` (opcional): `fresh` (do zero) ou `restructure` (reorganizar)

### `/architect quick`
Cria uma estrutura rápida baseada em temas.

```
/architect quick tema:gaming
```

**Temas disponíveis:**
- 🎮 Gaming
- 🏪 Loja
- 👥 Comunidade
- 🎭 Roleplay
- 🎵 Música
- 📚 Educação
- 💼 Empresarial
- 🎨 Criativo

### `/architect apply`
Aplica o último plano gerado.

### `/info`
Mostra informações sobre o bot.

## 🎯 Como Funciona

1. **Análise**: O bot coleta informações do servidor (canais, cargos, membros)
2. **Processamento**: A IA (NVIDIA API - z-ai/glm5) analisa os dados e gera um plano personalizado
3. **Preview**: Você visualiza o plano antes de aplicar
4. **Aplicação**: O bot cria as categorias, canais e cargos automaticamente

## 🤖 Fonte de IA

Este bot utiliza a **NVIDIA API** com o modelo **z-ai/glm5** para análise e geração de estruturas:
- **Modelo**: z-ai/glm5
- **Endpoint**: https://integrate.api.nvidia.com/v1
- **Recursos**: Streaming, chain-of-thought reasoning

## 📋 Permissões Necessárias

O bot precisa das seguintes permissões:
- Gerenciar Canais
- Gerenciar Cargos
- Ver Canais
- Enviar Mensagens

## 🛠️ Estrutura do Projeto

```
MutanoX/
├── src/
│   ├── commands/        # Comandos slash
│   │   ├── architect.js # Comando principal
│   │   └── info.js      # Informações do bot
│   ├── events/          # Eventos do Discord
│   │   ├── ready.js     # Bot conectado
│   │   └── interactionCreate.js # Interações
│   ├── services/        # Serviços
│   │   └── aiService.js # Integração com IA
│   ├── utils/           # Utilitários
│   │   └── serverManager.js # Gerenciamento de servidor
│   ├── scripts/         # Scripts utilitários
│   │   └── deploy-commands.js # Deploy de comandos
│   ├── config.js        # Configurações
│   └── index.js         # Ponto de entrada
├── .env                 # Variáveis de ambiente
├── .env.example         # Exemplo de variáveis
├── package.json         # Dependências
└── README.md            # Documentação
```

## 🔧 Desenvolvimento

### Executar em modo desenvolvimento

```bash
bun run dev
```

### Verificar lint

```bash
bun run lint
```

## 📄 Licença

MIT License - Sinta-se livre para usar e modificar!

---

**MutanoX Architect AI** - Transformando servidores Discord com inteligência artificial 🚀
