/**
 * MutanoX Architect AI - Bot Discord
 * Ponto de entrada principal
 * 
 * @description Bot Discord para análise e reestruturação de servidores usando IA
 * @version 1.0.0
 */

import { Client, GatewayIntentBits, Collection, REST, Routes } from 'discord.js';
import { config } from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import aiService from './src/services/aiService.js';

// Carregar variáveis de ambiente
config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Validar variáveis de ambiente obrigatórias
if (!process.env.DISCORD_TOKEN) {
  console.error('❌ DISCORD_TOKEN não definido nas variáveis de ambiente');
  process.exit(1);
}

if (!process.env.DISCORD_CLIENT_ID) {
  console.error('❌ DISCORD_CLIENT_ID não definido nas variáveis de ambiente');
  process.exit(1);
}

// Criar cliente Discord
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ]
});

// Coleção para comandos
client.commands = new Collection();

// Armazenamento temporário de planos
global.mutanoxPlans = {};

// Array para armazenar dados dos comandos para registro
const commandsData = [];

/**
 * Carregar comandos
 */
async function loadCommands() {
  const commandsPath = path.join(__dirname, 'src', 'commands');
  const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

  for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    try {
      const module = await import(filePath);
      const command = module.default || module;
      
      if (command.data && command.execute) {
        client.commands.set(command.data.name, command);
        commandsData.push(command.data.toJSON());
        console.log(`📄 [Commands] Carregado: /${command.data.name}`);
      } else {
        console.log(`⚠️ [Commands] Arquivo sem export válido (data ou execute faltando): ${file}`);
      }
    } catch (error) {
      console.error(`❌ [Commands] Erro ao carregar comando ${file}:`, error.message);
    }
  }
}

/**
 * Carregar eventos
 */
async function loadEvents() {
  const eventsPath = path.join(__dirname, 'src', 'events');
  const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

  for (const file of eventFiles) {
    const filePath = path.join(eventsPath, file);
    const event = await import(filePath);
    
    if (event.name && event.execute) {
      if (event.once) {
        client.once(event.name, (...args) => event.execute(...args));
      } else {
        client.on(event.name, (...args) => event.execute(...args));
      }
      console.log(`🎯 [Events] Carregado: ${event.name}`);
    } else {
      console.log(`⚠️ [Events] Arquivo sem export válido: ${file}`);
    }
  }
}

/**
 * Registrar comandos slash no Discord
 */
async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

  try {
    console.log('🔄 Registrando comandos slash...');

    if (process.env.DISCORD_GUILD_ID) {
      // Registro específico para um servidor (instantâneo)
      await rest.put(
        Routes.applicationGuildCommands(
          process.env.DISCORD_CLIENT_ID,
          process.env.DISCORD_GUILD_ID
        ),
        { body: commandsData }
      );
      console.log(`✅ Comandos registrados no servidor!`);
    } else {
      // Registro global (pode demorar até 1 hora)
      await rest.put(
        Routes.applicationCommands(process.env.DISCORD_CLIENT_ID),
        { body: commandsData }
      );
      console.log('✅ Comandos registrados globalmente!');
      console.log('⏳ Nota: Comandos globais podem demorar até 1 hora para aparecer');
    }
  } catch (error) {
    console.error('❌ Erro ao registrar comandos:', error);
  }
}

/**
 * Inicialização do bot
 */
async function start() {
  console.log('');
  console.log('═══════════════════════════════════════════');
  console.log('       🏗️  MUTANOX ARCHITECT AI  🏗️');
  console.log('       Bot Discord - Node.js Edition');
  console.log('═══════════════════════════════════════════');
  console.log('');

  try {
    // Inicializar serviço de IA
    console.log('🤖 Inicializando serviço de IA...');
    await aiService.initialize();

    // Carregar comandos e eventos
    console.log('📂 Carregando módulos...');
    await loadCommands();
    await loadEvents();

    console.log('');
    console.log('🔌 Conectando ao Discord...');

    // Login no Discord
    await client.login(process.env.DISCORD_TOKEN);

    // Registrar comandos após conectar
    await registerCommands();

  } catch (error) {
    console.error('❌ Erro durante inicialização:', error);
    process.exit(1);
  }
}

// Tratamento de erros não capturados
process.on('unhandledRejection', error => {
  console.error('❌ Promise rejection não tratada:', error);
});

process.on('uncaughtException', error => {
  console.error('❌ Exceção não capturada:', error);
  process.exit(1);
});

// Iniciar o bot
start();

export default client;
