'use client'

import { useState } from 'react'
import {
  Search,
  Video,
  PlayCircle,
  Loader2,
  SlidersHorizontal,
  Info,
  Youtube,
  Package,
  Sticker,
  Image as ImageIcon,
  Globe,
  Sparkles,
  Type,
  Shield,
  Gamepad2
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'

interface TikTokResult {
  status: boolean
  query: string
  creator: string
  total_results: number
  requested_count: number
  result: string[]
}

type ServiceType = 'tiktok' | 'ytstalk' | 'npmstalk' | 'sticker' | 'pinterest' | 'glitchtext' | 'writetext' | 'proxy' | 'brainrots'

export default function Home() {
  const [activeService, setActiveService] = useState<ServiceType>('tiktok')
  const [query, setQuery] = useState('')
  const [resultCount, setResultCount] = useState('100')
  const [loading, setLoading] = useState(false)
  const [results, setResults] = useState<any>(null)
  const [error, setError] = useState('')
  const [requestedCount, setRequestedCount] = useState(0)

  const serviceConfigs: Record<ServiceType, {
    name: string
    icon: any
    placeholder: string
    param: string
    endpoint: string
    description: string
    hasCount: boolean
    hasInput: boolean
  }> = {
    tiktok: {
      name: 'TikTok Video Search',
      icon: Video,
      placeholder: 'Ex: cosplay, música, dança...',
      param: 'q',
      endpoint: '/api/tiktok',
      description: 'Buscar vídeos do TikTok',
      hasCount: true,
      hasInput: true
    },
    ytstalk: {
      name: 'YouTube Stalk',
      icon: Youtube,
      placeholder: 'Ex: nome do canal ou @username',
      param: 'username',
      endpoint: '/api/ytstalk',
      description: 'Informações de canais do YouTube',
      hasCount: false,
      hasInput: true
    },
    npmstalk: {
      name: 'NPM Stalk',
      icon: Package,
      placeholder: 'Ex: nome do pacote',
      param: 'q',
      endpoint: '/api/npmstalk',
      description: 'Informações de pacotes NPM',
      hasCount: false,
      hasInput: true
    },
    sticker: {
      name: 'Sticker Tool',
      icon: Sticker,
      placeholder: 'Ex: emoji ou termo',
      param: 'q',
      endpoint: '/api/sticker',
      description: 'Criar/Buscar stickers',
      hasCount: false,
      hasInput: true
    },
    pinterest: {
      name: 'Pinterest Search',
      icon: ImageIcon,
      placeholder: 'Ex: arte, design, fotografias...',
      param: 'q',
      endpoint: '/api/pinterest',
      description: 'Buscar imagens no Pinterest',
      hasCount: false,
      hasInput: true
    },
    glitchtext: {
      name: 'Glitch Text',
      icon: Sparkles,
      placeholder: 'Ex: MutanoX',
      param: 'text',
      endpoint: '/api/glitchtext',
      description: 'Criar efeito glitch em texto',
      hasCount: false,
      hasInput: true
    },
    writetext: {
      name: 'Write Text',
      icon: Type,
      placeholder: 'Ex: Hello World',
      param: 'text',
      endpoint: '/api/writetext',
      description: 'Escrever texto em imagem',
      hasCount: false,
      hasInput: true
    },
    proxy: {
      name: 'Random Proxy',
      icon: Shield,
      placeholder: 'Clique em gerar',
      param: '',
      endpoint: '/api/proxy',
      description: 'Gerar proxy aleatório',
      hasCount: false,
      hasInput: false
    },
    brainrots: {
      name: 'Brainrots Game',
      icon: Gamepad2,
      placeholder: 'Clique em gerar',
      param: '',
      endpoint: '/api/brainrots',
      description: 'Gerar desafio do jogo Brainrots',
      hasCount: false,
      hasInput: false
    }
  }

  const currentConfig = serviceConfigs[activeService]

  const handleSearch = async () => {
    if (currentConfig.hasInput && !query.trim()) return

    setLoading(true)
    setError('')
    setResults(null)

    try {
      const config = serviceConfigs[activeService]
      const url = new URL(config.endpoint, window.location.origin)

      if (activeService === 'tiktok') {
        const count = resultCount || '100'
        url.searchParams.append('q', query)
        url.searchParams.append('count', count)
      } else if (currentConfig.hasInput) {
        url.searchParams.append(config.param, query)
      }

      const response = await fetch(url.toString())
      const data = await response.json()

      if (data.status || data.result) {
        setResults(data)
        if (activeService === 'tiktok') {
          setRequestedCount(data.requested_count)
        }
      } else {
        setError('Nenhum resultado encontrado')
      }
    } catch (err) {
      setError('Erro ao buscar dados. Tente novamente.')
    } finally {
      setLoading(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch()
    }
  }

  const renderResults = () => {
    if (!results) return null

    switch (activeService) {
      case 'tiktok':
        return renderTikTokResults(results)
      case 'ytstalk':
        return renderYtStalkResults(results)
      case 'npmstalk':
        return renderNpmStalkResults(results)
      case 'sticker':
        return renderStickerResults(results)
      case 'pinterest':
        return renderPinterestResults(results)
      case 'glitchtext':
        return renderGlitchTextResults(results)
      case 'writetext':
        return renderWriteTextResults(results)
      case 'proxy':
        return renderProxyResults(results)
      case 'brainrots':
        return renderBrainrotsResults(results)
      default:
        return null
    }
  }

  const renderTikTokResults = (data: TikTokResult) => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <PlayCircle className="h-5 w-5" />
          Resultados da Busca
        </CardTitle>
        <CardDescription className="space-y-1">
          <p>{data.total_results} vídeo(s) encontrado(s) para "{query}"</p>
          {requestedCount > 0 && data.total_results < requestedCount && (
            <p className="text-amber-600 dark:text-amber-400 flex items-center gap-1 text-xs">
              <Info className="h-3 w-3" />
              Foram solicitados {requestedCount} resultados, mas a API retornou {data.total_results}
            </p>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[600px] pr-4">
          <div className="grid gap-4">
            {data.result?.map((url: string, index: number) => (
              <Card key={index} className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-muted-foreground">
                          Vídeo #{index + 1}
                        </span>
                        <Button variant="ghost" size="sm" asChild className="gap-2">
                          <a href={url} target="_blank" rel="noopener noreferrer">
                            <PlayCircle className="h-4 w-4" />
                            Assistir
                          </a>
                        </Button>
                      </div>
                      <div className="bg-muted rounded-md p-2">
                        <code className="text-xs break-all text-muted-foreground">
                          {url}
                        </code>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )

  const renderYtStalkResults = (data: any) => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Youtube className="h-5 w-5 text-red-600" />
          Informações do Canal
        </CardTitle>
        <CardDescription>Dados do canal "{query}"</CardDescription>
      </CardHeader>
      <CardContent>
        {data.result?.channelMetadata && (
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <img
                src={data.result.channelMetadata.avatarUrl}
                alt="Avatar"
                className="w-20 h-20 rounded-full"
              />
              <div>
                <h3 className="text-xl font-bold">{data.result.channelMetadata.username}</h3>
                <p className="text-sm text-muted-foreground">
                  {data.result.channelMetadata.subscriberCount}
                </p>
              </div>
            </div>
            {data.result.channelMetadata.description && (
              <div>
                <Label>Descrição</Label>
                <p className="text-sm mt-1">{data.result.channelMetadata.description}</p>
              </div>
            )}
            <div className="flex gap-2">
              <Button variant="outline" size="sm" asChild>
                <a href={data.result.channelMetadata.channelUrl} target="_blank" rel="noopener noreferrer">
                  <Globe className="h-4 w-4 mr-2" />
                  Ver Canal
                </a>
              </Button>
              {data.result.channelMetadata.rssUrl && (
                <Button variant="outline" size="sm" asChild>
                  <a href={data.result.channelMetadata.rssUrl} target="_blank" rel="noopener noreferrer">
                    RSS Feed
                  </a>
                </Button>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )

  const renderNpmStalkResults = (data: any) => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="h-5 w-5" />
          Informações do Pacote NPM
        </CardTitle>
        <CardDescription>Dados do pacote "{query}"</CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[500px] pr-4">
          <pre className="text-xs bg-muted p-4 rounded-lg overflow-auto">
            {JSON.stringify(data, null, 2)}
          </pre>
        </ScrollArea>
      </CardContent>
    </Card>
  )

  const renderStickerResults = (data: any) => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sticker className="h-5 w-5" />
          Resultado do Sticker
        </CardTitle>
        <CardDescription>Sticker para "{query}"</CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[500px] pr-4">
          <pre className="text-xs bg-muted p-4 rounded-lg overflow-auto">
            {JSON.stringify(data, null, 2)}
          </pre>
        </ScrollArea>
      </CardContent>
    </Card>
  )

  const renderPinterestResults = (data: any) => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ImageIcon className="h-5 w-5 text-red-600" />
          Resultados do Pinterest
        </CardTitle>
        <CardDescription>Imagens para "{query}"</CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[500px] pr-4">
          <pre className="text-xs bg-muted p-4 rounded-lg overflow-auto">
            {JSON.stringify(data, null, 2)}
          </pre>
        </ScrollArea>
      </CardContent>
    </Card>
  )

  const renderGlitchTextResults = (data: any) => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-purple-600" />
          Imagem com Efeito Glitch
        </CardTitle>
        <CardDescription>Texto: "{query}"</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {data.image && (
          <div className="space-y-4">
            <div className="rounded-lg overflow-hidden border">
              <img src={data.image} alt="Glitch Text" className="w-full" />
            </div>
            <Button variant="outline" size="sm" asChild className="w-full">
              <a href={data.image} target="_blank" rel="noopener noreferrer">
                <Globe className="h-4 w-4 mr-2" />
                Abrir Imagem
              </a>
            </Button>
            <ScrollArea className="h-[200px] pr-4">
              <pre className="text-xs bg-muted p-4 rounded-lg overflow-auto">
                {JSON.stringify(data, null, 2)}
              </pre>
            </ScrollArea>
          </div>
        )}
      </CardContent>
    </Card>
  )

  const renderWriteTextResults = (data: any) => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Type className="h-5 w-5 text-blue-600" />
          Imagem com Texto
        </CardTitle>
        <CardDescription>Texto: "{query}"</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {data.image && (
          <div className="space-y-4">
            <div className="rounded-lg overflow-hidden border">
              <img src={data.image} alt="Write Text" className="w-full" />
            </div>
            <Button variant="outline" size="sm" asChild className="w-full">
              <a href={data.image} target="_blank" rel="noopener noreferrer">
                <Globe className="h-4 w-4 mr-2" />
                Abrir Imagem
              </a>
            </Button>
            <ScrollArea className="h-[200px] pr-4">
              <pre className="text-xs bg-muted p-4 rounded-lg overflow-auto">
                {JSON.stringify(data, null, 2)}
              </pre>
            </ScrollArea>
          </div>
        )}
      </CardContent>
    </Card>
  )

  const renderProxyResults = (data: any) => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-green-600" />
          Proxy Aleatório
        </CardTitle>
        <CardDescription>Proxy gerado</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {data.proxy && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>IP</Label>
                <p className="text-sm font-mono mt-1">{data.proxy.ip}</p>
              </div>
              <div>
                <Label>Porta</Label>
                <p className="text-sm font-mono mt-1">{data.proxy.port}</p>
              </div>
              <div>
                <Label>País</Label>
                <p className="text-sm mt-1">{data.proxy.country}</p>
              </div>
              <div>
                <Label>Latência</Label>
                <p className="text-sm mt-1">{data.proxy.latency}ms</p>
              </div>
              <div>
                <Label>Anonimato</Label>
                <p className="text-sm mt-1">{data.proxy.anonymity}</p>
              </div>
              <div>
                <Label>Organização</Label>
                <p className="text-sm mt-1">{data.proxy.org || 'N/A'}</p>
              </div>
            </div>
            {data.proxy.full && (
              <div>
                <Label>URL Completa</Label>
                <div className="bg-muted rounded-md p-2 mt-1">
                  <code className="text-xs break-all">{data.proxy.full}</code>
                </div>
              </div>
            )}
            <ScrollArea className="h-[200px] pr-4">
              <pre className="text-xs bg-muted p-4 rounded-lg overflow-auto">
                {JSON.stringify(data, null, 2)}
              </pre>
            </ScrollArea>
          </div>
        )}
      </CardContent>
    </Card>
  )

  const renderBrainrotsResults = (data: any) => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Gamepad2 className="h-5 w-5 text-orange-600" />
          Desafio Brainrots
        </CardTitle>
        <CardDescription>Adivinhe o desafio!</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {data.result && (
          <div className="space-y-4">
            {data.result.img && (
              <div className="rounded-lg overflow-hidden border">
                <img src={data.result.img} alt="Brainrots Challenge" className="w-full" />
              </div>
            )}
            {data.result.jawaban && (
              <div>
                <Label>Resposta</Label>
                <div className="bg-muted rounded-md p-4 mt-1 text-center">
                  <p className="text-lg font-bold">{data.result.jawaban}</p>
                </div>
              </div>
            )}
            <ScrollArea className="h-[200px] pr-4">
              <pre className="text-xs bg-muted p-4 rounded-lg overflow-auto">
                {JSON.stringify(data, null, 2)}
              </pre>
            </ScrollArea>
          </div>
        )}
      </CardContent>
    </Card>
  )

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <header className="border-b bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <Globe className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-2xl font-bold">Multi API Hub</h1>
              <p className="text-sm text-muted-foreground">Powered by MutanoX</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto space-y-6">
          {/* Service Selector */}
          <Tabs value={activeService} onValueChange={(v) => {
            setActiveService(v as ServiceType)
            setQuery('')
            setResults(null)
            setError('')
          }}>
            <TabsList className="grid w-full grid-cols-3 md:grid-cols-9 gap-1">
              <TabsTrigger value="tiktok" className="gap-1 text-xs md:text-sm">
                <Video className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden md:inline">TikTok</span>
              </TabsTrigger>
              <TabsTrigger value="ytstalk" className="gap-1 text-xs md:text-sm">
                <Youtube className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden md:inline">YouTube</span>
              </TabsTrigger>
              <TabsTrigger value="npmstalk" className="gap-1 text-xs md:text-sm">
                <Package className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden md:inline">NPM</span>
              </TabsTrigger>
              <TabsTrigger value="sticker" className="gap-1 text-xs md:text-sm">
                <Sticker className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden md:inline">Sticker</span>
              </TabsTrigger>
              <TabsTrigger value="pinterest" className="gap-1 text-xs md:text-sm">
                <ImageIcon className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden md:inline">Pinterest</span>
              </TabsTrigger>
              <TabsTrigger value="glitchtext" className="gap-1 text-xs md:text-sm">
                <Sparkles className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden md:inline">Glitch</span>
              </TabsTrigger>
              <TabsTrigger value="writetext" className="gap-1 text-xs md:text-sm">
                <Type className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden md:inline">Write</span>
              </TabsTrigger>
              <TabsTrigger value="proxy" className="gap-1 text-xs md:text-sm">
                <Shield className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden md:inline">Proxy</span>
              </TabsTrigger>
              <TabsTrigger value="brainrots" className="gap-1 text-xs md:text-sm">
                <Gamepad2 className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden md:inline">Game</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value={activeService} className="mt-6">
              {/* Search Section */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <currentConfig.icon className="h-5 w-5" />
                    {currentConfig.name}
                  </CardTitle>
                  <CardDescription>{currentConfig.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {currentConfig.hasInput && (
                    <div className="space-y-2">
                      <Label htmlFor="query">
                        {activeService === 'ytstalk' ? 'Username' : 
                         activeService === 'glitchtext' || activeService === 'writetext' ? 'Texto' : 
                         'Termo de Busca'}
                      </Label>
                      <Input
                        id="query"
                        placeholder={currentConfig.placeholder}
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        onKeyPress={handleKeyPress}
                        disabled={loading}
                      />
                    </div>
                  )}

                  {currentConfig.hasCount && (
                    <div className="space-y-2">
                      <Label htmlFor="resultCount" className="flex items-center gap-2">
                        <SlidersHorizontal className="h-4 w-4" />
                        Quantidade de Resultados
                      </Label>
                      <Select value={resultCount} onValueChange={setResultCount} disabled={loading}>
                        <SelectTrigger id="resultCount">
                          <SelectValue placeholder="Selecione a quantidade" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="10">10 resultados</SelectItem>
                          <SelectItem value="25">25 resultados</SelectItem>
                          <SelectItem value="50">50 resultados</SelectItem>
                          <SelectItem value="75">75 resultados</SelectItem>
                          <SelectItem value="100">100 resultados (padrão)</SelectItem>
                          <SelectItem value="150">150 resultados</SelectItem>
                          <SelectItem value="200">200 resultados (máximo)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <Button onClick={handleSearch} disabled={loading || (currentConfig.hasInput && !query.trim())} className="w-full">
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processando...
                      </>
                    ) : (
                      <>
                        <Search className="mr-2 h-4 w-4" />
                        {activeService === 'ytstalk' ? 'Stalk' : 
                         activeService === 'proxy' || activeService === 'brainrots' ? 'Gerar' :
                         activeService === 'glitchtext' || activeService === 'writetext' ? 'Criar' :
                         'Buscar'}
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Error Message */}
              {error && (
                <Card className="border-destructive bg-destructive/10">
                  <CardContent className="pt-6">
                    <p className="text-destructive">{error}</p>
                  </CardContent>
                </Card>
              )}

              {/* Results */}
              {renderResults()}

              {/* Empty State */}
              {!loading && !results && !error && (
                <Card className="border-dashed">
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <currentConfig.icon className="h-16 w-16 text-muted-foreground mb-4" />
                    <p className="text-muted-foreground text-center">
                      {currentConfig.hasInput
                        ? `Digite o ${activeService === 'ytstalk' ? 'username' : 'texto'} para usar o serviço`
                        : 'Clique em gerar para usar o serviço'}
                    </p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm mt-auto">
        <div className="container mx-auto px-4 py-4 text-center text-sm text-muted-foreground">
          <p>Multi API Hub - Powered by MutanoX</p>
          <p className="text-xs mt-1">
            TikTok • YouTube • NPM • Sticker • Pinterest • Glitch • Write • Proxy • Game
          </p>
        </div>
      </footer>
    </div>
  )
}
