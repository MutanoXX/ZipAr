import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    // Fazer a requisição para a API externa
    const response = await fetch(
      'https://zelapioffciall.koyeb.app/games/brainrots',
      {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );

    if (!response.ok) {
      throw new Error(`External API responded with status: ${response.status}`);
    }

    const data = await response.json();

    // Substituir o campo creator por "MutanoX" se existir
    if (data && data.creator) {
      data.creator = 'MutanoX';
    }

    return NextResponse.json(data);
  } catch (error) {
    console.error('Error fetching brainrots game:', error);
    return NextResponse.json(
      { error: 'Failed to fetch brainrots game data', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
