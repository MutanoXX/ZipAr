import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const text = searchParams.get('text');

    if (!text) {
      return NextResponse.json(
        { error: 'Query parameter "text" is required' },
        { status: 400 }
      );
    }

    // Fazer a requisição para a API externa
    const response = await fetch(
      `https://jerrycoder.oggyapi.workers.dev/ephoto/glitchtext?text=${encodeURIComponent(text)}`,
      {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );

    if (!response.ok) {
      throw new Error(`External API responded with status: ${response.status}`);
    }

    const data = await response.json();

    // Substituir o campo Creator por "MutanoX" e remover o campo telegram
    if (data) {
      data.Creator = 'MutanoX';
      delete data.telegram;
    }

    return NextResponse.json(data);
  } catch (error) {
    console.error('Error fetching glitch text:', error);
    return NextResponse.json(
      { error: 'Failed to fetch glitch text data', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
