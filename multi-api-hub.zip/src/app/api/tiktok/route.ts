import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const query = searchParams.get('q');
    const count = searchParams.get('count') || '100'; // Padrão: 100 resultados

    if (!query) {
      return NextResponse.json(
        { error: 'Query parameter "q" is required' },
        { status: 400 }
      );
    }

    // Validar o parâmetro count
    const countNum = parseInt(count, 10);
    if (isNaN(countNum) || countNum < 1 || countNum > 200) {
      return NextResponse.json(
        { error: 'Count parameter must be between 1 and 200' },
        { status: 400 }
      );
    }

    // Construir a URL com parâmetros para maximizar resultados
    const externalUrl = new URL('https://zelapioffciall.koyeb.app/search/tiktok');
    externalUrl.searchParams.append('q', query);
    externalUrl.searchParams.append('count', countNum.toString());

    // Fazer a requisição para a API externa
    const response = await fetch(externalUrl.toString(), {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`External API responded with status: ${response.status}`);
    }

    const data = await response.json();

    // Extrair apenas o campo "play" de cada vídeo
    const playUrls = data.result?.map((video: any) => video.play).filter((url: any) => url) || [];

    return NextResponse.json({
      status: true,
      query: query,
      creator: 'MutanoX', // Substituir por MutanoX
      total_results: playUrls.length,
      requested_count: countNum,
      result: playUrls,
    });
  } catch (error) {
    console.error('Error fetching TikTok videos:', error);
    return NextResponse.json(
      { error: 'Failed to fetch TikTok videos', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
