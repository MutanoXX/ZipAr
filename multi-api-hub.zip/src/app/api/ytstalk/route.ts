import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const username = searchParams.get('username');

    if (!username) {
      return NextResponse.json(
        { error: 'Query parameter "username" is required' },
        { status: 400 }
      );
    }

    // Fazer a requisição para a API externa
    const response = await fetch(
      `https://restapiarceus.vercel.app/stalk/ytstalk?username=${encodeURIComponent(username)}`,
      {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );

    if (!response.ok) {
      throw new Error(`External API responded with status: ${response.status}`);
    }

    const data = await response.json();

    // Substituir o campo creator por "MutanoX"
    if (data && data.creator) {
      data.creator = 'MutanoX';
    }

    return NextResponse.json(data);
  } catch (error) {
    console.error('Error fetching YouTube stalk:', error);
    return NextResponse.json(
      { error: 'Failed to fetch YouTube stalk data', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
