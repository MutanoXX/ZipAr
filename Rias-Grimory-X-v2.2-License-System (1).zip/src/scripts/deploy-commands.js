/**
 * MutanoX Architect - Deploy de Comandos
 * Registra comandos slash no Discord
 * 
 * @description Script para registro de comandos slash via REST API
 * @version 2.0.0
 * @author MutanoX Team
 */

import { REST, Routes } from 'discord.js';
import { config } from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// ============================================
// CONFIGURAÇÃO
// ============================================

// Carregar variáveis de ambiente
config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ============================================
// CONSTANTES
// ============================================

/** Timeout para registro de comandos (ms) */
const REGISTER_TIMEOUT = 60000;

/** Comandos a registrar */
const commands = [];

/** Caminho para diretório de comandos */
const commandsPath = path.join(__dirname, '..', 'commands');

// ============================================
// VALIDAÇÃO
// ============================================

/**
 * Valida variáveis de ambiente necessárias
 */
function validateEnvironment() {
  const required = ['DISCORD_TOKEN', 'DISCORD_CLIENT_ID'];
  const missing = required.filter(key => !process.env[key]);

  if (missing.length > 0) {
    console.error('❌ Variáveis de ambiente faltando:');
    missing.forEach(key => console.error(`   - ${key}`));
    process.exit(1);
  }

  console.log('✅ Variáveis de ambiente validadas');
}

// ============================================
// CARREGAMENTO DE COMANDOS
// ============================================

/**
 * Carrega todos os comandos do diretório
 * @async
 * @returns {Promise<number>} Número de comandos carregados
 */
async function loadCommands() {
  // Verificar se o diretório existe
  if (!fs.existsSync(commandsPath)) {
    console.error(`❌ Diretório de comandos não encontrado: ${commandsPath}`);
    return 0;
  }

  const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

  if (commandFiles.length === 0) {
    console.warn('⚠️ Nenhum arquivo de comando encontrado');
    return 0;
  }

  console.log('');
  console.log('📂 Carregando comandos...');

  let loadedCount = 0;
  const errors = [];

  for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);

    try {
      const module = await import(filePath);
      const command = module.default || module;

      // Validar estrutura do comando
      if (!command.data) {
        console.log(`  ⚠️ ${file} - Propriedade 'data' ausente`);
        continue;
      }

      // Validar nome
      const commandName = command.data.name;
      if (!commandName || typeof commandName !== 'string') {
        console.log(`  ⚠️ ${file} - Nome de comando inválido`);
        continue;
      }

      // Adicionar à lista
      commands.push(command.data.toJSON());
      console.log(`  ✅ /${commandName}`);
      loadedCount++;

    } catch (error) {
      errors.push({ file, error: error.message });
      console.error(`  ❌ ${file} - ${error.message}`);
    }
  }

  console.log(`  📊 Total: ${loadedCount} comando(s) carregado(s)`);

  if (errors.length > 0) {
    console.log(`  ⚠️ ${errors.length} arquivo(s) com erro`);
  }

  return loadedCount;
}

// ============================================
// REGISTRO DE COMANDOS
// ============================================

/**
 * Registra comandos no Discord
 * @async
 */
async function registerCommands() {
  if (commands.length === 0) {
    console.warn('⚠️ Nenhum comando para registrar');
    return;
  }

  console.log('');
  console.log('🔌 Registrando comandos slash...');

  // Configurar REST
  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

  try {
    // Verificar se há servidor específico para desenvolvimento
    if (process.env.DISCORD_GUILD_ID) {
      // Registro específico para um servidor (mais rápido para desenvolvimento)
      console.log(`📍 Modo: Desenvolvimento (servidor específico)`);
      console.log(`   Servidor ID: ${process.env.DISCORD_GUILD_ID}`);
      console.log('');

      const data = await rest.put(
        Routes.applicationGuildCommands(
          process.env.DISCORD_CLIENT_ID,
          process.env.DISCORD_GUILD_ID
        ),
        { body: commands }
      );

      console.log(`✅ Comandos registrados no servidor: ${data.length} comando(s)`);
      console.log('⏱️ Comandos estarão disponíveis instantaneamente');

    } else {
      // Registro global (para produção)
      console.log('📍 Modo: Produção (global)');
      console.log('');

      const data = await rest.put(
        Routes.applicationCommands(process.env.DISCORD_CLIENT_ID),
        { body: commands }
      );

      console.log(`✅ Comandos registrados globalmente: ${data.length} comando(s)`);
      console.log('⏳ Nota: Comandos globais podem demorar até 1 hora para aparecer');
    }

  } catch (error) {
    console.error('❌ Erro no registro de comandos:', error.message);

    // Log adicional para erros comuns
    if (error.status === 401) {
      console.error('   Causa provável: DISCORD_TOKEN inválido');
    } else if (error.status === 403) {
      console.error('   Causa provável: Bot não tem permissão para registrar comandos');
    } else if (error.status === 429) {
      console.error('   Causa provável: Rate limit atingido. Aguarde antes de tentar novamente');
    }

    throw error;
  }
}

// ============================================
// FUNÇÃO PRINCIPAL
// ============================================

/**
 * Função principal de deploy
 * @async
 */
async function main() {
  console.log('');
  console.log('═══════════════════════════════════════════');
  console.log('       🚀 DEPLOY DE COMANDOS SLASH');
  console.log('═══════════════════════════════════════════');
  console.log('');

  try {
    // 1. Validar ambiente
    validateEnvironment();

    // 2. Carregar comandos
    const loadedCount = await loadCommands();

    if (loadedCount === 0) {
      console.error('❌ Nenhum comando carregado. Abortando.');
      process.exit(1);
    }

    // 3. Registrar comandos
    await registerCommands();

    console.log('');
    console.log('═══════════════════════════════════════════');
    console.log('       ✅ DEPLOY CONCLUÍDO COM SUCESSO!');
    console.log('═══════════════════════════════════════════');
    console.log('');

    process.exit(0);

  } catch (error) {
    console.error('');
    console.error('═══════════════════════════════════════════');
    console.error('       ❌ ERRO NO DEPLOY');
    console.error('═══════════════════════════════════════════');
    console.error('');

    if (error.stack) {
      console.error('Stack trace:');
      console.error(error.stack);
    }

    process.exit(1);
  }
}

// ============================================
// EXECUÇÃO
// ============================================
main();
