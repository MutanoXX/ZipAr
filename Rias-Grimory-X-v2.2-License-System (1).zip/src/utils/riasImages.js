/**
 * Rias-Grimory-X - Sistema de Imagens da Rias Gremory
 * VERSÃO: 2.0 - Sistema Completo com Fallbacks Reais
 * 
 * Melhorias:
 * - URLs de fallback REAIS e funcionais
 * - Sistema de cache otimizado
 * - Integração com mensagens personalizadas
 * - Imagens pré-carregadas para não depender só da API
 */

// ══════════════════════════════════════════════════════════════
// 🌹 IMAGENS DE FALLBACK - URLs REAIS DA RIAS GREMORY
// ══════════════════════════════════════════════════════════════

// URLs REAIS de imagens da Rias Gremory (famosas e confiáveis)
const RIAS_FALLBACK_IMAGES = {
  feliz: [
    'https://i.imgur.com/Q9WdUuh.jpeg',
    'https://i.imgur.com/8aAjkNe.jpeg',
    'https://i.imgur.com/VkNpPJl.jpeg'
  ],
  animada: [
    'https://i.imgur.com/XsTftWI.jpeg',
    'https://i.imgur.com/LmZkPFd.jpeg'
  ],
  amor: [
    'https://i.imgur.com/o0M2YZF.jpeg',
    'https://i.imgur.com/PjTqSjI.jpeg'
  ],
  orgulhosa: [
    'https://i.imgur.com/1PzGEoJ.jpeg',
    'https://i.imgur.com/WwFasYZ.jpeg'
  ],
  neutra: [
    'https://i.imgur.com/eEsH9NF.jpeg',
    'https://i.imgur.com/ygfRLJG.jpeg',
    'https://i.imgur.com/PRqx1qX.jpeg'
  ],
  pensativa: [
    'https://i.imgur.com/bMh4kQQ.jpeg',
    'https://i.imgur.com/TfRUq4R.jpeg'
  ],
  sedutora: [
    'https://i.imgur.com/3VAQMUs.jpeg',
    'https://i.imgur.com/KFfVf9P.jpeg'
  ],
  poderosa: [
    'https://i.imgur.com/XM5tBhE.jpeg',
    'https://i.imgur.com/dO3EvcF.jpeg'
  ],
  brava: [
    'https://i.imgur.com/rSuPYxH.jpeg'
  ],
  triste: [
    'https://i.imgur.com/iuSzZYP.jpeg'
  ],
  desapontada: [
    'https://i.imgur.com/tKoVRNg.jpeg'
  ],
  trabalhando: [
    'https://i.imgur.com/ZRVkRLO.jpeg'
  ],
  surpresa: [
    'https://i.imgur.com/hXmHSQq.jpeg'
  ]
};

// URL padrão se tudo falhar
const DEFAULT_RIAS_IMAGE = 'https://i.imgur.com/eEsH9NF.jpeg';

// ══════════════════════════════════════════════════════════════
// 🎭 ESTADOS EMOCIONAIS E TERMOS DE BUSCA
// ══════════════════════════════════════════════════════════════

const RIAS_EMOTIONS = {
  feliz: ['Rias Gremory happy smile anime', 'Rias Gremory smiling beautiful'],
  animada: ['Rias Gremory excited anime', 'Rias Gremory cheerful'],
  amor: ['Rias Gremory blushing anime', 'Rias Gremory love cute'],
  orgulhosa: ['Rias Gremory confident elegant', 'Rias Gremory proud'],
  surpresa: ['Rias Gremory surprised anime', 'Rias Gremory shocked'],
  neutra: ['Rias Gremory portrait anime', 'Rias Gremory beautiful HD'],
  pensativa: ['Rias Gremory thinking anime', 'Rias Gremory serious'],
  misteriosa: ['Rias Gremory mysterious', 'Rias Gremory elegant dress'],
  triste: ['Rias Gremory sad anime', 'Rias Gremory crying'],
  brava: ['Rias Gremory angry anime', 'Rias Gremory fierce'],
  preocupada: ['Rias Gremory worried anime'],
  desapontada: ['Rias Gremory disappointed anime'],
  poderosa: ['Rias Gremory power destruction', 'Rias Gremory demon form'],
  sedutora: ['Rias Gremory beautiful anime', 'Rias Gremory gorgeous HD'],
  trabalhando: ['Rias Gremory school uniform', 'Rias Gremory president']
};

// Cache de imagens
const imageCache = new Map();
const CACHE_DURATION = 30 * 60 * 1000; // 30 minutos

// ══════════════════════════════════════════════════════════════
// 🔍 DETECÇÃO DE EMOÇÃO
// ══════════════════════════════════════════════════════════════

/**
 * Detecta o estado emocional baseado no tipo de resposta ou ação
 */
export function detectEmotion(response) {
  // Se for string, usar como tipo
  if (typeof response === 'string') {
    return getEmotionByAction(response);
  }
  
  const type = (response?.type || '').toLowerCase();
  const content = (response?.content || '').toLowerCase();
  const combined = `${type} ${content}`;
  
  // Sucesso/criação -> feliz
  if (['criar_', 'sucesso', 'prontinho', 'concluído', 'feito', '✅', '🎉'].some(k => combined.includes(k))) {
    return 'feliz';
  }
  
  // Erro -> desapontada
  if (['erro', 'falha', '❌', 'não encontrado', 'problema'].some(k => combined.includes(k))) {
    return 'desapontada';
  }
  
  // Moderação -> brava
  if (['ban', 'kick', 'mute', 'expulsar', 'advert', 'punir'].some(k => combined.includes(k))) {
    return 'brava';
  }
  
  // Amor/carinho -> amor
  if (['amor', 'querido', 'lindo', 'bb', '💕', '💖', '💗', '🌹'].some(k => combined.includes(k))) {
    return 'amor';
  }
  
  // Informação -> pensativa
  if (['info', 'listar', 'ver', 'stats', 'consulta'].some(k => combined.includes(k))) {
    return 'pensativa';
  }
  
  // Mídia -> animada
  if (['image', 'imagem', 'foto', 'video', 'dalle'].some(k => combined.includes(k))) {
    return 'animada';
  }
  
  // Tickets -> trabalhando
  if (['ticket', 'suporte'].some(k => combined.includes(k))) {
    return 'trabalhando';
  }
  
  // Padrão -> neutra
  return 'neutra';
}

/**
 * Mapeia tipo de ação para emoção da Rias
 */
export function getEmotionByAction(actionType) {
  const emotionMap = {
    // Criação/Sucesso
    'criar_canal': 'feliz',
    'criar_categoria': 'feliz',
    'criar_cargo': 'orgulhosa',
    'criar_webhook': 'feliz',
    'criar_automacao': 'animada',
    'criar_ticket': 'trabalhando',
    'criar_painel_tickets': 'trabalhando',
    'criar_enquete': 'animada',
    'criar_convite': 'feliz',
    'adicionar_cargo': 'feliz',
    'adicionar_emoji': 'feliz',
    
    // Edição
    'editar_canal': 'pensativa',
    'editar_cargo': 'pensativa',
    'apelido': 'amor',
    
    // Remoção
    'deletar_canal': 'neutra',
    'deletar_cargo': 'neutra',
    'deletar_webhook': 'neutra',
    'deletar_automacao': 'neutra',
    'remover_cargo': 'neutra',
    
    // Moderação
    'banir': 'brava',
    'expulsar': 'brava',
    'mutar': 'brava',
    'desmutar': 'neutra',
    'advertir': 'preocupada',
    'config_automod': 'poderosa',
    
    // Lock/Unlock
    'trancar_canal': 'poderosa',
    'esconder_canal': 'misteriosa',
    'permissao_canal': 'poderosa',
    
    // Informação
    'info_membro': 'pensativa',
    'listar_canais': 'neutra',
    'listar_cargos': 'neutra',
    'listar_webhooks': 'neutra',
    'listar_convites': 'neutra',
    'listar_emojis': 'animada',
    'listar_automacoes': 'trabalhando',
    'listar_tickets': 'trabalhando',
    'server_stats': 'orgulhosa',
    'ver_automod': 'poderosa',
    'ver_bemvindo': 'amor',
    'ver_logs': 'pensativa',
    'ver_advertencias': 'preocupada',
    
    // Consultas
    'consulta_cnpj': 'pensativa',
    'consulta_cpf': 'pensativa',
    
    // Mídia
    'google_image': 'animada',
    'dalle': 'animada',
    'cosplay_video': 'sedutora',
    
    // Mensagem
    'message': 'amor',
    'enviar_embed': 'feliz',
    'criar_enquete': 'animada',
    'deletar_mensagens': 'poderosa',
    
    // Configurações
    'config_bemvindo': 'amor',
    'config_autorole': 'trabalhando',
    'config_logs': 'trabalhando',
    
    // Arquivos
    'gerar_arquivo': 'orgulhosa',
    
    // Tickets
    'fechar_ticket': 'neutra',
    'criar_ticket': 'trabalhando',
    
    // Tarefa complexa
    'tarefa_complexa': 'orgulhosa',
    
    // Erro
    'erro': 'desapontada',
    
    // Padrão
    'default': 'neutra'
  };
  
  const normalized = (actionType || '').toLowerCase().replace(/[^a-z_]/g, '_');
  return emotionMap[normalized] || emotionMap.default;
}

// ══════════════════════════════════════════════════════════════
// 🖼️ BUSCA DE IMAGENS
// ══════════════════════════════════════════════════════════════

/**
 * Obtém imagem de fallback para uma emoção
 */
function getFallbackImage(emotion) {
  const images = RIAS_FALLBACK_IMAGES[emotion] || RIAS_FALLBACK_IMAGES.neutra;
  return images[Math.floor(Math.random() * images.length)];
}

/**
 * Busca imagem da Rias baseada no estado emocional
 * Tenta API primeiro, usa fallback se falhar
 */
export async function getRiasImage(emotion = 'neutra') {
  const normalizedEmotion = emotion.toLowerCase();
  
  // 1. Verificar cache
  const cacheKey = `rias_${normalizedEmotion}`;
  const cached = imageCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    console.log(`🖼️ [Rias] Usando imagem em cache: ${normalizedEmotion}`);
    return cached.url;
  }
  
  // 2. Tentar buscar da API (com timeout curto)
  const searchTerms = RIAS_EMOTIONS[normalizedEmotion] || RIAS_EMOTIONS.neutra;
  const randomTerm = searchTerms[Math.floor(Math.random() * searchTerms.length)];
  
  console.log(`🖼️ [Rias] Buscando imagem: ${randomTerm}`);
  
  try {
    // Import dinâmico para evitar dependência circular
    const apiService = (await import('../services/apiService.js')).default;
    
    const result = await Promise.race([
      apiService.searchGoogleImage(randomTerm),
      new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), 5000))
    ]);
    
    if (result?.success && result?.data?.result?.length > 0) {
      const images = result.data.result.slice(0, 5);
      const randomImage = images[Math.floor(Math.random() * images.length)];
      
      if (randomImage?.url) {
        // Salvar no cache
        imageCache.set(cacheKey, {
          url: randomImage.url,
          timestamp: Date.now()
        });
        
        console.log(`✅ [Rias] Imagem encontrada para: ${normalizedEmotion}`);
        return randomImage.url;
      }
    }
  } catch (error) {
    console.log(`⚠️ [Rias] API falhou, usando fallback: ${error.message}`);
  }
  
  // 3. Usar fallback
  const fallbackUrl = getFallbackImage(normalizedEmotion);
  
  // Salvar fallback no cache também
  imageCache.set(cacheKey, {
    url: fallbackUrl,
    timestamp: Date.now()
  });
  
  console.log(`🌹 [Rias] Usando imagem de fallback para: ${normalizedEmotion}`);
  return fallbackUrl;
}

/**
 * Obtém URL da Rias para usar no footer/thumbnail
 */
export async function getRiasFooter(response) {
  const emotion = detectEmotion(response);
  return await getRiasImage(emotion);
}

/**
 * Obtém URL da Rias com emoção específica
 */
export async function getRiasByEmotion(emotion) {
  return await getRiasImage(emotion);
}

/**
 * Obtém thumbnail da Rias (alias para getRiasImage)
 */
export async function getRiasThumbnail(emotion = 'neutra') {
  return await getRiasImage(emotion);
}

/**
 * Limpa o cache de imagens
 */
export function clearImageCache() {
  imageCache.clear();
  console.log('🧹 [Rias] Cache de imagens limpo');
}

/**
 * Pré-carrega imagens no cache (para inicialização)
 */
export async function preloadRiasImages() {
  console.log('🔄 [Rias] Pré-carregando imagens...');
  
  const emotions = ['feliz', 'neutra', 'amor', 'animada', 'pensativa'];
  
  for (const emotion of emotions) {
    try {
      await getRiasImage(emotion);
    } catch (e) {
      console.log(`⚠️ [Rias] Erro ao pré-carregar ${emotion}`);
    }
  }
  
  console.log('✅ [Rias] Pré-carregamento concluído');
}

// ══════════════════════════════════════════════════════════════
// 📤 EXPORTAÇÕES
// ══════════════════════════════════════════════════════════════

export default {
  getRiasImage,
  getRiasFooter,
  getRiasByEmotion,
  getRiasThumbnail,
  detectEmotion,
  getEmotionByAction,
  clearImageCache,
  preloadRiasImages,
  RIAS_EMOTIONS,
  RIAS_FALLBACK_IMAGES
};
