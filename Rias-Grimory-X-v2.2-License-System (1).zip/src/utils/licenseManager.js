/**
 * Rias-Grimory-X - Sistema de Licenças
 * Gerencia licenças de acesso ao bot
 * 
 * @version 2.1.0
 * @author MutanoX
 * 
 * FUNCIONALIDADES:
 * - Geração de códigos de acesso únicos
 * - Ativação e vinculação de licenças
 * - Verificação de licenças ativas
 * - Sistema de expiração automática
 * - Renovação de licenças
 */

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

// Configurações
const CONFIG = {
  BOT_OWNER_ID: '1387242867700924568',
  SUPPORT_SERVER: 'https://discord.gg/bmePQmsq6w',
  LICENSE_FILE: '/tmp/rias-licenses.json',
  
  // Tipos de licença (em dias)
  LICENSE_TYPES: {
    'semanal': 7,
    'semanal_premium': 7,
    'mensal': 30,
    'mensal_premium': 30,
    'vitalicio': 36500 // 100 anos
  },
  
  // Rate limits
  MAX_SUPPORT_CHANNELS_PER_USER: 1,
  
  // Cores
  COLORS: {
    active: '#10B981',
    expired: '#EF4444',
    pending: '#F59E0B'
  }
};

/**
 * @typedef {Object} LicenseCode
 * @property {string} code - Código único de acesso
 * @property {number} durationDays - Duração em dias
 * @property {string} type - Tipo da licença (semanal, mensal, etc)
 * @property {number} createdAt - Timestamp de criação
 * @property {boolean} used - Se já foi usado
 * @property {string|null} usedBy - ID do usuário que usou
 * @property {number|null} usedAt - Timestamp de uso
 */

/**
 * @typedef {Object} UserLicense
 * @property {string} userId - ID do usuário
 * @property {string} username - Nome do usuário
 * @property {string} code - Código usado
 * @property {string} type - Tipo da licença
 * @property {number} activatedAt - Timestamp de ativação
 * @property {number} expiresAt - Timestamp de expiração
 * @property {number} lastActivity - Última atividade
 * @property {string[]} servers - Lista de IDs de servidores adicionados
 * @property {boolean} notifiedExpiry - Se já foi notificado da expiração
 */

/**
 * @typedef {Object} SupportChannel
 * @property {string} channelId - ID do canal
 * @property {string} userId - ID do usuário
 * @property {string} guildId - ID do servidor
 * @property {number} createdAt - Timestamp de criação
 * @property {string} status - Status do ticket
 */

// Estado do sistema
let licenseData = {
  codes: [],
  users: {},
  supportChannels: []
};

/**
 * Inicializa o sistema de licenças
 */
export function initLicenseSystem() {
  try {
    if (fs.existsSync(CONFIG.LICENSE_FILE)) {
      const data = fs.readFileSync(CONFIG.LICENSE_FILE, 'utf8');
      licenseData = JSON.parse(data);
      console.log('✅ [License] Sistema de licenças carregado');
      console.log(`📊 [License] ${Object.keys(licenseData.users).length} usuários ativos`);
    } else {
      saveLicenseData();
      console.log('✅ [License] Novo arquivo de licenças criado');
    }
    
    // Iniciar verificação de expiração
    startExpirationChecker();
    
  } catch (error) {
    console.error('❌ [License] Erro ao inicializar:', error.message);
    saveLicenseData();
  }
}

/**
 * Salva os dados de licença no arquivo
 */
function saveLicenseData() {
  try {
    fs.writeFileSync(CONFIG.LICENSE_FILE, JSON.stringify(licenseData, null, 2));
  } catch (error) {
    console.error('❌ [License] Erro ao salvar:', error.message);
  }
}

/**
 * Gera um código único de acesso
 * @returns {string} Código gerado
 */
function generateUniqueCode() {
  const prefix = 'RIAS';
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = prefix + '-';
  
  for (let i = 0; i < 4; i++) {
    let segment = '';
    for (let j = 0; j < 4; j++) {
      segment += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    code += segment;
    if (i < 3) code += '-';
  }
  
  return code;
}

/**
 * Gera múltiplos códigos de acesso
 * @param {number} quantity - Quantidade de códigos
 * @param {string} durationType - Tipo de duração (semanal, mensal)
 * @param {string} requesterId - ID do solicitante
 * @returns {{success: boolean, codes: string[], error?: string}}
 */
export function generateAccessCodes(quantity, durationType, requesterId) {
  // Verificar permissão
  if (requesterId !== CONFIG.BOT_OWNER_ID) {
    return { success: false, codes: [], error: 'Apenas o dono do bot pode gerar códigos' };
  }
  
  // Validar quantidade
  quantity = Math.min(Math.max(1, parseInt(quantity) || 1), 100);
  
  // Validar tipo
  const validTypes = Object.keys(CONFIG.LICENSE_TYPES);
  const type = validTypes.includes(durationType.toLowerCase()) 
    ? durationType.toLowerCase() 
    : 'mensal';
  
  const durationDays = CONFIG.LICENSE_TYPES[type];
  const codes = [];
  
  for (let i = 0; i < quantity; i++) {
    let code;
    let attempts = 0;
    
    // Garantir código único
    do {
      code = generateUniqueCode();
      attempts++;
    } while (licenseData.codes.find(c => c.code === code) && attempts < 100);
    
    const licenseCode = {
      code: code,
      durationDays: durationDays,
      type: type,
      createdAt: Date.now(),
      createdById: requesterId,
      used: false,
      usedBy: null,
      usedAt: null
    };
    
    licenseData.codes.push(licenseCode);
    codes.push(code);
  }
  
  saveLicenseData();
  
  console.log(`🎫 [License] ${quantity} código(s) gerado(s) - Tipo: ${type}`);
  
  return { 
    success: true, 
    codes: codes,
    type: type,
    durationDays: durationDays
  };
}

/**
 * Ativa uma licença com um código
 * @param {string} code - Código de acesso
 * @param {string} userId - ID do usuário
 * @param {string} username - Nome do usuário
 * @returns {{success: boolean, license?: UserLicense, error?: string}}
 */
export function redeemAccessCode(code, userId, username) {
  // Verificar se o usuário já tem licença ativa
  const existingLicense = getUserLicense(userId);
  if (existingLicense && isLicenseValid(userId)) {
    return { 
      success: false, 
      error: `Você já possui uma licença ativa até <t:${Math.floor(existingLicense.expiresAt / 1000)}:R>` 
    };
  }
  
  // Buscar código
  const licenseCode = licenseData.codes.find(c => c.code === code && !c.used);
  
  if (!licenseCode) {
    return { success: false, error: 'Código inválido ou já utilizado' };
  }
  
  // Marcar código como usado
  licenseCode.used = true;
  licenseCode.usedBy = userId;
  licenseCode.usedAt = Date.now();
  
  // Criar licença para o usuário
  const now = Date.now();
  const userLicense = {
    userId: userId,
    username: username,
    code: code,
    type: licenseCode.type,
    durationDays: licenseCode.durationDays,
    activatedAt: now,
    expiresAt: now + (licenseCode.durationDays * 24 * 60 * 60 * 1000),
    lastActivity: now,
    servers: [],
    notifiedExpiry: false
  };
  
  licenseData.users[userId] = userLicense;
  saveLicenseData();
  
  console.log(`✅ [License] Licença ativada para ${username} (${userId})`);
  console.log(`   Tipo: ${licenseCode.type}, Expira em: ${licenseCode.durationDays} dias`);
  
  return { 
    success: true, 
    license: userLicense,
    message: `Licença **${licenseCode.type}** ativada com sucesso! Válida até <t:${Math.floor(userLicense.expiresAt / 1000)}:R>`
  };
}

/**
 * Obtém a licença de um usuário
 * @param {string} userId - ID do usuário
 * @returns {UserLicense|null}
 */
export function getUserLicense(userId) {
  return licenseData.users[userId] || null;
}

/**
 * Verifica se a licença do usuário está válida
 * @param {string} userId - ID do usuário
 * @returns {boolean}
 */
export function isLicenseValid(userId) {
  // Dono do bot sempre tem acesso
  if (userId === CONFIG.BOT_OWNER_ID) return true;
  
  const license = getUserLicense(userId);
  if (!license) return false;
  
  return Date.now() < license.expiresAt;
}

/**
 * Verifica se a licença está expirada
 * @param {string} userId - ID do usuário
 * @returns {boolean}
 */
export function isLicenseExpired(userId) {
  const license = getUserLicense(userId);
  if (!license) return false;
  
  return Date.now() >= license.expiresAt;
}

/**
 * Verifica se o usuário tem licença (ativa ou expirada)
 * @param {string} userId - ID do usuário
 * @returns {boolean}
 */
export function hasLicense(userId) {
  return !!licenseData.users[userId] || userId === CONFIG.BOT_OWNER_ID;
}

/**
 * Obtém o tempo restante da licença
 * @param {string} userId - ID do usuário
 * @returns {{valid: boolean, remaining: number, formatted: string}}
 */
export function getLicenseTimeRemaining(userId) {
  const license = getUserLicense(userId);
  
  if (!license) {
    return { valid: false, remaining: 0, formatted: 'Sem licença' };
  }
  
  const remaining = license.expiresAt - Date.now();
  
  if (remaining <= 0) {
    return { valid: false, remaining: 0, formatted: 'Expirada' };
  }
  
  const days = Math.floor(remaining / (24 * 60 * 60 * 1000));
  const hours = Math.floor((remaining % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
  
  let formatted = '';
  if (days > 0) formatted += `${days} dia(s)`;
  if (hours > 0) formatted += ` ${hours}h`;
  
  return { 
    valid: true, 
    remaining: remaining, 
    formatted: formatted.trim() || 'Menos de 1 hora',
    expiresAt: license.expiresAt
  };
}

/**
 * Renova a licença de um usuário
 * @param {string} userId - ID do usuário
 * @param {string} durationType - Tipo de duração
 * @param {string} requesterId - ID do solicitante (deve ser o dono)
 * @returns {{success: boolean, license?: UserLicense, error?: string}}
 */
export function renewUserLicense(userId, durationType, requesterId) {
  // Verificar permissão
  if (requesterId !== CONFIG.BOT_OWNER_ID) {
    return { success: false, error: 'Apenas o dono do bot pode renovar licenças' };
  }
  
  // Validar tipo
  const validTypes = Object.keys(CONFIG.LICENSE_TYPES);
  const type = validTypes.includes(durationType.toLowerCase()) 
    ? durationType.toLowerCase() 
    : 'mensal';
  
  const durationDays = CONFIG.LICENSE_TYPES[type];
  const license = getUserLicense(userId);
  
  if (!license) {
    return { success: false, error: 'Usuário não possui licença' };
  }
  
  const now = Date.now();
  
  // Se a licença ainda está válida, adicionar dias ao final
  // Se expirou, renovar a partir de agora
  const baseTime = license.expiresAt > now ? license.expiresAt : now;
  
  license.expiresAt = baseTime + (durationDays * 24 * 60 * 60 * 1000);
  license.type = type;
  license.durationDays = durationDays;
  license.notifiedExpiry = false;
  license.lastActivity = now;
  
  saveLicenseData();
  
  console.log(`✅ [License] Licença renovada para ${license.username} (${userId})`);
  console.log(`   Tipo: ${type}, Nova expiração: ${new Date(license.expiresAt).toISOString()}`);
  
  return { 
    success: true, 
    license: license,
    message: `Licença renovada! Nova expiração: <t:${Math.floor(license.expiresAt / 1000)}:R>`
  };
}

/**
 * Registra um servidor onde o usuário adicionou o bot
 * @param {string} userId - ID do usuário
 * @param {string} guildId - ID do servidor
 */
export function registerUserServer(userId, guildId) {
  const license = getUserLicense(userId);
  if (license && !license.servers.includes(guildId)) {
    license.servers.push(guildId);
    saveLicenseData();
  }
}

/**
 * Verifica permissão do usuário em um servidor
 * @param {string} userId - ID do usuário
 * @param {import('discord.js').Guild} guild - Servidor
 * @param {import('discord.js').GuildMember} [member] - Membro
 * @returns {{authorized: boolean, reason: string, licenseStatus?: string}}
 */
export function checkUserPermission(userId, guild, member) {
  // Dono do bot sempre tem acesso total
  if (userId === CONFIG.BOT_OWNER_ID) {
    return { authorized: true, reason: 'Dono do bot' };
  }
  
  // Verificar licença
  const license = getUserLicense(userId);
  
  if (!license) {
    return { 
      authorized: false, 
      reason: 'Você não possui uma licença ativa. Use `/redeem-access` para ativar uma licença.' 
    };
  }
  
  if (!isLicenseValid(userId)) {
    return { 
      authorized: false, 
      reason: `Sua licença expirou! Use \`/support\` para renovar. Servidor de suporte: ${CONFIG.SUPPORT_SERVER}`,
      licenseStatus: 'expired'
    };
  }
  
  // Verificar se é admin ou dono do servidor
  if (!member) {
    return { authorized: false, reason: 'Membro não encontrado no servidor' };
  }
  
  // Dono do servidor
  if (guild.ownerId === userId) {
    return { authorized: true, reason: 'Dono do servidor (Licença ativa)' };
  }
  
  // Administrador
  if (member.permissions && member.permissions.has('Administrator')) {
    return { authorized: true, reason: 'Administrador (Licença ativa)' };
  }
  
  return { 
    authorized: false, 
    reason: 'Você precisa ser **Administrador** ou **Dono do servidor** para usar a IA neste servidor.' 
  };
}

/**
 * Cria um canal de suporte para o usuário
 * @param {import('discord.js').Guild} guild - Servidor
 * @param {string} userId - ID do usuário
 * @param {import('discord.js').User} user - Usuário
 * @param {import('discord.js').GuildMember} member - Membro
 * @returns {{success: boolean, channel?: any, error?: string}}
 */
export async function createSupportChannel(guild, userId, user, member) {
  // Verificar se o usuário tem licença (ativa ou expirada)
  const license = getUserLicense(userId);
  
  if (!license) {
    return { 
      success: false, 
      error: 'Você precisa ter uma licença para usar este comando. Use `/redeem-access` primeiro.' 
    };
  }
  
  // Verificar rate limit
  const existingChannel = licenseData.supportChannels.find(
    c => c.userId === userId && c.guildId === guild.id && c.status === 'open'
  );
  
  if (existingChannel) {
    return { 
      success: false, 
      error: `Você já tem um canal de suporte aberto: <#${existingChannel.channelId}>` 
    };
  }
  
  try {
    // Buscar ou criar categoria "Renovações"
    let category = guild.channels.cache.find(
      c => c.type === 4 && c.name.toLowerCase().includes('renovações')
    );
    
    if (!category) {
      category = await guild.channels.create({
        name: '🔄 Renovações',
        type: 4,
        reason: 'Categoria para suporte de licenças'
      });
    }
    
    // Criar canal para o usuário
    const channelName = `renovacao-${user.username.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
    const channel = await guild.channels.create({
      name: channelName.substring(0, 100),
      type: 0,
      parent: category.id,
      reason: `Canal de suporte para ${user.username}`,
      permissionOverwrites: [
        {
          id: guild.roles.everyone.id,
          deny: ['ViewChannel']
        },
        {
          id: userId,
          allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory']
        },
        {
          id: CONFIG.BOT_OWNER_ID,
          allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory', 'ManageChannels']
        }
      ]
    });
    
    // Registrar canal
    const supportChannel = {
      channelId: channel.id,
      userId: userId,
      username: user.username,
      guildId: guild.id,
      createdAt: Date.now(),
      status: 'open'
    };
    
    licenseData.supportChannels.push(supportChannel);
    saveLicenseData();
    
    console.log(`🎫 [License] Canal de suporte criado: ${channel.name} para ${user.username}`);
    
    return { success: true, channel: channel };
    
  } catch (error) {
    console.error('❌ [License] Erro ao criar canal:', error.message);
    return { success: false, error: `Erro ao criar canal: ${error.message}` };
  }
}

/**
 * Fecha um canal de suporte
 * @param {string} channelId - ID do canal
 * @param {string} closedBy - ID de quem fechou
 */
export function closeSupportChannel(channelId, closedBy) {
  const index = licenseData.supportChannels.findIndex(c => c.channelId === channelId);
  
  if (index !== -1) {
    licenseData.supportChannels[index].status = 'closed';
    licenseData.supportChannels[index].closedAt = Date.now();
    licenseData.supportChannels[index].closedBy = closedBy;
    saveLicenseData();
  }
}

/**
 * Obtém estatísticas do sistema de licenças
 * @returns {Object}
 */
export function getLicenseStats() {
  const now = Date.now();
  
  const activeLicenses = Object.values(licenseData.users).filter(u => u.expiresAt > now).length;
  const expiredLicenses = Object.values(licenseData.users).filter(u => u.expiresAt <= now).length;
  const unusedCodes = licenseData.codes.filter(c => !c.used).length;
  const openTickets = licenseData.supportChannels.filter(c => c.status === 'open').length;
  
  return {
    totalUsers: Object.keys(licenseData.users).length,
    activeLicenses: activeLicenses,
    expiredLicenses: expiredLicenses,
    totalCodesGenerated: licenseData.codes.length,
    unusedCodes: unusedCodes,
    openTickets: openTickets
  };
}

/**
 * Lista usuários com licença
 * @param {boolean} [activeOnly=true] - Apenas ativos
 * @returns {UserLicense[]}
 */
export function listLicensedUsers(activeOnly = true) {
  const now = Date.now();
  
  return Object.values(licenseData.users).filter(u => {
    if (activeOnly) {
      return u.expiresAt > now;
    }
    return true;
  });
}

/**
 * Remove licença expirada de um usuário
 * @param {string} userId - ID do usuário
 */
export function removeExpiredLicense(userId) {
  delete licenseData.users[userId];
  saveLicenseData();
  console.log(`🗑️ [License] Licença removida para ${userId}`);
}

/**
 * Obtém o ID do dono do bot
 * @returns {string}
 */
export function getBotOwnerId() {
  return CONFIG.BOT_OWNER_ID;
}

/**
 * Verifica se é o dono do bot
 * @param {string} userId - ID do usuário
 * @returns {boolean}
 */
export function isBotOwner(userId) {
  return userId === CONFIG.BOT_OWNER_ID;
}

/**
 * Obtém link do servidor de suporte
 * @returns {string}
 */
export function getSupportServerLink() {
  return CONFIG.SUPPORT_SERVER;
}

/**
 * Inicia verificador de expiração automática
 */
function startExpirationChecker() {
  // Verificar a cada 1 hora
  setInterval(async () => {
    const now = Date.now();
    const expiringSoon = now + (24 * 60 * 60 * 1000); // 24 horas
    
    for (const [userId, license] of Object.entries(licenseData.users)) {
      // Notificar se vai expirar em 24h
      if (license.expiresAt > now && license.expiresAt <= expiringSoon && !license.notifiedExpiry) {
        license.notifiedExpiry = true;
        saveLicenseData();
        console.log(`⚠️ [License] Licença de ${license.username} expira em 24h`);
        // Aqui poderia enviar DM para o usuário
      }
      
      // Marcar como expirado (não remove, apenas loga)
      if (license.expiresAt <= now && license.notifiedExpiry !== 'expired') {
        license.notifiedExpiry = 'expired';
        saveLicenseData();
        console.log(`❌ [License] Licença de ${license.username} expirou`);
      }
    }
  }, 60 * 60 * 1000); // 1 hora
}

// Inicializar ao carregar
initLicenseSystem();

export default {
  generateAccessCodes,
  redeemAccessCode,
  getUserLicense,
  isLicenseValid,
  isLicenseExpired,
  hasLicense,
  getLicenseTimeRemaining,
  renewUserLicense,
  registerUserServer,
  checkUserPermission,
  createSupportChannel,
  closeSupportChannel,
  getLicenseStats,
  listLicensedUsers,
  removeExpiredLicense,
  getBotOwnerId,
  isBotOwner,
  getSupportServerLink,
  initLicenseSystem
};
