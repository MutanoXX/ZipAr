/**
 * Rias-Grimory-X - Handlers V6.0
 * Funções para os novos sistemas: Automod, Logs, Welcome, Tickets, etc.
 * 
 * Este arquivo contém todas as funções handler para os novos comandos
 */

import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import automodManager from './automodManager.js';
import logsManager from './logsManager.js';
import welcomeManager from './welcomeManager.js';
import ticketsManager from './ticketsManager.js';
import apiService from '../services/apiService.js';
import { getRiasFooter, detectEmotion } from './riasImages.js';

// ═══════════════════════════════════════════════════════════
// 🛡️ MODERAÇÃO AUTOMÁTICA
// ═══════════════════════════════════════════════════════════

export async function handleConfigAutomod(message, response, guild, thinkingMsg) {
  try {
    const config = automodManager.updateAutomodConfig(guild.id, response);
    
    const embed = new EmbedBuilder()
      .setTitle('🛡️ AutoMod Configurado!')
      .setDescription(`Regra **${response.regra}** foi atualizada!`)
      .addFields(
        { name: '📋 Regra', value: response.regra, inline: true },
        { name: '⚖️ Punição', value: response.punicao || 'Nenhuma', inline: true }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X | AutoMod' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

export async function handleVerAutomod(message, guild, thinkingMsg) {
  try {
    const settings = automodManager.getAutomodSettings(guild.id);
    
    const embed = new EmbedBuilder()
      .setTitle('🛡️ Configurações AutoMod')
      .setDescription(`Status: ${settings.enabled ? '✅ Ativo' : '❌ Desativado'}`)
      .addFields(
        { name: '🚫 Anti-Spam', value: settings.rules.antiSpam.enabled ? '✅' : '❌', inline: true },
        { name: '🔗 Anti-Link', value: settings.rules.antiLink.enabled ? '✅' : '❌', inline: true },
        { name: '👥 Anti-Mention', value: settings.rules.antiMention.enabled ? '✅' : '❌', inline: true },
        { name: '🚨 Anti-Raid', value: settings.rules.antiRaid.enabled ? '✅' : '❌', inline: true },
        { name: '📝 Palavras Proibidas', value: settings.rules.badWords.enabled ? `✅ (${settings.rules.badWords.count})` : '❌', inline: true },
        { name: '⌨️ Caps Lock', value: settings.rules.capsLock.enabled ? '✅' : '❌', inline: true }
      )
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

export async function handleDesativarAutomod(message, response, guild, thinkingMsg) {
  try {
    automodManager.disableRule(guild.id, response.regra);
    
    const embed = new EmbedBuilder()
      .setTitle('🛡️ Regra Desativada')
      .setDescription(`A regra **${response.regra}** foi desativada!`)
      .setColor('#F59E0B')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

export async function handleAdvertir(message, response, guild, thinkingMsg) {
  try {
    const userId = response.usuario || response.userId || response.membro;
    const reason = response.motivo || response.reason || 'Sem motivo';
    
    const result = automodManager.addWarning(guild.id, userId, reason);
    
    const embed = new EmbedBuilder()
      .setTitle('⚠️ Advertência Aplicada!')
      .addFields(
        { name: '👤 Usuário', value: `<@${userId}>`, inline: true },
        { name: '📝 Motivo', value: reason, inline: true },
        { name: '📊 Total', value: `${result.total} advertência(s)`, inline: true }
      )
      .setColor('#F59E0B')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

export async function handleVerAdvertencias(message, response, guild, thinkingMsg) {
  try {
    const userId = response.usuario || response.userId || response.membro;
    const result = automodManager.getWarnings(guild.id, userId);
    
    const embed = new EmbedBuilder()
      .setTitle('⚠️ Advertências')
      .setDescription(`Usuário: <@${userId}>`)
      .addFields(
        { name: '📊 Total', value: `${result.total} advertência(s)`, inline: true }
      )
      .setColor('#F59E0B')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    if (result.warnings.length > 0) {
      const warningsList = result.warnings.slice(0, 5).map((w, i) => 
        `${i + 1}. ${w.reason} - <t:${Math.floor(w.timestamp / 1000)}:R>`
      ).join('\n');
      embed.addFields({ name: '📋 Últimas', value: warningsList });
    }
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

// ═══════════════════════════════════════════════════════════
// 📝 SISTEMA DE LOGS
// ═══════════════════════════════════════════════════════════

export async function handleConfigLogs(message, response, guild, thinkingMsg) {
  try {
    const channelId = response.canal || response.channelId;
    const events = response.eventos || response.events;
    
    const channel = channelId ? guild.channels.cache.get(channelId.replace(/[<#>]/g, '')) : message.channel;
    
    logsManager.setLogsChannel(guild.id, channel.id, events);
    
    const embed = new EmbedBuilder()
      .setTitle('📝 Logs Configurados!')
      .setDescription(`Canal: <#${channel.id}>`)
      .addFields(
        { name: '📊 Eventos', value: events ? events.join(', ') : 'Todos os eventos' }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

export async function handleVerLogs(message, guild, thinkingMsg) {
  try {
    const settings = logsManager.getLogsSettings(guild.id);
    
    const embed = new EmbedBuilder()
      .setTitle('📝 Configurações de Logs')
      .setDescription(`Status: ${settings.enabled ? '✅ Ativo' : '❌ Desativado'}`)
      .addFields(
        { name: '📍 Canal', value: settings.channelMention, inline: true },
        { name: '📊 Eventos', value: settings.activeEvents.length > 0 ? settings.activeEvents.join(', ') : 'Nenhum' }
      )
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

export async function handleDesativarLogs(message, guild, thinkingMsg) {
  logsManager.disableLogs(guild.id);
  
  const embed = new EmbedBuilder()
    .setTitle('📝 Logs Desativados')
    .setDescription('O sistema de logs foi desativado.')
    .setColor('#EF4444')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
}

export async function handleLogsModeracao(message, response, guild, thinkingMsg) {
  try {
    const limit = response.limite || response.limit || 20;
    const logs = logsManager.getLogs(guild.id, limit, 'member_kick');
    const banLogs = logsManager.getLogs(guild.id, limit, 'member_ban');
    
    const embed = new EmbedBuilder()
      .setTitle('📋 Logs de Moderação')
      .setDescription(`Últimas ações de moderação`)
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

export async function handleExportarLogs(message, response, guild, thinkingMsg) {
  try {
    const days = response.periodo || response.days || 7;
    const logs = logsManager.exportLogs(guild.id, days);
    
    const embed = new EmbedBuilder()
      .setTitle('📤 Logs Exportados!')
      .setDescription(`Exportados logs dos últimos ${days} dias`)
      .addFields(
        { name: '📊 Período', value: `${days} dias`, inline: true }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

// ═══════════════════════════════════════════════════════════
// 👋 SISTEMA DE BEM-VINDO
// ═══════════════════════════════════════════════════════════

export async function handleConfigBemvindo(message, response, guild, thinkingMsg) {
  try {
    const channelId = response.canal || response.channelId;
    const channel = channelId ? guild.channels.cache.get(channelId.replace(/[<#>]/g, '')) : message.channel;
    
    welcomeManager.setWelcomeChannel(guild.id, channel.id, {
      message: response.mensagem || response.message,
      showCard: response.imagem !== false && response.showCard !== false
    });
    
    const embed = new EmbedBuilder()
      .setTitle('👋 Bem-vindo Configurado!')
      .setDescription(`Canal: <#${channel.id}>`)
      .addFields(
        { name: '💬 Mensagem', value: response.mensagem || 'Padrão' },
        { name: '🖼️ Card', value: response.imagem !== false ? '✅ Ativado' : '❌ Desativado', inline: true }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

export async function handleConfigAutorole(message, response, guild, thinkingMsg) {
  try {
    const roles = response.cargos || response.roles || [];
    const roleIds = roles.map(r => r.replace(/[<@&>]/g, ''));
    
    welcomeManager.setAutorole(guild.id, roleIds);
    
    const embed = new EmbedBuilder()
      .setTitle('👥 Autorole Configurado!')
      .setDescription(`Cargos: ${roles.map(r => `<@&${r.replace(/[<@&>]/g, '')}>`).join(', ')}`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

export async function handleConfigSaida(message, response, guild, thinkingMsg) {
  try {
    const channelId = response.canal || response.channelId;
    const channel = channelId ? guild.channels.cache.get(channelId.replace(/[<#>]/g, '')) : message.channel;
    
    welcomeManager.setGoodbyeChannel(guild.id, channel.id, response.mensagem || response.message);
    
    const embed = new EmbedBuilder()
      .setTitle('👋 Mensagem de Saída Configurada!')
      .setDescription(`Canal: <#${channel.id}>`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

export async function handleVerBemvindo(message, guild, thinkingMsg) {
  try {
    const settings = welcomeManager.getWelcomeSettings(guild.id);
    
    const embed = new EmbedBuilder()
      .setTitle('👋 Sistema de Bem-vindo')
      .addFields(
        { name: '✅ Status', value: settings.enabled ? 'Ativo' : 'Desativado', inline: true },
        { name: '📍 Canal', value: settings.welcome.channel, inline: true },
        { name: '🖼️ Card', value: settings.welcome.showCard ? '✅' : '❌', inline: true },
        { name: '👥 Autorole', value: settings.autorole.enabled ? settings.autorole.roles : 'Desativado', inline: true },
        { name: '🚪 Saída', value: settings.goodbye.enabled ? settings.goodbye.channel : 'Desativado', inline: true }
      )
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

export async function handleTestarBemvindo(message, guild, thinkingMsg) {
  try {
    const result = await welcomeManager.testWelcome(guild, message.author);
    
    const embed = new EmbedBuilder()
      .setTitle('🧪 Teste de Bem-vindo')
      .setDescription(result.message)
      .setColor(result.success ? '#10B981' : '#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

// ═══════════════════════════════════════════════════════════
// 🎫 SISTEMA DE TICKETS
// ═══════════════════════════════════════════════════════════

export async function handleCriarPainelTickets(message, response, guild, thinkingMsg) {
  try {
    const channelId = response.canal || response.channelId;
    
    // Adicionar categorias se fornecidas
    if (response.categorias && Array.isArray(response.categorias)) {
      for (const cat of response.categorias) {
        ticketsManager.addCategory(guild.id, { name: cat });
      }
    }
    
    const result = await ticketsManager.createTicketPanel(guild, {
      channelId: channelId ? channelId.replace(/[<#>]/g, '') : null,
      title: response.titulo || response.title,
      description: response.descricao || response.description
    });
    
    if (result.success) {
      const embed = new EmbedBuilder()
        .setTitle('🎫 Painel de Tickets Criado!')
        .setDescription(`O painel foi criado com sucesso!`)
        .setColor('#10B981')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      
      await editEmbed(thinkingMsg, embed);
    } else {
      await editEmbed(thinkingMsg, '❌ Erro', result.error, '#EF4444');
    }
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

export async function handleCriarTicket(message, response, guild, thinkingMsg) {
  try {
    const result = await ticketsManager.createTicket(
      guild,
      message.author,
      response.categoria || response.category || 'suporte',
      response.motivo || response.reason
    );
    
    if (result.success) {
      const embed = new EmbedBuilder()
        .setTitle('🎫 Ticket Criado!')
        .setDescription(`Ticket #${result.ticket.number} criado!`)
        .addFields(
          { name: '📍 Canal', value: `<#${result.ticket.channelId}>`, inline: true },
          { name: '📂 Categoria', value: result.ticket.category.name, inline: true }
        )
        .setColor('#10B981')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      
      await editEmbed(thinkingMsg, embed);
    } else {
      await editEmbed(thinkingMsg, '❌ Erro', result.error, '#EF4444');
    }
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

export async function handleFecharTicket(message, response, guild, thinkingMsg) {
  try {
    const ticket = ticketsManager.getTicket(message.channel.id);
    
    if (!ticket) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'Este canal não é um ticket!', '#EF4444');
    }
    
    const result = await ticketsManager.closeTicket(
      guild,
      message.channel.id,
      message.author.id,
      response.motivo || response.reason || 'Fechado pelo usuário'
    );
    
    const embed = new EmbedBuilder()
      .setTitle('🔒 Ticket Fechado!')
      .setDescription(`O ticket será fechado em alguns segundos...`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

export async function handleAdicionarTicket(message, response, guild, thinkingMsg) {
  try {
    const userId = response.usuario || response.userId;
    const result = await ticketsManager.addUserToTicket(guild, message.channel.id, userId);
    
    const embed = new EmbedBuilder()
      .setTitle('➕ Usuário Adicionado!')
      .setDescription(`<@${userId}> foi adicionado ao ticket!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

export async function handleRemoverTicket(message, response, guild, thinkingMsg) {
  try {
    const userId = response.usuario || response.userId;
    const result = await ticketsManager.removeUserFromTicket(guild, message.channel.id, userId);
    
    const embed = new EmbedBuilder()
      .setTitle('➖ Usuário Removido!')
      .setDescription(`<@${userId}> foi removido do ticket!`)
      .setColor('#F59E0B')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

export async function handleListarTickets(message, guild, thinkingMsg) {
  try {
    const tickets = ticketsManager.listTickets(guild.id);
    const stats = ticketsManager.getTicketStats(guild.id);
    
    const embed = new EmbedBuilder()
      .setTitle('🎫 Tickets')
      .setDescription(`**${tickets.length}** ticket(s) aberto(s)`)
      .addFields(
        { name: '📊 Total Criado', value: `${stats.total}`, inline: true },
        { name: '✅ Abertos', value: `${stats.open}`, inline: true },
        { name: '🔒 Fechados', value: `${stats.closed}`, inline: true }
      )
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    if (tickets.length > 0) {
      const ticketList = tickets.slice(0, 10).map(t => 
        `• #${t.number} - <@${t.userId}> - ${t.category.name}`
      ).join('\n');
      embed.addFields({ name: '📋 Lista', value: ticketList });
    }
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', error.message, '#EF4444');
  }
}

// ═══════════════════════════════════════════════════════════
// 💰 SISTEMA DE ECONOMIA (Placeholders)
// ═══════════════════════════════════════════════════════════

export async function handleSaldo(message, response, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('💰 Saldo')
    .setDescription('Sistema de economia em desenvolvimento!')
    .setColor('#FFD700')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleAdicionarMoedas(message, response, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('💰 Moedas Adicionadas!')
    .setDescription('Sistema de economia em desenvolvimento!')
    .setColor('#10B981')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleTransferir(message, response, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('💸 Transferência!')
    .setDescription('Sistema de economia em desenvolvimento!')
    .setColor('#8B5CF6')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleDaily(message, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('🎁 Daily!')
    .setDescription('Sistema de economia em desenvolvimento!')
    .setColor('#FFD700')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleTrabalhar(message, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('💼 Trabalhar!')
    .setDescription('Sistema de economia em desenvolvimento!')
    .setColor('#8B5CF6')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleVerLoja(message, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('🛒 Loja')
    .setDescription('Sistema de economia em desenvolvimento!')
    .setColor('#FFD700')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleCriarItem(message, response, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('📦 Item Criado!')
    .setDescription('Sistema de economia em desenvolvimento!')
    .setColor('#10B981')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleComprar(message, response, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('🛒 Compra Realizada!')
    .setDescription('Sistema de economia em desenvolvimento!')
    .setColor('#10B981')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleRankingEconomia(message, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('🏆 Ranking')
    .setDescription('Sistema de economia em desenvolvimento!')
    .setColor('#FFD700')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

// ═══════════════════════════════════════════════════════════
// 🎁 SISTEMA DE GIVEAWAY (Placeholders)
// ═══════════════════════════════════════════════════════════

export async function handleCriarGiveaway(message, response, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('🎁 Giveaway Criado!')
    .setDescription(`Prêmio: **${response.premio || response.prize}**`)
    .addFields(
      { name: '⏰ Duração', value: response.duracao || '24h', inline: true },
      { name: '👥 Ganhadores', value: `${response.ganhadores || 1}`, inline: true }
    )
    .setColor('#FF69B4')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleEncerrarGiveaway(message, response, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('🎁 Giveaway Encerrado!')
    .setDescription('Sistema de giveaway em desenvolvimento!')
    .setColor('#10B981')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleRerolarGiveaway(message, response, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('🔄 Reroll!')
    .setDescription('Sistema de giveaway em desenvolvimento!')
    .setColor('#8B5CF6')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleListarGiveaways(message, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('🎁 Giveaways')
    .setDescription('Nenhum giveaway ativo.')
    .setColor('#8B5CF6')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

// ═══════════════════════════════════════════════════════════
// 🎮 COMANDOS DE DIVERSÃO
// ═══════════════════════════════════════════════════════════

export async function handle8ball(message, response, thinkingMsg) {
  const respostas = [
    '✅ Sim, com certeza!', '❌ Não, de jeito nenhum!', '🤔 Talvez...', 
    '🎲 Pergunta de novo mais tarde!', '✨ Com certeza!', '🚫 Não conte com isso.',
    '💭 Acho que sim...', '🔮 Os astros dizem que sim!', '⭐ Pode acreditar!',
    '❓ Incerto, tente novamente.', '🌟 Absolutamente!', '🙅 Duvido muito.'
  ];
  
  const resposta = respostas[Math.floor(Math.random() * respostas.length)];
  
  const embed = new EmbedBuilder()
    .setTitle('🎱 Bola Mágica')
    .addFields(
      { name: '❓ Pergunta', value: response.pergunta || response.question || 'Pergunta não informada' },
      { name: '🔮 Resposta', value: resposta }
    )
    .setColor('#8B5CF6')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
}

export async function handleRoletaRussa(message, guild, thinkingMsg) {
  const sobreviveu = Math.random() > 0.17;
  
  const embed = new EmbedBuilder()
    .setTitle('🔫 Roleta Russa')
    .setDescription(sobreviveu 
      ? '🎉 Você sobreviveu! A bala não estava na câmara!' 
      : '💀 BANG! Você não teve sorte dessa vez...')
    .setColor(sobreviveu ? '#10B981' : '#EF4444')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
}

export async function handleRPS(message, response, thinkingMsg) {
  const opcoes = ['pedra', 'papel', 'tesoura'];
  const escolhaUsuario = (response.escolha || response.choice || 'pedra').toLowerCase();
  const escolhaBot = opcoes[Math.floor(Math.random() * opcoes.length)];
  
  let resultado = '';
  if (escolhaUsuario === escolhaBot) {
    resultado = '🤝 Empate!';
  } else if (
    (escolhaUsuario === 'pedra' && escolhaBot === 'tesoura') ||
    (escolhaUsuario === 'papel' && escolhaBot === 'pedra') ||
    (escolhaUsuario === 'tesoura' && escolhaBot === 'papel')
  ) {
    resultado = '🎉 Você venceu!';
  } else {
    resultado = '😢 Eu venci!';
  }
  
  const emojis = { pedra: '🪨', papel: '📄', tesoura: '✂️' };
  
  const embed = new EmbedBuilder()
    .setTitle('✊ Pedra, Papel, Tesoura!')
    .addFields(
      { name: '👤 Você', value: `${emojis[escolhaUsuario]} ${escolhaUsuario}`, inline: true },
      { name: '🤖 Rias', value: `${emojis[escolhaBot]} ${escolhaBot}`, inline: true },
      { name: '📊 Resultado', value: resultado }
    )
    .setColor('#8B5CF6')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
}

export async function handleCasar(message, response, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('💒 Casamento!')
    .setDescription(`💖 ${message.author} quer se casar!`)
    .setColor('#FF69B4')
    .setFooter({ text: '💎 Rias-Grimory-X | Sistema em desenvolvimento' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleDivorciar(message, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('💔 Divórcio!')
    .setDescription('Sistema de casamento em desenvolvimento!')
    .setColor('#EF4444')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleShip(message, response, guild, thinkingMsg) {
  const porcentagem = Math.floor(Math.random() * 100) + 1;
  const emoji = porcentagem > 80 ? '💕' : porcentagem > 50 ? '❤️' : porcentagem > 30 ? '💗' : '💔';
  
  const embed = new EmbedBuilder()
    .setTitle('💕 Ship!')
    .setDescription(`${emoji} **${porcentagem}%** de compatibilidade!`)
    .setColor('#FF69B4')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
}

export async function handleMeme(message, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('😂 Meme!')
    .setDescription('Sistema de memes em desenvolvimento!')
    .setColor('#FFD700')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handlePiada(message, thinkingMsg) {
  const piadas = [
    'Por que o JavaScript foi ao psicólogo? Porque tinha muitos problemas de callback! 😂',
    'Qual é o contrário de volátil? Bem-tátil! 🤣',
    'Por que o programador foi ao oftalmologista? Porque não conseguia ver C#! 👓',
    'O que o zero disse para o oito? Belo cinto! 😄',
    'Por que o Java e o JavaScript não se dão bem? Porque têm problemas de herança! 😂'
  ];
  
  const piada = piadas[Math.floor(Math.random() * piadas.length)];
  
  const embed = new EmbedBuilder()
    .setTitle('😂 Piada!')
    .setDescription(piada)
    .setColor('#FFD700')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
}

export async function handleVerdadeDesafio(message, response, thinkingMsg) {
  const tipo = response.tipo || (Math.random() > 0.5 ? 'verdade' : 'desafio');
  
  const verdades = [
    'Qual é o seu maior segredo?', 'Qual foi a coisa mais embaraçosa que você já fez?',
    'Se você pudesse mudar uma coisa na sua vida, o que seria?'
  ];
  
  const desafios = [
    'Envie uma mensagem para a última pessoa que você conversou dizendo "Eu te amo"!',
    'Poste uma foto engraçada sua!', 'Faça uma imitação de alguém famoso!'
  ];
  
  const lista = tipo === 'verdade' ? verdades : desafios;
  const randomItem = lista[Math.floor(Math.random() * lista.length)];
  
  const embed = new EmbedBuilder()
    .setTitle(tipo === 'verdade' ? '🤔 Verdade!' : '🎯 Desafio!')
    .setDescription(randomItem)
    .setColor('#FF69B4')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
}

// ═══════════════════════════════════════════════════════════
// 🔗 INTEGRAÇÕES EXTERNAS
// ═══════════════════════════════════════════════════════════

export async function handleClima(message, response, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('🌤️ Clima')
    .setDescription('Sistema de clima em desenvolvimento!')
    .setColor('#00BFFF')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleTraduzir(message, response, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('🌐 Tradução')
    .setDescription('Sistema de tradução em desenvolvimento!')
    .setColor('#8B5CF6')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleWiki(message, response, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('📚 Wikipedia')
    .setDescription('Sistema de Wikipedia em desenvolvimento!')
    .setColor('#8B5CF6')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleFilme(message, response, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('🎬 Filmes')
    .setDescription('Sistema de filmes em desenvolvimento!')
    .setColor('#8B5CF6')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleCrypto(message, response, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('₿ Criptomoedas')
    .setDescription('Sistema de criptomoedas em desenvolvimento!')
    .setColor('#F7931A')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleQRCode(message, response, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('📱 QR Code')
    .setDescription('Sistema de QR Code em desenvolvimento!')
    .setColor('#8B5CF6')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

// ═══════════════════════════════════════════════════════════
// 📊 SISTEMA DE NÍVEL (Placeholders)
// ═══════════════════════════════════════════════════════════

export async function handleNivel(message, response, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('📊 Nível')
    .setDescription('Sistema de níveis em desenvolvimento!')
    .setColor('#8B5CF6')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleAdicionarXP(message, response, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('✨ XP Adicionado!')
    .setDescription('Sistema de níveis em desenvolvimento!')
    .setColor('#10B981')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleRankingNivel(message, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('🏆 Ranking de Níveis')
    .setDescription('Sistema de níveis em desenvolvimento!')
    .setColor('#FFD700')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

export async function handleRecompensaNivel(message, response, guild, thinkingMsg) {
  const embed = new EmbedBuilder()
    .setTitle('🎁 Recompensa Configurada!')
    .setDescription('Sistema de níveis em desenvolvimento!')
    .setColor('#10B981')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  await editEmbed(thinkingMsg, embed);
}

// ═══════════════════════════════════════════════════════════
// 🔧 FUNÇÃO AUXILIAR
// ═══════════════════════════════════════════════════════════

async function editEmbed(thinkingMsg, titleOrEmbed, description, color) {
  if (!thinkingMsg) return;
  
  try {
    if (typeof titleOrEmbed === 'object' && titleOrEmbed.constructor?.name === 'EmbedBuilder') {
      // Adicionar footer com imagem da Rias
      const footerImage = await getRiasFooter({ type: titleOrEmbed.data?.title || 'message' });
      if (footerImage) {
        titleOrEmbed.setFooter({ 
          text: titleOrEmbed.data?.footer?.text || '💎 Rias-Grimory-X', 
          iconURL: footerImage 
        });
      }
      await thinkingMsg.edit({ embeds: [titleOrEmbed] });
    } else {
      const embed = new EmbedBuilder()
        .setTitle(titleOrEmbed)
        .setDescription((description || '').trim() || 'Sem descrição')
        .setColor(color || '#8B5CF6')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      await thinkingMsg.edit({ embeds: [embed] });
    }
  } catch (e) {
    console.error('Erro ao editar embed:', e.message);
  }
}

export default {
  // Automod
  handleConfigAutomod,
  handleVerAutomod,
  handleDesativarAutomod,
  handleAdvertir,
  handleVerAdvertencias,
  // Logs
  handleConfigLogs,
  handleVerLogs,
  handleDesativarLogs,
  handleLogsModeracao,
  handleExportarLogs,
  // Welcome
  handleConfigBemvindo,
  handleConfigAutorole,
  handleConfigSaida,
  handleVerBemvindo,
  handleTestarBemvindo,
  // Tickets
  handleCriarPainelTickets,
  handleCriarTicket,
  handleFecharTicket,
  handleAdicionarTicket,
  handleRemoverTicket,
  handleListarTickets,
  // Economia
  handleSaldo,
  handleAdicionarMoedas,
  handleTransferir,
  handleDaily,
  handleTrabalhar,
  handleVerLoja,
  handleCriarItem,
  handleComprar,
  handleRankingEconomia,
  // Giveaway
  handleCriarGiveaway,
  handleEncerrarGiveaway,
  handleRerolarGiveaway,
  handleListarGiveaways,
  // Diversão
  handle8ball,
  handleRoletaRussa,
  handleRPS,
  handleCasar,
  handleDivorciar,
  handleShip,
  handleMeme,
  handlePiada,
  handleVerdadeDesafio,
  // Integrações
  handleClima,
  handleTraduzir,
  handleWiki,
  handleFilme,
  handleCrypto,
  handleQRCode,
  // Nível
  handleNivel,
  handleAdicionarXP,
  handleRankingNivel,
  handleRecompensaNivel
};
