/**
 * Rias-Grimory-X - Mensagens Personalizadas da Rias
 * VERSÃO: 2.0 - Sistema de Personalidade com Imagens
 * 
 * Este arquivo contém mensagens automáticas da Rias Gremory
 * que são enviadas após cada ação executada, com imagem de thumbnail!
 */

import { getRiasImage, getEmotionByAction } from './riasImages.js';

// Mapa de mensagens por tipo de ação
const RIAS_MESSAGES = {
  // 🖼️ Imagens
  google_image: [
    "Aqui está, amor! 🌹✨ Espero que goste das imagens! 💜",
    "Prontinho, meu bem! 🌹🔥 Trouxe essas imagens especialmente para você! 💋",
    "Yosh! ✨ Aqui estão as imagens que você pediu! 🌹💖",
    "Hmph! 🌹 Achei as melhores imagens para você, querido! 💜✨",
    "Aqui está, lindo! 🌹 Espero que aprecie meu bom gosto! 😏💜"
  ],
  
  // 🎨 DALL-E
  dalle: [
    "Olha só o que eu criei para você, amor! 🎨🌹 Usei todo meu poder demoníaco! 💜✨",
    "Prontinho! 🌹🔥 Uma arte única, assim como você! 💋",
    "Yosh! ✨ Gerei essa imagem com todo carinho! 🌹💖",
    "Hmph! 🌹 Não está nada mal, né? Arte digna de uma Princesa Demônio! 😏💜"
  ],
  
  // 🎬 Cosplay
  cosplay_video: [
    "Olha esse cosplay, amor! 🎬🌹 Muito fofo, né? 💜✨",
    "Encontrei esse vídeo para você, querido! 🌹🔥 Aproveite! 💋"
  ],
  
  // 📁 Canais
  criar_canal: [
    "Canal criado com sucesso, amor! 🌹✨ Está pronto para usar! 💜",
    "Prontinho, meu bem! 🌹🔥 Mais um canal para nosso servidor! 💋",
    "Yosh! ✨ Canal criado! Precisa de mais alguma coisa? 🌹💖",
    "Hmph! 🌹 Mais um local para nós conversarmos! 😏💜"
  ],
  
  criar_categoria: [
    "Categoria criada, amor! 🌹✨ Organização é tudo! 💜",
    "Prontinho! 🌹🔥 Nova categoria pronta! 💋",
    "Yosh! ✨ Tudo organizadinho como manda o figurino! 🌹💖"
  ],
  
  editar_canal: [
    "Canal atualizado, querido! 🌹✨ Ficou perfeito! 💜",
    "Prontinho! 🌹🔥 Modificações aplicadas! 💋"
  ],
  
  deletar_canal: [
    "Canal removido, amor! 🌹 Tchau tchau! 💜",
    "Feito! 🌹🔥 Não se preocupe, estava na hora mesmo! 💋"
  ],
  
  trancar_canal: [
    "Canal trancado, amor! 🔒🌹 Ninguém entra sem permissão! 💜",
    "Prontinho! 🔒 Ninguém vai perturbar aqui! 💋🌹"
  ],
  
  esconder_canal: [
    "Canal escondido, amor! 👁️🌹 Segredo guardado! 💜",
    "Feito! 👁️🔥 Agora só os escolhidos veem! 💋"
  ],
  
  permissao_canal: [
    "Permissões atualizadas, amor! 🔐🌹 Agora está mais seguro! 💜",
    "Prontinho! 🔐🔥 Controle de acesso ajustado! 💋"
  ],
  
  // 🎭 Cargos
  criar_cargo: [
    "Cargo criado, amor! 🌹✨ Novo poder no servidor! 💜",
    "Prontinho, meu bem! 🌹🔥 Cargo fresquinho! 💋",
    "Yosh! ✨ Mais um cargo para nosso servidor! 🌹💖",
    "Hmph! 🌹 Cargo criado! Digno de um servo meu! 😏💜"
  ],
  
  editar_cargo: [
    "Cargo atualizado, querido! 🌹✨ Ficou lindo! 💜",
    "Prontinho! 🌹🔥 Modificações aplicadas! 💋"
  ],
  
  deletar_cargo: [
    "Cargo removido, amor! 🌹 Adeus! 💜",
    "Feito! 🌹🔥 Não precisávamos mais dele mesmo! 💋"
  ],
  
  adicionar_cargo: [
    "Cargo adicionado, amor! 🌹✨ Agora você tem mais poder! 💜",
    "Prontinho, meu bem! 🌹🔥 Você está especial agora! 💋",
    "Yosh! ✨ Cargo aplicado! Use com sabedoria! 🌹💖"
  ],
  
  remover_cargo: [
    "Cargo removido, amor! 🌹 Talvez na próxima! 💜",
    "Feito! 🌹🔥 Sem problemas! 💋"
  ],
  
  // 👥 Membros
  expulsar: [
    "Membro expulso, amor! 👢🌹 Às vezes é necessário! 💜",
    "Feito! 🌹 Alguém teve que aprender da forma difícil! 💋"
  ],
  
  banir: [
    "Membro banido, amor! 🔨🌹 Fora do servidor permanentemente! 💜",
    "Feito! 🔨🔥 Justiça foi feita! 💋🌹"
  ],
  
  desbanir: [
    "Banimento revogado, amor! ♻️🌹 Segunda chance dada! 💜",
    "Prontinho! 🌹 Que ele se comporte agora! 💋"
  ],
  
  mutar: [
    "Membro silenciado, amor! 🔇🌹 Um tempo de reflexão! 💜",
    "Feito! 🔇🔥 Silence é dourado, né? 💋🌹"
  ],
  
  desmutar: [
    "Membro desmutado, amor! 🔊🌹 Vamos ver se aprendeu! 💜",
    "Prontinho! 🔊🔥 Espero que comporte melhor! 💋"
  ],
  
  apelido: [
    "Apelido alterado, amor! ✏️🌹 Nome novo, vida nova! 💜",
    "Prontinho! ✏️🔥 Gostei do nome! 💋"
  ],
  
  info_membro: [
    "Aqui estão as informações, amor! 📋🌹 Tudo sobre o membro! 💜",
    "Prontinho! 📋🔥 Aqui está o que você precisa saber! 💋"
  ],
  
  // 💬 Mensagens
  deletar_mensagens: [
    "Mensagens deletadas, amor! 🧹🌹 Limpeza feita! 💜",
    "Prontinho! 🧹🔥 Canais limpos como novos! 💋"
  ],
  
  // 🪝 Webhooks
  criar_webhook: [
    "Webhook criado, amor! 🪝🌹 Agora podemos enviar mensagens secretas! 💜",
    "Prontinho! 🪝🔥 Mais uma ferramenta poderosa! 💋"
  ],
  
  listar_webhooks: [
    "Aqui estão os webhooks, amor! 📋🌹 Todos eles! 💜",
    "Prontinho! 📋🔥 Eis a lista completa! 💋"
  ],
  
  // 🎫 Convites
  criar_convite: [
    "Convite criado, amor! 🎫🌹 Compartilhe com cuidado! 💜",
    "Prontinho! 🎫🔥 Chame seus amigos! 💋"
  ],
  
  listar_convites: [
    "Aqui estão os convites, amor! 📋🌹 Todos ativos! 💜",
    "Prontinho! 📋🔥 Veja quem está convidando! 💋"
  ],
  
  // 😀 Emojis
  adicionar_emoji: [
    "Emoji adicionado, amor! 😀🌹 Mais expressões! 💜",
    "Prontinho! 😀🔥 Seu emoji está pronto! 💋"
  ],
  
  listar_emojis: [
    "Aqui estão os emojis, amor! 📋🌹 Temos vários! 💜",
    "Prontinho! 📋🔥 Nossa coleção de emojis! 💋"
  ],
  
  // 🤖 Automação
  criar_automacao: [
    "Automação criada, amor! 🤖🌹 Vai funcionar sozinho! 💜",
    "Prontinho! 🤖🔥 O servidor vai cuidar de si mesmo! 💋",
    "Yosh! ✨ Automação ativa! 🌹💖"
  ],
  
  listar_automacoes: [
    "Aqui estão as automações, amor! 📋🌹 Tudo funcionando! 💜",
    "Prontinho! 📋🔥 Nossas tarefas automáticas! 💋"
  ],
  
  pausar_automacao: [
    "Automação pausada, amor! ⏸️🌹 Descanso merecido! 💜",
    "Feito! ⏸️🔥 Pausada até você querer de volta! 💋"
  ],
  
  retomar_automacao: [
    "Automação retomada, amor! ▶️🌹 De volta ao trabalho! 💜",
    "Prontinho! ▶️🔥 Funcionando novamente! 💋"
  ],
  
  deletar_automacao: [
    "Automação removida, amor! 🗑️🌹 Não precisávamos mais! 💜",
    "Feito! 🗑️🔥 Adeus automação! 💋"
  ],
  
  editar_automacao: [
    "Automação editada, amor! ✏️🌹 Modificações aplicadas! 💜",
    "Prontinho! ✏️🔥 Tudo atualizado como você pediu! 💋",
    "Yosh! ✨ Automação modificada! 🌹💖"
  ],
  
  executar_automacao: [
    "Automação executada, amor! ⚡🌹 Tarefa cumprida! 💜",
    "Feito! ⚡🔥 Rodei a automação manualmente! 💋"
  ],
  
  // 🔍 Consultas
  consulta_cnpj: [
    "Aqui estão os dados, amor! 📋🌹 Informações do CNPJ! 💜",
    "Prontinho! 📋🔥 Dados encontrados! 💋"
  ],
  
  consulta_cpf: [
    "Aqui estão os dados, amor! 📋🌹 Informações do CPF! 💜",
    "Prontinho! 📋🔥 Dados encontrados! 💋"
  ],
  
  // 📄 Arquivos
  gerar_arquivo: [
    "Arquivo criado, amor! 📄🌹 Pronto para download! 💜",
    "Prontinho! 📄🔥 Seu arquivo está aqui! 💋"
  ],
  
  // 🛡️ AutoMod
  config_automod: [
    "AutoMod configurado, amor! 🛡️🌹 Servidor protegido! 💜",
    "Prontinho! 🛡️🔥 Ninguém vai aprontar! 💋"
  ],
  
  ver_automod: [
    "Aqui estão as configurações, amor! 📋🌹 Nosso escudo! 💜",
    "Prontinho! 📋🔥 Proteção ativa! 💋"
  ],
  
  advertir: [
    "Advertência aplicada, amor! ⚠️🌹 Um aviso sério! 💜",
    "Feito! ⚠️🔥 Espero que aprenda! 💋"
  ],
  
  // 👋 Bem-vindo
  config_bemvindo: [
    "Bem-vindo configurado, amor! 👋🌹 Novos membros serão recebidos! 💜",
    "Prontinho! 👋🔥 Primeira impressão é tudo! 💋"
  ],
  
  ver_bemvindo: [
    "Aqui estão as configurações, amor! 📋🌹 Nossa recepção! 💜",
    "Prontinho! 📋🔥 Veja como recebemos! 💋"
  ],
  
  // 📝 Logs
  config_logs: [
    "Logs configurados, amor! 📝🌹 Tudo será registrado! 💜",
    "Prontinho! 📝🔥 Nada escapa! 💋"
  ],
  
  ver_logs: [
    "Aqui estão as configurações, amor! 📋🌹 Nossos registros! 💜",
    "Prontinho! 📋🔥 Tudo documentado! 💋"
  ],
  
  // 🎫 Tickets
  criar_painel_tickets: [
    "Painel de tickets criado, amor! 🎫🌹 Suporte organizado! 💜",
    "Prontinho! 🎫🔥 Agora podemos ajudar todo mundo! 💋"
  ],
  
  criar_ticket: [
    "Ticket criado, amor! 🎫🌹 Suporte a caminho! 💜",
    "Prontinho! 🎫🔥 Alguém vai te ajudar! 💋"
  ],
  
  fechar_ticket: [
    "Ticket fechado, amor! 🔒🌹 Problema resolvido! 💜",
    "Feito! 🔒🔥 Até a próxima! 💋"
  ],
  
  listar_tickets: [
    "Aqui estão os tickets, amor! 📋🌹 Todos abertos! 💜",
    "Prontinho! 📋🔥 Veja o que está pendente! 💋"
  ],
  
  // 📊 Estatísticas
  server_stats: [
    "Aqui estão as estatísticas, amor! 📊🌹 Nosso servidor em números! 💜",
    "Prontinho! 📊🔥 Olha como estamos crescendo! 💋"
  ],
  
  // 💬 Embeds
  enviar_embed: [
    "Embed enviado, amor! 💬🌹 Mensagem formatada! 💜",
    "Prontinho! 💬🔥 Ficou lindo! 💋"
  ],
  
  criar_enquete: [
    "Enquete criada, amor! 📊🌹 Vamos ver a opinião de todos! 💜",
    "Prontinho! 📊🔥 Agora é só esperar os votos! 💋"
  ],
  
  // 🔄 Tarefa Complexa
  tarefa_complexa: [
    "Tarefa completa, amor! 🔄✨ Tudo foi executado perfeitamente! 🌹💜",
    "Prontinho! 🔄🔥 Trabalho duro feito com maestria! 💋🌹",
    "Yosh! ✨ Tudo feito, meu bem! 🌹💖",
    "Hmph! 🌹 Mais uma missão cumprida! 😏💜✨"
  ],
  
  // 📋 Listagens gerais
  listar_canais: [
    "Aqui estão os canais, amor! 📋🌹 Todos organizados! 💜",
    "Prontinho! 📋🔥 Veja nossa estrutura! 💋"
  ],
  
  listar_cargos: [
    "Aqui estão os cargos, amor! 📋🌹 Nossa hierarquia! 💜",
    "Prontinho! 📋🔥 Poderes do servidor! 💋"
  ],
  
  membros_cargo: [
    "Aqui estão os membros, amor! 📋🌹 Quem tem esse cargo! 💜",
    "Prontinho! 📋🔥 Veja quem são! 💋"
  ],
  
  // 📁 Arquivo
  listar_webhooks_servidor: [
    "Aqui estão todos os webhooks, amor! 📋🌹 Do servidor inteiro! 💜",
    "Prontinho! 📋🔥 Todos os webhooks! 💋"
  ]
};

// Mensagens de erro
const RIAS_ERROR_MESSAGES = [
  "Ah não, amor! 😰 Algo deu errado... Pode tentar de novo? 🌹💜",
  "Oops! 🙈 Tive um probleminha, meu bem! Vamos tentar novamente? 🌹💖",
  "Gomen! 😅 Errei algo aqui... Me dá uma segunda chance? 🌹✨",
  "Ah, droga! 😤 Algo não funcionou como eu queria! Tenta de novo, amor? 🌹💜"
];

// Mensagens quando não encontra algo
const RIAS_NOTFOUND_MESSAGES = [
  "Hmm, não encontrei isso, amor! 🤔🌹 Pode verificar? 💜",
  "Ops! 😅 Não achei o que você procura, meu bem! 🌹💖",
  "Desculpa, querido! 🥺 Não consegui encontrar... 🌹✨"
];

/**
 * Pega uma mensagem aleatória da Rias para o tipo de ação
 */
export function getRiasMessage(actionType, context = {}) {
  const messages = RIAS_MESSAGES[actionType.toLowerCase()];
  
  if (!messages || messages.length === 0) {
    return "Prontinho, amor! 🌹✨ Está feito! 💜";
  }
  
  return messages[Math.floor(Math.random() * messages.length)];
}

/**
 * Pega mensagem de erro
 */
export function getRiasErrorMessage() {
  return RIAS_ERROR_MESSAGES[Math.floor(Math.random() * RIAS_ERROR_MESSAGES.length)];
}

/**
 * Pega mensagem de "não encontrado"
 */
export function getRiasNotFoundMessage() {
  return RIAS_NOTFOUND_MESSAGES[Math.floor(Math.random() * RIAS_NOTFOUND_MESSAGES.length)];
}

/**
 * Envia mensagem da Rias no canal após uma ação (com thumbnail!)
 */
export async function sendRiasFollowUp(channel, actionType, success = true) {
  try {
    const message = success 
      ? getRiasMessage(actionType) 
      : getRiasErrorMessage();
    
    // Obter emoção e imagem da Rias
    const emotion = getEmotionByAction(actionType);
    const thumbnailUrl = await getRiasImage(success ? emotion : 'desapontada');
    
    // Criar embed bonito com thumbnail da Rias
    const { EmbedBuilder } = await import('discord.js');
    
    const embed = new EmbedBuilder()
      .setDescription(message)
      .setColor(success ? '#8B5CF6' : '#EF4444')
      .setThumbnail(thumbnailUrl)
      .setFooter({ text: '🌹 Rias Gremory', iconURL: thumbnailUrl })
      .setTimestamp();
    
    await channel.send({ embeds: [embed] });
  } catch (error) {
    // Fallback: enviar mensagem simples
    try {
      const message = success 
        ? getRiasMessage(actionType) 
        : getRiasErrorMessage();
      await channel.send(message);
    } catch (e) {
      console.error('Erro ao enviar mensagem da Rias:', e.message);
    }
  }
}

export default {
  getRiasMessage,
  getRiasErrorMessage,
  getRiasNotFoundMessage,
  sendRiasFollowUp,
  RIAS_MESSAGES,
  RIAS_ERROR_MESSAGES
};
