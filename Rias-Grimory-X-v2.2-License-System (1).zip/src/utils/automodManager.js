/**
 * Rias-Grimory-X - Sistema de Moderação Automática
 * Proteção completa do servidor contra spam, links, menções em massa, etc.
 */

import { PermissionFlagsBits } from 'discord.js';

// Armazenamento de configurações por servidor
const automodConfigs = new Map();

// Armazenamento de infrações por usuário
const userInfractions = new Map();

// Armazenamento de mensagens recentes (para anti-spam)
const recentMessages = new Map();

// Configuração padrão
const DEFAULT_CONFIG = {
  enabled: true,
  antiSpam: {
    enabled: true,
    maxMessages: 5,
    timeWindow: 3000, // 3 segundos
    punishment: 'mute',
    muteDuration: 600, // 10 minutos
    maxDuplicates: 3
  },
  antiLink: {
    enabled: false,
    allowedDomains: [],
    allowedChannels: [],
    allowedRoles: [],
    punishment: 'delete'
  },
  antiMention: {
    enabled: true,
    maxMentions: 5,
    punishment: 'mute',
    muteDuration: 600
  },
  antiRaid: {
    enabled: true,
    joinThreshold: 10,
    joinTimeWindow: 10000, // 10 segundos
    punishment: 'kick'
  },
  badWords: {
    enabled: false,
    words: [],
    punishment: 'warn'
  },
  capsLock: {
    enabled: true,
    minPercentage: 70,
    minLength: 10,
    punishment: 'delete'
  },
  warnings: {
    maxWarnings: 3,
    punishment: 'kick' // kick ou ban
  }
};

/**
 * Inicializa configuração de automod para um servidor
 */
export function initAutomodConfig(guildId) {
  if (!automodConfigs.has(guildId)) {
    automodConfigs.set(guildId, { ...DEFAULT_CONFIG, guildId });
    console.log(`🛡️ [Automod] Configuração inicializada para: ${guildId}`);
  }
  return automodConfigs.get(guildId);
}

/**
 * Obtém configuração de automod
 */
export function getAutomodConfig(guildId) {
  return automodConfigs.get(guildId) || initAutomodConfig(guildId);
}

/**
 * Atualiza configuração de automod
 */
export function updateAutomodConfig(guildId, updates) {
  const config = getAutomodConfig(guildId);
  
  // Atualizar regras específicas
  if (updates.regra) {
    const rule = updates.regra;
    switch (rule) {
      case 'anti_spam':
        config.antiSpam = { 
          ...config.antiSpam, 
          enabled: true,
          maxMessages: updates.max_mensagens || updates.maxMessages || 5,
          timeWindow: (updates.tempo || updates.timeWindow || 3) * 1000,
          punishment: updates.punicao || updates.punishment || 'mute',
          muteDuration: updates.duracao || updates.muteDuration || 600
        };
        break;
        
      case 'anti_link':
        config.antiLink = {
          ...config.antiLink,
          enabled: true,
          allowedDomains: updates.dominios_permitidos || updates.allowedDomains || [],
          allowedChannels: updates.canais_permitidos || updates.allowedChannels || [],
          allowedRoles: updates.cargos_permitidos || updates.allowedRoles || [],
          punishment: updates.punicao || updates.punishment || 'delete'
        };
        break;
        
      case 'anti_mass_mention':
        config.antiMention = {
          ...config.antiMention,
          enabled: true,
          maxMentions: updates.max_mencoes || updates.maxMentions || 5,
          punishment: updates.punicao || updates.punishment || 'mute',
          muteDuration: updates.duracao || updates.muteDuration || 600
        };
        break;
        
      case 'anti_raid':
        config.antiRaid = {
          ...config.antiRaid,
          enabled: true,
          joinThreshold: updates.limite || updates.joinThreshold || 10,
          joinTimeWindow: (updates.tempo || updates.joinTimeWindow || 10) * 1000,
          punishment: updates.punicao || updates.punishment || 'kick'
        };
        break;
        
      case 'palavras_proibidas':
        config.badWords = {
          ...config.badWords,
          enabled: true,
          words: updates.lista || updates.words || [],
          punishment: updates.punicao || updates.punishment || 'warn'
        };
        break;
        
      case 'caps_lock':
        config.capsLock = {
          ...config.capsLock,
          enabled: updates.enabled !== false,
          minPercentage: updates.porcentagem || updates.minPercentage || 70,
          minLength: updates.tamanho_min || updates.minLength || 10,
          punishment: updates.punicao || updates.punishment || 'delete'
        };
        break;
    }
  }
  
  if (updates.enabled !== undefined) {
    config.enabled = updates.enabled;
  }
  
  automodConfigs.set(guildId, config);
  console.log(`✅ [Automod] Configuração atualizada para: ${guildId}`);
  return config;
}

/**
 * Desativa uma regra específica
 */
export function disableRule(guildId, rule) {
  const config = getAutomodConfig(guildId);
  
  switch (rule) {
    case 'anti_spam':
      config.antiSpam.enabled = false;
      break;
    case 'anti_link':
      config.antiLink.enabled = false;
      break;
    case 'anti_mass_mention':
      config.antiMention.enabled = false;
      break;
    case 'anti_raid':
      config.antiRaid.enabled = false;
      break;
    case 'palavras_proibidas':
      config.badWords.enabled = false;
      break;
    case 'caps_lock':
      config.capsLock.enabled = false;
      break;
    default:
      config.enabled = false;
  }
  
  automodConfigs.set(guildId, config);
  return config;
}

/**
 * Verifica mensagem contra todas as regras
 */
export async function checkMessage(message, guild) {
  const config = getAutomodConfig(guild.id);
  
  if (!config.enabled) return { passed: true };
  
  // Ignorar administradores
  if (message.member?.permissions?.has(PermissionFlagsBits.Administrator)) {
    return { passed: true };
  }
  
  const content = message.content;
  const userId = message.author.id;
  
  // 1. Anti-Spam
  if (config.antiSpam.enabled) {
    const spamResult = checkSpam(message, config.antiSpam);
    if (!spamResult.passed) {
      return { 
        passed: false, 
        reason: 'spam', 
        punishment: config.antiSpam.punishment,
        details: spamResult 
      };
    }
  }
  
  // 2. Anti-Link
  if (config.antiLink.enabled) {
    const linkResult = checkLinks(message, config.antiLink, guild);
    if (!linkResult.passed) {
      return { 
        passed: false, 
        reason: 'link', 
        punishment: config.antiLink.punishment,
        details: linkResult 
      };
    }
  }
  
  // 3. Anti-Mass Mention
  if (config.antiMention.enabled) {
    const mentionResult = checkMentions(message, config.antiMention);
    if (!mentionResult.passed) {
      return { 
        passed: false, 
        reason: 'mass_mention', 
        punishment: config.antiMention.punishment,
        details: mentionResult 
      };
    }
  }
  
  // 4. Bad Words
  if (config.badWords.enabled && config.badWords.words.length > 0) {
    const wordResult = checkBadWords(content, config.badWords);
    if (!wordResult.passed) {
      return { 
        passed: false, 
        reason: 'bad_word', 
        punishment: config.badWords.punishment,
        details: wordResult 
      };
    }
  }
  
  // 5. Caps Lock
  if (config.capsLock.enabled) {
    const capsResult = checkCapsLock(content, config.capsLock);
    if (!capsResult.passed) {
      return { 
        passed: false, 
        reason: 'caps_lock', 
        punishment: config.capsLock.punishment,
        details: capsResult 
      };
    }
  }
  
  return { passed: true };
}

/**
 * Verifica spam
 */
function checkSpam(message, config) {
  const userId = message.author.id;
  const content = message.content.toLowerCase();
  const now = Date.now();
  
  // Inicializar registro do usuário
  if (!recentMessages.has(userId)) {
    recentMessages.set(userId, []);
  }
  
  const userMessages = recentMessages.get(userId);
  
  // Filtrar mensagens dentro da janela de tempo
  const recentMsgs = userMessages.filter(
    m => now - m.timestamp < config.timeWindow
  );
  
  // Adicionar mensagem atual
  recentMsgs.push({ content, timestamp: now });
  recentMessages.set(userId, recentMsgs);
  
  // Verificar quantidade de mensagens
  if (recentMsgs.length > config.maxMessages) {
    return { passed: false, count: recentMsgs.length };
  }
  
  // Verificar mensagens duplicadas
  const duplicates = recentMsgs.filter(m => m.content === content).length;
  if (duplicates > config.maxDuplicates) {
    return { passed: false, duplicates, reason: 'duplicate' };
  }
  
  return { passed: true };
}

/**
 * Verifica links
 */
function checkLinks(message, config, guild) {
  const content = message.content;
  const linkRegex = /https?:\/\/[^\s]+/gi;
  const links = content.match(linkRegex) || [];
  
  if (links.length === 0) return { passed: true };
  
  // Verificar canais permitidos
  if (config.allowedChannels.length > 0) {
    const channelName = message.channel.name;
    const channelId = message.channel.id;
    if (config.allowedChannels.some(c => 
      c === channelId || c.toLowerCase() === channelName.toLowerCase()
    )) {
      return { passed: true };
    }
  }
  
  // Verificar cargos permitidos
  if (config.allowedRoles.length > 0 && message.member) {
    const memberRoles = message.member.roles.cache.map(r => r.name.toLowerCase());
    if (config.allowedRoles.some(r => 
      memberRoles.includes(r.toLowerCase())
    )) {
      return { passed: true };
    }
  }
  
  // Verificar domínios permitidos
  if (config.allowedDomains.length > 0) {
    const allowedLinks = links.filter(link => 
      config.allowedDomains.some(domain => link.includes(domain))
    );
    if (allowedLinks.length === links.length) {
      return { passed: true };
    }
  }
  
  return { passed: false, links };
}

/**
 * Verifica menções em massa
 */
function checkMentions(message, config) {
  const content = message.content;
  const mentionCount = (content.match(/<@!?&?\d+>/g) || []).length;
  const everyoneMention = content.includes('@everyone') || content.includes('@here');
  
  if (mentionCount > config.maxMentions || everyoneMention) {
    return { 
      passed: false, 
      mentions: mentionCount,
      everyone: everyoneMention 
    };
  }
  
  return { passed: true };
}

/**
 * Verifica palavras proibidas
 */
function checkBadWords(content, config) {
  const lowerContent = content.toLowerCase();
  const found = config.words.filter(word => 
    lowerContent.includes(word.toLowerCase())
  );
  
  if (found.length > 0) {
    return { passed: false, words: found };
  }
  
  return { passed: true };
}

/**
 * Verifica caps lock excessivo
 */
function checkCapsLock(content, config) {
  if (content.length < config.minLength) return { passed: true };
  
  const letters = content.replace(/[^a-zA-Z]/g, '');
  if (letters.length === 0) return { passed: true };
  
  const capsCount = letters.replace(/[^A-Z]/g, '').length;
  const percentage = (capsCount / letters.length) * 100;
  
  if (percentage >= config.minPercentage) {
    return { passed: false, percentage: Math.round(percentage) };
  }
  
  return { passed: true };
}

/**
 * Adiciona advertência ao usuário
 */
export function addWarning(guildId, userId, reason) {
  const key = `${guildId}_${userId}`;
  
  if (!userInfractions.has(key)) {
    userInfractions.set(key, { warnings: [], mutes: 0 });
  }
  
  const user = userInfractions.get(key);
  user.warnings.push({
    reason,
    timestamp: Date.now()
  });
  
  userInfractions.set(key, user);
  
  return {
    total: user.warnings.length,
    warning: user.warnings[user.warnings.length - 1]
  };
}

/**
 * Obtém advertências do usuário
 */
export function getWarnings(guildId, userId) {
  const key = `${guildId}_${userId}`;
  const user = userInfractions.get(key);
  
  return {
    warnings: user?.warnings || [],
    total: user?.warnings?.length || 0
  };
}

/**
 * Remove uma advertência
 */
export function removeWarning(guildId, userId, index) {
  const key = `${guildId}_${userId}`;
  const user = userInfractions.get(key);
  
  if (user && user.warnings[index]) {
    user.warnings.splice(index, 1);
    userInfractions.set(key, user);
    return true;
  }
  
  return false;
}

/**
 * Limpa todas as advertências
 */
export function clearWarnings(guildId, userId) {
  const key = `${guildId}_${userId}`;
  userInfractions.delete(key);
  return true;
}

/**
 * Verifica se usuário deve ser punido por excesso de advertências
 */
export function checkMaxWarnings(guildId, userId) {
  const config = getAutomodConfig(guildId);
  const warnings = getWarnings(guildId, userId);
  
  if (warnings.total >= config.warnings.maxWarnings) {
    return {
      exceeded: true,
      punishment: config.warnings.punishment
    };
  }
  
  return { exceeded: false };
}

/**
 * Obtém configurações formatadas para exibição
 */
export function getAutomodSettings(guildId) {
  const config = getAutomodConfig(guildId);
  
  return {
    enabled: config.enabled,
    rules: {
      antiSpam: {
        enabled: config.antiSpam.enabled,
        maxMessages: config.antiSpam.maxMessages,
        timeWindow: config.antiSpam.timeWindow / 1000,
        punishment: config.antiSpam.punishment
      },
      antiLink: {
        enabled: config.antiLink.enabled,
        allowedDomains: config.antiLink.allowedDomains.length,
        punishment: config.antiLink.punishment
      },
      antiMention: {
        enabled: config.antiMention.enabled,
        maxMentions: config.antiMention.maxMentions,
        punishment: config.antiMention.punishment
      },
      antiRaid: {
        enabled: config.antiRaid.enabled,
        threshold: config.antiRaid.joinThreshold,
        punishment: config.antiRaid.punishment
      },
      badWords: {
        enabled: config.badWords.enabled,
        count: config.badWords.words.length,
        punishment: config.badWords.punishment
      },
      capsLock: {
        enabled: config.capsLock.enabled,
        minPercentage: config.capsLock.minPercentage,
        punishment: config.capsLock.punishment
      }
    },
    warnings: {
      max: config.warnings.maxWarnings,
      punishment: config.warnings.punishment
    }
  };
}

export default {
  initAutomodConfig,
  getAutomodConfig,
  updateAutomodConfig,
  disableRule,
  checkMessage,
  addWarning,
  getWarnings,
  removeWarning,
  clearWarnings,
  checkMaxWarnings,
  getAutomodSettings
};
