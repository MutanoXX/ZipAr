/**
 * MutanoX Architect - Gerenciador de Servidor
 * Funções para criar canais, categorias e cargos
 */

/**
 * Mapeamento de permissões string para bitmask
 */
const PERMISSION_FLAGS = {
  Administrator: 8n,
  ViewChannel: 1024n,
  ManageChannels: 16n,
  ManageRoles: 268435456n,
  ManageMessages: 8192n,
  SendMessages: 2048n,
  EmbedLinks: 16384n,
  AttachFiles: 32768n,
  ReadMessageHistory: 65536n,
  MentionEveryone: 131072n,
  UseExternalEmojis: 262144n,
  AddReactions: 64n,
  Connect: 1048576n,
  Speak: 2097152n,
  Stream: 4194304n,
  UseVAD: 33554432n,
  PrioritySpeaker: 8388608n,
  MuteMembers: 4194304n,
  DeafenMembers: 8388608n,
  MoveMembers: 16777216n,
  ManageGuild: 32n,
  KickMembers: 2n,
  BanMembers: 4n,
  CreateInstantInvite: 1n,
  ChangeNickname: 67108864n,
  ManageNicknames: 134217728n,
  ModerateMembers: 1099511627776n,
  ViewAuditLog: 128n,
  ViewGuildInsights: 524288n,
  ManageWebhooks: 536870912n,
  ManageEmojisAndStickers: 1073741824n,
  UseApplicationCommands: 2147483648n,
  RequestToSpeak: 4294967296n,
  ManageEvents: 2199023255552n,
  ManageThreads: 17179869184n,
  CreatePublicThreads: 34359738368n,
  CreatePrivateThreads: 68719476736n,
  UseExternalStickers: 137438953472n,
  SendMessagesInThreads: 274877906944n,
  UseEmbeddedActivities: 549755813888n,
  UseSoundboard: 549755813888n,
  CreateExpressions: 8796093022208n
};

/**
 * Converte array de strings de permissão para bitmask
 */
function parsePermissions(permissions) {
  if (!permissions || !Array.isArray(permissions)) return 0n;
  
  let bitmask = 0n;
  for (const perm of permissions) {
    if (PERMISSION_FLAGS[perm]) {
      bitmask |= PERMISSION_FLAGS[perm];
    }
  }
  return bitmask;
}

/**
 * Converte cor hex para número inteiro
 */
function hexToInt(hex) {
  if (!hex) return null;
  const clean = hex.replace('#', '');
  return parseInt(clean, 16) || null;
}

/**
 * Limpa nome do canal - preserva emojis e fontes especiais Unicode
 * Remove apenas caracteres realmente problemáticos
 */
function cleanChannelName(name) {
  if (!name) return 'canal';
  
  // Apenas remover caracteres que o Discord realmente não aceita
  // Preserva: emojis, caracteres Unicode (fontes especiais), letras, números, hífens
  let clean = name
    .replace(/[<>@#&!]/g, '') // Remove menções e caracteres especiais do Discord
    .replace(/\s+/g, '-')      // Espaços viram hífens
    .replace(/-+/g, '-')       // Múltiplos hífens viram um
    .replace(/^-|-$/g, '')     // Remove hífens no início/fim
    .substring(0, 100);        // Limite de 100 caracteres
  
  return clean || 'canal';
}

/**
 * Limpa o topic do canal - remove caracteres problemáticos mas preserva acentos
 */
function cleanTopic(topic) {
  if (!topic) return undefined;
  
  // Remover apenas caracteres que podem causar problemas
  return topic
    .replace(/[<>@#&!]/g, '') // Remove menções
    .substring(0, 1024); // Limite do Discord
}

/**
 * Aplica um plano de reestruturação ao servidor
 * @param {Guild} guild - Servidor Discord
 * @param {Object} plan - Plano de reestruturação
 * @returns {Object} Resultado da operação
 */
export async function applyPlan(guild, plan) {
  const result = {
    categories: 0,
    channels: 0,
    roles: 0,
    errors: []
  };

  console.log(`🏗️ [ServerManager] Iniciando aplicação do plano em: ${guild.name}`);
  console.log(`📋 [ServerManager] Plano: ${plan.plan?.name}`);
  console.log(`📋 [ServerManager] Cargos: ${plan.changes?.createRoles?.length || 0}`);
  console.log(`📋 [ServerManager] Categorias: ${plan.changes?.createCategories?.length || 0}`);

  try {
    // 1. Criar cargos
    if (plan.changes?.createRoles?.length > 0) {
      console.log(`👥 [ServerManager] Criando ${plan.changes.createRoles.length} cargos...`);
      
      for (const roleData of plan.changes.createRoles) {
        try {
          console.log(`   Criando cargo: ${roleData.name}`);
          
          await guild.roles.create({
            name: roleData.name,
            color: hexToInt(roleData.color),
            permissions: parsePermissions(roleData.permissions),
            reason: 'MutanoX Architect'
          });
          result.roles++;
          await sleep(300);
        } catch (error) {
          console.error(`Erro ao criar cargo ${roleData.name}:`, error.message);
          result.errors.push(`Cargo "${roleData.name}": ${error.message}`);
        }
      }
    }

    // 2. Criar categorias e canais
    if (plan.changes?.createCategories?.length > 0) {
      console.log(`📁 [ServerManager] Criando ${plan.changes.createCategories.length} categorias...`);
      
      for (const categoryData of plan.changes.createCategories) {
        try {
          console.log(`   Criando categoria: ${categoryData.name}`);
          
          // Criar categoria
          const category = await guild.channels.create({
            name: categoryData.name,
            type: 4, // GuildCategory
            reason: 'MutanoX Architect'
          });
          result.categories++;
          
          await sleep(300);

          // Criar canais dentro da categoria
          if (categoryData.channels?.length > 0) {
            for (const channelData of categoryData.channels) {
              try {
                const isVoiceChannel = channelData.type === 2;
                
                // Limpar nome do canal (preserva emojis e fontes)
                const channelName = cleanChannelName(channelData.name);
                
                console.log(`      Criando canal: ${channelName} (type: ${channelData.type || 0})`);
                
                const channelOptions = {
                  name: channelName,
                  type: channelData.type || 0,
                  parent: category.id,
                  reason: 'MutanoX Architect'
                };

                // APENAS canais de texto podem ter topic
                if (!isVoiceChannel && channelData.topic) {
                  channelOptions.topic = cleanTopic(channelData.topic);
                }

                // Processar permissões
                if (channelData.permissionOverwrites?.length > 0) {
                  channelOptions.permissionOverwrites = [];
                  
                  for (const perm of channelData.permissionOverwrites) {
                    let roleId;
                    
                    if (perm.roleName === '@everyone') {
                      roleId = guild.roles.everyone.id;
                    } else {
                      const role = guild.roles.cache.find(
                        r => r.name.toLowerCase() === perm.roleName.toLowerCase()
                      );
                      if (role) roleId = role.id;
                    }
                    
                    if (roleId) {
                      channelOptions.permissionOverwrites.push({
                        id: roleId,
                        deny: parsePermissions(perm.deny),
                        allow: parsePermissions(perm.allow)
                      });
                    }
                  }
                }

                await guild.channels.create(channelOptions);
                result.channels++;
                
                await sleep(300);
              } catch (error) {
                console.error(`Erro ao criar canal ${channelData.name}:`, error.message);
                result.errors.push(`Canal "${channelData.name}": ${error.message}`);
              }
            }
          }
        } catch (error) {
          console.error(`Erro ao criar categoria ${categoryData.name}:`, error.message);
          result.errors.push(`Categoria "${categoryData.name}": ${error.message}`);
        }
      }
    }

    console.log(`✅ [ServerManager] Plano aplicado: ${result.categories} categorias, ${result.channels} canais, ${result.roles} cargos`);
    
    return result;

  } catch (error) {
    console.error('❌ [ServerManager] Erro crítico:', error);
    throw error;
  }
}

/**
 * Função utilitária para sleep
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Valida se o bot tem permissões necessárias
 */
export function checkBotPermissions(guild) {
  const botMember = guild.members.me;
  
  const requiredPermissions = [
    'ManageChannels',
    'ManageRoles',
    'ViewChannel',
    'SendMessages'
  ];
  
  const missing = requiredPermissions.filter(perm => !botMember.permissions.has(perm));
  
  return {
    hasAllPermissions: missing.length === 0,
    missingPermissions: missing
  };
}

export default {
  applyPlan,
  checkBotPermissions,
  parsePermissions,
  hexToInt,
  cleanChannelName,
  cleanTopic
};
