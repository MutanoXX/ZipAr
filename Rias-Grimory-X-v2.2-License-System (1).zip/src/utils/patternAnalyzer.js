/**
 * Rias-Grimory-X - Sistema de Análise de Padrões
 * VERSÃO: 2.0 - Simplificado e Robusto
 */

// Emojis por categoria
export const EMOJI_SUGGESTIONS = {
  chat: ['💬', '🗣️', '💭'],
  geral: ['🌐', '🏠', '📍'],
  anime: ['🎌', '📺', '🎬', '🎭'],
  games: ['🎮', '🕹️', '👾', '🎯'],
  music: ['🎵', '🎶', '🎧'],
  art: ['🎨', '🖼️', '✏️'],
  memes: ['😂', '🤣', '😹'],
  nsfw: ['🔞', '🌶️'],
  bot: ['🤖', '⚙️', '🔧'],
  logs: ['📋', '📝', '📊'],
  welcome: ['👋', '🚪', '✨'],
  ticket: ['🎫', '🎟️', '🏷️'],
  voice: ['🔊', '🎙️', '📻'],
  admin: ['👑', '🔐', '🛡️'],
  mod: ['⚔️', '🛡️', '⚖️'],
  staff: ['👑', '⭐', '🌟'],
  vip: ['💎', '💠', '👑'],
  booster: ['💎', '🚀', '✨'],
  member: ['👤', '👥'],
  love: ['❤️', '💕', '💗', '🌹']
};

// Separadores comuns
export const SEPARATORS = ['│', '┃', '|', '-', '•', '·'];

/**
 * Extrai emojis de uma string
 */
export function extractEmojis(str) {
  if (!str) return [];
  const emojiRegex = /[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu;
  return str.match(emojiRegex) || [];
}

/**
 * Detecta categoria pelo nome
 */
export function detectCategoryFromName(name) {
  if (!name) return null;
  const lower = name.toLowerCase();
  
  const categoryMap = {
    chat: ['chat', 'conversa', 'papo'],
    geral: ['geral', 'general', 'main'],
    anime: ['anime', 'manga', 'otaku'],
    games: ['game', 'jogo', 'gaming'],
    music: ['music', 'musica', 'música'],
    art: ['art', 'arte', 'desenho'],
    memes: ['meme', 'memes', 'humor'],
    nsfw: ['nsfw', '+18'],
    bot: ['bot', 'comando'],
    logs: ['log', 'registro'],
    welcome: ['welcome', 'bem-vindo'],
    ticket: ['ticket', 'suporte'],
    voice: ['voice', 'voz', 'call'],
    admin: ['admin', 'staff', 'dono'],
    mod: ['mod', 'moderação'],
    vip: ['vip', 'premium'],
    booster: ['booster', 'boost']
  };
  
  for (const [category, keywords] of Object.entries(categoryMap)) {
    if (keywords.some(kw => lower.includes(kw))) {
      return category;
    }
  }
  return null;
}

/**
 * Detecta separador usado
 */
export function detectSeparator(str) {
  if (!str) return null;
  for (const sep of SEPARATORS) {
    if (str.includes(sep)) return sep;
  }
  return null;
}

/**
 * Analisa padrões dos canais
 */
export function analyzeChannelPatterns(guild) {
  try {
    const channels = guild.channels.cache
      .filter(c => c.type !== 4)
      .map(c => c.name);
    
    if (channels.length === 0) {
      return { hasEmojis: false, commonEmojis: [], separator: null };
    }
    
    const allEmojis = [];
    let separatorCount = {};
    
    for (const name of channels) {
      allEmojis.push(...extractEmojis(name));
      const sep = detectSeparator(name);
      if (sep) {
        separatorCount[sep] = (separatorCount[sep] || 0) + 1;
      }
    }
    
    // Top emojis
    const emojiCounts = {};
    for (const e of allEmojis) {
      emojiCounts[e] = (emojiCounts[e] || 0) + 1;
    }
    const topEmojis = Object.entries(emojiCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([emoji]) => emoji);
    
    // Most common separator
    let topSeparator = null;
    let maxCount = 0;
    for (const [sep, count] of Object.entries(separatorCount)) {
      if (count > maxCount) {
        maxCount = count;
        topSeparator = sep;
      }
    }
    
    return {
      hasEmojis: topEmojis.length > 0,
      commonEmojis: topEmojis,
      separator: topSeparator,
      sampleNames: channels.slice(0, 3)
    };
  } catch (e) {
    console.error('[PatternAnalyzer] Erro:', e.message);
    return { hasEmojis: false, commonEmojis: [], separator: null };
  }
}

/**
 * Analisa padrões das categorias
 */
export function analyzeCategoryPatterns(guild) {
  return analyzeChannelPatterns(guild);
}

/**
 * Analisa padrões dos cargos
 */
export function analyzeRolePatterns(guild) {
  try {
    const roles = guild.roles.cache
      .filter(r => r.name !== '@everyone' && !r.managed)
      .map(r => ({ name: r.name, color: r.hexColor }));
    
    if (roles.length === 0) {
      return { hasEmojis: false, commonEmojis: [], commonColors: ['#99AAB5'] };
    }
    
    const allEmojis = [];
    const colorCounts = {};
    
    for (const role of roles) {
      allEmojis.push(...extractEmojis(role.name));
      if (role.color && role.color !== '#000000') {
        colorCounts[role.color] = (colorCounts[role.color] || 0) + 1;
      }
    }
    
    const emojiCounts = {};
    for (const e of allEmojis) {
      emojiCounts[e] = (emojiCounts[e] || 0) + 1;
    }
    const topEmojis = Object.entries(emojiCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([emoji]) => emoji);
    
    const topColors = Object.entries(colorCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([color]) => color);
    
    return {
      hasEmojis: topEmojis.length > 0,
      commonEmojis: topEmojis,
      commonColors: topColors.length > 0 ? topColors : ['#99AAB5']
    };
  } catch (e) {
    console.error('[PatternAnalyzer] Erro:', e.message);
    return { hasEmojis: false, commonEmojis: [], commonColors: ['#99AAB5'] };
  }
}

/**
 * Análise completa do servidor
 */
export function analyzeServerPatterns(guild) {
  return {
    channels: analyzeChannelPatterns(guild),
    categories: analyzeCategoryPatterns(guild),
    roles: analyzeRolePatterns(guild),
    suggestions: EMOJI_SUGGESTIONS
  };
}

/**
 * Decora nome de canal seguindo padrão
 */
export function decorateChannelName(guild, name) {
  try {
    const pattern = analyzeChannelPatterns(guild);
    const category = detectCategoryFromName(name);
    
    // Verificar se já tem emoji
    const hasEmoji = extractEmojis(name).length > 0;
    
    if (pattern.hasEmojis && !hasEmoji) {
      let emoji = pattern.commonEmojis[0];
      
      // Usar emoji da categoria se disponível
      if (category && EMOJI_SUGGESTIONS[category]) {
        emoji = EMOJI_SUGGESTIONS[category][0];
      }
      
      const sep = pattern.separator || '';
      return `${emoji}${sep}${name}`;
    }
    
    return name;
  } catch (e) {
    return name;
  }
}

/**
 * Decora nome de categoria
 */
export function decorateCategoryName(guild, name) {
  return decorateChannelName(guild, name);
}

/**
 * Decora nome de cargo
 */
export function decorateRoleName(guild, name) {
  try {
    const pattern = analyzeRolePatterns(guild);
    const category = detectCategoryFromName(name);
    
    const hasEmoji = extractEmojis(name).length > 0;
    
    if (pattern.hasEmojis && !hasEmoji) {
      let emoji = pattern.commonEmojis[0];
      
      if (category && EMOJI_SUGGESTIONS[category]) {
        emoji = EMOJI_SUGGESTIONS[category][0];
      }
      
      return `${emoji} ${name}`;
    }
    
    return name;
  } catch (e) {
    return name;
  }
}

/**
 * Sugere cor para cargo
 */
export function suggestRoleColor(guild, hint) {
  if (hint) return hint;
  
  try {
    const pattern = analyzeRolePatterns(guild);
    if (pattern.commonColors && pattern.commonColors.length > 0) {
      return pattern.commonColors[Math.floor(Math.random() * pattern.commonColors.length)];
    }
  } catch (e) {}
  
  return '#99AAB5';
}

// Aliases para compatibilidade
export const formatChannelName = decorateChannelName;
export const formatCategoryName = decorateCategoryName;
export const formatRoleName = decorateRoleName;

export default {
  analyzeServerPatterns,
  analyzeChannelPatterns,
  analyzeCategoryPatterns,
  analyzeRolePatterns,
  decorateChannelName,
  decorateCategoryName,
  decorateRoleName,
  suggestRoleColor,
  detectCategoryFromName,
  extractEmojis,
  detectSeparator,
  EMOJI_SUGGESTIONS,
  SEPARATORS,
  // Aliases
  formatChannelName,
  formatCategoryName,
  formatRoleName
};
