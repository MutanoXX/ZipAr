/**
 * Rias-Grimory-X - Sistema de Tickets
 * Sistema completo de suporte com painel, categorias e transcripts
 */

import {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ChannelType,
  PermissionFlagsBits,
  TextInputStyle
} from 'discord.js';

// Configurações por servidor
const ticketConfigs = new Map();

// Tickets ativos
const activeTickets = new Map();

// Contador de tickets
const ticketCounters = new Map();

// Configuração padrão
const DEFAULT_TICKET_CONFIG = {
  enabled: true,
  
  // Painel de tickets
  panel: {
    channelId: null,
    messageId: null,
    title: '🎫 Central de Suporte',
    description: 'Selecione uma categoria abaixo para abrir um ticket',
    color: '#8B5CF6',
    categories: [
      { id: 'suporte', name: '🛠️ Suporte', description: 'Ajuda com problemas técnicos' },
      { id: 'duvida', name: '❓ Dúvida', description: 'Tire suas dúvidas' },
      { id: 'denuncia', name: '⚠️ Denúncia', description: 'Denuncie um usuário' },
      { id: 'parceria', name: '🤝 Parceria', description: 'Propostas de parceria' }
    ]
  },
  
  // Configurações do ticket
  settings: {
    categoryId: null,
    supportRoleId: null,
    logChannelId: null,
    prefix: 'ticket',
    claimButton: true,
    closeButton: true,
    transcriptOnClose: true,
    maxPerUser: 3,
    nameFormat: 'ticket-{count}' // ou 'ticket-{username}'
  },
  
  // Mensagens
  messages: {
    opened: '🎫 **Ticket Aberto!**\n\nOlá {user}! Sua solicitação foi recebida.\nCategoria: **{category}**\n\nDescreva seu problema e aguarde o atendimento.',
    closed: '🔒 **Ticket Fechado!**\n\nFechado por: {closer}\nMotivo: {reason}',
    claimed: '✋ **Ticket Reivindicado!**\n\n{staff} está agora responsável por este ticket.'
  }
};

/**
 * Inicializa configuração de tickets
 */
export function initTicketConfig(guildId) {
  if (!ticketConfigs.has(guildId)) {
    ticketConfigs.set(guildId, { ...DEFAULT_TICKET_CONFIG, guildId });
    ticketCounters.set(guildId, 0);
    console.log(`🎫 [Tickets] Configuração inicializada para: ${guildId}`);
  }
  return ticketConfigs.get(guildId);
}

/**
 * Obtém configuração de tickets
 */
export function getTicketConfig(guildId) {
  return ticketConfigs.get(guildId) || initTicketConfig(guildId);
}

/**
 * Configura categoria de tickets
 */
export function setTicketCategory(guildId, categoryId) {
  const config = getTicketConfig(guildId);
  config.settings.categoryId = categoryId;
  ticketConfigs.set(guildId, config);
  return config;
}

/**
 * Configura cargo de suporte
 */
export function setSupportRole(guildId, roleId) {
  const config = getTicketConfig(guildId);
  config.settings.supportRoleId = roleId;
  ticketConfigs.set(guildId, config);
  return config;
}

/**
 * Configura canal de logs
 */
export function setLogChannel(guildId, channelId) {
  const config = getTicketConfig(guildId);
  config.settings.logChannelId = channelId;
  ticketConfigs.set(guildId, config);
  return config;
}

/**
 * Adiciona categoria de ticket
 */
export function addCategory(guildId, category) {
  const config = getTicketConfig(guildId);
  
  const newCategory = {
    id: category.id || category.name.toLowerCase().replace(/\s+/g, '-'),
    name: category.name,
    description: category.description || '',
    emoji: category.emoji || '🎫'
  };
  
  config.panel.categories.push(newCategory);
  ticketConfigs.set(guildId, config);
  
  return config;
}

/**
 * Remove categoria
 */
export function removeCategory(guildId, categoryId) {
  const config = getTicketConfig(guildId);
  config.panel.categories = config.panel.categories.filter(c => c.id !== categoryId);
  ticketConfigs.set(guildId, config);
  return config;
}

/**
 * Cria painel de tickets
 */
export async function createTicketPanel(guild, options = {}) {
  const config = getTicketConfig(guild.id);
  
  const channel = options.channelId 
    ? guild.channels.cache.get(options.channelId)
    : guild.channels.cache.get(config.panel.channelId);
  
  if (!channel) {
    return { success: false, error: 'Canal não encontrado' };
  }
  
  // Criar embed do painel
  const embed = new EmbedBuilder()
    .setTitle(options.title || config.panel.title)
    .setDescription(options.description || config.panel.description)
    .setColor(options.color || config.panel.color)
    .setFooter({ text: '💎 Rias-Grimory-X | Sistema de Tickets' })
    .setTimestamp();
  
  // Adicionar categorias ao embed
  const categoriesList = config.panel.categories
    .map(c => `${c.name} - ${c.description}`)
    .join('\n');
  
  embed.addFields({ name: '📂 Categorias', value: categoriesList || 'Nenhuma categoria' });
  
  // Criar menu de seleção
  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId('ticket_select_category')
    .setPlaceholder('🎫 Selecione uma categoria...')
    .addOptions(
      config.panel.categories.map(c => ({
        label: c.name,
        description: c.description,
        value: c.id,
        emoji: c.emoji
      }))
    );
  
  // Criar botão de criar ticket
  const button = new ButtonBuilder()
    .setCustomId('ticket_create_default')
    .setLabel('Abrir Ticket')
    .setEmoji('🎫')
    .setStyle(ButtonStyle.Primary);
  
  const row1 = new ActionRowBuilder().addComponents(selectMenu);
  const row2 = new ActionRowBuilder().addComponents(button);
  
  try {
    // Deletar painel anterior se existir
    if (config.panel.messageId) {
      try {
        const oldMessage = await channel.messages.fetch(config.panel.messageId);
        if (oldMessage) await oldMessage.delete();
      } catch (e) {}
    }
    
    const message = await channel.send({
      embeds: [embed],
      components: [row1, row2]
    });
    
    // Salvar ID da mensagem
    config.panel.messageId = message.id;
    config.panel.channelId = channel.id;
    ticketConfigs.set(guild.id, config);
    
    console.log(`✅ [Tickets] Painel criado: ${message.id}`);
    return { success: true, message };
    
  } catch (error) {
    console.error('❌ [Tickets] Erro ao criar painel:', error.message);
    return { success: false, error: error.message };
  }
}

/**
 * Cria um ticket
 */
export async function createTicket(guild, user, categoryId = 'default', reason = '') {
  const config = getTicketConfig(guild.id);
  
  // Verificar limite de tickets por usuário
  const userTickets = getUserTickets(guild.id, user.id);
  if (userTickets.length >= config.settings.maxPerUser) {
    return { 
      success: false, 
      error: `Você já tem ${config.settings.maxPerUser} ticket(s) aberto(s).` 
    };
  }
  
  // Incrementar contador
  const count = (ticketCounters.get(guild.id) || 0) + 1;
  ticketCounters.set(guild.id, count);
  
  // Nome do canal
  const channelName = config.settings.nameFormat
    .replace('{count}', count.toString().padStart(4, '0'))
    .replace('{username}', user.username.toLowerCase().substring(0, 15));
  
  // Obter categoria
  const category = config.settings.categoryId
    ? guild.channels.cache.get(config.settings.categoryId)
    : null;
  
  // Categoria do ticket
  const ticketCategory = config.panel.categories.find(c => c.id === categoryId) 
    || { id: 'default', name: '🎫 Ticket' };
  
  try {
    // Criar canal do ticket
    const channel = await guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: category,
      topic: `Ticket #${count} - ${user.tag} - ${ticketCategory.name}`,
      permissionOverwrites: [
        {
          id: guild.roles.everyone.id,
          deny: [PermissionFlagsBits.ViewChannel]
        },
        {
          id: user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
            PermissionFlagsBits.AttachFiles
          ]
        }
      ]
    });
    
    // Adicionar cargo de suporte se configurado
    if (config.settings.supportRoleId) {
      await channel.permissionOverwrites.edit(config.settings.supportRoleId, {
        ViewChannel: true,
        SendMessages: true,
        ReadMessageHistory: true
      });
    }
    
    // Registrar ticket ativo
    const ticketId = channel.id;
    activeTickets.set(ticketId, {
      id: ticketId,
      number: count,
      channelId: channel.id,
      categoryId: categoryId,
      category: ticketCategory,
      userId: user.id,
      userTag: user.tag,
      guildId: guild.id,
      createdAt: Date.now(),
      status: 'open',
      claimed: false,
      claimedBy: null,
      messages: []
    });
    
    // Enviar mensagem inicial
    const welcomeEmbed = new EmbedBuilder()
      .setTitle(`${ticketCategory.name} - Ticket #${count}`)
      .setDescription(config.messages.opened
        .replace('{user}', `<@${user.id}>`)
        .replace('{category}', ticketCategory.name)
      )
      .setColor('#10B981')
      .addFields(
        { name: '👤 Autor', value: `<@${user.id}> (${user.tag})`, inline: true },
        { name: '📂 Categoria', value: ticketCategory.name, inline: true },
        { name: '🆔 Número', value: `#${count}`, inline: true }
      )
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    if (reason) {
      welcomeEmbed.addFields({ name: '📝 Motivo', value: reason });
    }
    
    // Botões de ação
    const buttons = [];
    
    if (config.settings.claimButton) {
      buttons.push(
        new ButtonBuilder()
          .setCustomId('ticket_claim')
          .setLabel('Reivindicar')
          .setEmoji('✋')
          .setStyle(ButtonStyle.Primary)
      );
    }
    
    buttons.push(
      new ButtonBuilder()
        .setCustomId('ticket_close')
        .setLabel('Fechar')
        .setEmoji('🔒')
        .setStyle(ButtonStyle.Danger)
    );
    
    const row = new ActionRowBuilder().addComponents(buttons);
    
    await channel.send({
      content: `<@${user.id}>${config.settings.supportRoleId ? ` <@&${config.settings.supportRoleId}>` : ''}`,
      embeds: [welcomeEmbed],
      components: [row]
    });
    
    console.log(`✅ [Tickets] Ticket criado: #${count} por ${user.tag}`);
    
    return { 
      success: true, 
      ticket: activeTickets.get(ticketId),
      channel 
    };
    
  } catch (error) {
    console.error('❌ [Tickets] Erro ao criar ticket:', error.message);
    return { success: false, error: error.message };
  }
}

/**
 * Obtém tickets do usuário
 */
export function getUserTickets(guildId, userId) {
  return Array.from(activeTickets.values())
    .filter(t => t.guildId === guildId && t.userId === userId && t.status === 'open');
}

/**
 * Obtém ticket por ID do canal
 */
export function getTicket(channelId) {
  return activeTickets.get(channelId);
}

/**
 * Reivindica ticket
 */
export async function claimTicket(guild, channelId, staffId) {
  const ticket = activeTickets.get(channelId);
  
  if (!ticket) {
    return { success: false, error: 'Ticket não encontrado' };
  }
  
  ticket.claimed = true;
  ticket.claimedBy = staffId;
  ticket.claimedAt = Date.now();
  
  activeTickets.set(channelId, ticket);
  
  // Notificar no canal
  const channel = guild.channels.cache.get(channelId);
  if (channel) {
    const embed = new EmbedBuilder()
      .setDescription(config.messages.claimed.replace('{staff}', `<@${staffId}>`))
      .setColor('#8B5CF6')
      .setTimestamp();
    
    await channel.send({ embeds: [embed] }).catch(() => {});
  }
  
  console.log(`✅ [Tickets] Ticket reivindicado: #${ticket.number}`);
  return { success: true, ticket };
}

/**
 * Fecha ticket
 */
export async function closeTicket(guild, channelId, closerId, reason = 'Sem motivo') {
  const ticket = activeTickets.get(channelId);
  
  if (!ticket) {
    return { success: false, error: 'Ticket não encontrado' };
  }
  
  const config = getTicketConfig(guild.id);
  
  ticket.status = 'closed';
  ticket.closedBy = closerId;
  ticket.closedAt = Date.now();
  ticket.closeReason = reason;
  
  const channel = guild.channels.cache.get(channelId);
  
  if (channel) {
    try {
      // Enviar mensagem de fechamento
      const closeEmbed = new EmbedBuilder()
        .setTitle('🔒 Ticket Fechado')
        .setDescription(config.messages.closed
          .replace('{closer}', `<@${closerId}>`)
          .replace('{reason}', reason)
        )
        .setColor('#EF4444')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      
      await channel.send({ embeds: [closeEmbed] });
      
      // Gerar transcript se configurado
      if (config.settings.transcriptOnClose) {
        const transcript = await generateTranscript(channel, ticket);
        ticket.transcript = transcript;
      }
      
      // Enviar log
      if (config.settings.logChannelId) {
        const logChannel = guild.channels.cache.get(config.settings.logChannelId);
        if (logChannel) {
          const logEmbed = new EmbedBuilder()
            .setTitle('📋 Ticket Fechado')
            .addFields(
              { name: '🎫 Número', value: `#${ticket.number}`, inline: true },
              { name: '👤 Autor', value: `<@${ticket.userId}>`, inline: true },
              { name: '👮 Fechado por', value: `<@${closerId}>`, inline: true },
              { name: '📂 Categoria', value: ticket.category.name, inline: true },
              { name: '📝 Motivo', value: reason, inline: false }
            )
            .setColor('#F59E0B')
            .setTimestamp();
          
          await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }
      }
      
      // Deletar canal após 10 segundos
      setTimeout(async () => {
        try {
          await channel.delete('Ticket fechado');
        } catch (e) {}
      }, 10000);
      
    } catch (error) {
      console.error('❌ [Tickets] Erro ao fechar:', error.message);
    }
  }
  
  activeTickets.set(channelId, ticket);
  console.log(`✅ [Tickets] Ticket fechado: #${ticket.number}`);
  
  return { success: true, ticket };
}

/**
 * Adiciona usuário ao ticket
 */
export async function addUserToTicket(guild, channelId, userId) {
  const ticket = activeTickets.get(channelId);
  
  if (!ticket) {
    return { success: false, error: 'Ticket não encontrado' };
  }
  
  const channel = guild.channels.cache.get(channelId);
  if (!channel) {
    return { success: false, error: 'Canal não encontrado' };
  }
  
  try {
    await channel.permissionOverwrites.edit(userId, {
      ViewChannel: true,
      SendMessages: true,
      ReadMessageHistory: true
    });
    
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

/**
 * Remove usuário do ticket
 */
export async function removeUserFromTicket(guild, channelId, userId) {
  const ticket = activeTickets.get(channelId);
  
  if (!ticket) {
    return { success: false, error: 'Ticket não encontrado' };
  }
  
  // Não pode remover o criador
  if (userId === ticket.userId) {
    return { success: false, error: 'Não é possível remover o criador do ticket' };
  }
  
  const channel = guild.channels.cache.get(channelId);
  if (!channel) {
    return { success: false, error: 'Canal não encontrado' };
  }
  
  try {
    await channel.permissionOverwrites.edit(userId, {
      ViewChannel: false
    });
    
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

/**
 * Gera transcript do ticket
 */
async function generateTranscript(channel, ticket) {
  try {
    const messages = await channel.messages.fetch({ limit: 100 });
    
    const lines = messages
      .reverse()
      .map(m => {
        const time = new Date(m.createdTimestamp).toLocaleString('pt-BR');
        const author = m.author.tag;
        const content = m.content || '[Anexo/Embed]';
        return `[${time}] ${author}: ${content}`;
      });
    
    return {
      ticketNumber: ticket.number,
      createdAt: new Date(ticket.createdAt).toLocaleString('pt-BR'),
      closedAt: new Date().toLocaleString('pt-BR'),
      messages: lines.length,
      content: lines.join('\n')
    };
  } catch (error) {
    return null;
  }
}

/**
 * Lista tickets abertos
 */
export function listTickets(guildId) {
  return Array.from(activeTickets.values())
    .filter(t => t.guildId === guildId && t.status === 'open');
}

/**
 * Obtém estatísticas
 */
export function getTicketStats(guildId) {
  const allTickets = Array.from(activeTickets.values())
    .filter(t => t.guildId === guildId);
  
  return {
    total: allTickets.length,
    open: allTickets.filter(t => t.status === 'open').length,
    closed: allTickets.filter(t => t.status === 'closed').length,
    counter: ticketCounters.get(guildId) || 0
  };
}

/**
 * Obtém configurações formatadas
 */
export function getTicketSettings(guildId) {
  const config = getTicketConfig(guildId);
  const stats = getTicketStats(guildId);
  
  return {
    enabled: config.enabled,
    panel: {
      channelId: config.panel.channelId,
      messageId: config.panel.messageId,
      categories: config.panel.categories.length
    },
    settings: {
      category: config.settings.categoryId ? `<#${config.settings.categoryId}>` : 'Não configurado',
      supportRole: config.settings.supportRoleId ? `<@&${config.settings.supportRoleId}>` : 'Não configurado',
      logChannel: config.settings.logChannelId ? `<#${config.settings.logChannelId}>` : 'Não configurado',
      maxPerUser: config.settings.maxPerUser
    },
    stats
  };
}

export default {
  initTicketConfig,
  getTicketConfig,
  setTicketCategory,
  setSupportRole,
  setLogChannel,
  addCategory,
  removeCategory,
  createTicketPanel,
  createTicket,
  getUserTickets,
  getTicket,
  claimTicket,
  closeTicket,
  addUserToTicket,
  removeUserFromTicket,
  listTickets,
  getTicketStats,
  getTicketSettings
};
