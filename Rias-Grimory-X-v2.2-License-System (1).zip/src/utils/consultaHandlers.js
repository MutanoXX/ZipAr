/**
 * Rias-Grimory-X - Handlers de Consulta CPF/CNPJ
 * VERSÃO 5.1 - Mostra TODAS as informações da API
 */

// ============================================
// HANDLER CNPJ - MOSTRA TODOS OS DADOS
// ============================================

async function handleCNPJ(message, response, thinkingMsg) {
  const cnpj = response.cnpj || response.value || response.cnpj_number;
  if (!cnpj) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'CNPJ não informado!', '#EF4444');
  }
  
  const result = await apiService.consultaCNPJ(cnpj);
  
  console.log(`📋 [CNPJ] Resultado recebido:`, JSON.stringify(result, null, 2).substring(0, 1000));
  
  // Verificar se tem dados
  if (!result || result.status === 'error') {
    return await editEmbed(thinkingMsg, '❌ Erro', result?.error || 'CNPJ não encontrado', '#EF4444');
  }
  
  // Pegar os dados de qualquer lugar que estejam
  const data = result.data || result.parsed || result.resultado || result;
  
  // Criar embed
  const embed = new EmbedBuilder()
    .setTitle('📋 Consulta CNPJ')
    .setColor('#10B981')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  // Description com nome da empresa
  const razaoSocial = data.razao_social || data['RAZÃO SOCIAL'] || data.nome_empresarial || data.nome || result.razao_social;
  if (razaoSocial) {
    embed.setDescription(`**${razaoSocial}**`);
  }
  
  // Coletar TODOS os campos possíveis
  const fields = [];
  
  // Função para adicionar campo se tiver valor
  const addField = (label, value, inline = false) => {
    if (value && value !== 'null' && value !== '' && value !== 'undefined') {
      const strValue = String(value).substring(0, 300);
      fields.push({ name: label, value: strValue, inline });
    }
  };
  
  // Campos do CNPJ - tenta várias variações de nomes
  addField('📝 Razão Social', data.razao_social || data['RAZÃO SOCIAL'] || data.nome_empresarial);
  addField('🏪 Nome Fantasia', data.nome_fantasia || data['NOME FANTASIA'] || data.fantasia);
  addField('🔢 CNPJ', data.cnpj || data['CNPJ'] || cnpj, true);
  addField('📊 Situação', data.situacao || data['SITUAÇÃO'] || data.situacao_cadastral, true);
  addField('📅 Data Situação', data.data_situacao || data['DATA SITUAÇÃO']);
  addField('🏢 Tipo', data.tipo || data['TIPO'] || data.tipo_empresa, true);
  addField('📏 Porte', data.porte || data['PORTE'], true);
  addField('📜 Natureza Jurídica', data.natureza_juridica || data['NATUREZA JURÍDICA']);
  addField('📆 Abertura', data.abertura || data['ABERTURA'] || data.data_abertura, true);
  addField('💰 Capital Social', data.capital_social || data['CAPITAL SOCIAL'], true);
  
  // Atividades
  if (data.atividade_principal) {
    if (Array.isArray(data.atividade_principal)) {
      addField('🎯 Atividade Principal', data.atividade_principal.map(a => a.text || a).join('\n'));
    } else {
      addField('🎯 Atividade Principal', data.atividade_principal?.text || data.atividade_principal);
    }
  }
  addField('🎯 Atividade Principal', data['ATIVIDADE PRINCIPAL'] || data.cnae_principal);
  
  if (data.atividades_secundarias && data.atividades_secundarias.length > 0) {
    addField('📋 Atividades Secundárias', data.atividades_secundarias.map(a => a.text || a).join('\n'));
  }
  
  // Endereço
  addField('📍 Logradouro', data.logradouro || data['LOGRADOURO'] || data.endereco);
  addField('🔢 Número', data.numero || data['NUMERO'], true);
  addField('🏠 Complemento', data.complemento || data['COMPLEMENTO']);
  addField('🏘️ Bairro', data.bairro || data['BAIRRO'], true);
  addField('🏙️ Município', data.municipio || data['MUNICÍPIO'] || data.cidade, true);
  addField('🗺️ UF', data.uf || data['UF'], true);
  addField('📮 CEP', data.cep || data['CEP'], true);
  
  // Contato
  addField('📧 Email', data.email || data['EMAIL']);
  addField('📞 Telefone', data.telefone || data['TELEFONE']);
  
  // QSA - Quadro de Sócios
  if (data.qsa && data.qsa.length > 0) {
    const qsaText = data.qsa.map(s => `${s.nome} (${s.qual || s.qualificacao || 'Sócio'})`).join('\n');
    addField('👥 Quadro de Sócios', qsaText.substring(0, 500));
  }
  
  // Outros campos
  addField('📅 Última Atualização', data.ultima_atualizacao || data['ÚLTIMA ATUALIZAÇÃO']);
  addField('🏛️ Situação Especial', data.situacao_especial);
  addField('📅 Data Situação Especial', data.data_situacao_especial);
  
  // Se não encontrou nada, mostrar o que a API retornou
  if (fields.length === 0) {
    // Mostrar todos os dados brutos
    const allData = JSON.stringify(data, null, 2);
    if (allData && allData !== '{}') {
      fields.push({ 
        name: '📋 Dados Retornados', 
        value: `\`\`\`json\n${allData.substring(0, 1000)}\n\`\`\``, 
        inline: false 
      });
    }
  }
  
  embed.addFields(fields.slice(0, 25));
  
  await editEmbed(thinkingMsg, embed);
}

// ============================================
// HANDLER CPF - MOSTRA TODOS OS DADOS
// ============================================

async function handleCPF(message, response, thinkingMsg) {
  const cpf = response.cpf || response.value;
  if (!cpf) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'CPF não informado!', '#EF4444');
  }
  
  const result = await apiService.consultaCPF(cpf);
  
  console.log(`📋 [CPF] Resultado recebido:`, JSON.stringify(result, null, 2).substring(0, 1000));
  
  // Verificar se tem dados
  if (!result || result.status === 'error') {
    return await editEmbed(thinkingMsg, '❌ Erro', result?.error || 'CPF não encontrado', '#EF4444');
  }
  
  // Pegar os dados de qualquer lugar que estejam
  const data = result.data || result.parsed || result.resultado || result;
  
  // Criar embed
  const embed = new EmbedBuilder()
    .setTitle('👤 Consulta CPF')
    .setColor('#10B981')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  // Description com nome
  const nome = result.nome || data.nome || data.NOME || data.name;
  if (nome) {
    embed.setDescription(`**${nome}**`);
  }
  
  // Coletar TODOS os campos possíveis
  const fields = [];
  
  // Função para adicionar campo se tiver valor
  const addField = (label, value, inline = false) => {
    if (value && value !== 'null' && value !== '' && value !== 'undefined') {
      const strValue = String(value).substring(0, 300);
      fields.push({ name: label, value: strValue, inline });
    }
  };
  
  // Campos do CPF - tenta várias variações de nomes
  addField('📝 Nome', result.nome || data.nome || data.NOME || data.name);
  addField('🔢 CPF', data.cpf || data.CPF || cpf, true);
  addField('📅 Nascimento', result.data_nascimento || data.data_nascimento || data.NASCIMENTO || data['DATA DE NASCIMENTO'] || data.birth_date, true);
  addField('🎂 Idade', data.idade || data.IDADE || data.age, true);
  addField('♊ Signo', data.signo || data.SIGNO, true);
  addField('⚧ Sexo', data.sexo || data.SEXO || data.gender, true);
  
  // Filiação
  addField('👩 Nome da Mãe', result.nome_mae || data.nome_mae || data['NOME DA MÃE'] || data.MAE || data.mother_name);
  addField('👨 Nome do Pai', data.nome_pai || data['NOME DO PAI'] || data.PAI || data.father_name);
  
  // Documentos
  addField('🪪 RG', data.rg || data.RG, true);
  addField('🏛️ Órgão Emissor', data.orgao_emissor || data['ÓRGÃO EMISSOR'], true);
  addField('📅 Emissão RG', data.data_emissao_rg || data['DATA EMISSÃO RG']);
  
  // Status civil e outros
  addField('💑 Estado Civil', data.estado_civil || data['ESTADO CIVIL'], true);
  addField('🎓 Escolaridade', data.escolaridade || data.ESCOLARIDADE, true);
  addField('💼 Profissão', data.profissao || data.PROFISSAO || data.ocupacao);
  
  // Renda
  addField('💰 Renda', data.renda || data.RENDA, true);
  addField('📈 Renda Presumida', data.renda_presumida || data['RENDA PRESUMIDA'], true);
  
  // Endereço
  addField('📍 Logradouro', data.logradouro || data.LOGRADOURO || data.endereco || data.address);
  addField('🔢 Número', data.numero || data.NUMERO, true);
  addField('🏠 Complemento', data.complemento || data.COMPLEMENTO);
  addField('🏘️ Bairro', data.bairro || data.BAIRRO, true);
  addField('🏙️ Cidade', data.cidade || data.municipio || data.CIDADE || data.MUNICÍPIO, true);
  addField('🗺️ UF', data.uf || data.UF || data.state, true);
  addField('📮 CEP', data.cep || data.CEP, true);
  
  // Contato
  addField('📧 Email', data.email || data.EMAIL);
  addField('📞 Telefone', data.telefone || data.TELEFONE || data.celular);
  
  // Status
  addField('✅ Situação Cadastral', data.situacao_cadastral || data['SITUAÇÃO CADASTRAL'] || data.status_cpf);
  addField('📅 Última Atualização', data.ultima_atualizacao || data['ÚLTIMA ATUALIZAÇÃO']);
  
  // Score (se disponível)
  addField('📊 Score', data.score || data.SCORE || data.pontuacao);
  addField('🔒 Situação', data.situacao || data.SITUAÇÃO);
  
  // Se não encontrou nada, mostrar o que a API retornou
  if (fields.length === 0) {
    // Mostrar todos os dados brutos
    const allData = JSON.stringify(data, null, 2);
    if (allData && allData !== '{}') {
      fields.push({ 
        name: '📋 Dados Retornados', 
        value: `\`\`\`json\n${allData.substring(0, 1000)}\n\`\`\``, 
        inline: false 
      });
    }
  }
  
  embed.addFields(fields.slice(0, 25));
  
  await editEmbed(thinkingMsg, embed);
}

export { handleCNPJ, handleCPF };
