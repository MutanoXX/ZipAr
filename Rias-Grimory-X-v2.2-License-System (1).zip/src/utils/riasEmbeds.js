/**
 * Rias-Grimory-X - Sistema de Embeds Avançados
 * VERSÃO: 1.0 - Embeds Ultra Customizados
 * 
 * Recursos do Discord.js 14 usados:
 * - setAuthor (com ícone)
 * - setThumbnail
 * - setImage
 * - addFields (inline e normal)
 * - setURL (links clicáveis)
 * - formatação Markdown (bold, italic, code, etc)
 * - Separators com campos vazios
 * - Colors customizadas por contexto
 * - Timestamps dinâmicos
 */

import { EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } from 'discord.js';
import { getRiasImage, getEmotionByAction } from './riasImages.js';

// ══════════════════════════════════════════════════════════════
// 🎨 CORES DO TEMA RIAS
// ══════════════════════════════════════════════════════════════

export const RIAS_COLORS = {
  // Cores principais
  primary: 0x8B5CF6,      // Roxo vibrante
  success: 0x10B981,      // Verde esmeralda
  error: 0xEF4444,        // Vermelho
  warning: 0xF59E0B,      // Amarelo âmbar
  info: 0x3B82F6,         // Azul
  
  // Cores temáticas Rias
  crimson: 0xDC143C,      // Carmesim (Rias)
  darkRed: 0x8B0000,      // Vermelho escuro
  rose: 0xE11D48,         // Rosa
  purple: 0x7C3AED,       // Roxo
  violet: 0x8B5CF6,       // Violeta
  
  // Por tipo de ação
  creation: 0x10B981,
  deletion: 0xEF4444,
  edit: 0x3B82F6,
  moderation: 0xF59E0B,
  media: 0xEC4899,
  automation: 0x8B5CF6,
  info: 0x06B6D4,
  
  // Especiais
  love: 0xFF69B4,
  power: 0xFF4500,
  magic: 0x9400D3
};

// ══════════════════════════════════════════════════════════════
// 🌹 BUILDER DE EMBED AVANÇADO
// ══════════════════════════════════════════════════════════════

/**
 * Cria um embed ultra customizado com tema Rias
 */
export class RiasEmbed {
  constructor(options = {}) {
    this.embed = new EmbedBuilder();
    this.actionType = options.actionType || 'default';
    this.emotion = options.emotion || getEmotionByAction(this.actionType);
    this.showThumbnail = options.showThumbnail !== false;
    this.showAuthor = options.showAuthor !== false;
    this.showFooter = options.showFooter !== false;
    this.color = options.color || this.getColorByAction();
  }
  
  /**
   * Define a cor baseada no tipo de ação
   */
  getColorByAction() {
    const colorMap = {
      criar_: RIAS_COLORS.creation,
      deletar_: RIAS_COLORS.deletion,
      editar_: RIAS_COLORS.edit,
      banir: RIAS_COLORS.moderation,
      expulsar: RIAS_COLORS.moderation,
      mutar: RIAS_COLORS.moderation,
      google_image: RIAS_COLORS.media,
      dalle: RIAS_COLORS.media,
      automacao: RIAS_COLORS.automation,
      info_: RIAS_COLORS.info,
      listar_: RIAS_COLORS.info,
      message: RIAS_COLORS.love
    };
    
    for (const [key, color] of Object.entries(colorMap)) {
      if (this.actionType.toLowerCase().includes(key)) {
        return color;
      }
    }
    return RIAS_COLORS.primary;
  }
  
  /**
   * Define título com emoji automático
   */
  setTitle(title, emoji = null) {
    const emojiMap = {
      criar_: '✨',
      deletar_: '🗑️',
      editar_: '✏️',
      banir: '🔨',
      expulsar: '👢',
      mutar: '🔇',
      desmutar: '🔊',
      sucesso: '✅',
      erro: '❌',
      info: '📋',
      imagem: '🖼️',
      automacao: '🤖',
      warning: '⚠️'
    };
    
    let autoEmoji = emoji;
    if (!autoEmoji) {
      for (const [key, e] of Object.entries(emojiMap)) {
        if (this.actionType.toLowerCase().includes(key)) {
          autoEmoji = e;
          break;
        }
      }
    }
    
    this.embed.setTitle(autoEmoji ? `${autoEmoji} ${title}` : title);
    this.embed.setColor(this.color);
    return this;
  }
  
  /**
   * Define descrição com formatação
   */
  setDescription(text) {
    this.embed.setDescription(text);
    return this;
  }
  
  /**
   * Adiciona campo com formatação
   */
  addField(name, value, inline = false) {
    this.embed.addFields({ name, value: String(value), inline });
    return this;
  }
  
  /**
   * Adiciona múltiplos campos
   */
  addFields(fields) {
    this.embed.addFields(fields);
    return this;
  }
  
  /**
   * Adiciona separador visual
   */
  addSeparator() {
    this.embed.addFields({ 
      name: '\u200B', 
      value: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 
      inline: false 
    });
    return this;
  }
  
  /**
   * Adiciona seção com título
   */
  addSection(title, content) {
    this.addSeparator();
    this.addField(`━━ ${title} ━━`, content, false);
    return this;
  }
  
  /**
   * Define imagem grande
   */
  setImage(url) {
    if (url) this.embed.setImage(url);
    return this;
  }
  
  /**
   * Define thumbnail (miniatura)
   */
  setThumbnail(url) {
    if (url) this.embed.setThumbnail(url);
    return this;
  }
  
  /**
   * Define autor com ícone
   */
  setAuthor(name, iconURL = null, url = null) {
    this.embed.setAuthor({ 
      name, 
      iconURL: iconURL || 'https://i.imgur.com/eEsH9NF.jpeg',
      url
    });
    return this;
  }
  
  /**
   * Define footer com ícone
   */
  setFooter(text, iconURL = null) {
    this.embed.setFooter({ 
      text: text || '💎 Rias-Grimory-X', 
      iconURL: iconURL || 'https://i.imgur.com/eEsH9NF.jpeg'
    });
    return this;
  }
  
  /**
   * Define URL clicável no título
   */
  setURL(url) {
    if (url) this.embed.setURL(url);
    return this;
  }
  
  /**
   * Define cor
   */
  setColor(color) {
    this.embed.setColor(color);
    return this;
  }
  
  /**
   * Define timestamp
   */
  setTimestamp(time = null) {
    this.embed.setTimestamp(time || new Date());
    return this;
  }
  
  /**
   * Finaliza e retorna o embed pronto
   */
  async build() {
    // Adicionar thumbnail da Rias automaticamente
    if (this.showThumbnail) {
      try {
        const thumbnailUrl = await getRiasImage(this.emotion);
        this.embed.setThumbnail(thumbnailUrl);
      } catch (e) {
        // Fallback silencioso
      }
    }
    
    // Adicionar footer padrão se não definido
    if (this.showFooter) {
      this.embed.setFooter({ 
        text: '🌹 Rias Gremory • Power of Destruction', 
        iconURL: 'https://i.imgur.com/eEsH9NF.jpeg'
      });
    }
    
    // Timestamp
    this.embed.setTimestamp();
    
    return this.embed;
  }
  
  /**
   * Retorna o embed sem await (para casos simples)
   */
  buildSync() {
    return this.embed;
  }
}

// ══════════════════════════════════════════════════════════════
// 🎯 FUNÇÕES HELPER PARA EMBEDS COMUNS
// ══════════════════════════════════════════════════════════════

/**
 * Cria embed de sucesso
 */
export async function createSuccessEmbed(title, description, fields = []) {
  const embed = new RiasEmbed({ actionType: 'sucesso' })
    .setTitle(title)
    .setDescription(description)
    .setColor(RIAS_COLORS.success);
  
  if (fields.length > 0) {
    embed.addFields(fields);
  }
  
  return await embed.build();
}

/**
 * Cria embed de erro
 */
export async function createErrorEmbed(title, description) {
  const embed = new RiasEmbed({ actionType: 'erro', emotion: 'desapontada' })
    .setTitle(title)
    .setDescription(description)
    .setColor(RIAS_COLORS.error);
  
  return await embed.build();
}

/**
 * Cria embed de informação
 */
export async function createInfoEmbed(title, description, fields = []) {
  const embed = new RiasEmbed({ actionType: 'info' })
    .setTitle(title)
    .setDescription(description)
    .setColor(RIAS_COLORS.info);
  
  if (fields.length > 0) {
    embed.addFields(fields);
  }
  
  return await embed.build();
}

/**
 * Cria embed de automação rodando
 */
export async function createAutomationEmbed(config) {
  const embed = new RiasEmbed({ actionType: 'automacao', emotion: 'animada' })
    .setTitle(config.title || 'Automação Executada')
    .setDescription(config.description || '')
    .setColor(RIAS_COLORS.automation);
  
  if (config.image) embed.setImage(config.image);
  if (config.fields) embed.addFields(config.fields);
  if (config.thumbnail) embed.setThumbnail(config.thumbnail);
  
  return await embed.build();
}

/**
 * Cria embed com imagem da Rias
 */
export async function createRiasImageEmbed(imageUrl, caption = '') {
  const embed = new RiasEmbed({ actionType: 'google_image', emotion: 'amor' })
    .setTitle('🖼️ Aqui está, amor!')
    .setDescription(caption || 'Imagem encontrada para você! 🌹')
    .setImage(imageUrl)
    .setColor(RIAS_COLORS.crimson);
  
  return await embed.build();
}

/**
 * Cria embed de lista formatada
 */
export async function createListEmbed(title, items, options = {}) {
  const embed = new RiasEmbed({ actionType: 'listar' })
    .setTitle(title)
    .setColor(RIAS_COLORS.info);
  
  // Adicionar items como campos ou descrição
  if (items.length <= 10) {
    items.forEach((item, i) => {
      embed.addField(
        item.name || `Item ${i + 1}`, 
        item.value || item, 
        item.inline !== false
      );
    });
  } else {
    // Muitos itens: usar descrição
    const listText = items.map((item, i) => {
      const name = item.name || item;
      const value = item.value || '';
      return `**${i + 1}.** ${name}${value ? ` - ${value}` : ''}`;
    }).join('\n');
    
    embed.setDescription(listText.substring(0, 4000));
  }
  
  // Adicionar contador
  if (options.showCount !== false) {
    embed.addSeparator();
    embed.addField('📊 Total', `${items.length} itens`, true);
  }
  
  return await embed.build();
}

/**
 * Cria embed com botões de ação
 */
export function createEmbedWithButtons(embed, buttons) {
  const row = new ActionRowBuilder();
  
  buttons.forEach(btn => {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(btn.customId || btn.id)
        .setLabel(btn.label || btn.text)
        .setStyle(btn.style || ButtonStyle.Primary)
        .setEmoji(btn.emoji || null)
    );
  });
  
  return { embeds: [embed], components: [row] };
}

/**
 * Adiciona barra de progresso visual
 */
export function createProgressBar(current, total, length = 10) {
  const percent = Math.min(current / total, 1);
  const filled = Math.round(length * percent);
  const empty = length - filled;
  
  const bar = '█'.repeat(filled) + '░'.repeat(empty);
  const percentText = `${Math.round(percent * 100)}%`;
  
  return `${bar} ${percentText}`;
}

/**
 * Formata número com separador de milhar
 */
export function formatNumber(num) {
  return num.toLocaleString('pt-BR');
}

/**
 * Formata data para exibição
 */
export function formatDate(date) {
  const d = new Date(date);
  return `<t:${Math.floor(d.getTime() / 1000)}:d>`;
}

/**
 * Formata data e hora
 */
export function formatDateTime(date) {
  const d = new Date(date);
  return `<t:${Math.floor(d.getTime() / 1000)}:F>`;
}

/**
 * Formata tempo relativo
 */
export function formatRelativeTime(date) {
  const d = new Date(date);
  return `<t:${Math.floor(d.getTime() / 1000)}:R>`;
}

// ══════════════════════════════════════════════════════════════
// 📤 EXPORTAÇÕES
// ══════════════════════════════════════════════════════════════

export default {
  RiasEmbed,
  RIAS_COLORS,
  createSuccessEmbed,
  createErrorEmbed,
  createInfoEmbed,
  createAutomationEmbed,
  createRiasImageEmbed,
  createListEmbed,
  createEmbedWithButtons,
  createProgressBar,
  formatNumber,
  formatDate,
  formatDateTime,
  formatRelativeTime
};
