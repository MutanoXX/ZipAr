/**
 * Rias-Grimory-X - Sistema de Logs
 * Registra todas as ações importantes do servidor
 */

import { EmbedBuilder } from 'discord.js';

// Armazenamento de configurações de logs por servidor
const logsConfigs = new Map();

// Buffer de logs para exportação
const logsBuffer = new Map();

// Eventos disponíveis para log
const LOG_EVENTS = {
  // Mensagens
  message_delete: { emoji: '🗑️', name: 'Mensagem Deletada', color: '#EF4444' },
  message_edit: { emoji: '✏️', name: 'Mensagem Editada', color: '#F59E0B' },
  message_bulk_delete: { emoji: '🧹', name: 'Mensagens Apagadas em Massa', color: '#EF4444' },
  
  // Membros
  member_join: { emoji: '👋', name: 'Membro Entrou', color: '#10B981' },
  member_leave: { emoji: '🚪', name: 'Membro Saiu', color: '#F59E0B' },
  member_kick: { emoji: '👢', name: 'Membro Expulso', color: '#EF4444' },
  member_ban: { emoji: '🔨', name: 'Membro Banido', color: '#EF4444' },
  member_unban: { emoji: '✅', name: 'Membro Desbanido', color: '#10B981' },
  member_update: { emoji: '📝', name: 'Membro Atualizado', color: '#8B5CF6' },
  nickname_change: { emoji: '🏷️', name: 'Apelido Alterado', color: '#3B82F6' },
  role_add: { emoji: '➕', name: 'Cargo Adicionado', color: '#10B981' },
  role_remove: { emoji: '➖', name: 'Cargo Removido', color: '#EF4444' },
  
  // Canais
  channel_create: { emoji: '📝', name: 'Canal Criado', color: '#10B981' },
  channel_delete: { emoji: '🗑️', name: 'Canal Deletado', color: '#EF4444' },
  channel_update: { emoji: '✏️', name: 'Canal Atualizado', color: '#F59E0B' },
  
  // Cargos
  role_create: { emoji: '🎭', name: 'Cargo Criado', color: '#10B981' },
  role_delete: { emoji: '🗑️', name: 'Cargo Deletado', color: '#EF4444' },
  role_update: { emoji: '✏️', name: 'Cargo Atualizado', color: '#F59E0B' },
  
  // Voz
  voice_join: { emoji: '🔊', name: 'Entrou em Voz', color: '#10B981' },
  voice_leave: { emoji: '🔇', name: 'Saiu de Voz', color: '#F59E0B' },
  voice_move: { emoji: '🔀', name: 'Moveu de Canal', color: '#8B5CF6' },
  voice_mute: { emoji: '🙊', name: 'Mutado em Voz', color: '#EF4444' },
  voice_deafen: { emoji: '🙉', name: 'Ensanguentado', color: '#EF4444' },
  
  // Servidor
  guild_update: { emoji: '⚙️', name: 'Servidor Atualizado', color: '#8B5CF6' },
  emoji_create: { emoji: '😀', name: 'Emoji Criado', color: '#10B981' },
  emoji_delete: { emoji: '🗑️', name: 'Emoji Deletado', color: '#EF4444' },
  sticker_create: { emoji: '🎨', name: 'Sticker Criado', color: '#10B981' },
  sticker_delete: { emoji: '🗑️', name: 'Sticker Deletado', color: '#EF4444' },
  
  // Convites
  invite_create: { emoji: '📨', name: 'Convite Criado', color: '#10B981' },
  invite_delete: { emoji: '🗑️', name: 'Convite Deletado', color: '#EF4444' },
  
  // Moderação
  timeout: { emoji: '⏰', name: 'Timeout Aplicado', color: '#F59E0B' },
  timeout_remove: { emoji: '⏱️', name: 'Timeout Removido', color: '#10B981' },
  warning: { emoji: '⚠️', name: 'Advertência', color: '#F59E0B' },
  
  // Automod
  automod_action: { emoji: '🛡️', name: 'Ação Automática', color: '#8B5CF6' }
};

// Configuração padrão
const DEFAULT_LOG_CONFIG = {
  enabled: true,
  channelId: null,
  events: ['message_delete', 'message_edit', 'member_join', 'member_leave', 'member_kick', 'member_ban', 'role_add', 'role_remove'],
  ignoredChannels: [],
  ignoredRoles: [],
  embedStyle: {
    showTimestamp: true,
    showFooter: true,
    compactMode: false
  }
};

/**
 * Inicializa configuração de logs para um servidor
 */
export function initLogsConfig(guildId) {
  if (!logsConfigs.has(guildId)) {
    logsConfigs.set(guildId, { ...DEFAULT_LOG_CONFIG, guildId });
    console.log(`📝 [Logs] Configuração inicializada para: ${guildId}`);
  }
  return logsConfigs.get(guildId);
}

/**
 * Obtém configuração de logs
 */
export function getLogsConfig(guildId) {
  return logsConfigs.get(guildId) || initLogsConfig(guildId);
}

/**
 * Configura canal de logs
 */
export function setLogsChannel(guildId, channelId, events = null) {
  const config = getLogsConfig(guildId);
  
  config.enabled = true;
  config.channelId = channelId;
  
  if (events && Array.isArray(events)) {
    config.events = events;
  }
  
  logsConfigs.set(guildId, config);
  console.log(`✅ [Logs] Canal configurado: ${channelId}`);
  return config;
}

/**
 * Atualiza eventos de log
 */
export function updateLogEvents(guildId, events) {
  const config = getLogsConfig(guildId);
  config.events = events;
  logsConfigs.set(guildId, config);
  return config;
}

/**
 * Adiciona evento para monitorar
 */
export function addLogEvent(guildId, event) {
  const config = getLogsConfig(guildId);
  if (!config.events.includes(event)) {
    config.events.push(event);
    logsConfigs.set(guildId, config);
  }
  return config;
}

/**
 * Remove evento do monitoramento
 */
export function removeLogEvent(guildId, event) {
  const config = getLogsConfig(guildId);
  config.events = config.events.filter(e => e !== event);
  logsConfigs.set(guildId, config);
  return config;
}

/**
 * Desativa logs
 */
export function disableLogs(guildId) {
  const config = getLogsConfig(guildId);
  config.enabled = false;
  logsConfigs.set(guildId, config);
  return config;
}

/**
 * Verifica se evento deve ser logado
 */
export function shouldLog(guildId, event) {
  const config = getLogsConfig(guildId);
  return config.enabled && config.channelId && config.events.includes(event);
}

/**
 * Adiciona canal à lista de ignorados
 */
export function addIgnoredChannel(guildId, channelId) {
  const config = getLogsConfig(guildId);
  if (!config.ignoredChannels.includes(channelId)) {
    config.ignoredChannels.push(channelId);
    logsConfigs.set(guildId, config);
  }
  return config;
}

/**
 * Registra um log
 */
export async function logEvent(guild, event, data) {
  const config = getLogsConfig(guild.id);
  
  if (!config.enabled || !config.channelId) return false;
  if (!config.events.includes(event)) return false;
  
  // Ignorar canais específicos
  if (data.channelId && config.ignoredChannels.includes(data.channelId)) {
    return false;
  }
  
  const channel = guild.channels.cache.get(config.channelId);
  if (!channel) return false;
  
  const eventInfo = LOG_EVENTS[event] || { emoji: '📋', name: event, color: '#8B5CF6' };
  
  // Adicionar ao buffer
  addToBuffer(guild.id, event, data);
  
  // Criar embed do log
  const embed = createLogEmbed(event, eventInfo, data);
  
  try {
    await channel.send({ embeds: [embed] });
    return true;
  } catch (error) {
    console.error('❌ [Logs] Erro ao enviar log:', error.message);
    return false;
  }
}

/**
 * Cria embed do log
 */
function createLogEmbed(event, eventInfo, data) {
  const embed = new EmbedBuilder()
    .setTitle(`${eventInfo.emoji} ${eventInfo.name}`)
    .setColor(eventInfo.color)
    .setTimestamp();
  
  // Adicionar campos baseado no tipo de evento
  switch (event) {
    case 'message_delete':
      if (data.author) {
        embed.addFields(
          { name: '👤 Autor', value: `<@${data.author.id}> (${data.author.tag})`, inline: true },
          { name: '📍 Canal', value: `<#${data.channelId}>`, inline: true }
        );
        if (data.content) {
          embed.addFields({ name: '💬 Conteúdo', value: data.content.substring(0, 1024) || '*Vazio*' });
        }
        if (data.attachments?.length > 0) {
          embed.addFields({ name: '📎 Anexos', value: `${data.attachments.length} anexo(s)` });
        }
      }
      break;
      
    case 'message_edit':
      if (data.author) {
        embed.addFields(
          { name: '👤 Autor', value: `<@${data.author.id}>`, inline: true },
          { name: '📍 Canal', value: `<#${data.channelId}>`, inline: true }
        );
        if (data.oldContent) {
          embed.addFields({ name: '📝 Antes', value: data.oldContent.substring(0, 500) || '*Vazio*' });
        }
        if (data.newContent) {
          embed.addFields({ name: '📝 Depois', value: data.newContent.substring(0, 500) || '*Vazio*' });
        }
      }
      break;
      
    case 'member_join':
      embed.addFields(
        { name: '👤 Usuário', value: `<@${data.userId}>`, inline: true },
        { name: '🆔 ID', value: data.userId, inline: true },
        { name: '📅 Conta criada', value: `<t:${Math.floor(data.createdAt / 1000)}:R>`, inline: true }
      );
      break;
      
    case 'member_leave':
      embed.addFields(
        { name: '👤 Usuário', value: `${data.userTag}`, inline: true },
        { name: '🆔 ID', value: data.userId, inline: true },
        { name: '📅 Estadia', value: data.joinedAt ? `<t:${Math.floor(data.joinedAt / 1000)}:R>` : 'N/A', inline: true }
      );
      break;
      
    case 'member_kick':
    case 'member_ban':
      embed.addFields(
        { name: '👤 Usuário', value: `${data.userTag}`, inline: true },
        { name: '🆔 ID', value: data.userId, inline: true },
        { name: '👮 Moderador', value: data.moderator ? `<@${data.moderator}>` : 'Desconhecido', inline: true }
      );
      if (data.reason) {
        embed.addFields({ name: '📝 Motivo', value: data.reason });
      }
      break;
      
    case 'role_add':
    case 'role_remove':
      embed.addFields(
        { name: '👤 Usuário', value: `<@${data.userId}>`, inline: true },
        { name: '🎭 Cargo', value: `<@&${data.roleId}>`, inline: true },
        { name: '👮 Por', value: data.moderator ? `<@${data.moderator}>` : 'Sistema', inline: true }
      );
      break;
      
    case 'channel_create':
    case 'channel_delete':
      embed.addFields(
        { name: '📝 Canal', value: data.channelName, inline: true },
        { name: '📁 Tipo', value: data.channelType || 'Texto', inline: true }
      );
      break;
      
    case 'voice_join':
    case 'voice_leave':
      embed.addFields(
        { name: '👤 Usuário', value: `<@${data.userId}>`, inline: true },
        { name: '🔊 Canal', value: data.channelName, inline: true }
      );
      break;
      
    case 'voice_move':
      embed.addFields(
        { name: '👤 Usuário', value: `<@${data.userId}>`, inline: true },
        { name: '📤 De', value: data.oldChannel, inline: true },
        { name: '📥 Para', value: data.newChannel, inline: true }
      );
      break;
      
    case 'warning':
      embed.addFields(
        { name: '👤 Usuário', value: `<@${data.userId}>`, inline: true },
        { name: '👮 Moderador', value: `<@${data.moderator}>`, inline: true },
        { name: '🔢 Total', value: `${data.totalWarnings}`, inline: true }
      );
      if (data.reason) {
        embed.addFields({ name: '📝 Motivo', value: data.reason });
      }
      break;
      
    case 'automod_action':
      embed.addFields(
        { name: '👤 Usuário', value: `<@${data.userId}>`, inline: true },
        { name: '🛡️ Violação', value: data.violation, inline: true },
        { name: '⚖️ Punição', value: data.punishment, inline: true }
      );
      break;
      
    default:
      // Log genérico
      if (data.description) {
        embed.setDescription(data.description);
      }
  }
  
  return embed;
}

/**
 * Adiciona log ao buffer
 */
function addToBuffer(guildId, event, data) {
  if (!logsBuffer.has(guildId)) {
    logsBuffer.set(guildId, []);
  }
  
  const buffer = logsBuffer.get(guildId);
  buffer.push({
    event,
    data,
    timestamp: Date.now()
  });
  
  // Manter apenas últimos 1000 logs
  if (buffer.length > 1000) {
    buffer.shift();
  }
  
  logsBuffer.set(guildId, buffer);
}

/**
 * Obtém logs do buffer
 */
export function getLogs(guildId, limit = 50, eventFilter = null) {
  const buffer = logsBuffer.get(guildId) || [];
  
  let logs = buffer;
  if (eventFilter) {
    logs = logs.filter(l => l.event === eventFilter);
  }
  
  return logs.slice(-limit);
}

/**
 * Exporta logs para texto
 */
export function exportLogs(guildId, period = 7) {
  const buffer = logsBuffer.get(guildId) || [];
  const cutoff = Date.now() - (period * 24 * 60 * 60 * 1000);
  
  const logs = buffer.filter(l => l.timestamp > cutoff);
  
  if (logs.length === 0) {
    return 'Nenhum log encontrado no período.';
  }
  
  const lines = logs.map(l => {
    const date = new Date(l.timestamp).toISOString();
    const eventInfo = LOG_EVENTS[l.event] || { name: l.event };
    return `[${date}] ${eventInfo.name}: ${JSON.stringify(l.data)}`;
  });
  
  return lines.join('\n');
}

/**
 * Limpa logs antigos
 */
export function clearOldLogs(guildId, days = 30) {
  const buffer = logsBuffer.get(guildId) || [];
  const cutoff = Date.now() - (days * 24 * 60 * 60 * 1000);
  
  const filtered = buffer.filter(l => l.timestamp > cutoff);
  logsBuffer.set(guildId, filtered);
  
  return buffer.length - filtered.length;
}

/**
 * Obtém lista de eventos disponíveis
 */
export function getAvailableEvents() {
  return Object.entries(LOG_EVENTS).map(([key, value]) => ({
    key,
    name: value.name,
    emoji: value.emoji
  }));
}

/**
 * Obtém configuração formatada para exibição
 */
export function getLogsSettings(guildId) {
  const config = getLogsConfig(guildId);
  const events = getAvailableEvents();
  
  return {
    enabled: config.enabled,
    channelId: config.channelId,
    channelMention: config.channelId ? `<#${config.channelId}>` : 'Não configurado',
    activeEvents: config.events.map(e => LOG_EVENTS[e]?.name || e),
    availableEvents: events,
    ignoredChannels: config.ignoredChannels.length,
    ignoredRoles: config.ignoredRoles.length
  };
}

export default {
  initLogsConfig,
  getLogsConfig,
  setLogsChannel,
  updateLogEvents,
  addLogEvent,
  removeLogEvent,
  disableLogs,
  shouldLog,
  addIgnoredChannel,
  logEvent,
  getLogs,
  exportLogs,
  clearOldLogs,
  getAvailableEvents,
  getLogsSettings,
  LOG_EVENTS
};
