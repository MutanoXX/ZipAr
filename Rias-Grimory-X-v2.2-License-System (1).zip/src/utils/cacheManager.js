/**
 * MutanoX Architect - Gerenciador de Cache Seguro
 * Resolve problemas de permissão EACCES ao criar/acessar diretórios de cache
 * 
 * @description Sistema de cache seguro com fallback para diretório temporário
 * @version 2.0.0
 * @author MutanoX Team
 * 
 * PROBLEMA RESOLVIDO:
 * - RateLimit persist: EACCES: permission denied, open '.cache/ratelimits.json'
 * - EACCES: permission denied, mkdir '.cache/files'
 * 
 * SOLUÇÃO:
 * - Usa diretório temporário do sistema (/tmp) como fallback
 * - Cria diretórios de forma segura com tratamento de erros
 * - Fornece caminhos absolutos para evitar problemas de permissão
 */

// ============================================
// IMPORTS
// ============================================
import fs from 'fs';
import path from 'path';
import os from 'os';

// ============================================
// CONSTANTES
// ============================================

/** Diretório base para cache */
const CACHE_BASE_DIR = process.env.CACHE_DIR || path.join(os.tmpdir(), 'mutanox-cache');

/** Diretório de arquivos */
const FILES_DIR = path.join(CACHE_BASE_DIR, 'files');

/** Arquivo de rate limits */
const RATELIMIT_FILE = path.join(CACHE_BASE_DIR, 'ratelimits.json');

/** Permissões padrão para diretórios */
const DIR_PERMISSIONS = 0o755;

/** Permissões padrão para arquivos */
const FILE_PERMISSIONS = 0o644;

/** Idade máxima para limpeza de cache (1 hora) */
const MAX_CACHE_AGE = 3600000;

// ============================================
// ESTADO
// ============================================

/** Flag para verificar se o cache foi inicializado */
let cacheInitialized = false;

/** Diretório de cache atual (pode ser alterado pelo fallback) */
let currentCacheDir = CACHE_BASE_DIR;

/** Diretório de arquivos atual */
let currentFilesDir = FILES_DIR;

/** Arquivo de ratelimit atual */
let currentRatelimitFile = RATELIMIT_FILE;

// ============================================
// FUNÇÕES DE INICIALIZAÇÃO
// ============================================

/**
 * Cria um diretório de forma segura
 * @param {string} dirPath - Caminho do diretório
 * @returns {boolean} Se foi criado com sucesso
 */
function createDirectorySafe(dirPath) {
  try {
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true, mode: DIR_PERMISSIONS });
      console.log(`✅ [CacheManager] Diretório criado: ${dirPath}`);
    }
    return true;
  } catch (error) {
    console.error(`❌ [CacheManager] Erro ao criar diretório ${dirPath}:`, error.message);
    return false;
  }
}

/**
 * Inicializa o sistema de cache de forma segura
 * Cria os diretórios necessários com tratamento de erros
 * @returns {boolean} Se a inicialização foi bem-sucedida
 */
export function initCache() {
  if (cacheInitialized) {
    return true;
  }

  try {
    // Tentar criar diretório base de cache
    if (!createDirectorySafe(currentCacheDir)) {
      throw new Error('Falha ao criar diretório base');
    }

    // Tentar criar diretório de arquivos
    if (!createDirectorySafe(currentFilesDir)) {
      throw new Error('Falha ao criar diretório de arquivos');
    }

    cacheInitialized = true;
    console.log(`✅ [CacheManager] Cache inicializado: ${currentCacheDir}`);
    return true;

  } catch (error) {
    console.error(`❌ [CacheManager] Erro ao inicializar cache: ${error.message}`);
    
    // Tentar usar diretório temporário alternativo
    return initFallbackCache();
  }
}

/**
 * Inicializa cache em diretório alternativo
 * @returns {boolean} Se a inicialização foi bem-sucedida
 */
function initFallbackCache() {
  try {
    const altDir = path.join(os.tmpdir(), `mutanox-${Date.now()}`);
    
    if (!createDirectorySafe(altDir)) {
      throw new Error('Falha ao criar diretório alternativo');
    }
    
    const altFilesDir = path.join(altDir, 'files');
    if (!createDirectorySafe(altFilesDir)) {
      throw new Error('Falha ao criar diretório de arquivos alternativo');
    }

    // Atualizar caminhos globais
    currentCacheDir = altDir;
    currentFilesDir = altFilesDir;
    currentRatelimitFile = path.join(altDir, 'ratelimits.json');

    cacheInitialized = true;
    console.log(`✅ [CacheManager] Usando cache alternativo: ${altDir}`);
    return true;

  } catch (altError) {
    console.error(`❌ [CacheManager] Erro crítico no cache alternativo: ${altError.message}`);
    return false;
  }
}

// ============================================
// FUNÇÕES DE CAMINHOS
// ============================================

/**
 * Obtém o caminho do diretório de arquivos
 * @returns {string} Caminho absoluto para o diretório de arquivos
 */
export function getFilesDir() {
  if (!cacheInitialized) {
    initCache();
  }
  return currentFilesDir;
}

/**
 * Obtém o caminho do arquivo de rate limits
 * @returns {string} Caminho absoluto para o arquivo de rate limits
 */
export function getRatelimitFile() {
  if (!cacheInitialized) {
    initCache();
  }
  return currentRatelimitFile;
}

/**
 * Obtém o caminho base do cache
 * @returns {string} Caminho absoluto para o diretório de cache
 */
export function getCacheDir() {
  if (!cacheInitialized) {
    initCache();
  }
  return currentCacheDir;
}

/**
 * Gera um caminho de arquivo seguro para criação de arquivos
 * @param {string} filename - Nome do arquivo
 * @returns {string} Caminho absoluto seguro para o arquivo
 * @throws {Error} Se o nome do arquivo for inválido
 */
export function getSecureFilePath(filename) {
  if (!cacheInitialized) {
    initCache();
  }

  // Validação de entrada
  if (!filename || typeof filename !== 'string') {
    throw new Error('Nome de arquivo inválido');
  }

  // Sanitizar nome do arquivo
  const safeName = filename
    .replace(/[<>:"/\\|?*]/g, '_')    // Remover caracteres inválidos
    .replace(/\.\./g, '')              // Remover path traversal
    .replace(/^\.+/, '')               // Remover pontos no início
    .substring(0, 200);                // Limitar tamanho

  if (!safeName || safeName.trim() === '') {
    throw new Error('Nome de arquivo inválido após sanitização');
  }

  return path.join(currentFilesDir, safeName);
}

// ============================================
// FUNÇÕES DE RATE LIMIT
// ============================================

/**
 * Salva dados de rate limit de forma segura
 * @param {Object} data - Dados de rate limit
 * @returns {boolean} Sucesso da operação
 */
export function saveRatelimitData(data) {
  if (!cacheInitialized) {
    initCache();
  }

  // Validação de entrada
  if (!data || typeof data !== 'object') {
    console.warn('[CacheManager] Dados de rate limit inválidos');
    return false;
  }

  try {
    const filePath = currentRatelimitFile;
    const jsonData = JSON.stringify(data, null, 2);
    
    fs.writeFileSync(filePath, jsonData, { 
      encoding: 'utf8',
      mode: FILE_PERMISSIONS 
    });
    
    return true;
  } catch (error) {
    console.error(`❌ [CacheManager] Erro ao salvar rate limits: ${error.message}`);
    return false;
  }
}

/**
 * Carrega dados de rate limit
 * @returns {Object|null} Dados de rate limit ou null se não existir
 */
export function loadRatelimitData() {
  if (!cacheInitialized) {
    initCache();
  }

  try {
    const filePath = currentRatelimitFile;
    
    if (!fs.existsSync(filePath)) {
      return null;
    }

    const data = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(data);
    
  } catch (error) {
    console.error(`❌ [CacheManager] Erro ao carregar rate limits: ${error.message}`);
    return null;
  }
}

// ============================================
// FUNÇÕES DE LIMPEZA
// ============================================

/**
 * Limpa arquivos antigos do cache
 * @param {number} [maxAgeMs=MAX_CACHE_AGE] - Idade máxima em milissegundos
 * @returns {number} Número de arquivos removidos
 */
export function cleanOldFiles(maxAgeMs = MAX_CACHE_AGE) {
  if (!cacheInitialized) {
    initCache();
  }

  try {
    const files = fs.readdirSync(currentFilesDir);
    const now = Date.now();
    let cleaned = 0;

    for (const file of files) {
      const filePath = path.join(currentFilesDir, file);
      
      try {
        const stats = fs.statSync(filePath);
        
        if (now - stats.mtimeMs > maxAgeMs) {
          fs.unlinkSync(filePath);
          cleaned++;
        }
      } catch (fileError) {
        // Ignorar erros de arquivos individuais
        console.debug(`[CacheManager] Erro ao processar arquivo ${file}:`, fileError.message);
      }
    }

    if (cleaned > 0) {
      console.log(`🧹 [CacheManager] Limpos ${cleaned} arquivos antigos`);
    }

    return cleaned;
    
  } catch (error) {
    console.error(`❌ [CacheManager] Erro ao limpar cache: ${error.message}`);
    return 0;
  }
}

/**
 * Limpa todo o cache
 * @returns {boolean} Se a limpeza foi bem-sucedida
 */
export function clearAllCache() {
  try {
    if (!cacheInitialized) {
      initCache();
    }

    // Limpar arquivos
    const files = fs.readdirSync(currentFilesDir);
    for (const file of files) {
      try {
        fs.unlinkSync(path.join(currentFilesDir, file));
      } catch (e) {
        // Ignorar erros individuais
      }
    }

    // Limpar rate limits
    if (fs.existsSync(currentRatelimitFile)) {
      fs.unlinkSync(currentRatelimitFile);
    }

    console.log('🧹 [CacheManager] Cache limpo completamente');
    return true;
    
  } catch (error) {
    console.error(`❌ [CacheManager] Erro ao limpar cache: ${error.message}`);
    return false;
  }
}

// ============================================
// FUNÇÕES DE VERIFICAÇÃO
// ============================================

/**
 * Verifica se o sistema de cache está funcionando
 * @returns {boolean} Status do cache
 */
export function isCacheWorking() {
  try {
    if (!cacheInitialized) {
      initCache();
    }

    const testFile = path.join(currentFilesDir, '.test');
    
    // Tentar escrever
    fs.writeFileSync(testFile, 'test', { mode: FILE_PERMISSIONS });
    
    // Tentar ler
    fs.readFileSync(testFile, 'utf8');
    
    // Remover arquivo de teste
    fs.unlinkSync(testFile);
    
    return true;
    
  } catch (error) {
    console.warn(`⚠️ [CacheManager] Cache não está funcionando: ${error.message}`);
    return false;
  }
}

/**
 * Obtém estatísticas do cache
 * @returns {Object} Estatísticas do cache
 */
export function getCacheStats() {
  try {
    if (!cacheInitialized) {
      initCache();
    }

    const files = fs.readdirSync(currentFilesDir);
    let totalSize = 0;

    for (const file of files) {
      try {
        const stats = fs.statSync(path.join(currentFilesDir, file));
        totalSize += stats.size;
      } catch (e) {
        // Ignorar erros
      }
    }

    return {
      initialized: cacheInitialized,
      cacheDir: currentCacheDir,
      filesDir: currentFilesDir,
      fileCount: files.length,
      totalSize: totalSize,
      totalSizeMB: Math.round(totalSize / 1024 / 1024 * 100) / 100
    };
    
  } catch (error) {
    return {
      initialized: false,
      error: error.message
    };
  }
}

// ============================================
// INICIALIZAÇÃO AUTOMÁTICA
// ============================================

// Inicializar cache ao carregar o módulo
initCache();

// ============================================
// EXPORT DEFAULT
// ============================================
export default {
  initCache,
  getFilesDir,
  getRatelimitFile,
  getCacheDir,
  getSecureFilePath,
  saveRatelimitData,
  loadRatelimitData,
  cleanOldFiles,
  clearAllCache,
  isCacheWorking,
  getCacheStats
};
