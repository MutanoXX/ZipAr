/**
 * Rias-Grimory-X - Sistema de Automação
 * VERSÃO 6.0 - Embeds Avançados + Integração com API de Imagens
 * 
 * MELHORIAS V6.0:
 * - Embeds ultra customizados com thumbnail da Rias
 * - Busca automática de imagens para tarefas de imagem
 * - Suporte a múltiplos tipos de conteúdo
 * - Correção de inicialização automática
 */

import fs from 'fs';
import path from 'path';
import { EmbedBuilder } from 'discord.js';
import OpenAI from 'openai';

// Diretório base para automações
const AUTOMATION_DIR = '/tmp/rias-automations';

// Garantir que o diretório existe
function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

ensureDir(AUTOMATION_DIR);

// Store de automações ativas
const activeAutomations = new Map();

// Cliente OpenAI para automações
const NVIDIA_KEY = process.env.NVIDIA_API_KEY || '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';

const aiClient = new OpenAI({
  baseURL: 'https://integrate.api.nvidia.com/v1',
  apiKey: NVIDIA_KEY,
  timeout: 30000,
  maxRetries: 1
});

/**
 * Classe que representa um Script de Automação
 */
class AutomationScript {
  constructor(guildId, config) {
    this.guildId = guildId;
    this.id = config.id || `${guildId}_${Date.now()}`;
    this.name = config.name;
    this.description = config.description;
    this.channelId = config.channelId;
    this.interval = config.interval || 60; // minutos
    this.task = config.task; // descrição da tarefa
    this.active = config.active !== false;
    this.lastRun = config.lastRun || null;
    this.runCount = config.runCount || 0;
    this.context = []; // Contexto da IA para este script
    this.intervalId = null;
    this.client = null; // Referência ao client Discord
    
    // Prompt específico para o script
    this.systemPrompt = this.buildSystemPrompt(config);
  }
  
  buildSystemPrompt(config) {
    // Detectar se é uma tarefa de imagem
    const isImageTask = (config.task || '').toLowerCase().includes('imagem') ||
                        (config.task || '').toLowerCase().includes('foto') ||
                        (config.task || '').toLowerCase().includes('picture') ||
                        (config.task || '').toLowerCase().includes('image');
    
    if (isImageTask) {
      return `# 🤖 Rias-Grimory-X - Script de Automação de Imagens

Você é uma **Automação de Imagens** do Rias-Grimory-X!

## 📋 Script: ${this.name}
## 📝 Tarefa: ${this.task}

## 🎯 SEU TRABALHO:
Você deve enviar imagens automaticamente! Use o formato abaixo:

## 📤 FORMATO DE RESPOSTA OBRIGATÓRIO:

\`\`\`json
{
  "type": "enviar_embed",
  "title": "Título Bonito",
  "description": "Descrição com emojis! 🌹✨",
  "color": "roxo",
  "image_search": "termo de busca para imagem",
  "thumbnail_rias": true
}
\`\`\`

## 💖 DICAS:
- Se a tarefa pede imagens DE VOCÊ (Rias), use: "Rias Gremory High School DxD anime"
- Use emojis generosamente
- Varie as descrições a cada execução
- Seja carinhosa e use "amor", "meu bem", etc.`;
    }
    
    return `# 🤖 Rias-Grimory-X - Script de Automação

Você é uma **Automação Automática** do Rias-Grimory-X!

## 📋 Script: ${this.name}
## 📝 Tarefa: ${this.task}

## 🎯 SEU TRABALHO:
Você deve executar a tarefa descrita acima automaticamente.
A cada execução, gere conteúdo novo e interessante!

## 📤 FORMATO DE RESPOSTA:
**SEMPRE retorne um JSON válido com o conteúdo a ser enviado:**

\`\`\`json
{
  "type": "enviar_embed",
  "title": "Título do Embed",
  "description": "Descrição bonita! ✨",
  "color": "roxo",
  "image": "URL_DA_IMAGEM (se houver)",
  "fields": []
}
\`\`\`

Ou para mensagem simples:
\`\`\`json
{
  "type": "message",
  "content": "Sua mensagem aqui! ✨"
}
\`\`\`

## 💖 DICAS:
- Seja criativa! Varie o conteúdo a cada execução
- Use emojis para decorar
- Mantenha o tema: ${this.task}
- Não repita o mesmo conteúdo`;
  }
  
  /**
   * Inicia o intervalo de execução
   */
  start(client) {
    if (!this.active) {
      console.log(`⏸️ [Automação] ${this.name} está pausada, não iniciando.`);
      return;
    }
    
    this.client = client;
    
    // Converter minutos para milissegundos
    const intervalMs = this.interval * 60 * 1000;
    
    console.log(`🤖 [Automação] Iniciando: ${this.name} (a cada ${this.interval} min)`);
    
    // Executar imediatamente após 2 segundos (dar tempo do bot estabilizar)
    setTimeout(() => {
      this.execute(client);
    }, 2000);
    
    // Agendar próximas execuções
    this.intervalId = setInterval(() => {
      this.execute(client);
    }, intervalMs);
    
    // Marcar como ativo
    this.active = true;
  }
  
  /**
   * Para o script
   */
  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.active = false;
    console.log(`⏹️ [Automação] Parado: ${this.name}`);
  }
  
  /**
   * Executa a automação
   */
  async execute(client) {
    try {
      const execTime = new Date().toLocaleString('pt-BR');
      console.log(`⚡ [Automação] Executando: ${this.name} (${execTime})`);
      
      const guild = client.guilds.cache.get(this.guildId);
      if (!guild) {
        console.error(`❌ [Automação] Servidor não encontrado: ${this.guildId}`);
        return;
      }
      
      const channel = guild.channels.cache.get(this.channelId);
      if (!channel) {
        console.error(`❌ [Automação] Canal não encontrado: ${this.channelId}`);
        return;
      }
      
      // Chamar IA para gerar conteúdo
      const messages = [
        { role: 'system', content: this.systemPrompt },
        { role: 'user', content: `Execute a automação agora! (${execTime}) - Execução #${this.runCount + 1}` }
      ];
      
      const completion = await aiClient.chat.completions.create({
        model: 'stepfun-ai/step-3.5-flash',
        messages: messages,
        temperature: 0.9,
        max_tokens: 2000
      });
      
      const content = completion.choices[0]?.message?.content || '';
      
      // Parse da resposta
      const response = this.parseResponse(content);
      
      // Enviar para o canal
      await this.sendToChannel(channel, response);
      
      // Atualizar estatísticas
      this.lastRun = new Date().toISOString();
      this.runCount++;
      this.save();
      
      console.log(`✅ [Automação] Executado: ${this.name} (Total: ${this.runCount})`);
      
    } catch (error) {
      console.error(`❌ [Automação] Erro em ${this.name}:`, error.message);
    }
  }
  
  parseResponse(content) {
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
    } catch (e) {}
    
    return { type: 'message', content: content };
  }
  
  async sendToChannel(channel, response) {
    try {
      // Verificar se precisa buscar imagem
      if (response.image_search) {
        const imageUrl = await this.searchImage(response.image_search);
        if (imageUrl) {
          response.image = imageUrl;
        }
      }
      
      if (response.type === 'enviar_embed' || response.type === 'send_embed') {
        const embed = await this.createAdvancedEmbed(response);
        await channel.send({ embeds: [embed] });
      } else {
        // Mensagem simples com emoji da Rias
        await channel.send({ 
          content: `🌹 ${response.content?.substring(0, 1990) || '🤖 Automação executada!'}`
        });
      }
    } catch (error) {
      console.error(`❌ [Automação] Erro ao enviar:`, error.message);
    }
  }
  
  /**
   * Cria embed avançado com thumbnail da Rias
   */
  async createAdvancedEmbed(response) {
    const colorMap = {
      'roxo': 0x8B5CF6,
      'vermelho': 0xDC143C,
      'verde': 0x10B981,
      'azul': 0x3B82F6,
      'amarelo': 0xF59E0B,
      'rosa': 0xEC4899,
      'crimson': 0xDC143C
    };
    
    const color = colorMap[response.color] || 0xDC143C; // Crimson padrão
    
    // Thumbnail da Rias (se pedido ou por padrão para certos tipos)
    let thumbnailUrl = null;
    if (response.thumbnail_rias || response.thumbnailRias) {
      thumbnailUrl = 'https://i.imgur.com/eEsH9NF.jpeg';
    }
    
    const embed = new EmbedBuilder()
      .setTitle(`✨ ${response.title || response.titulo || this.name}`)
      .setDescription(response.description || response.descricao || '')
      .setColor(color)
      .setThumbnail(thumbnailUrl || 'https://i.imgur.com/eEsH9NF.jpeg')
      .setFooter({ 
        text: `🤖 ${this.name} | Execução #${this.runCount + 1}`, 
        iconURL: 'https://i.imgur.com/eEsH9NF.jpeg'
      })
      .setTimestamp();
    
    // Adicionar imagem se tiver
    if (response.image || response.imagem) {
      embed.setImage(response.image || response.imagem);
    }
    
    // Adicionar campos se tiver
    if (response.fields && Array.isArray(response.fields)) {
      response.fields.forEach(f => {
        embed.addFields({ 
          name: f.name || '━━━━', 
          value: f.value || '•', 
          inline: f.inline || false 
        });
      });
    }
    
    // Adicionar info da automação
    embed.addFields(
      { name: '\u200B', value: '━━━━━━━━━━━━━━━━━━━━', inline: false },
      { name: '⏱️ Intervalo', value: `${this.interval} min`, inline: true },
      { name: '📊 Execução', value: `#${this.runCount + 1}`, inline: true }
    );
    
    return embed;
  }
  
  /**
   * Busca imagem via API
   */
  async searchImage(query) {
    try {
      // Import dinâmico para evitar dependência circular
      const apiService = (await import('../services/apiService.js')).default;
      
      const result = await apiService.searchGoogleImage(query);
      
      if (result?.success && result?.data?.result?.length > 0) {
        const images = result.data.result.slice(0, 5);
        const randomImage = images[Math.floor(Math.random() * images.length)];
        return randomImage?.url;
      }
    } catch (error) {
      console.error(`❌ [Automação] Erro ao buscar imagem:`, error.message);
    }
    
    return null;
  }
  
  /**
   * Salva o script no disco
   */
  save() {
    const guildDir = path.join(AUTOMATION_DIR, this.guildId);
    ensureDir(guildDir);
    
    const filePath = path.join(guildDir, `${this.id}.json`);
    
    const data = {
      id: this.id,
      name: this.name,
      description: this.description,
      channelId: this.channelId,
      interval: this.interval,
      task: this.task,
      active: this.active,
      lastRun: this.lastRun,
      runCount: this.runCount
    };
    
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  }
  
  /**
   * Remove o script do disco
   */
  delete() {
    this.stop();
    
    const filePath = path.join(AUTOMATION_DIR, this.guildId, `${this.id}.json`);
    
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  }
  
  toObject() {
    return {
      id: this.id,
      name: this.name,
      description: this.description,
      channelId: this.channelId,
      channelMention: `<#${this.channelId}>`,
      interval: this.interval,
      task: this.task,
      active: this.active,
      lastRun: this.lastRun,
      runCount: this.runCount
    };
  }
}

// ============================================
// FUNÇÕES DE GERENCIAMENTO
// ============================================

/**
 * Cria uma nova automação
 */
export function createAutomation(guildId, config) {
  const script = new AutomationScript(guildId, config);
  script.save();
  
  // Adicionar ao store
  if (!activeAutomations.has(guildId)) {
    activeAutomations.set(guildId, new Map());
  }
  activeAutomations.get(guildId).set(script.id, script);
  
  return script;
}

/**
 * Obtém uma automação específica
 */
export function getAutomation(guildId, scriptId) {
  const guildAutomations = activeAutomations.get(guildId);
  if (!guildAutomations) return null;
  return guildAutomations.get(scriptId);
}

/**
 * Lista todas as automações de um servidor
 */
export function listAutomations(guildId) {
  const guildAutomations = activeAutomations.get(guildId);
  if (!guildAutomations) return [];
  
  return Array.from(guildAutomations.values()).map(s => s.toObject());
}

/**
 * Remove uma automação
 */
export function deleteAutomation(guildId, scriptId) {
  const script = getAutomation(guildId, scriptId);
  if (!script) return false;
  
  script.delete();
  
  const guildAutomations = activeAutomations.get(guildId);
  if (guildAutomations) {
    guildAutomations.delete(scriptId);
  }
  
  return true;
}

/**
 * Pausa uma automação
 */
export function pauseAutomation(guildId, scriptId) {
  const script = getAutomation(guildId, scriptId);
  if (!script) return false;
  
  script.stop();
  script.save();
  
  return true;
}

/**
 * Retoma uma automação
 */
export function resumeAutomation(guildId, scriptId, client) {
  const script = getAutomation(guildId, scriptId);
  if (!script) return false;
  
  script.active = true;
  script.start(client);
  script.save();
  
  return true;
}

/**
 * Edita uma automação e reinicia
 */
export function editAutomation(guildId, scriptId, newConfig, client = null) {
  const script = getAutomation(guildId, scriptId);
  if (!script) return null;
  
  // Parar antes de editar
  const wasActive = script.active;
  script.stop();
  
  // Aplicar mudanças
  if (newConfig.name) script.name = newConfig.name;
  if (newConfig.description) script.description = newConfig.description;
  if (newConfig.interval) script.interval = newConfig.interval;
  if (newConfig.task) script.task = newConfig.task;
  if (newConfig.channelId) script.channelId = newConfig.channelId;
  
  // Rebuild prompt
  script.systemPrompt = script.buildSystemPrompt(script);
  
  script.save();
  
  // Reiniciar se estava ativo
  if (wasActive && client) {
    script.active = true;
    script.start(client);
  }
  
  return script.toObject();
}

/**
 * Inicia todas as automações de um servidor
 */
export function startGuildAutomations(guildId, client) {
  const guildDir = path.join(AUTOMATION_DIR, guildId);
  
  if (!fs.existsSync(guildDir)) {
    console.log(`📁 [Automação] Nenhuma automação salva para: ${guildId}`);
    return;
  }
  
  const files = fs.readdirSync(guildDir).filter(f => f.endsWith('.json'));
  
  if (files.length === 0) {
    return;
  }
  
  if (!activeAutomations.has(guildId)) {
    activeAutomations.set(guildId, new Map());
  }
  
  for (const file of files) {
    try {
      const filePath = path.join(guildDir, file);
      const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      
      const script = new AutomationScript(guildId, data);
      activeAutomations.get(guildId).set(script.id, script);
      
      if (script.active) {
        script.start(client);
      }
      
      console.log(`🤖 [Automação] Carregado: ${script.name} (${script.active ? 'ativo' : 'pausado'})`);
    } catch (error) {
      console.error(`❌ [Automação] Erro ao carregar ${file}:`, error.message);
    }
  }
}

/**
 * Para todas as automações de um servidor
 */
export function stopGuildAutomations(guildId) {
  const guildAutomations = activeAutomations.get(guildId);
  if (!guildAutomations) return;
  
  for (const script of guildAutomations.values()) {
    script.stop();
  }
}

/**
 * Executa uma automação manualmente
 */
export async function runAutomationNow(guildId, scriptId, client) {
  const script = getAutomation(guildId, scriptId);
  if (!script) return false;
  
  await script.execute(client);
  return true;
}

/**
 * Obtém estatísticas de automação
 */
export function getAutomationStats(guildId) {
  const automations = listAutomations(guildId);
  
  return {
    total: automations.length,
    active: automations.filter(a => a.active).length,
    totalRuns: automations.reduce((sum, a) => sum + a.runCount, 0)
  };
}

export { AutomationScript };

export default {
  createAutomation,
  getAutomation,
  listAutomations,
  deleteAutomation,
  pauseAutomation,
  resumeAutomation,
  editAutomation,
  startGuildAutomations,
  stopGuildAutomations,
  runAutomationNow,
  getAutomationStats,
  AutomationScript
};
