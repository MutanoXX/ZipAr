/**
 * Rias-Grimory-X - Sistema de Bem-vindo
 * Boas-vindas automáticas com cards, autorole e mensagens personalizadas
 */

import { EmbedBuilder, AttachmentBuilder } from 'discord.js';
import apiService from '../services/apiService.js';

// Configurações por servidor
const welcomeConfigs = new Map();

// Contador de membros
const memberCounts = new Map();

// Configuração padrão
const DEFAULT_WELCOME_CONFIG = {
  enabled: true,
  
  // Mensagem de boas-vindas
  welcome: {
    enabled: true,
    channelId: null,
    message: 'Olá {usuario}! Bem-vindo ao {servidor}! 🎉',
    showCard: true,
    cardStyle: 'default', // default, anime, gaming, elegant
    mentionUser: true,
    dmEnabled: false,
    dmMessage: 'Bem-vindo ao {servidor}! Leia as regras e divirta-se! 💖'
  },
  
  // Mensagem de saída
  goodbye: {
    enabled: true,
    channelId: null,
    message: '{usuario} saiu do servidor. Até mais! 👋',
    showCard: false
  },
  
  // Autorole
  autorole: {
    enabled: false,
    roles: []
  },
  
  // Contador de membros
  memberCount: {
    enabled: false,
    channelId: null,
    format: '👥 Membros: {count}'
  }
};

/**
 * Inicializa configuração de boas-vindas
 */
export function initWelcomeConfig(guildId) {
  if (!welcomeConfigs.has(guildId)) {
    welcomeConfigs.set(guildId, { ...DEFAULT_WELCOME_CONFIG, guildId });
    console.log(`👋 [Welcome] Configuração inicializada para: ${guildId}`);
  }
  return welcomeConfigs.get(guildId);
}

/**
 * Obtém configuração de boas-vindas
 */
export function getWelcomeConfig(guildId) {
  return welcomeConfigs.get(guildId) || initWelcomeConfig(guildId);
}

/**
 * Configura canal de boas-vindas
 */
export function setWelcomeChannel(guildId, channelId, options = {}) {
  const config = getWelcomeConfig(guildId);
  
  config.welcome.enabled = true;
  config.welcome.channelId = channelId;
  
  if (options.message) config.welcome.message = options.message;
  if (options.showCard !== undefined) config.welcome.showCard = options.showCard;
  if (options.cardStyle) config.welcome.cardStyle = options.cardStyle;
  if (options.mentionUser !== undefined) config.welcome.mentionUser = options.mentionUser;
  
  welcomeConfigs.set(guildId, config);
  console.log(`✅ [Welcome] Canal de boas-vindas configurado: ${channelId}`);
  return config;
}

/**
 * Configura mensagem de boas-vindas
 */
export function setWelcomeMessage(guildId, message) {
  const config = getWelcomeConfig(guildId);
  config.welcome.message = message;
  welcomeConfigs.set(guildId, config);
  return config;
}

/**
 * Configura DM de boas-vindas
 */
export function setWelcomeDM(guildId, enabled, message = null) {
  const config = getWelcomeConfig(guildId);
  config.welcome.dmEnabled = enabled;
  if (message) config.welcome.dmMessage = message;
  welcomeConfigs.set(guildId, config);
  return config;
}

/**
 * Configura canal de saída
 */
export function setGoodbyeChannel(guildId, channelId, message = null) {
  const config = getWelcomeConfig(guildId);
  
  config.goodbye.enabled = true;
  config.goodbye.channelId = channelId;
  if (message) config.goodbye.message = message;
  
  welcomeConfigs.set(guildId, config);
  return config;
}

/**
 * Configura autorole
 */
export function setAutorole(guildId, roles) {
  const config = getWelcomeConfig(guildId);
  
  config.autorole.enabled = roles.length > 0;
  config.autorole.roles = roles;
  
  welcomeConfigs.set(guildId, config);
  console.log(`✅ [Welcome] Autorole configurado: ${roles.length} cargo(s)`);
  return config;
}

/**
 * Adiciona cargo ao autorole
 */
export function addAutorole(guildId, roleId) {
  const config = getWelcomeConfig(guildId);
  
  if (!config.autorole.roles.includes(roleId)) {
    config.autorole.roles.push(roleId);
    config.autorole.enabled = true;
    welcomeConfigs.set(guildId, config);
  }
  
  return config;
}

/**
 * Remove cargo do autorole
 */
export function removeAutorole(guildId, roleId) {
  const config = getWelcomeConfig(guildId);
  
  config.autorole.roles = config.autorole.roles.filter(r => r !== roleId);
  config.autorole.enabled = config.autorole.roles.length > 0;
  
  welcomeConfigs.set(guildId, config);
  return config;
}

/**
 * Configura contador de membros
 */
export function setMemberCounter(guildId, channelId, format = null) {
  const config = getWelcomeConfig(guildId);
  
  config.memberCount.enabled = true;
  config.memberCount.channelId = channelId;
  if (format) config.memberCount.format = format;
  
  welcomeConfigs.set(guildId, config);
  return config;
}

/**
 * Processa entrada de novo membro
 */
export async function handleMemberJoin(member, guild) {
  const config = getWelcomeConfig(guild.id);
  
  // Atualizar contador de membros
  updateMemberCount(guild);
  
  // Aplicar autorole
  if (config.autorole.enabled && config.autorole.roles.length > 0) {
    try {
      for (const roleId of config.autorole.roles) {
        const role = guild.roles.cache.get(roleId);
        if (role) {
          await member.roles.add(role, 'Autorole - Boas-vindas');
        }
      }
      console.log(`✅ [Welcome] Autorole aplicado para: ${member.user.tag}`);
    } catch (error) {
      console.error('❌ [Welcome] Erro ao aplicar autorole:', error.message);
    }
  }
  
  // Enviar mensagem de boas-vindas
  if (config.welcome.enabled && config.welcome.channelId) {
    const channel = guild.channels.cache.get(config.welcome.channelId);
    
    if (channel) {
      try {
        const welcomeData = {
          user: member.user,
          guild: guild,
          member: member
        };
        
        // Processar mensagem com variáveis
        const message = processVariables(config.welcome.message, welcomeData);
        
        // Criar embed
        const embed = new EmbedBuilder()
          .setTitle('👋 Bem-vindo(a)!')
          .setDescription(message)
          .setColor('#10B981')
          .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
          .addFields(
            { name: '👤 Usuário', value: `<@${member.id}>`, inline: true },
            { name: '🆔 ID', value: member.id, inline: true },
            { name: '📅 Conta criada', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true }
          )
          .setFooter({ text: `💎 Rias-Grimory-X | Membro #${guild.memberCount}` })
          .setTimestamp();
        
        // Adicionar card se habilitado
        if (config.welcome.showCard) {
          const cardUrl = await generateWelcomeCard(member, guild, config.welcome.cardStyle);
          if (cardUrl) {
            embed.setImage(cardUrl);
          }
        }
        
        const sendOptions = { embeds: [embed] };
        
        // Mencionar usuário se configurado
        if (config.welcome.mentionUser) {
          sendOptions.content = `<@${member.id}>`;
        }
        
        await channel.send(sendOptions);
        console.log(`✅ [Welcome] Mensagem enviada para: ${member.user.tag}`);
        
      } catch (error) {
        console.error('❌ [Welcome] Erro ao enviar boas-vindas:', error.message);
      }
    }
  }
  
  // Enviar DM de boas-vindas
  if (config.welcome.dmEnabled && config.welcome.dmMessage) {
    try {
      const dmData = { user: member.user, guild: guild, member: member };
      const dmMessage = processVariables(config.welcome.dmMessage, dmData);
      
      await member.send({
        embeds: [
          new EmbedBuilder()
            .setTitle(`👋 Bem-vindo ao ${guild.name}!`)
            .setDescription(dmMessage)
            .setColor('#8B5CF6')
            .setThumbnail(guild.iconURL({ dynamic: true }))
            .setFooter({ text: '💎 Rias-Grimory-X' })
            .setTimestamp()
        ]
      });
    } catch (error) {
      // DMs podem estar desabilitadas
      console.log('⚠️ [Welcome] Não foi possível enviar DM');
    }
  }
  
  return config;
}

/**
 * Processa saída de membro
 */
export async function handleMemberLeave(member, guild) {
  const config = getWelcomeConfig(guild.id);
  
  // Atualizar contador de membros
  updateMemberCount(guild);
  
  // Enviar mensagem de saída
  if (config.goodbye.enabled && config.goodbye.channelId) {
    const channel = guild.channels.cache.get(config.goodbye.channelId);
    
    if (channel) {
      try {
        const leaveData = {
          user: member.user,
          guild: guild,
          member: member
        };
        
        const message = processVariables(config.goodbye.message, leaveData);
        
        const embed = new EmbedBuilder()
          .setTitle('👋 Até logo!')
          .setDescription(message)
          .setColor('#F59E0B')
          .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
          .addFields(
            { name: '👤 Usuário', value: member.user.tag, inline: true },
            { name: '📅 Estadia', value: member.joinedAt ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : 'N/A', inline: true }
          )
          .setFooter({ text: `💎 Rias-Grimory-X | ${guild.memberCount} membros` })
          .setTimestamp();
        
        await channel.send({ embeds: [embed] });
        console.log(`✅ [Welcome] Mensagem de saída enviada para: ${member.user.tag}`);
        
      } catch (error) {
        console.error('❌ [Welcome] Erro ao enviar saída:', error.message);
      }
    }
  }
  
  return config;
}

/**
 * Atualiza contador de membros
 */
async function updateMemberCount(guild) {
  const config = getWelcomeConfig(guild.id);
  
  if (!config.memberCount.enabled || !config.memberCount.channelId) return;
  
  const channel = guild.channels.cache.get(config.memberCount.channelId);
  if (!channel) return;
  
  const count = guild.memberCount;
  const newName = config.memberCount.format.replace('{count}', count);
  
  try {
    if (channel.name !== newName) {
      await channel.setName(newName);
      memberCounts.set(guild.id, count);
    }
  } catch (error) {
    console.error('❌ [Welcome] Erro ao atualizar contador:', error.message);
  }
}

/**
 * Processa variáveis na mensagem
 */
function processVariables(text, data) {
  if (!text) return '';
  
  const variables = {
    '{usuario}': data.user ? `<@${data.user.id}>` : 'Usuário',
    '{usuario_nome}': data.user?.username || 'Usuário',
    '{usuario_tag}': data.user?.tag || 'Usuário',
    '{servidor}': data.guild?.name || 'Servidor',
    '{membros}': data.guild?.memberCount?.toString() || '0',
    '{data}': new Date().toLocaleDateString('pt-BR'),
    '{hora}': new Date().toLocaleTimeString('pt-BR')
  };
  
  let result = text;
  for (const [key, value] of Object.entries(variables)) {
    result = result.replace(new RegExp(key, 'gi'), value);
  }
  
  return result;
}

/**
 * Gera card de boas-vindas
 */
async function generateWelcomeCard(member, guild, style = 'default') {
  try {
    // Buscar imagem de fundo baseada no estilo
    const styleQueries = {
      'anime': 'anime girl welcome beautiful',
      'gaming': 'gaming neon aesthetic',
      'elegant': 'elegant dark aesthetic purple',
      'cute': 'cute pink aesthetic',
      'default': 'welcome banner aesthetic'
    };
    
    const query = styleQueries[style] || styleQueries.default;
    const result = await apiService.searchGoogleImage(query);
    
    if (result.success && result.data?.result?.[0]?.url) {
      return result.data.result[0].url;
    }
  } catch (error) {
    console.error('❌ [Welcome] Erro ao gerar card:', error.message);
  }
  
  return null;
}

/**
 * Testa sistema de boas-vindas
 */
export async function testWelcome(guild, tester) {
  const config = getWelcomeConfig(guild.id);
  
  if (!config.welcome.enabled || !config.welcome.channelId) {
    return { success: false, message: 'Sistema de boas-vindas não configurado' };
  }
  
  const channel = guild.channels.cache.get(config.welcome.channelId);
  if (!channel) {
    return { success: false, message: 'Canal de boas-vindas não encontrado' };
  }
  
  // Simular entrada
  const fakeMember = {
    user: tester,
    id: tester.id,
    user: tester,
    tag: tester.tag,
    joinedAt: new Date(),
    joinedTimestamp: Date.now(),
    roles: { add: () => {} },
    displayAvatarURL: tester.displayAvatarURL.bind(tester)
  };
  
  const welcomeData = {
    user: tester,
    guild: guild,
    member: fakeMember
  };
  
  const message = processVariables(config.welcome.message, welcomeData);
  
  const embed = new EmbedBuilder()
    .setTitle('🧪 TESTE - Bem-vindo(a)!')
    .setDescription(message)
    .setColor('#10B981')
    .setThumbnail(tester.displayAvatarURL({ dynamic: true, size: 256 }))
    .addFields(
      { name: '👤 Usuário', value: `<@${tester.id}>`, inline: true },
      { name: '🧪 Modo', value: 'TESTE', inline: true }
    )
    .setFooter({ text: '💎 Rias-Grimory-X | Teste de Boas-vindas' })
    .setTimestamp();
  
  try {
    await channel.send({ 
      content: `🧪 **TESTE** - Simulação de boas-vindas`,
      embeds: [embed] 
    });
    return { success: true, message: 'Teste enviado com sucesso!' };
  } catch (error) {
    return { success: false, message: `Erro: ${error.message}` };
  }
}

/**
 * Obtém configurações formatadas
 */
export function getWelcomeSettings(guildId) {
  const config = getWelcomeConfig(guildId);
  
  return {
    enabled: config.enabled,
    welcome: {
      enabled: config.welcome.enabled,
      channel: config.welcome.channelId ? `<#${config.welcome.channelId}>` : 'Não configurado',
      message: config.welcome.message,
      showCard: config.welcome.showCard,
      cardStyle: config.welcome.cardStyle,
      dmEnabled: config.welcome.dmEnabled
    },
    goodbye: {
      enabled: config.goodbye.enabled,
      channel: config.goodbye.channelId ? `<#${config.goodbye.channelId}>` : 'Não configurado',
      message: config.goodbye.message
    },
    autorole: {
      enabled: config.autorole.enabled,
      roles: config.autorole.roles.map(r => `<@&${r}>`).join(', ') || 'Nenhum'
    },
    memberCount: {
      enabled: config.memberCount.enabled,
      channel: config.memberCount.channelId ? `<#${config.memberCount.channelId}>` : 'Não configurado'
    }
  };
}

export default {
  initWelcomeConfig,
  getWelcomeConfig,
  setWelcomeChannel,
  setWelcomeMessage,
  setWelcomeDM,
  setGoodbyeChannel,
  setAutorole,
  addAutorole,
  removeAutorole,
  setMemberCounter,
  handleMemberJoin,
  handleMemberLeave,
  testWelcome,
  getWelcomeSettings
};
