/**
 * Rias-Grimory-X - Ferramentas Completas de Gestão de Servidor
 * VERSÃO 7.0 - Sistema com Análise de Padrões
 */

import {
  ChannelType,
  PermissionFlagsBits
} from 'discord.js';

import {
  decorateChannelName,
  decorateCategoryName,
  decorateRoleName,
  suggestRoleColor,
  analyzeChannelPatterns,
  analyzeCategoryPatterns,
  analyzeRolePatterns,
  detectCategoryFromName,
  EMOJI_SUGGESTIONS,
  extractEmojis
} from './patternAnalyzer.js';

// ============================================
// CONSTANTES E MAPEAMENTOS
// ============================================

export const PERMISSION_FLAGS = {
  'administrator': PermissionFlagsBits.Administrator,
  'view_channel': PermissionFlagsBits.ViewChannel,
  'manage_channels': PermissionFlagsBits.ManageChannels,
  'manage_roles': PermissionFlagsBits.ManageRoles,
  'manage_guild': PermissionFlagsBits.ManageGuild,
  'kick_members': PermissionFlagsBits.KickMembers,
  'ban_members': PermissionFlagsBits.BanMembers,
  'create_instant_invite': PermissionFlagsBits.CreateInstantInvite,
  'change_nickname': PermissionFlagsBits.ChangeNickname,
  'manage_nicknames': PermissionFlagsBits.ManageNicknames,
  'manage_messages': PermissionFlagsBits.ManageMessages,
  'manage_webhooks': PermissionFlagsBits.ManageWebhooks,
  'manage_emojis': PermissionFlagsBits.ManageEmojisAndStickers,
  'moderate_members': PermissionFlagsBits.ModerateMembers,
  'send_messages': PermissionFlagsBits.SendMessages,
  'embed_links': PermissionFlagsBits.EmbedLinks,
  'attach_files': PermissionFlagsBits.AttachFiles,
  'add_reactions': PermissionFlagsBits.AddReactions,
  'use_external_emojis': PermissionFlagsBits.UseExternalEmojis,
  'mention_everyone': PermissionFlagsBits.MentionEveryone,
  'read_message_history': PermissionFlagsBits.ReadMessageHistory,
  'connect': PermissionFlagsBits.Connect,
  'speak': PermissionFlagsBits.Speak,
  'stream': PermissionFlagsBits.Stream,
  'mute_members': PermissionFlagsBits.MuteMembers,
  'deafen_members': PermissionFlagsBits.DeafenMembers,
  'move_members': PermissionFlagsBits.MoveMembers
};

export const COLOR_MAP = {
  'vermelho': '#EF4444', 'red': '#EF4444',
  'verde': '#10B981', 'green': '#10B981',
  'azul': '#3B82F6', 'blue': '#3B82F6',
  'roxo': '#8B5CF6', 'purple': '#8B5CF6',
  'amarelo': '#F59E0B', 'yellow': '#F59E0B',
  'rosa': '#EC4899', 'pink': '#EC4899',
  'laranja': '#F97316', 'orange': '#F97316',
  'dourado': '#FFD700', 'gold': '#FFD700',
  'branco': '#FFFFFF', 'white': '#FFFFFF',
  'preto': '#000000', 'black': '#000000',
  'ciano': '#06B6D4', 'cyan': '#06B6D4',
  'cinza': '#6B7280', 'gray': '#6B7280'
};

// ============================================
// FUNÇÕES AUXILIARES
// ============================================

export function parsePermissions(permissions) {
  if (!permissions || !Array.isArray(permissions)) return 0n;
  let bitmask = 0n;
  for (const perm of permissions) {
    const key = perm.toLowerCase().replace(/[\s-]/g, '_');
    if (PERMISSION_FLAGS[key]) {
      bitmask |= PERMISSION_FLAGS[key];
    }
  }
  return bitmask;
}

export function parseColor(color) {
  if (!color) return null;
  if (typeof color === 'number') return color;
  
  const lower = color.toLowerCase();
  if (COLOR_MAP[lower] !== undefined) {
    return COLOR_MAP[lower] ? parseInt(COLOR_MAP[lower].replace('#', ''), 16) : null;
  }
  
  if (color.startsWith('#')) {
    return parseInt(color.slice(1), 16) || null;
  }
  
  return parseInt(color, 16) || null;
}

export function findChannel(guild, identifier) {
  if (!identifier) return null;
  const cleanId = identifier.replace(/[<#>]/g, '');
  
  if (/^\d+$/.test(cleanId)) {
    return guild.channels.cache.get(cleanId);
  }
  
  return guild.channels.cache.find(c => 
    c.name.toLowerCase() === identifier.toLowerCase() ||
    c.name.toLowerCase().includes(identifier.toLowerCase())
  );
}

export function findRole(guild, identifier) {
  if (!identifier) return null;
  const cleanId = identifier.replace(/[<@&>]/g, '');
  
  if (/^\d+$/.test(cleanId)) {
    return guild.roles.cache.get(cleanId);
  }
  
  return guild.roles.cache.find(r => 
    r.name.toLowerCase() === identifier.toLowerCase() ||
    r.name.toLowerCase().includes(identifier.toLowerCase())
  );
}

export function findMember(guild, identifier) {
  if (!identifier) return null;
  const cleanId = identifier.replace(/[<@!>]/g, '');
  
  if (/^\d+$/.test(cleanId)) {
    return guild.members.cache.get(cleanId);
  }
  
  if (identifier.includes('#')) {
    return guild.members.cache.find(m => m.user.tag === identifier);
  }
  
  return guild.members.cache.find(m => 
    m.user.username.toLowerCase() === identifier.toLowerCase() ||
    m.user.username.toLowerCase().includes(identifier.toLowerCase()) ||
    (m.nickname && m.nickname.toLowerCase().includes(identifier.toLowerCase()))
  );
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ============================================
// FERRAMENTAS DE CANAIS
// ============================================

export async function createChannel(guild, options) {
  const { name, type = 'texto', parent, topic, slowmode, nsfw, bitrate, userLimit, permissions, preserveStyle = true } = options;
  
  if (!name) throw new Error('Nome do canal é obrigatório');
  
  const channelType = type === 'voz' || type === 'voice' ? ChannelType.GuildVoice : 
                      type === 'anuncio' || type === 'announcement' ? ChannelType.GuildAnnouncement :
                      ChannelType.GuildText;
  
  // Decorar nome se preservar estilo
  let finalName = name;
  if (preserveStyle) {
    try {
      const decorated = decorateChannelName(guild, name);
      finalName = decorated;
    } catch (e) {
      console.log('[serverTools] Erro ao decorar nome:', e.message);
    }
  }
  
  // Formatar para Discord
  const discordName = finalName.toLowerCase().replace(/\s+/g, '-').substring(0, 100);
  
  const channelOptions = {
    name: discordName,
    type: channelType,
    reason: 'Rias-Grimory-X'
  };
  
  if (parent) {
    const parentChannel = findChannel(guild, parent);
    if (parentChannel && parentChannel.type === ChannelType.GuildCategory) {
      channelOptions.parent = parentChannel.id;
    }
  }
  
  if (topic && channelType === ChannelType.GuildText) {
    channelOptions.topic = topic.substring(0, 1024);
  }
  
  if (slowmode && channelType === ChannelType.GuildText) {
    channelOptions.rateLimitPerUser = Math.min(Math.max(0, parseInt(slowmode)), 21600);
  }
  
  if (nsfw && channelType === ChannelType.GuildText) {
    channelOptions.nsfw = Boolean(nsfw);
  }
  
  if (bitrate && channelType === ChannelType.GuildVoice) {
    channelOptions.bitrate = Math.min(Math.max(8000, parseInt(bitrate)), 96000);
  }
  
  if (userLimit && channelType === ChannelType.GuildVoice) {
    channelOptions.userLimit = Math.min(Math.max(0, parseInt(userLimit)), 99);
  }
  
  if (permissions && Array.isArray(permissions)) {
    channelOptions.permissionOverwrites = [];
    for (const perm of permissions) {
      const role = findRole(guild, perm.role);
      if (role) {
        channelOptions.permissionOverwrites.push({
          id: role.id,
          allow: parsePermissions(perm.allow),
          deny: parsePermissions(perm.deny)
        });
      }
    }
  }
  
  const channel = await guild.channels.create(channelOptions);
  
  return {
    success: true,
    channel: {
      id: channel.id,
      name: channel.name,
      type: type,
      mention: `<#${channel.id}>`
    },
    discordChannel: channel
  };
}

export async function editChannel(guild, options) {
  const { channel: channelId, name, topic, slowmode, nsfw, bitrate, userLimit, position } = options;
  
  const channel = findChannel(guild, channelId);
  if (!channel) throw new Error('Canal não encontrado');
  
  const editOptions = { reason: 'Rias-Grimory-X' };
  
  if (name) editOptions.name = name.toLowerCase().replace(/\s+/g, '-').substring(0, 100);
  if (topic !== undefined && channel.type === ChannelType.GuildText) {
    editOptions.topic = topic?.substring(0, 1024) || '';
  }
  if (slowmode !== undefined && channel.type === ChannelType.GuildText) {
    editOptions.rateLimitPerUser = Math.min(Math.max(0, parseInt(slowmode) || 0), 21600);
  }
  if (nsfw !== undefined && channel.type === ChannelType.GuildText) {
    editOptions.nsfw = Boolean(nsfw);
  }
  if (bitrate !== undefined && channel.type === ChannelType.GuildVoice) {
    editOptions.bitrate = Math.min(Math.max(8000, parseInt(bitrate)), 96000);
  }
  if (userLimit !== undefined && channel.type === ChannelType.GuildVoice) {
    editOptions.userLimit = Math.min(Math.max(0, parseInt(userLimit) || 0), 99);
  }
  if (position !== undefined) {
    editOptions.position = parseInt(position);
  }
  
  await channel.edit(editOptions);
  
  return {
    success: true,
    channel: {
      id: channel.id,
      name: channel.name
    }
  };
}

export async function deleteChannel(guild, channelId, reason = 'Rias-Grimory-X') {
  const channel = findChannel(guild, channelId);
  if (!channel) throw new Error('Canal não encontrado');
  
  const name = channel.name;
  await channel.delete(reason);
  
  return { success: true, name };
}

export async function cloneChannel(guild, channelId, newName) {
  const channel = findChannel(guild, channelId);
  if (!channel) throw new Error('Canal não encontrado');
  
  const cloned = await channel.clone({
    name: newName || `${channel.name}-copia`,
    reason: 'Rias-Grimory-X'
  });
  
  return {
    success: true,
    original: channel.name,
    cloned: {
      id: cloned.id,
      name: cloned.name,
      mention: `<#${cloned.id}>`
    }
  };
}

export async function lockChannel(guild, channelId, locked = true) {
  const channel = findChannel(guild, channelId);
  if (!channel) throw new Error('Canal não encontrado');
  
  if (locked) {
    await channel.permissionOverwrites.edit(guild.roles.everyone, {
      SendMessages: false,
      SendMessagesInThreads: false
    }, { reason: 'Rias-Grimory-X - Trancar' });
  } else {
    await channel.permissionOverwrites.edit(guild.roles.everyone, {
      SendMessages: null,
      SendMessagesInThreads: null
    }, { reason: 'Rias-Grimory-X - Destrancar' });
  }
  
  return {
    success: true,
    channel: channel.name,
    locked
  };
}

export async function hideChannelFromRole(guild, options) {
  const { channel: channelId, role: roleId, hidden = true } = options;
  
  const channel = findChannel(guild, channelId);
  if (!channel) throw new Error('Canal não encontrado');
  
  const role = findRole(guild, roleId);
  if (!role) throw new Error('Cargo não encontrado');
  
  await channel.permissionOverwrites.edit(role, {
    ViewChannel: hidden ? false : true
  }, { reason: 'Rias-Grimory-X' });
  
  return {
    success: true,
    channel: channel.name,
    role: role.name,
    hidden
  };
}

export async function setChannelPermissions(guild, options) {
  const { channel: channelId, role: roleId, allow = [], deny = [] } = options;
  
  const channel = findChannel(guild, channelId);
  if (!channel) throw new Error('Canal não encontrado');
  
  const role = findRole(guild, roleId);
  if (!role) throw new Error('Cargo não encontrado');
  
  await channel.permissionOverwrites.edit(role, {
    allow: parsePermissions(allow),
    deny: parsePermissions(deny)
  }, { reason: 'Rias-Grimory-X' });
  
  return {
    success: true,
    channel: channel.name,
    role: role.name
  };
}

export async function createCategory(guild, options) {
  const { name, channels = [], permissions = [], preserveStyle = true } = options;
  
  if (!name) throw new Error('Nome da categoria é obrigatório');
  
  // Decorar nome
  let finalName = name;
  if (preserveStyle) {
    try {
      finalName = decorateCategoryName(guild, name);
    } catch (e) {}
  }
  
  const categoryOptions = {
    name: finalName.substring(0, 100),
    type: ChannelType.GuildCategory,
    reason: 'Rias-Grimory-X'
  };
  
  if (permissions.length > 0) {
    categoryOptions.permissionOverwrites = [];
    for (const perm of permissions) {
      const role = perm.role === '@everyone' ? guild.roles.everyone : findRole(guild, perm.role);
      if (role) {
        categoryOptions.permissionOverwrites.push({
          id: role.id,
          allow: parsePermissions(perm.allow),
          deny: parsePermissions(perm.deny)
        });
      }
    }
  }
  
  const category = await guild.channels.create(categoryOptions);
  
  const createdChannels = [];
  for (const ch of channels) {
    try {
      await createChannel(guild, {
        name: ch.name,
        type: ch.type || 'texto',
        parent: category.id,
        topic: ch.topic,
        slowmode: ch.slowmode
      });
      createdChannels.push(ch.name);
      await sleep(200);
    } catch (e) {
      console.error(`Erro ao criar canal ${ch.name}:`, e.message);
    }
  }
  
  return {
    success: true,
    category: {
      id: category.id,
      name: category.name,
      mention: `<#${category.id}>`
    },
    discordCategory: category,
    channels: createdChannels
  };
}

// ============================================
// FERRAMENTAS DE CARGOS
// ============================================

export async function createRole(guild, options) {
  const { name, color, permissions = [], hoist = false, mentionable = false, preserveStyle = true } = options;
  
  if (!name) throw new Error('Nome do cargo é obrigatório');
  
  // Decorar nome e cor
  let finalName = name;
  let finalColor = color;
  
  if (preserveStyle) {
    try {
      finalName = decorateRoleName(guild, name);
      finalColor = suggestRoleColor(guild, color);
    } catch (e) {}
  }
  
  const roleOptions = {
    name: finalName.substring(0, 100),
    color: parseColor(finalColor),
    permissions: parsePermissions(permissions),
    hoist: Boolean(hoist),
    mentionable: Boolean(mentionable),
    reason: 'Rias-Grimory-X'
  };
  
  const role = await guild.roles.create(roleOptions);
  
  return {
    success: true,
    role: {
      id: role.id,
      name: role.name,
      color: role.hexColor,
      mention: `<@&${role.id}>`
    }
  };
}

export async function editRole(guild, options) {
  const { role: roleId, name, color, permissions, hoist, mentionable } = options;
  
  const role = findRole(guild, roleId);
  if (!role) throw new Error('Cargo não encontrado');
  
  const editOptions = { reason: 'Rias-Grimory-X' };
  
  if (name) editOptions.name = name.substring(0, 100);
  if (color !== undefined) editOptions.color = parseColor(color);
  if (permissions) editOptions.permissions = parsePermissions(permissions);
  if (hoist !== undefined) editOptions.hoist = Boolean(hoist);
  if (mentionable !== undefined) editOptions.mentionable = Boolean(mentionable);
  
  await role.edit(editOptions);
  
  return {
    success: true,
    role: {
      id: role.id,
      name: role.name,
      color: role.hexColor
    }
  };
}

export async function deleteRole(guild, roleId, reason = 'Rias-Grimory-X') {
  const role = findRole(guild, roleId);
  if (!role) throw new Error('Cargo não encontrado');
  
  const name = role.name;
  await role.delete(reason);
  
  return { success: true, name };
}

export async function addRoleToMember(guild, options) {
  const { member: memberId, role: roleId, reason = 'Rias-Grimory-X' } = options;
  
  const member = findMember(guild, memberId);
  if (!member) throw new Error('Membro não encontrado');
  
  const role = findRole(guild, roleId);
  if (!role) throw new Error('Cargo não encontrado');
  
  await member.roles.add(role, reason);
  
  return {
    success: true,
    member: member.user.tag,
    role: role.name
  };
}

export async function removeRoleFromMember(guild, options) {
  const { member: memberId, role: roleId, reason = 'Rias-Grimory-X' } = options;
  
  const member = findMember(guild, memberId);
  if (!member) throw new Error('Membro não encontrado');
  
  const role = findRole(guild, roleId);
  if (!role) throw new Error('Cargo não encontrado');
  
  await member.roles.remove(role, reason);
  
  return {
    success: true,
    member: member.user.tag,
    role: role.name
  };
}

export async function cloneRole(guild, roleId, newName) {
  const role = findRole(guild, roleId);
  if (!role) throw new Error('Cargo não encontrado');
  
  const cloned = await guild.roles.create({
    name: newName || `${role.name}-copia`,
    color: role.color,
    permissions: role.permissions,
    hoist: role.hoist,
    mentionable: role.mentionable,
    reason: 'Rias-Grimory-X'
  });
  
  return {
    success: true,
    original: role.name,
    cloned: {
      id: cloned.id,
      name: cloned.name,
      mention: `<@&${cloned.id}>`
    }
  };
}

// ============================================
// FERRAMENTAS DE MEMBROS
// ============================================

export async function kickMember(guild, options) {
  const { member: memberId, reason = 'Rias-Grimory-X' } = options;
  
  const member = findMember(guild, memberId);
  if (!member) throw new Error('Membro não encontrado');
  
  const tag = member.user.tag;
  await member.kick(reason);
  
  return { success: true, tag };
}

export async function banMember(guild, options) {
  const { member: memberId, reason = 'Rias-Grimory-X', deleteMessageDays = 1 } = options;
  
  const member = findMember(guild, memberId);
  if (!member) throw new Error('Membro não encontrado');
  
  const tag = member.user.tag;
  await member.ban({ reason, deleteMessageSeconds: deleteMessageDays * 86400 });
  
  return { success: true, tag };
}

export async function unbanMember(guild, options) {
  const { userId, reason = 'Rias-Grimory-X' } = options;
  
  const cleanId = userId.replace(/[<@!>]/g, '');
  await guild.members.unban(cleanId, reason);
  
  return { success: true, userId: cleanId };
}

export async function muteMember(guild, options) {
  const { member: memberId, duration = 60, reason = 'Rias-Grimory-X' } = options;
  
  const member = findMember(guild, memberId);
  if (!member) throw new Error('Membro não encontrado');
  
  const timeout = Math.min(duration * 60 * 1000, 2419200000);
  await member.timeout(timeout, reason);
  
  return {
    success: true,
    tag: member.user.tag,
    duration: `${duration} minutos`
  };
}

export async function unmuteMember(guild, options) {
  const { member: memberId, reason = 'Rias-Grimory-X' } = options;
  
  const member = findMember(guild, memberId);
  if (!member) throw new Error('Membro não encontrado');
  
  await member.timeout(null, reason);
  
  return { success: true, tag: member.user.tag };
}

export async function setNickname(guild, options) {
  const { member: memberId, nickname, reason = 'Rias-Grimory-X' } = options;
  
  const member = findMember(guild, memberId);
  if (!member) throw new Error('Membro não encontrado');
  
  await member.setNickname(nickname || null, reason);
  
  return {
    success: true,
    tag: member.user.tag,
    newNickname: nickname
  };
}

export async function getMemberInfo(guild, memberId) {
  const member = findMember(guild, memberId);
  if (!member) throw new Error('Membro não encontrado');
  
  return {
    success: true,
    member: {
      id: member.id,
      tag: member.user.tag,
      nickname: member.nickname,
      joinedAt: member.joinedAt,
      roles: member.roles.cache.map(r => r.name).slice(0, 20),
      isOwner: guild.ownerId === member.id,
      isBot: member.user.bot,
      createdAt: member.user.createdAt
    }
  };
}

export async function listMembersByRole(guild, roleId, limit = 50) {
  const role = findRole(guild, roleId);
  if (!role) throw new Error('Cargo não encontrado');
  
  const members = Array.from(guild.members.cache
    .filter(m => m.roles.cache.has(role.id))
    .first(limit))
    .map(m => ({
      tag: m.user.tag,
      id: m.id,
      nickname: m.nickname
    }));
  
  return {
    success: true,
    role: role.name,
    count: members.length,
    members
  };
}

// ============================================
// FERRAMENTAS DE MENSAGENS
// ============================================

export async function bulkDeleteMessages(channel, options) {
  const { amount = 10, userId } = options;
  
  const limit = Math.min(Math.max(1, amount), 100);
  
  let messages = await channel.messages.fetch({ limit: Math.min(limit + 10, 100) });
  
  if (userId) {
    const cleanUserId = userId.replace(/[<@!>]/g, '');
    messages = messages.filter(m => m.author.id === cleanUserId);
  }
  
  const twoWeeksAgo = Date.now() - 1209600000;
  messages = messages.filter(m => m.createdTimestamp > twoWeeksAgo);
  
  const messagesArray = Array.from(messages.values());
  const messagesToDelete = messagesArray.slice(0, limit);
  
  if (messagesToDelete.length === 0) {
    return { success: true, deleted: 0 };
  }
  
  const deleted = await channel.bulkDelete(messagesToDelete, true);
  
  return { success: true, deleted: deleted.size };
}

export async function pinMessage(channel, messageId) {
  const message = await channel.messages.fetch(messageId);
  if (!message) throw new Error('Mensagem não encontrada');
  await message.pin();
  return { success: true, url: message.url };
}

export async function unpinMessage(channel, messageId) {
  const message = await channel.messages.fetch(messageId);
  if (!message) throw new Error('Mensagem não encontrada');
  await message.unpin();
  return { success: true };
}

// ============================================
// FERRAMENTAS DE WEBHOOKS
// ============================================

export async function createWebhook(channel, options) {
  const { name = 'Rias-Grimory-X Webhook', avatar } = options;
  
  const webhook = await channel.createWebhook({
    name,
    avatar,
    reason: 'Rias-Grimory-X'
  });
  
  const webhookUrl = `https://discord.com/api/webhooks/${webhook.id}/${webhook.token}`;
  
  return {
    success: true,
    webhook: {
      id: webhook.id,
      name: webhook.name,
      token: webhook.token,
      url: webhookUrl,
      channel: `<#${channel.id}>`
    }
  };
}

export async function listWebhooks(channel) {
  const webhooks = await channel.fetchWebhooks();
  
  const webhookList = Array.from(webhooks.values()).map(w => ({
    id: w.id,
    name: w.name,
    token: w.token,
    url: w.token ? `https://discord.com/api/webhooks/${w.id}/${w.token}` : null,
    channel: `<#${w.channelId}>`,
    owner: w.owner?.tag
  }));
  
  return { success: true, count: webhookList.length, webhooks: webhookList };
}

export async function listGuildWebhooks(guild) {
  const webhooks = await guild.fetchWebhooks();
  
  const webhookList = Array.from(webhooks.values()).map(w => ({
    id: w.id,
    name: w.name,
    token: w.token,
    url: w.token ? `https://discord.com/api/webhooks/${w.id}/${w.token}` : null,
    channel: w.channel ? `<#${w.channelId}>` : 'Desconhecido'
  }));
  
  return { success: true, count: webhookList.length, webhooks: webhookList };
}

export async function getWebhook(guild, webhookId) {
  const webhooks = await guild.fetchWebhooks();
  const webhook = webhooks.get(webhookId);
  if (!webhook) throw new Error('Webhook não encontrado');
  
  return {
    success: true,
    webhook: {
      id: webhook.id,
      name: webhook.name,
      token: webhook.token,
      url: webhook.token ? `https://discord.com/api/webhooks/${webhook.id}/${webhook.token}` : null,
      channel: webhook.channel ? `<#${webhook.channelId}>` : 'Desconhecido'
    }
  };
}

export async function editWebhook(channel, options) {
  const { webhookId, name, avatar } = options;
  
  const webhooks = await channel.fetchWebhooks();
  const webhook = webhooks.get(webhookId);
  if (!webhook) throw new Error('Webhook não encontrado');
  
  const editOptions = { reason: 'Rias-Grimory-X' };
  if (name) editOptions.name = name;
  if (avatar) editOptions.avatar = avatar;
  
  await webhook.edit(editOptions);
  
  return {
    success: true,
    webhook: {
      id: webhook.id,
      name: webhook.name,
      url: webhook.token ? `https://discord.com/api/webhooks/${webhook.id}/${webhook.token}` : null
    }
  };
}

export async function deleteWebhook(channel, webhookId) {
  const webhooks = await channel.fetchWebhooks();
  const webhook = webhooks.get(webhookId);
  if (!webhook) throw new Error('Webhook não encontrado');
  
  const name = webhook.name;
  await webhook.delete('Rias-Grimory-X');
  
  return { success: true, name };
}

export async function sendWebhookMessage(channel, options) {
  const { webhookId, content, username, avatarURL, embeds } = options;
  
  const webhooks = await channel.fetchWebhooks();
  const webhook = webhooks.get(webhookId);
  if (!webhook) throw new Error('Webhook não encontrado');
  
  const sendOptions = {};
  if (content) sendOptions.content = content;
  if (username) sendOptions.username = username;
  if (avatarURL) sendOptions.avatarURL = avatarURL;
  if (embeds && Array.isArray(embeds)) sendOptions.embeds = embeds;
  
  const message = await webhook.send(sendOptions);
  
  return { success: true, messageId: message.id };
}

// ============================================
// FERRAMENTAS DE CONVITES
// ============================================

export async function createInvite(channel, options = {}) {
  const { maxAge = 86400, maxUses = 0, temporary = false, unique = false } = options;
  
  const invite = await channel.createInvite({
    maxAge,
    maxUses,
    temporary,
    unique,
    reason: 'Rias-Grimory-X'
  });
  
  return {
    success: true,
    invite: {
      code: invite.code,
      url: invite.url,
      expiresAt: invite.expiresAt
    }
  };
}

export async function listInvites(guild) {
  const invites = await guild.invites.fetch();
  
  return {
    success: true,
    invites: Array.from(invites.values()).map(i => ({
      code: i.code,
      channel: i.channel?.name,
      inviter: i.inviter?.tag,
      uses: i.uses,
      maxUses: i.maxUses
    })).slice(0, 50)
  };
}

export async function deleteInvite(guild, code) {
  const invite = await guild.invites.fetch(code);
  if (!invite) throw new Error('Convite não encontrado');
  
  await invite.delete('Rias-Grimory-X');
  
  return { success: true, code };
}

// ============================================
// FERRAMENTAS DE EMOJIS
// ============================================

export async function addEmoji(guild, options) {
  const { name, url, roles = [] } = options;
  
  if (!name || !url) throw new Error('Nome e URL são obrigatórios');
  
  const roleIds = roles.map(r => {
    const role = findRole(guild, r);
    return role?.id;
  }).filter(Boolean);
  
  const emoji = await guild.emojis.create({
    attachment: url,
    name: name.replace(/[^a-zA-Z0-9_]/g, '_').substring(0, 32),
    roles: roleIds,
    reason: 'Rias-Grimory-X'
  });
  
  return {
    success: true,
    emoji: {
      id: emoji.id,
      name: emoji.name,
      string: emoji.toString()
    }
  };
}

export async function deleteEmoji(guild, emojiId) {
  const emoji = guild.emojis.cache.get(emojiId);
  if (!emoji) throw new Error('Emoji não encontrado');
  
  const name = emoji.name;
  await emoji.delete('Rias-Grimory-X');
  
  return { success: true, name };
}

export async function listEmojis(guild) {
  const emojis = guild.emojis.cache.map(e => ({
    id: e.id,
    name: e.name,
    animated: e.animated,
    string: e.toString()
  }));
  
  return {
    success: true,
    count: emojis.length,
    emojis: emojis.slice(0, 100)
  };
}

// ============================================
// INFORMAÇÕES DO SERVIDOR
// ============================================

export async function getServerStats(guild) {
  const textChannels = guild.channels.cache.filter(c => c.type === ChannelType.GuildText).size;
  const voiceChannels = guild.channels.cache.filter(c => c.type === ChannelType.GuildVoice).size;
  const categories = guild.channels.cache.filter(c => c.type === ChannelType.GuildCategory).size;
  
  const humans = guild.members.cache.filter(m => !m.user.bot).size;
  const bots = guild.members.cache.filter(m => m.user.bot).size;
  
  return {
    success: true,
    server: {
      name: guild.name,
      id: guild.id,
      icon: guild.iconURL(),
      ownerId: guild.ownerId,
      createdAt: guild.createdAt,
      memberCount: guild.memberCount,
      humans,
      bots,
      channels: {
        total: guild.channels.cache.size,
        text: textChannels,
        voice: voiceChannels,
        categories
      },
      roles: guild.roles.cache.size,
      emojis: guild.emojis.cache.size,
      boost: {
        level: guild.premiumTier,
        count: guild.premiumSubscriptionCount
      }
    }
  };
}

export async function listChannels(guild, type = 'all') {
  let channels = guild.channels.cache;
  
  if (type === 'texto') {
    channels = channels.filter(c => c.type === ChannelType.GuildText);
  } else if (type === 'voz') {
    channels = channels.filter(c => c.type === ChannelType.GuildVoice);
  } else if (type === 'categorias') {
    channels = channels.filter(c => c.type === ChannelType.GuildCategory);
  }
  
  return {
    success: true,
    channels: Array.from(channels.values()).map(c => ({
      id: c.id,
      name: c.name,
      type: c.type === ChannelType.GuildCategory ? 'categoria' :
            c.type === ChannelType.GuildVoice ? 'voz' : 'texto'
    })).slice(0, 100)
  };
}

export async function listRoles(guild) {
  return {
    success: true,
    roles: Array.from(guild.roles.cache.values())
      .sort((a, b) => b.position - a.position)
      .map(r => ({
        id: r.id,
        name: r.name,
        color: r.hexColor,
        position: r.position,
        members: r.members.size
      }))
  };
}

// ============================================
// EXPORTAÇÕES
// ============================================

export default {
  // Canais
  createChannel,
  editChannel,
  deleteChannel,
  cloneChannel,
  lockChannel,
  hideChannelFromRole,
  setChannelPermissions,
  createCategory,
  
  // Cargos
  createRole,
  editRole,
  deleteRole,
  addRoleToMember,
  removeRoleFromMember,
  cloneRole,
  
  // Membros
  kickMember,
  banMember,
  unbanMember,
  muteMember,
  unmuteMember,
  setNickname,
  getMemberInfo,
  listMembersByRole,
  
  // Mensagens
  bulkDeleteMessages,
  pinMessage,
  unpinMessage,
  
  // Webhooks
  createWebhook,
  listWebhooks,
  listGuildWebhooks,
  getWebhook,
  editWebhook,
  deleteWebhook,
  sendWebhookMessage,
  
  // Convites
  createInvite,
  listInvites,
  deleteInvite,
  
  // Emojis
  addEmoji,
  deleteEmoji,
  listEmojis,
  
  // Informações
  getServerStats,
  listChannels,
  listRoles,
  
  // Utilitários
  findChannel,
  findRole,
  findMember,
  parseColor,
  parsePermissions
};
