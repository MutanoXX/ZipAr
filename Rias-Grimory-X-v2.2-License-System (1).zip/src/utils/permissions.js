/**
 * MutanoX Architect - Sistema de Permissões (Compatibilidade)
 * Integração com sistema por servidor
 * 
 * VERSÃO 2.0 - Permissões por servidor
 */

import {
  initServerConfig,
  checkServerPermission,
  isServerOwner as checkIsServerOwner,
  isServerAdmin,
  getBotOwnerId,
  isBotOwner,
  addAllowedRole as addAllowedRoleToServer,
  removeAllowedRole as removeAllowedRoleFromServer,
  getAllServerConfigs,
  getServerConfig
} from './serverPermissions.js';

// Re-exportar funções do novo sistema
export {
  initServerConfig,
  checkServerPermission,
  isServerAdmin,
  getBotOwnerId,
  isBotOwner,
  getAllServerConfigs,
  getServerConfig
};

/**
 * Verifica se um usuário tem permissão para usar comandos (compatibilidade)
 * NOTA: Esta função agora requer contexto do servidor
 * @param {string} userId - ID do usuário
 * @param {Object} context - Contexto opcional { guild, member }
 * @returns {boolean}
 */
export function isAuthorized(userId, context = null) {
  // Dono do bot sempre tem acesso
  if (isBotOwner(userId)) return true;
  
  // Se não tem contexto, permitir apenas dono do bot
  if (!context || !context.guild) {
    console.warn('⚠️ [Permissions] isAuthorized chamado sem contexto de servidor');
    return false;
  }
  
  const { guild, member } = context;
  const result = checkServerPermission(guild, { id: userId }, member);
  return result.authorized;
}

/**
 * Verifica se o usuário é dono do servidor específico
 * @param {string} userId - ID do usuário
 * @param {Object} context - Contexto { guild }
 * @returns {boolean}
 */
export function isServerOwner(userId, context = null) {
  if (isBotOwner(userId)) return true;
  
  if (!context || !context.guild) {
    return false;
  }
  
  return checkIsServerOwner(context.guild, userId);
}

/**
 * Verifica se o usuário pode executar comandos críticos (delete-server)
 * APENAS dono do servidor ou dono do bot
 * @param {string} userId - ID do usuário
 * @param {Object} context - Contexto { guild }
 * @returns {boolean}
 */
export function canExecuteCritical(userId, context = null) {
  // Dono do bot pode tudo
  if (isBotOwner(userId)) return true;
  
  if (!context || !context.guild) {
    return false;
  }
  
  // Apenas dono do servidor pode executar comandos críticos
  return checkIsServerOwner(context.guild, userId);
}

/**
 * Compatibilidade: Mantém funções antigas para não quebrar código existente
 * Estas funções agora são obsoletas e devem ser substituídas
 */

// Lista de usuários autorizados globalmente (obsoleto, mantido para compatibilidade)
const authorizedUsers = new Set();

/**
 * Adiciona um usuário autorizado (obsoleto)
 * @deprecated Use checkServerPermission no lugar
 */
export function addAuthorizedUser(userId) {
  console.warn('⚠️ [Permissions] addAuthorizedUser está obsoleto. Use sistema por servidor.');
  if (isBotOwner(userId)) return false;
  if (authorizedUsers.has(userId)) return false;
  authorizedUsers.add(userId);
  return true;
}

/**
 * Remove um usuário autorizado (obsoleto)
 * @deprecated Use sistema por servidor
 */
export function removeAuthorizedUser(userId) {
  console.warn('⚠️ [Permissions] removeAuthorizedUser está obsoleto. Use sistema por servidor.');
  if (isBotOwner(userId)) return false;
  return authorizedUsers.delete(userId);
}

/**
 * Retorna a lista de usuários autorizados (obsoleto)
 * @deprecated Use sistema por servidor
 */
export function getAuthorizedUsers() {
  console.warn('⚠️ [Permissions] getAuthorizedUsers está obsoleto. Use sistema por servidor.');
  return [getBotOwnerId(), ...Array.from(authorizedUsers)];
}

/**
 * Verifica se o usuário é o dono do bot
 * @param {string} userId - ID do usuário
 * @returns {boolean}
 */
export function isOwner(userId) {
  return isBotOwner(userId);
}

/**
 * Retorna o ID do dono
 * @returns {string}
 */
export function getOwnerId() {
  return getBotOwnerId();
}

/**
 * Função helper para verificar permissão completa
 * @param {Interaction|Message} interaction - Interação ou mensagem do Discord
 * @returns {Object} { authorized: boolean, reason: string, isCritical: boolean }
 */
export function verifyPermission(interaction) {
  const userId = interaction.user?.id;
  const guild = interaction.guild;
  const member = interaction.member;
  
  if (!userId) {
    return { authorized: false, reason: 'Usuário não identificado', isCritical: false };
  }
  
  if (!guild) {
    return { authorized: false, reason: 'Este comando só pode ser usado em servidores', isCritical: false };
  }
  
  const result = checkServerPermission(guild, { id: userId }, member);
  const isCritical = checkIsServerOwner(guild, userId) || isBotOwner(userId);
  
  return {
    authorized: result.authorized,
    reason: result.reason,
    isCritical: isCritical
  };
}

/**
 * Adiciona um cargo à lista de permitidos no servidor
 * @param {string} guildId - ID do servidor
 * @param {string} roleId - ID do cargo
 * @returns {boolean}
 */
export function addAllowedRole(guildId, roleId) {
  return addAllowedRoleToServer(guildId, roleId);
}

/**
 * Remove um cargo da lista de permitidos
 * @param {string} guildId - ID do servidor
 * @param {string} roleId - ID do cargo
 * @returns {boolean}
 */
export function removeAllowedRole(guildId, roleId) {
  return removeAllowedRoleFromServer(guildId, roleId);
}

export default {
  isAuthorized,
  isServerOwner,
  isOwner,
  isBotOwner,
  getOwnerId,
  getBotOwnerId,
  canExecuteCritical,
  addAuthorizedUser,
  removeAuthorizedUser,
  getAuthorizedUsers,
  verifyPermission,
  initServerConfig,
  checkServerPermission,
  isServerAdmin,
  addAllowedRole,
  removeAllowedRole,
  getAllServerConfigs,
  getServerConfig
};
