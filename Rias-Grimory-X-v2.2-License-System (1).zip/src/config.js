/**
 * MutanoX Architect - Configurações do Bot
 * @version 2.1.0
 * @author MutanoX
 */

/**
 * @typedef {Object} BotConfig
 * @property {string} token - Token do Discord
 * @property {string} clientId - ID do cliente
 * @property {string} prefix - Prefixo do bot
 * @property {string} language - Idioma padrão
 * @property {Object} colors - Cores do tema
 * @property {Object} emojis - Emojis padrão
 */

/**
 * Configurações do bot
 * @type {BotConfig}
 */
export const config = {
  // Discord
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.DISCORD_CLIENT_ID,
  
  // Bot Settings
  prefix: process.env.BOT_PREFIX || '/',
  language: process.env.DEFAULT_LANGUAGE || 'pt-BR',
  
  // Cores do tema MutanoX
  colors: {
    primary: '#8B5CF6',    // Roxo MutanoX
    success: '#10B981',    // Verde
    error: '#EF4444',      // Vermelho
    warning: '#F59E0B',    // Amarelo
    info: '#3B82F6',       // Azul
    crimson: '#DC143C'     // Crimson (Rias)
  },
  
  // Emojis
  emojis: {
    success: '✅',
    error: '❌',
    warning: '⚠️',
    loading: '⏳',
    architecture: '🏗️',
    analysis: '🔍',
    roles: '👥',
    channels: '📢',
    settings: '⚙️',
    rose: '🌹',
    diamond: '💎',
    star: '⭐'
  },

  // Timeouts (ms)
  timeouts: {
    api: 30000,
    discord: 15000,
    ai: 120000
  },

  // Limites
  limits: {
    maxContextMessages: 60,
    maxChannelsPerCategory: 50,
    maxRolesPerServer: 250,
    maxAutomationsPerServer: 10
  }
};

/**
 * Valida se a configuração está completa
 * @returns {{valid: boolean, missing: string[]}}
 */
export function validateConfig() {
  const required = ['token', 'clientId'];
  const missing = required.filter(key => !config[key]);
  
  return {
    valid: missing.length === 0,
    missing
  };
}

/**
 * Obtém uma cor pelo nome
 * @param {string} name - Nome da cor
 * @returns {string} Código hex da cor
 */
export function getColor(name) {
  return config.colors[name] || config.colors.primary;
}

/**
 * Obtém um emoji pelo nome
 * @param {string} name - Nome do emoji
 * @returns {string} Emoji
 */
export function getEmoji(name) {
  return config.emojis[name] || '❓';
}

export default config;
