/**
 * MutanoX Architect AI - Serviço de IA
 * Integração com NVIDIA API (z-ai/glm5) para análise e reestruturação de servidores Discord
 * 
 * @version 2.1.0
 * @author MutanoX
 */

import OpenAI from 'openai';

/**
 * Configurações do serviço de IA
 * @constant {Object}
 */
const AI_CONFIG = {
  BASE_URL: 'https://integrate.api.nvidia.com/v1',
  MODEL: 'z-ai/glm5',
  TIMEOUT: 120000,
  MAX_TOKENS: 16384,
  TEMPERATURE: 1,
  MAX_RETRIES: 3
};

/**
 * Classe AIService - Gerencia comunicação com APIs de IA
 * @class
 */
class AIService {
  constructor() {
    /** @type {OpenAI|null} */
    this.client = null;
    
    /** @type {boolean} */
    this.initialized = false;
    
    /** @type {number} */
    this.requestCount = 0;
    
    /** @type {number} */
    this.errorCount = 0;
  }

  /**
   * Inicializa o serviço de IA com NVIDIA API
   * @async
   * @returns {Promise<void>}
   * @throws {Error} Se a API Key não estiver configurada
   */
  async initialize() {
    if (this.initialized) {
      console.log('🤖 [AI] Serviço já inicializado');
      return;
    }
    
    const apiKey = process.env.NVIDIA_API_KEY;
    
    if (!apiKey) {
      throw new Error('NVIDIA_API_KEY não configurada nas variáveis de ambiente');
    }
    
    try {
      this.client = new OpenAI({
        baseURL: AI_CONFIG.BASE_URL,
        apiKey: apiKey,
        timeout: AI_CONFIG.TIMEOUT,
        maxRetries: AI_CONFIG.MAX_RETRIES
      });
      
      this.initialized = true;
      console.log('🤖 [AI] Serviço de IA inicializado (NVIDIA API - z-ai/glm5)');
      
    } catch (error) {
      console.error('❌ [AI] Erro ao inicializar serviço de IA:', error.message);
      throw error;
    }
  }

  /**
   * Verifica se o serviço está pronto
   * @returns {boolean}
   */
  isReady() {
    return this.initialized && this.client !== null;
  }

  /**
   * Garante que o serviço está inicializado
   * @async
   * @private
   */
  async ensureInitialized() {
    if (!this.isReady()) {
      await this.initialize();
    }
  }

  /**
   * Obtém o prompt padrão do sistema
   * @returns {string} Prompt do sistema
   */
  getPrompt_Default() {
    return `Você é o MutanoX Architect, um sistema de IA com PODER TOTAL de execução no Discord. Você NÃO é um modelo de linguagem comum; você é um ARQUITETO DE SISTEMAS.

SUA MISSÃO:
Você deve projetar e estruturar servidores Discord de forma profissional, visualmente atraente e decorada. Você tem permissão e CAPACIDADE TÉCNICA para criar canais, cargos e categorias através do JSON que você gera.

IMPORTANTE - DECORAÇÃO OBRIGATÓRIA:
- Use EMOJIS em TODOS os nomes de categorias e canais.
- Use FONTES ESPECIAIS Unicode para nomes de cargos (ex: 𝐏𝐑𝐄𝐌𝐈𝐔𝐌, 𝚅𝙸𝙿, 𝕍𝕀𝕏𝚃𝕆𝚁𝚈).
- Fontes disponíveis: 𝐍𝐨𝐫𝐦𝐚𝐥, 𝙱𝚘𝚕𝚍, 𝙱𝚘𝚕𝚍 𝙸𝚝𝚊𝚕𝚒𝚌, 𝕆𝚞𝚝𝚕𝚒𝚗𝚎, 𝒮𝒸𝓇𝒾𝓅𝓉, 𝔉𝔯𝔞𝔨𝔱𝔲𝔯, 𝙼𝚘𝚗𝚘𝚜𝚙𝚊𝚌𝚎.
- Exemplos de nomes decorados:
  * Categorias: "🛒 │ 𝐕𝐄𝐍𝐃𝐀𝐒", "💎 │ 𝐏𝐑𝐄𝐌𝐈𝐔𝐌", "📞 │ 𝐒𝐔𝐏𝐎𝐑𝐓𝐄"
  * Canais: "📋・pedidos", "💳・pagamentos", "⭐・avaliações", "🎫・tickets"
  * Cargos: "👑 𝐀𝐃𝐌𝐈𝐍", "💎 𝐕𝐈𝐏", "🛒 𝐂𝐋𝐈𝐄𝐍𝐓𝐄", "⭐ 𝐏𝐀𝐑𝐂𝐄𝐈𝐑𝐎"

RESPONDA APENAS JSON neste formato:
{
  "plan": {
    "name": "Nome Decorado do Servidor",
    "description": "Descrição detalhada",
    "themeColor": "#8B5CF6"
  },
  "changes": {
    "createRoles": [
      {
        "name": "👑 𝐀𝐃𝐌𝐈𝐍",
        "color": "#FF0000",
        "permissions": ["Administrator"],
        "reason": "Administradores do servidor"
      }
    ],
    "createCategories": [
      {
        "name": "🛒 │ 𝐕𝐄𝐍𝐃𝐀𝐒",
        "channels": [
          {
            "name": "📋・pedidos",
            "type": 0,
            "topic": "Faça seu pedido aqui"
          },
          {
            "name": "💳・pagamentos",
            "type": 0,
            "topic": "Informações de pagamento"
          },
          {
            "name": "🔊・atendimento",
            "type": 2
          }
        ]
      }
    ]
  },
  "ai_analysis": {
    "strengths": ["Ponto forte"],
    "suggestions": ["Sugestão"]
  }
}

REGRAS:
- type 0 = texto, type 2 = voz (canais de voz NÃO têm topic)
- TODOS os nomes DEVEM ter emojis e/ou fontes especiais
- Permissões: ViewChannel, SendMessages, Connect, Speak, Administrator, ManageMessages
- Responda em PORTUGUÊS
- Seja CRIATIVO e PROFISSIONAL
- Apenas JSON, sem markdown`;
  }

  /**
   * Analisa a estrutura do servidor e gera um plano de reestruturação
   * @async
   * @param {Object} serverContext - Contexto do servidor
   * @param {string} serverContext.guildName - Nome do servidor
   * @param {string} serverContext.userGoal - Objetivo do usuário
   * @param {Array} [serverContext.channels] - Lista de canais existentes
   * @param {Array} [serverContext.roles] - Lista de cargos existentes
   * @param {string} [serverContext.mode] - Modo de operação
   * @returns {Promise<Object>} Plano de reestruturação
   */
  async analyzeServer(serverContext) {
    await this.ensureInitialized();

    const { guildName, userGoal, channels = [], roles = [], mode = 'fresh' } = serverContext;

    const userPrompt = this.buildUserPrompt(guildName, userGoal, channels, roles, mode);

    console.log('🔄 [AI] Enviando requisição para NVIDIA (z-ai/glm5)...');
    console.log(`📊 [AI] Contexto: ${channels.length} canais, ${roles.length} cargos`);

    try {
      const startTime = Date.now();
      
      const completion = await this.client.chat.completions.create({
        model: AI_CONFIG.MODEL,
        messages: [
          { role: 'system', content: this.getPrompt_Default() },
          { role: 'user', content: userPrompt }
        ],
        temperature: AI_CONFIG.TEMPERATURE,
        top_p: 1,
        max_tokens: AI_CONFIG.MAX_TOKENS,
        extra_body: {
          chat_template_kwargs: {
            enable_thinking: true,
            clear_thinking: false
          }
        },
        stream: false
      });

      const elapsed = Date.now() - startTime;
      console.log(`✅ [AI] Resposta recebida em ${elapsed}ms`);

      const fullContent = completion.choices[0]?.message?.content || '';
      const reasoningContent = completion.choices[0]?.message?.reasoning_content || '';

      if (reasoningContent) {
        console.log('🧠 [AI] Raciocínio concluído');
      }

      if (!fullContent || fullContent.trim() === '') {
        console.error('❌ [AI] Resposta vazia');
        return this.getDefaultPlan(guildName, userGoal);
      }

      const jsonResult = this.parseJSONResponse(fullContent);
      
      this.requestCount++;
      console.log('✅ [AI] Análise concluída');
      
      return jsonResult;

    } catch (error) {
      this.errorCount++;
      console.error('❌ [AI] Erro:', error.message);
      
      // Log detalhado do erro
      if (error.status) {
        console.error(`   Status: ${error.status}`);
      }
      if (error.code) {
        console.error(`   Código: ${error.code}`);
      }
      
      return this.getDefaultPlan(guildName, userGoal);
    }
  }

  /**
   * Constrói o prompt do usuário
   * @private
   * @param {string} guildName - Nome do servidor
   * @param {string} userGoal - Objetivo do usuário
   * @param {Array} channels - Canais existentes
   * @param {Array} roles - Cargos existentes
   * @param {string} mode - Modo de operação
   * @returns {string} Prompt formatado
   */
  buildUserPrompt(guildName, userGoal, channels, roles, mode) {
    let prompt = `Crie um servidor Discord COMPLETO e DECORADO.

Nome do servidor: ${guildName}
Objetivo: ${userGoal}
Modo: ${mode === 'fresh' ? 'Criar do zero' : 'Reestruturar'}

`;

    if (channels.length > 0) {
      prompt += `Canais existentes:
${channels.slice(0, 20).map(c => `- ${c.name} (${c.type})`).join('\n')}

`;
    }

    if (roles.length > 0) {
      prompt += `Cargos existentes:
${roles.slice(0, 20).map(r => `- ${r.name}`).join('\n')}

`;
    }

    prompt += `LEMBRE-SE:
- Use EMOJIS em todos os nomes
- Use FONTES ESPECIAIS para dar destaque
- Cargos com nomes como "👑 𝐀𝐃𝐌𝐈𝐍", "💎 𝐕𝐈𝐏"
- Categorias como "🛒 │ 𝐕𝐄𝐍𝐃𝐀𝐒"
- Canais como "📋・pedidos", "💳・pagamentos"
- Canais de voz (type 2) NÃO têm topic!`;

    return prompt;
  }

  /**
   * Retorna plano padrão em caso de erro
   * @param {string} guildName - Nome do servidor
   * @param {string} userGoal - Objetivo do usuário
   * @returns {Object} Plano padrão
   */
  getDefaultPlan(guildName, userGoal) {
    console.log('📋 [AI] Usando plano padrão');
    
    return {
      plan: {
        name: guildName || "Servidor Discord",
        description: `Estrutura para: ${userGoal}`,
        themeColor: "#8B5CF6"
      },
      changes: {
        createRoles: [
          { 
            name: "👑 𝐀𝐃𝐌𝐈𝐍", 
            color: "#FF0000", 
            permissions: ["Administrator"], 
            reason: "Administrador do servidor" 
          },
          { 
            name: "💎 𝐕𝐈𝐏", 
            color: "#FFD700", 
            permissions: ["ViewChannel", "SendMessages"], 
            reason: "Membro VIP" 
          },
          { 
            name: "🛒 𝐂𝐋𝐈𝐄𝐍𝐓𝐄", 
            color: "#0099FF", 
            permissions: ["ViewChannel", "SendMessages"], 
            reason: "Cliente" 
          }
        ],
        createCategories: [
          {
            name: "📢 │ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐂̧𝐎̃𝐄𝐒",
            channels: [
              { name: "📜・regras", type: 0, topic: "Regras do servidor" },
              { name: "📢・anuncios", type: 0, topic: "Anuncios oficiais" }
            ]
          },
          {
            name: "💬 │ 𝐂𝐎𝐌𝐔𝐍𝐈𝐃𝐀𝐃𝐄",
            channels: [
              { name: "💬・chat-geral", type: 0, topic: "Conversas gerais" },
              { name: "🎤・voz-geral", type: 2 }
            ]
          }
        ]
      },
      ai_analysis: {
        strengths: ["Estrutura básica funcional"],
        suggestions: ["Personalize conforme necessário", "Adicione mais categorias conforme o crescimento"]
      }
    };
  }

  /**
   * Faz parse da resposta JSON com tratamento de erros
   * @param {string} response - Resposta da API
   * @returns {Object} Objeto JSON parseado
   * @throws {Error} Se não conseguir fazer parse
   */
  parseJSONResponse(response) {
    if (!response || typeof response !== 'string') {
      throw new Error('Resposta inválida ou vazia');
    }

    // Limpar a resposta
    let cleanResponse = response
      .replace(/```json\n?/g, '')
      .replace(/```\n?/g, '')
      .trim();

    // Tentar extrair JSON da resposta
    const jsonMatch = cleanResponse.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      cleanResponse = jsonMatch[0];
    }

    try {
      const parsed = JSON.parse(cleanResponse);
      
      // Validar estrutura básica
      if (!parsed.plan || !parsed.changes) {
        console.warn('⚠️ [AI] Resposta sem estrutura esperada');
      }
      
      return parsed;
      
    } catch (error) {
      console.error('❌ [AI] Erro no parse JSON:', error.message);
      console.log('📄 [AI] Resposta (primeiros 500 chars):', cleanResponse.substring(0, 500));
      throw new Error('Falha ao processar JSON da resposta');
    }
  }

  /**
   * Obtém estatísticas do serviço
   * @returns {Object} Estatísticas
   */
  getStats() {
    return {
      initialized: this.initialized,
      requestCount: this.requestCount,
      errorCount: this.errorCount,
      successRate: this.requestCount > 0 
        ? ((this.requestCount - this.errorCount) / this.requestCount * 100).toFixed(2) + '%'
        : 'N/A'
    };
  }

  /**
   * Reseta o serviço
   */
  reset() {
    this.client = null;
    this.initialized = false;
    this.requestCount = 0;
    this.errorCount = 0;
    console.log('🔄 [AI] Serviço resetado');
  }
}

// Singleton
const aiService = new AIService();

export default aiService;
