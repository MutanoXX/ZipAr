/**
 * MutanoX Architect - Comando /info
 * Mostra informações técnicas e status do bot
 * 
 * VERSÃO 2.0 - Com informações por servidor
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  MessageFlags
} from 'discord.js';
import { getStats } from '../utils/activeChannels.js';
import { getAllServerConfigs, getBotOwnerId } from '../utils/permissions.js';

export const data = new SlashCommandBuilder()
  .setName('info')
  .setDescription('📊 Informações técnicas do bot');

export async function execute(interaction) {
  const client = interaction.client;
  const stats = getStats();
  const serverConfigs = getAllServerConfigs();
  
  // Calcular uptime
  const uptime = process.uptime();
  const days = Math.floor(uptime / 86400);
  const hours = Math.floor((uptime % 86400) / 3600);
  const minutes = Math.floor((uptime % 3600) / 60);
  
  const uptimeString = `${days}d ${hours}h ${minutes}m`;
  
  // Memória
  const memoryUsage = process.memoryUsage();
  const memoryMB = Math.round(memoryUsage.heapUsed / 1024 / 1024);
  
  const mainEmbed = new EmbedBuilder()
    .setTitle('🏗️ MutanoX Architect AI')
    .setDescription('Bot Discord para análise e reestruturação de servidores usando IA')
    .setColor('#8B5CF6')
    .setThumbnail(client.user.displayAvatarURL())
    .addFields(
      { name: '🤖 Bot', value: `${client.user.tag}`, inline: true },
      { name: '📊 Versão', value: '2.0.0', inline: true },
      { name: '⏱️ Uptime', value: uptimeString, inline: true },
      { name: '💾 Memória', value: `${memoryMB} MB`, inline: true },
      { name: '📍 Servidores', value: `${client.guilds.cache.size}`, inline: true },
      { name: '👥 Usuários', value: `${client.users.cache.size}`, inline: true }
    )
    .setTimestamp();
  
  // Embed de IA
  const aiEmbed = new EmbedBuilder()
    .setTitle('🧠 Estatísticas da IA')
    .setColor('#10B981')
    .addFields(
      { name: '🖥️ Servidores Ativos', value: `${stats.totalServers}`, inline: true },
      { name: '💬 Canais Ativos', value: `${stats.totalChannels}`, inline: true },
      { name: '📝 Mensagens em Contexto', value: `${stats.totalMessages}`, inline: true },
      { name: '🧠 Limite de Contexto', value: `${stats.contextLimit} mensagens`, inline: true },
      { name: '⏰ Expiração', value: '2 horas', inline: true },
      { name: '🚀 Modelo IA', value: 'Step-3.5-Flash', inline: true }
    );
  
  // Embed de permissões
  const permissionsEmbed = new EmbedBuilder()
    .setTitle('🔐 Sistema de Permissões')
    .setColor('#F59E0B')
    .setDescription('**Sistema por servidor:**\n' +
      '• Cada servidor tem suas próprias configurações\n' +
      '• Apenas admins e donos podem usar a IA\n' +
      '• `/delete-server` exclusivo para dono do servidor\n' +
      '• Contexto isolado por servidor')
    .addFields(
      { name: '👑 Dono do Bot', value: `<@${getBotOwnerId()}>`, inline: true }
    );
  
  // Embed de funcionalidades
  const featuresEmbed = new EmbedBuilder()
    .setTitle('✨ Funcionalidades')
    .setColor('#EC4899')
    .setDescription(
      '📁 **Gestão de Canais:**\n' +
      '• Criar categorias e canais\n' +
      '• Renomear e organizar\n' +
      '• Configurar permissões\n\n' +
      '👥 **Gestão de Cargos:**\n' +
      '• Criar cargos personalizados\n' +
      '• Atribuir/remover cargos\n' +
      '• Configurar hierarquias\n\n' +
      '🎨 **Decoração:**\n' +
      '• Fontes Unicode especiais\n' +
      '• Emojis temáticos\n' +
      '• Embeds profissionais\n\n' +
      '🔧 **Ferramentas:**\n' +
      '• Geração de imagens\n' +
      '• Busca no Google\n' +
      '• Geração de arquivos\n' +
      '• Estatísticas do servidor'
    );
  
  await interaction.reply({
    embeds: [mainEmbed, aiEmbed, permissionsEmbed, featuresEmbed],
    flags: MessageFlags.Ephemeral
  });
}

export default { data, execute };
