/**
 * Rias-Grimory-X - Comando /support
 * Cria um canal de suporte para renovação de licença
 * 
 * @version 2.1.0
 * @author MutanoX
 * 
 * EXCLUSIVO PARA USUÁRIOS COM LICENÇA (ativa ou expirada)
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
  ChannelType
} from 'discord.js';
import licenseManager from '../utils/licenseManager.js';

export const data = new SlashCommandBuilder()
  .setName('support')
  .setDescription('🎫 Abre um canal de suporte para renovação de licença');

export async function execute(interaction) {
  const userId = interaction.user.id;
  const user = interaction.user;
  const guild = interaction.guild;
  const member = interaction.member;

  // Verificar se está em servidor
  if (!guild) {
    return interaction.reply({
      content: '❌ Este comando só pode ser usado em um servidor.',
      flags: MessageFlags.Ephemeral
    });
  }

  // Verificar se o usuário tem licença (ativa ou expirada)
  if (!licenseManager.hasLicense(userId)) {
    return interaction.reply({
      content: `❌ **Você não possui uma licença!**\n\nUse \`/redeem-access\` para ativar uma licença com um código de acesso.\n\n[Servidor de Suporte](${licenseManager.getSupportServerLink()})`,
      flags: MessageFlags.Ephemeral
    });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  try {
    const result = await licenseManager.createSupportChannel(guild, userId, user, member);

    if (!result.success) {
      return interaction.editReply({
        content: `❌ **Erro:** ${result.error}`
      });
    }

    const channel = result.channel;
    const license = licenseManager.getUserLicense(userId);
    const timeRemaining = licenseManager.getLicenseTimeRemaining(userId);

    // Enviar mensagem no canal criado
    const welcomeEmbed = new EmbedBuilder()
      .setTitle('🎫 Canal de Suporte para Renovação')
      .setDescription(`Olá <@${userId}>! Este é seu canal de suporte para renovação de licença.`)
      .setColor(timeRemaining.valid ? '#10B981' : '#EF4444')
      .addFields(
        { 
          name: '👤 Usuário', 
          value: `${user.tag}\n<@${userId}>`, 
          inline: true 
        },
        { 
          name: '📦 Tipo de Licença', 
          value: license?.type || 'N/A', 
          inline: true 
        },
        { 
          name: '⏰ Status', 
          value: timeRemaining.valid 
            ? `✅ Ativa - ${timeRemaining.formatted} restantes` 
            : '❌ Expirada', 
          inline: true 
        },
        {
          name: '📋 O que você deseja?',
          value: 'Aguarde um **Administrador** para assistência.\nEnquanto isso, descreva o que você precisa:',
          inline: false
        }
      )
      .addFields({
        name: '💡 Opções Comuns',
        value: '• Renovar licença existente\n• Trocar tipo de licença\n• Tirar dúvidas\n• Reportar problemas',
        inline: false
      })
      .setThumbnail(user.displayAvatarURL({ size: 256 }))
      .setTimestamp()
      .setFooter({ text: '💎 Rias-Grimory-X Bot | Aguarde um administrador' });

    // Botões de ação
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('support_renew_weekly')
          .setLabel('📅 Renovar Semanal')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('support_renew_monthly')
          .setLabel('📅 Renovar Mensal')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('support_close')
          .setLabel('❌ Fechar Ticket')
          .setStyle(ButtonStyle.Danger)
      );

    await channel.send({
      content: `<@${userId}> <@${licenseManager.getBotOwnerId()}>`,
      embeds: [welcomeEmbed],
      components: [row]
    });

    // Responder ao usuário
    const replyEmbed = new EmbedBuilder()
      .setTitle('✅ Canal de Suporte Criado!')
      .setDescription(`Seu canal de suporte foi criado: ${channel}`)
      .setColor('#10B981')
      .addFields({
        name: '📝 Próximos Passos',
        value: '1. Vá até o canal criado\n2. Descreva o que você precisa\n3. Aguarde um administrador',
        inline: false
      })
      .setTimestamp();

    await interaction.editReply({ embeds: [replyEmbed] });

    console.log(`🎫 [Support] Canal criado para ${user.tag} (${userId}) em ${guild.name}`);

  } catch (error) {
    console.error('❌ [Support] Erro:', error);
    await interaction.editReply({
      content: `❌ Erro ao criar canal de suporte: ${error.message}\n\nVerifique se o bot tem permissão para criar canais.`
    });
  }
}

/**
 * Handler para botões do suporte
 */
export async function handleSupportButton(interaction) {
  const customId = interaction.customId;
  const userId = interaction.user.id;
  const channel = interaction.channel;

  if (customId === 'support_close') {
    // Verificar se é o dono do ticket ou admin
    const license = licenseManager.getUserLicense(userId);
    
    if (!licenseManager.isBotOwner(userId) && license?.userId !== userId) {
      return interaction.reply({
        content: '❌ Apenas o criador do ticket ou um administrador pode fechar.',
        flags: MessageFlags.Ephemeral
      });
    }

    await interaction.reply({
      content: '🔒 Fechando ticket em 5 segundos...'
    });

    setTimeout(async () => {
      try {
        licenseManager.closeSupportChannel(channel.id, userId);
        await channel.delete('Ticket fechado pelo usuário');
      } catch (error) {
        console.error('Erro ao fechar ticket:', error.message);
      }
    }, 5000);

  } else if (customId === 'support_renew_weekly' || customId === 'support_renew_monthly') {
    const tipo = customId === 'support_renew_weekly' ? 'semanal' : 'mensal';
    
    await interaction.reply({
      content: `📝 **Solicitação de Renovação ${tipo}**\n\nUm administrador irá processar sua solicitação em breve.\nPor favor, aguarde.`,
      allowedMentions: { parse: [] }
    });
  }
}

export default { data, execute, handleSupportButton };
