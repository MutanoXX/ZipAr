/**
 * Rias-Grimory-X - Comando /license
 * Mostra informações da licença do usuário
 * 
 * @version 2.1.0
 * @author MutanoX
 * 
 * PÚBLICO - Qualquer usuário pode usar para ver sua licença
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  MessageFlags
} from 'discord.js';
import licenseManager from '../utils/licenseManager.js';

export const data = new SlashCommandBuilder()
  .setName('license')
  .setDescription('📋 Mostra informações da sua licença')
  .addUserOption(opt =>
    opt
      .setName('usuario')
      .setDescription('Ver licença de outro usuário (apenas dono)')
      .setRequired(false)
  );

export async function execute(interaction) {
  const requesterId = interaction.user.id;
  const targetUser = interaction.options.getUser('usuario') || interaction.user;
  
  // Se está verificando outro usuário, precisa ser dono
  if (targetUser.id !== requesterId && !licenseManager.isBotOwner(requesterId)) {
    return interaction.reply({
      content: '❌ Você não tem permissão para ver a licença de outros usuários.',
      flags: MessageFlags.Ephemeral
    });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  try {
    // Se for o dono do bot
    if (licenseManager.isBotOwner(targetUser.id)) {
      const stats = licenseManager.getLicenseStats();
      
      const ownerEmbed = new EmbedBuilder()
        .setTitle('👑 Dono do Bot')
        .setDescription('Você é o **Dono do Bot** e tem acesso total e permanente!')
        .setColor('#FFD700')
        .addFields(
          { name: '📊 Total de Usuários', value: `${stats.totalUsers}`, inline: true },
          { name: '✅ Licenças Ativas', value: `${stats.activeLicenses}`, inline: true },
          { name: '❌ Licenças Expiradas', value: `${stats.expiredLicenses}`, inline: true },
          { name: '🎫 Códigos Não Usados', value: `${stats.unusedCodes}`, inline: true },
          { name: '🎫 Tickets Abertos', value: `${stats.openTickets}`, inline: true }
        )
        .setTimestamp()
        .setFooter({ text: '💎 Rias-Grimory-X Bot' });

      return interaction.editReply({ embeds: [ownerEmbed] });
    }

    const license = licenseManager.getUserLicense(targetUser.id);
    const timeRemaining = licenseManager.getLicenseTimeRemaining(targetUser.id);

    if (!license) {
      const noLicenseEmbed = new EmbedBuilder()
        .setTitle('❌ Sem Licença')
        .setDescription('Você não possui uma licença ativa.')
        .setColor('#EF4444')
        .addFields(
          { 
            name: '🔑 Como obter?', 
            value: 'Use `/redeem-access` com um código de acesso válido para ativar sua licença.', 
            inline: false 
          },
          { 
            name: '🔗 Servidor de Suporte', 
            value: licenseManager.getSupportServerLink(), 
            inline: false 
          }
        )
        .setTimestamp()
        .setFooter({ text: '💎 Rias-Grimory-X Bot' });

      return interaction.editReply({ embeds: [noLicenseEmbed] });
    }

    // Embed com informações da licença
    const statusColor = timeRemaining.valid ? '#10B981' : '#EF4444';
    const statusText = timeRemaining.valid ? '✅ Ativa' : '❌ Expirada';

    const licenseEmbed = new EmbedBuilder()
      .setTitle('📋 Informações da Licença')
      .setDescription(`Informações da licença de <@${targetUser.id}>`)
      .setColor(statusColor)
      .addFields(
        { name: '👤 Usuário', value: `${targetUser.tag}`, inline: true },
        { name: '📦 Tipo', value: license.type, inline: true },
        { name: '📊 Status', value: statusText, inline: true },
        { 
          name: '📅 Ativada em', 
          value: `<t:${Math.floor(license.activatedAt / 1000)}:F>`, 
          inline: false 
        },
        { 
          name: '⏰ Expira em', 
          value: `<t:${Math.floor(license.expiresAt / 1000)}:R>\n(${timeRemaining.formatted})`, 
          inline: false 
        },
        { 
          name: '🔑 Código', 
          value: `\`${license.code}\``, 
          inline: true 
        },
        { 
          name: '🖥️ Servidores', 
          value: `${license.servers?.length || 0} servidor(es)`, 
          inline: true 
        }
      );

    if (!timeRemaining.valid) {
      licenseEmbed.addFields({
        name: '⚠️ Licença Expirada!',
        value: `Sua licença expirou! Use \`/support\` para abrir um ticket de renovação.\n[Servidor de Suporte](${licenseManager.getSupportServerLink()})`,
        inline: false
      });
    } else {
      licenseEmbed.addFields({
        name: '💡 Como usar',
        value: 'Use `/ask on` em um canal para ativar a IA. Lembre-se: você precisa ser **Admin** ou **Dono** do servidor.',
        inline: false
      });
    }

    licenseEmbed
      .setThumbnail(targetUser.displayAvatarURL({ size: 256 }))
      .setTimestamp()
      .setFooter({ text: '💎 Rias-Grimory-X Bot' });

    await interaction.editReply({ embeds: [licenseEmbed] });

  } catch (error) {
    console.error('❌ [License] Erro:', error);
    await interaction.editReply({
      content: `❌ Erro ao obter informações: ${error.message}`
    });
  }
}

export default { data, execute };
