/**
 * Rias-Grimory-X - Comando /gen-access
 * Gera códigos de acesso para licenças
 * 
 * @version 2.1.0
 * @author MutanoX
 * 
 * EXCLUSIVO PARA O DONO DO BOT
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  MessageFlags
} from 'discord.js';
import licenseManager from '../utils/licenseManager.js';

export const data = new SlashCommandBuilder()
  .setName('gen-access')
  .setDescription('🎫 Gera códigos de acesso para licenças (EXCLUSIVO DO DONO)')
  .addIntegerOption(opt =>
    opt
      .setName('quantidade')
      .setDescription('Quantidade de códigos a gerar (1-100)')
      .setRequired(true)
      .setMinValue(1)
      .setMaxValue(100)
  )
  .addStringOption(opt =>
    opt
      .setName('duracao')
      .setDescription('Duração da licença')
      .setRequired(true)
      .addChoices(
        { name: '📅 Semanal (7 dias)', value: 'semanal' },
        { name: '📅 Mensal (30 dias)', value: 'mensal' },
        { name: '💎 Semanal Premium (7 dias)', value: 'semanal_premium' },
        { name: '💎 Mensal Premium (30 dias)', value: 'mensal_premium' },
        { name: '👑 Vitalício', value: 'vitalicio' }
      )
  );

export async function execute(interaction) {
  const userId = interaction.user.id;
  
  // Verificar se é o dono do bot
  if (!licenseManager.isBotOwner(userId)) {
    return interaction.reply({
      content: '❌ **Acesso Negado!** Este comando é exclusivo do dono do bot.',
      flags: MessageFlags.Ephemeral
    });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const quantidade = interaction.options.getInteger('quantidade');
  const duracao = interaction.options.getString('duracao');

  try {
    const result = licenseManager.generateAccessCodes(quantidade, duracao, userId);

    if (!result.success) {
      return interaction.editReply({
        content: `❌ Erro: ${result.error}`
      });
    }

    // Criar embed com os códigos
    const embed = new EmbedBuilder()
      .setTitle('🎫 Códigos de Acesso Gerados')
      .setDescription(`**${quantidade}** código(s) de licença **${result.type}** (${result.durationDays} dias)`)
      .setColor('#8B5CF6')
      .setTimestamp();

    // Se poucos códigos, mostrar no embed
    if (result.codes.length <= 10) {
      const codesList = result.codes.map(c => `\`${c}\``).join('\n');
      embed.addFields({
        name: '📋 Códigos Gerados',
        value: codesList,
        inline: false
      });
    } else {
      // Muitos códigos, avisar que estão no arquivo
      embed.addFields({
        name: '📋 Códigos Gerados',
        value: `**${result.codes.length}** códigos gerados. Veja o arquivo anexo.`,
        inline: false
      });
    }

    embed.addFields(
      { name: '⏱️ Duração', value: `${result.durationDays} dias`, inline: true },
      { name: '📦 Tipo', value: result.type, inline: true },
      { name: '🔗 Servidor de Suporte', value: licenseManager.getSupportServerLink(), inline: false }
    );

    embed.setFooter({ 
      text: 'Compartilhe estes códigos com usuários para que possam ativar suas licenças' 
    });

    // Se muitos códigos, criar arquivo de texto
    if (result.codes.length > 10) {
      const codesText = result.codes.map(c => 
        `Código: ${c} | Tipo: ${result.type} | Duração: ${result.durationDays} dias`
      ).join('\n');
      
      const buffer = Buffer.from(codesText, 'utf-8');
      
      await interaction.editReply({
        embeds: [embed],
        files: [{
          attachment: buffer,
          name: `codigos-${result.type}-${Date.now()}.txt`
        }]
      });
    } else {
      await interaction.editReply({ embeds: [embed] });
    }

    console.log(`🎫 [GenAccess] ${quantidade} código(s) gerado(s) por ${interaction.user.tag}`);

  } catch (error) {
    console.error('❌ [GenAccess] Erro:', error);
    await interaction.editReply({
      content: `❌ Erro ao gerar códigos: ${error.message}`
    });
  }
}

export default { data, execute };
