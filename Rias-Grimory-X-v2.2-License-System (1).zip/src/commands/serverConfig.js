/**
 * MutanoX Architect - Comando /server-config
 * Gerencia configurações específicas do servidor
 * 
 * VERSÃO 1.0 - Sistema de configurações por servidor
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  MessageFlags
} from 'discord.js';
import { 
  initServerConfig, 
  getServerConfig, 
  addAllowedRole, 
  removeAllowedRole,
  isServerAdmin,
  isBotOwner
} from '../utils/permissions.js';
import { setServerSettings, getServerSettings } from '../utils/activeChannels.js';

export const data = new SlashCommandBuilder()
  .setName('server-config')
  .setDescription('⚙️ Configura o bot para este servidor')
  .addSubcommand(sub =>
    sub
      .setName('ver')
      .setDescription('📋 Mostra as configurações atuais do servidor')
  )
  .addSubcommand(sub =>
    sub
      .setName('add-cargo')
      .setDescription('➕ Adiciona um cargo que pode usar a IA')
      .addRoleOption(opt =>
        opt
          .setName('cargo')
          .setDescription('Cargo que poderá usar a IA')
          .setRequired(true)
      )
  )
  .addSubcommand(sub =>
    sub
      .setName('remove-cargo')
      .setDescription('➖ Remove um cargo da lista de permitidos')
      .addRoleOption(opt =>
        opt
          .setName('cargo')
          .setDescription('Cargo a ser removido')
          .setRequired(true)
      )
  )
  .addSubcommand(sub =>
    sub
      .setName('idioma')
      .setDescription('🌐 Define o idioma da IA')
      .addStringOption(opt =>
        opt
          .setName('lingua')
          .setDescription('Idioma para a IA')
          .setRequired(true)
          .addChoices(
            { name: '🇧🇷 Português (Brasil)', value: 'pt-BR' },
            { name: '🇺🇸 English', value: 'en-US' },
            { name: '🇪🇸 Español', value: 'es-ES' }
          )
      )
  );

export async function execute(interaction) {
  const userId = interaction.user.id;
  const guild = interaction.guild;
  const member = interaction.member;
  
  // Verificar se é admin ou dono
  if (!isServerAdmin(guild, member) && !isBotOwner(userId)) {
    return interaction.reply({
      content: '❌ Você precisa ser **Administrador** ou **Dono do servidor** para usar este comando.',
      flags: MessageFlags.Ephemeral
    });
  }
  
  // Inicializar configuração do servidor
  initServerConfig(guild);
  
  const subcommand = interaction.options.getSubcommand();
  
  switch (subcommand) {
    case 'ver':
      await handleView(interaction, guild);
      break;
    case 'add-cargo':
      await handleAddRole(interaction, guild);
      break;
    case 'remove-cargo':
      await handleRemoveRole(interaction, guild);
      break;
    case 'idioma':
      await handleLanguage(interaction, guild);
      break;
  }
}

/**
 * Mostra configurações do servidor
 */
async function handleView(interaction, guild) {
  const config = getServerConfig(guild.id);
  const settings = getServerSettings(guild.id);
  
  const embed = new EmbedBuilder()
    .setTitle(`⚙️ Configurações - ${guild.name}`)
    .setDescription('Configurações atuais do MutanoX Architect neste servidor:')
    .setColor('#8B5CF6')
    .setThumbnail(guild.iconURL())
    .setTimestamp();
  
  // Dono do servidor
  embed.addFields({
    name: '👑 Dono do Servidor',
    value: `<@${config?.ownerId || guild.ownerId}>`,
    inline: true
  });
  
  // Cargos permitidos
  let rolesList = 'Nenhum cargo adicional';
  if (config?.allowedRoles?.length > 0) {
    rolesList = config.allowedRoles.map(id => `<@&${id}>`).join('\n');
  }
  embed.addFields({
    name: '📋 Cargos Permitidos',
    value: rolesList,
    inline: true
  });
  
  // Idioma
  const languageNames = {
    'pt-BR': '🇧🇷 Português (Brasil)',
    'en-US': '🇺🇸 English',
    'es-ES': '🇪🇸 Español'
  };
  embed.addFields({
    name: '🌐 Idioma da IA',
    value: languageNames[settings.language] || '🇧🇷 Português (Brasil)',
    inline: true
  });
  
  // Canais ativos
  const activeChannelsCount = config?.activeChannels?.size || 0;
  embed.addFields({
    name: '🤖 Canais com IA Ativa',
    value: `${activeChannelsCount} canal(is)`,
    inline: true
  });
  
  // Permissões
  embed.addFields({
    name: '🔐 Quem pode usar a IA',
    value: '• 👑 Dono do servidor\n• ⚙️ Administradores\n• 📋 Cargos na lista de permitidos',
    inline: false
  });
  
  // Comandos críticos
  embed.addFields({
    name: '⚠️ Comandos Críticos',
    value: 'O comando `/delete-server` só pode ser usado pelo **Dono do Servidor**.',
    inline: false
  });
  
  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

/**
 * Adiciona cargo permitido
 */
async function handleAddRole(interaction, guild) {
  const role = interaction.options.getRole('cargo');
  
  // Não adicionar cargo @everyone
  if (role.id === guild.roles.everyone.id) {
    return interaction.reply({
      content: '❌ Não é possível adicionar o cargo @everyone.',
      flags: MessageFlags.Ephemeral
    });
  }
  
  // Não adicionar cargos de bots
  if (role.managed) {
    return interaction.reply({
      content: '❌ Não é possível adicionar cargos de bots.',
      flags: MessageFlags.Ephemeral
    });
  }
  
  const success = addAllowedRole(guild.id, role.id);
  
  if (success) {
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Adicionado')
      .setDescription(`O cargo ${role} foi adicionado à lista de permitidos!`)
      .addFields(
        { name: '📝 Cargo', value: `${role.name} (${role.id})`, inline: true },
        { name: '👥 Membros', value: `${role.members.size} membros`, inline: true }
      )
      .setColor('#10B981')
      .setTimestamp();
    
    await interaction.reply({ embeds: [embed] });
  } else {
    await interaction.reply({
      content: `❌ O cargo ${role} já está na lista de permitidos.`,
      flags: MessageFlags.Ephemeral
    });
  }
}

/**
 * Remove cargo permitido
 */
async function handleRemoveRole(interaction, guild) {
  const role = interaction.options.getRole('cargo');
  
  const success = removeAllowedRole(guild.id, role.id);
  
  if (success) {
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Removido')
      .setDescription(`O cargo ${role} foi removido da lista de permitidos.`)
      .setColor('#EF4444')
      .setTimestamp();
    
    await interaction.reply({ embeds: [embed] });
  } else {
    await interaction.reply({
      content: `❌ O cargo ${role} não estava na lista de permitidos.`,
      flags: MessageFlags.Ephemeral
    });
  }
}

/**
 * Define idioma do servidor
 */
async function handleLanguage(interaction, guild) {
  const language = interaction.options.getString('lingua');
  
  setServerSettings(guild.id, { language });
  
  const languageNames = {
    'pt-BR': '🇧🇷 Português (Brasil)',
    'en-US': '🇺🇸 English',
    'es-ES': '🇪🇸 Español'
  };
  
  const embed = new EmbedBuilder()
    .setTitle('✅ Idioma Atualizado')
    .setDescription(`O idioma da IA foi alterado para **${languageNames[language]}**`)
    .setColor('#10B981')
    .setTimestamp();
  
  await interaction.reply({ embeds: [embed] });
}

export default { data, execute };
