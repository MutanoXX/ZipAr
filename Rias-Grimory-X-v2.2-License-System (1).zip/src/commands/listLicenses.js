/**
 * Rias-Grimory-X - Comando /list-licenses
 * Lista todos os usuários com licença
 * 
 * @version 2.1.0
 * @author MutanoX
 * 
 * EXCLUSIVO PARA O DONO DO BOT
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  MessageFlags
} from 'discord.js';
import licenseManager from '../utils/licenseManager.js';

export const data = new SlashCommandBuilder()
  .setName('list-licenses')
  .setDescription('📊 Lista todos os usuários com licença (EXCLUSIVO DO DONO)')
  .addBooleanOption(opt =>
    opt
      .setName('ativas')
      .setDescription('Mostrar apenas licenças ativas (padrão: true)')
      .setRequired(false)
  );

export async function execute(interaction) {
  const userId = interaction.user.id;
  
  // Verificar se é o dono do bot
  if (!licenseManager.isBotOwner(userId)) {
    return interaction.reply({
      content: '❌ **Acesso Negado!** Este comando é exclusivo do dono do bot.',
      flags: MessageFlags.Ephemeral
    });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const ativasOnly = interaction.options.getBoolean('ativas') ?? true;

  try {
    const users = licenseManager.listLicensedUsers(!ativasOnly);
    const stats = licenseManager.getLicenseStats();

    if (users.length === 0) {
      return interaction.editReply({
        content: `📋 **Nenhuma licença ${ativasOnly ? 'ativa' : 'encontrada'}.**`
      });
    }

    // Criar embed principal
    const embed = new EmbedBuilder()
      .setTitle('📊 Lista de Licenças')
      .setDescription(`**${users.length}** licença(s) ${ativasOnly ? 'ativa(s)' : 'total'}`)
      .setColor('#8B5CF6')
      .addFields(
        { name: '📊 Estatísticas', value: `Total: ${stats.totalUsers}\nAtivas: ${stats.activeLicenses}\nExpiradas: ${stats.expiredLicenses}`, inline: true },
        { name: '🎫 Códigos', value: `Gerados: ${stats.totalCodesGenerated}\nNão usados: ${stats.unusedCodes}`, inline: true },
        { name: '🎫 Tickets', value: `Abertos: ${stats.openTickets}`, inline: true }
      )
      .setTimestamp();

    // Lista de usuários (limitar a 20 para não ultrapassar limite do embed)
    const usersList = users.slice(0, 20).map(u => {
      const remaining = u.expiresAt - Date.now();
      const status = remaining > 0 ? '✅' : '❌';
      const days = Math.max(0, Math.floor(remaining / (24 * 60 * 60 * 1000)));
      
      return `${status} <@${u.userId}> | ${u.type} | ${days}d`;
    }).join('\n');

    embed.addFields({
      name: '👥 Usuários',
      value: usersList || 'Nenhum',
      inline: false
    });

    if (users.length > 20) {
      embed.addFields({
        name: '⚠️ Nota',
        value: `Mostrando 20 de ${users.length} usuários.`,
        inline: false
      });
    }

    embed.setFooter({ text: '💎 Rias-Grimory-X Bot | Sistema de Licenças' });

    await interaction.editReply({ embeds: [embed] });

    console.log(`📊 [ListLicenses] Listagem solicitada por ${interaction.user.tag}`);

  } catch (error) {
    console.error('❌ [ListLicenses] Erro:', error);
    await interaction.editReply({
      content: `❌ Erro ao listar licenças: ${error.message}`
    });
  }
}

export default { data, execute };
