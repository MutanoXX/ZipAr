/**
 * MutanoX Architect - Comando /list-users
 * Lista todos os usuários autorizados
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  MessageFlags
} from 'discord.js';
import { isOwner, getAuthorizedUsers } from '../utils/permissions.js';

export const data = new SlashCommandBuilder()
  .setName('list-users')
  .setDescription('📋 Lista todos os usuários autorizados');

export async function execute(interaction) {
  const userId = interaction.user.id;
  
  // Apenas o dono pode usar este comando
  if (!isOwner(userId)) {
    return interaction.reply({
      content: '❌ Apenas o dono do bot pode usar este comando.',
      flags: MessageFlags.Ephemeral
    });
  }

  const authorizedList = getAuthorizedUsers();

  const embed = new EmbedBuilder()
    .setTitle('📋 Usuários Autorizados')
    .setDescription('Lista de usuários que podem usar os comandos do bot:')
    .setColor('#8B5CF6')
    .setTimestamp();

  if (authorizedList.length === 0) {
    embed.addFields({
      name: 'Nenhum usuário',
      value: 'Nenhum usuário autorizado além do dono.',
      inline: false
    });
  } else {
    const usersList = authorizedList.map(id => {
      const isDono = id === '1387242867700924568';
      return `<@${id}> ${isDono ? '(👑 Dono)' : ''}`;
    }).join('\n');

    embed.addFields({
      name: `Total: ${authorizedList.length}`,
      value: usersList,
      inline: false
    });
  }

  await interaction.reply({
    embeds: [embed],
    flags: MessageFlags.Ephemeral
  });
}

export default { data, execute };
