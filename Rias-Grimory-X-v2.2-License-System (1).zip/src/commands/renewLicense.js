/**
 * Rias-Grimory-X - Comando /renew-license
 * Renova a licença de um usuário
 * 
 * @version 2.1.0
 * @author MutanoX
 * 
 * EXCLUSIVO PARA O DONO DO BOT
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  MessageFlags
} from 'discord.js';
import licenseManager from '../utils/licenseManager.js';

export const data = new SlashCommandBuilder()
  .setName('renew-license')
  .setDescription('🔄 Renova a licença de um usuário (EXCLUSIVO DO DONO)')
  .addUserOption(opt =>
    opt
      .setName('usuario')
      .setDescription('Usuário para renovar a licença')
      .setRequired(true)
  )
  .addStringOption(opt =>
    opt
      .setName('duracao')
      .setDescription('Duração da renovação')
      .setRequired(true)
      .addChoices(
        { name: '📅 Semanal (7 dias)', value: 'semanal' },
        { name: '📅 Mensal (30 dias)', value: 'mensal' },
        { name: '💎 Semanal Premium (7 dias)', value: 'semanal_premium' },
        { name: '💎 Mensal Premium (30 dias)', value: 'mensal_premium' },
        { name: '👑 Vitalício', value: 'vitalicio' }
      )
  );

export async function execute(interaction) {
  const requesterId = interaction.user.id;
  
  // Verificar se é o dono do bot
  if (!licenseManager.isBotOwner(requesterId)) {
    return interaction.reply({
      content: '❌ **Acesso Negado!** Este comando é exclusivo do dono do bot.',
      flags: MessageFlags.Ephemeral
    });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const targetUser = interaction.options.getUser('usuario');
  const duracao = interaction.options.getString('duracao');

  if (!targetUser) {
    return interaction.editReply({
      content: '❌ Usuário não encontrado.'
    });
  }

  try {
    const result = licenseManager.renewUserLicense(targetUser.id, duracao, requesterId);

    if (!result.success) {
      return interaction.editReply({
        content: `❌ **Erro:** ${result.error}`
      });
    }

    const license = result.license;
    const timeRemaining = licenseManager.getLicenseTimeRemaining(targetUser.id);

    // Criar embed de sucesso
    const embed = new EmbedBuilder()
      .setTitle('✅ Licença Renovada!')
      .setDescription(result.message)
      .setColor('#10B981')
      .addFields(
        { name: '👤 Usuário', value: `<@${targetUser.id}> (${targetUser.tag})`, inline: true },
        { name: '📦 Tipo', value: license.type, inline: true },
        { name: '⏱️ Duração Adicionada', value: `${license.durationDays} dias`, inline: true },
        { 
          name: '⏰ Nova Expiração', 
          value: `<t:${Math.floor(license.expiresAt / 1000)}:R>`, 
          inline: false 
        },
        {
          name: '📊 Tempo Restante',
          value: timeRemaining.formatted,
          inline: true
        }
      )
      .setThumbnail(targetUser.displayAvatarURL({ size: 256 }))
      .setTimestamp()
      .setFooter({ text: '💎 Rias-Grimory-X Bot | Sistema de Licenças' });

    await interaction.editReply({ embeds: [embed] });

    // Log
    console.log(`🔄 [RenewLicense] Licença renovada para ${targetUser.tag} (${targetUser.id})`);
    console.log(`   Tipo: ${duracao}, Nova expiração: ${new Date(license.expiresAt).toISOString()}`);

  } catch (error) {
    console.error('❌ [RenewLicense] Erro:', error);
    await interaction.editReply({
      content: `❌ Erro ao renovar licença: ${error.message}`
    });
  }
}

export default { data, execute };
