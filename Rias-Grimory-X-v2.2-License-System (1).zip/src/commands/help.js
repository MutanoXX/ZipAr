/**
 * MutanoX Architect - Comando /help (Paginado)
 * Mostra a lista de comandos e capacidades da IA com navegação por botões
 */

import { 
  SlashCommandBuilder, 
  EmbedBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle, 
  MessageFlags 
} from 'discord.js';

export const data = new SlashCommandBuilder()
  .setName('help')
  .setDescription('❓ Guia completo de funcionalidades e capacidades da IA');

/**
 * Define as páginas de ajuda
 */
export const helpPages = [
  // Página 1: Introdução e Comandos Básicos
  {
    title: '🏗️ MutanoX Architect - Início',
    description: 'Sou uma IA avançada projetada para transformar seu servidor Discord. Utilizo tecnologia de ponta para entender seus comandos e executar ações complexas.',
    fields: [
      {
        name: '🚀 Comandos de Inicialização',
        value: '• `/architect analyze` - Analisa seu servidor e sugere melhorias.\n• `/architect quick` - Cria uma estrutura temática instantânea.\n• `/info` - Status técnico do bot.'
      },
      {
        name: '🔐 Acesso',
        value: 'Apenas usuários autorizados pelos administradores podem interagir com as funções de IA.'
      }
    ],
    color: '#8B5CF6'
  },
  // Página 2: Capacidades da IA (/ask)
  {
    title: '🤖 O que a IA pode fazer?',
    description: 'Ao ativar a IA com `/ask on`, você ganha um arquiteto virtual. Ela não apenas conversa, mas executa comandos diretamente no servidor.',
    fields: [
      {
        name: '📁 Gestão de Canais',
        value: '• Criar categorias e canais (texto/voz).\n• Renomear e organizar estruturas.\n• Configurar tópicos e permissões específicas.'
      },
      {
        name: '👥 Gestão de Cargos',
        value: '• Criar cargos com cores personalizadas.\n• Atribuir ou remover cargos de usuários.\n• Configurar hierarquias e permissões.'
      },
      {
        name: '🎨 Estética e Decoração',
        value: '• Aplicar fontes Unicode especiais (Ex: 𝐍𝐨𝐦𝐞).\n• Organizar nomes com Emojis temáticos.\n• Enviar Embeds profissionais com imagens.'
      }
    ],
    color: '#10B981'
  },
  // Página 3: Permissões e Segurança
  {
    title: '🛡️ Segurança e Permissões',
    description: 'O MutanoX Architect segue regras rigorosas para manter a ordem no seu servidor.',
    fields: [
      {
        name: '👤 Quem pode usar?',
        value: '• **Admins:** Têm acesso total por padrão.\n• **Autorizados:** Usuários adicionados via `/adduser`.\n• **IA:** Só executa o que você pedir e o que ela tem permissão para fazer.'
      },
      {
        name: '⚠️ Comandos Críticos',
        value: '• `/delete-server` - Requer confirmação dupla e é restrito a administradores de alto nível.\n• `/removeuser` - Revoga acesso de outros usuários.'
      },
      {
        name: '🧠 Memória de Contexto',
        value: 'Lembro de até 60 mensagens no canal para manter a fluidez da conversa.'
      }
    ],
    color: '#EF4444'
  }
];

/**
 * Cria o embed e os botões para uma página específica
 */
export function createHelpMessage(pageIndex) {
  const page = helpPages[pageIndex];
  
  const embed = new EmbedBuilder()
    .setTitle(page.title)
    .setDescription(page.description)
    .setColor(page.color)
    .addFields(page.fields)
    .setFooter({ text: `Página ${pageIndex + 1} de ${helpPages.length}` })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`help_prev_${pageIndex}`)
      .setLabel('⬅️ Anterior')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(pageIndex === 0),
    new ButtonBuilder()
      .setCustomId(`help_next_${pageIndex}`)
      .setLabel('Próximo ➡️')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(pageIndex === helpPages.length - 1)
  );

  return { embeds: [embed], components: [row] };
}

export async function execute(interaction) {
  const response = createHelpMessage(0);
  await interaction.reply({ ...response, flags: MessageFlags.Ephemeral });
}

export default { data, execute };
