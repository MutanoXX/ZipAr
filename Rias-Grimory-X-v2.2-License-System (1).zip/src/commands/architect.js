/**
 * MutanoX Architect - Comando /architect
 * Comando principal para análise e reestruturação de servidores
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags
} from 'discord.js';
import aiService from '../services/aiService.js';
import { applyPlan } from '../utils/serverManager.js';
import { isAuthorized } from '../utils/permissions.js';

export const data = new SlashCommandBuilder()
  .setName('architect')
  .setDescription('🏗️ Analisa e reestrutura o servidor com IA')
  .addSubcommand(sub =>
    sub
      .setName('analyze')
      .setDescription('Analisa o servidor e gera um plano de reestruturação')
      .addStringOption(opt =>
        opt
          .setName('objetivo')
          .setDescription('Qual é o objetivo do seu servidor?')
          .setRequired(true)
      )
      .addStringOption(opt =>
        opt
          .setName('modo')
          .setDescription('Modo de operação')
          .setRequired(false)
          .addChoices(
            { name: '🆕 Novo (criar do zero)', value: 'fresh' },
            { name: '🔄 Reestruturar (manter existente)', value: 'restructure' }
          )
      )
  )
  .addSubcommand(sub =>
    sub
      .setName('quick')
      .setDescription('Cria uma estrutura rápida baseada em um tema')
      .addStringOption(opt =>
        opt
          .setName('tema')
          .setDescription('Tema do servidor')
          .setRequired(true)
          .addChoices(
            { name: '🎮 Gaming / Games', value: 'gaming' },
            { name: '🏪 Loja / E-commerce', value: 'loja' },
            { name: '👥 Comunidade', value: 'comunidade' },
            { name: '🎭 Roleplay (RP)', value: 'roleplay' },
            { name: '🎵 Música', value: 'musica' },
            { name: '📚 Educação', value: 'educacao' },
            { name: '💼 Empresarial', value: 'empresarial' },
            { name: '🎨 Criativo / Arte', value: 'criativo' }
          )
      )
  )
  .addSubcommand(sub =>
    sub
      .setName('apply')
      .setDescription('Aplica o último plano gerado')
  );

export async function execute(interaction) {
  // Verificar permissão
  if (!isAuthorized(interaction.user.id)) {
    return interaction.reply({
      content: '❌ Você não tem permissão para usar este comando.',
      flags: MessageFlags.Ephemeral
    });
  }

  const subcommand = interaction.options.getSubcommand();

  switch (subcommand) {
    case 'analyze':
      await handleAnalyze(interaction);
      break;
    case 'quick':
      await handleQuick(interaction);
      break;
    case 'apply':
      await handleApply(interaction);
      break;
    default:
      await interaction.reply({
        content: '❌ Subcomando não reconhecido.',
        flags: MessageFlags.Ephemeral
      });
  }
}

/**
 * Handler para o subcomando analyze
 */
async function handleAnalyze(interaction) {
  await interaction.deferReply();

  const objetivo = interaction.options.getString('objetivo');
  const modo = interaction.options.getString('modo') || 'fresh';
  const guild = interaction.guild;

  // Coletar informações do servidor
  const channels = guild.channels.cache
    .filter(c => c.type !== 4) // Excluir categorias
    .map(c => ({
      id: c.id,
      name: c.name,
      type: c.type,
      parentId: c.parentId
    }));

  const roles = guild.roles.cache
    .filter(r => !r.managed) // Excluir cargos de bots
    .map(r => ({
      id: r.id,
      name: r.name,
      permissions: r.permissions.bitfield.toString()
    }));

  const serverContext = {
    guildName: guild.name,
    channels: channels,
    roles: roles,
    userGoal: objetivo,
    mode: modo
  };

  // Enviar mensagem de progresso
  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setTitle('🏗️ MutanoX Architect')
        .setDescription('Analisando estrutura do servidor...')
        .addFields(
          { name: '📋 Canais', value: `${channels.length} encontrados`, inline: true },
          { name: '👥 Cargos', value: `${roles.length} encontrados`, inline: true },
          { name: '🎯 Objetivo', value: objetivo, inline: false }
        )
        .setColor('#8B5CF6')
        .setFooter({ text: 'Aguarde enquanto a IA analisa seu servidor...' })
    ]
  });

  try {
    // Chamar serviço de IA
    const plan = await aiService.analyzeServer(serverContext);

    // Armazenar o plano para uso posterior
    if (!global.mutanoxPlans) global.mutanoxPlans = {};
    global.mutanoxPlans[guild.id] = plan;

    // Criar embed com o resultado
    const embed = createPlanEmbed(plan, guild.name);

    // Criar botões de ação
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('apply_plan')
          .setLabel('✅ Aplicar Plano')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('preview_plan')
          .setLabel('👀 Ver Detalhes')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('cancel_plan')
          .setLabel('❌ Cancelar')
          .setStyle(ButtonStyle.Danger)
      );

    await interaction.editReply({
      embeds: [embed],
      components: [row]
    });

  } catch (error) {
    console.error('Erro ao analisar servidor:', error);
    
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Erro na Análise')
          .setDescription('Ocorreu um erro ao analisar o servidor. Tente novamente.')
          .addFields({ name: 'Detalhes', value: error.message || 'Erro desconhecido' })
          .setColor('#EF4444')
      ],
      components: []
    });
  }
}

/**
 * Handler para o subcomando quick
 */
async function handleQuick(interaction) {
  await interaction.deferReply();

  const tema = interaction.options.getString('tema');
  const guild = interaction.guild;

  const temaNomes = {
    gaming: '🎮 Gaming',
    loja: '🏪 Loja',
    comunidade: '👥 Comunidade',
    roleplay: '🎭 Roleplay',
    musica: '🎵 Música',
    educacao: '📚 Educação',
    empresarial: '💼 Empresarial',
    criativo: '🎨 Criativo'
  };

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setTitle(`🏗️ Criando Estrutura: ${temaNomes[tema]}`)
        .setDescription('Gerando estrutura rápida com IA...')
        .setColor('#8B5CF6')
    ]
  });

  try {
    const plan = await aiService.analyzeServer({
      guildName: guild.name,
      channels: [],
      roles: [],
      userGoal: `Quero um servidor de ${temaNomes[tema]}`,
      mode: 'fresh'
    });

    // Armazenar o plano
    if (!global.mutanoxPlans) global.mutanoxPlans = {};
    global.mutanoxPlans[guild.id] = plan;

    const embed = createPlanEmbed(plan, guild.name);

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('apply_plan')
          .setLabel('✅ Aplicar Plano')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('cancel_plan')
          .setLabel('❌ Cancelar')
          .setStyle(ButtonStyle.Danger)
      );

    await interaction.editReply({
      embeds: [embed],
      components: [row]
    });

  } catch (error) {
    console.error('Erro no quick create:', error);
    
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Erro')
          .setDescription('Erro ao gerar estrutura rápida.')
          .setColor('#EF4444')
      ],
      components: []
    });
  }
}

/**
 * Handler para o subcomando apply
 */
async function handleApply(interaction) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const guild = interaction.guild;
  const plan = global.mutanoxPlans?.[guild.id];

  if (!plan) {
    return interaction.editReply({
      content: '❌ Nenhum plano encontrado. Use `/architect analyze` primeiro.'
    });
  }

  try {
    const result = await applyPlan(guild, plan);

    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('✅ Plano Aplicado!')
          .setDescription('A estrutura foi criada com sucesso.')
          .addFields(
            { name: '📁 Categorias', value: `${result.categories} criadas`, inline: true },
            { name: '📝 Canais', value: `${result.channels} criados`, inline: true },
            { name: '👥 Cargos', value: `${result.roles} criados`, inline: true }
          )
          .setColor('#10B981')
      ]
    });

  } catch (error) {
    console.error('Erro ao aplicar plano:', error);
    
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Erro ao Aplicar')
          .setDescription(error.message)
          .setColor('#EF4444')
      ]
    });
  }
}

/**
 * Cria embed com o plano
 */
function createPlanEmbed(plan, guildName) {
  const embed = new EmbedBuilder()
    .setTitle(`🏗️ Plano de Estrutura - ${plan.plan?.name || guildName}`)
    .setDescription(plan.plan?.description || 'Plano de reestruturação gerado por IA')
    .setColor(plan.plan?.themeColor || '#8B5CF6')
    .setTimestamp();

  // Cargos a criar
  if (plan.changes?.createRoles?.length > 0) {
    const rolesList = plan.changes.createRoles
      .slice(0, 10)
      .map(r => `• ${r.name}`)
      .join('\n');
    
    embed.addFields({
      name: `👥 Cargos (${plan.changes.createRoles.length})`,
      value: rolesList + (plan.changes.createRoles.length > 10 ? '\n...' : ''),
      inline: true
    });
  }

  // Categorias a criar
  if (plan.changes?.createCategories?.length > 0) {
    const categoriesList = plan.changes.createCategories
      .slice(0, 5)
      .map(c => `• ${c.name}`)
      .join('\n');
    
    embed.addFields({
      name: `📁 Categorias (${plan.changes.createCategories.length})`,
      value: categoriesList + (plan.changes.createCategories.length > 5 ? '\n...' : ''),
      inline: true
    });
  }

  // Análise da IA
  if (plan.ai_analysis) {
    if (plan.ai_analysis.strengths?.length > 0) {
      embed.addFields({
        name: '💪 Pontos Fortes',
        value: plan.ai_analysis.strengths.slice(0, 3).map(s => `• ${s}`).join('\n'),
        inline: false
      });
    }
    
    if (plan.ai_analysis.suggestions?.length > 0) {
      embed.addFields({
        name: '💡 Sugestões',
        value: plan.ai_analysis.suggestions.slice(0, 3).map(s => `• ${s}`).join('\n'),
        inline: false
      });
    }
  }

  return embed;
}

export default { data, execute };
