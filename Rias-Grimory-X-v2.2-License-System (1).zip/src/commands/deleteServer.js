/**
 * MutanoX Architect - Comando /delete-server
 * Comando PERIGOSO que deleta toda a estrutura do servidor
 * 
 * VERSÃO 2.0 - Restrito APENAS ao dono do servidor ou dono do bot
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags
} from 'discord.js';
import { canExecuteCritical, isBotOwner, isServerOwner } from '../utils/permissions.js';

export const data = new SlashCommandBuilder()
  .setName('delete-server')
  .setDescription('⚠️ COMANDO PERIGOSO - Deleta toda estrutura do servidor')
  .addStringOption(opt =>
    opt
      .setName('confirmacao')
      .setDescription('Digite "CONFIRMAR" para prosseguir')
      .setRequired(false)
  );

export async function execute(interaction) {
  const userId = interaction.user.id;
  const guild = interaction.guild;
  const context = { guild };

  // Verificar se é dono do servidor OU dono do bot
  const canExecute = canExecuteCritical(userId, context);
  
  if (!canExecute) {
    // Verificar qual é o motivo da negação
    const isOwner = isBotOwner(userId);
    const isServerOwnerResult = isServerOwner(userId, context);
    
    let reason = '❌ **Acesso Negado!**\n\n';
    
    if (isServerOwnerResult) {
      reason += 'Você é dono deste servidor, mas há um erro na verificação. Contate o suporte.';
    } else {
      reason += 'Este comando é **EXCLUSIVO** para:\n';
      reason += '• 👑 **Dono do servidor** (quem criou o servidor)\n';
      reason += '• 🤖 **Dono do bot**\n\n';
      reason += `O dono atual deste servidor é: <@${guild.ownerId}>`;
    }
    
    return interaction.reply({
      content: reason,
      flags: MessageFlags.Ephemeral
    });
  }

  // Verificar confirmação por texto
  const confirmacao = interaction.options.getString('confirmacao');
  
  if (confirmacao !== 'CONFIRMAR') {
    const warningEmbed = new EmbedBuilder()
      .setTitle('⚠️ ATENÇÃO: COMANDO PERIGOSO')
      .setDescription('Este comando irá **DELETAR TODA A ESTRUTURA** do servidor!')
      .addFields(
        { name: '📁 Canais', value: `${guild.channels.cache.size} serão deletados`, inline: true },
        { name: '👥 Cargos', value: `${guild.roles.cache.size} serão deletados`, inline: true },
        { name: '📍 Preservado', value: `Este canal será mantido`, inline: true },
        { name: '\u200B', value: '\u200B', inline: false },
        { name: '🔐 Segurança', value: 'Este comando é restrito ao **Dono do Servidor** ou **Dono do Bot**.', inline: false }
      )
      .setColor('#FF0000')
      .setFooter({ text: 'Esta ação é IRREVERSÍVEL! Digite "CONFIRMAR" no campo de confirmação.' })
      .setTimestamp();

    const infoEmbed = new EmbedBuilder()
      .setTitle('ℹ️ Como usar')
      .setDescription('Para confirmar a exclusão, use o comando novamente com a confirmação:\n\n`/delete-server confirmacao: CONFIRMAR`')
      .setColor('#F59E0B');

    return interaction.reply({
      embeds: [warningEmbed, infoEmbed],
      flags: MessageFlags.Ephemeral
    });
  }

  // Tem confirmação, mostrar botões de ação
  const warningEmbed = new EmbedBuilder()
    .setTitle('🚨 ÚLTIMA CHANCE - CONFIRMAÇÃO FINAL')
    .setDescription('**VOCÊ ESTÁ PRESTES A DELETAR TODO O SERVIDOR!**\n\nEsta ação não pode ser desfeita!')
    .addFields(
      { name: '📁 Canais a deletar', value: `${guild.channels.cache.size}`, inline: true },
      { name: '👥 Cargos a deletar', value: `${guild.roles.cache.size}`, inline: true },
      { name: '👤 Executado por', value: `<@${userId}>`, inline: true }
    )
    .setColor('#FF0000')
    .setFooter({ text: 'Clique em CONFIRMAR DELEÇÃO para prosseguir' })
    .setTimestamp();

  const confirmRow = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('confirm_delete')
        .setLabel('🗑️ CONFIRMAR DELEÇÃO')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('cancel_delete')
        .setLabel('❌ Cancelar')
        .setStyle(ButtonStyle.Secondary)
    );

  await interaction.reply({
    embeds: [warningEmbed],
    components: [confirmRow],
    flags: MessageFlags.Ephemeral
  });
}

/**
 * Executa a deleção do servidor
 */
export async function executeDelete(interaction, guild) {
  const currentChannel = interaction.channel;
  const userId = interaction.user.id;
  
  // Verificação extra de segurança
  const canExecute = canExecuteCritical(userId, { guild });
  
  if (!canExecute) {
    return interaction.update({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Acesso Negado')
          .setDescription('Apenas o dono do servidor pode executar esta ação.')
          .setColor('#EF4444')
      ],
      components: []
    });
  }
  
  await interaction.update({
    embeds: [
      new EmbedBuilder()
        .setTitle('🗑️ Deletando servidor...')
        .setDescription('Por favor, aguarde. Esta operação pode levar alguns segundos.')
        .setColor('#FF0000')
    ],
    components: []
  });

  const result = {
    channelsDeleted: 0,
    rolesDeleted: 0,
    errors: []
  };

  console.log(`🗑️ [DeleteServer] Iniciando deleção em: ${guild.name} por ${userId}`);

  try {
    // 1. Deletar todos os canais EXCETO o canal atual
    const channelsToDelete = guild.channels.cache.filter(c => c.id !== currentChannel.id);
    
    console.log(`📁 [DeleteServer] Deletando ${channelsToDelete.size} canais...`);
    
    for (const [id, channel] of channelsToDelete) {
      try {
        await channel.delete('MutanoX Architect - Limpeza de servidor');
        result.channelsDeleted++;
        await sleep(200);
      } catch (error) {
        console.error(`Erro ao deletar canal ${channel.name}:`, error.message);
        result.errors.push(`Canal "${channel.name}": ${error.message}`);
      }
    }

    // 2. Deletar todos os cargos EXCETO @everyone e cargos de bots
    const rolesToDelete = guild.roles.cache.filter(r => 
      !r.managed && // Não deletar cargos de bots
      r.id !== guild.roles.everyone.id && // Não deletar @everyone
      r.position < guild.members.me.roles.highest.position // Apenas cargos abaixo do bot
    );
    
    console.log(`👥 [DeleteServer] Deletando ${rolesToDelete.size} cargos...`);
    
    for (const [id, role] of rolesToDelete) {
      try {
        await role.delete('MutanoX Architect - Limpeza de servidor');
        result.rolesDeleted++;
        await sleep(200);
      } catch (error) {
        console.error(`Erro ao deletar cargo ${role.name}:`, error.message);
        result.errors.push(`Cargo "${role.name}": ${error.message}`);
      }
    }

    console.log(`✅ [DeleteServer] Deleção concluída: ${result.channelsDeleted} canais, ${result.rolesDeleted} cargos`);

    // Resultado final
    const successEmbed = new EmbedBuilder()
      .setTitle('✅ Servidor Limpo!')
      .setDescription('A estrutura do servidor foi completamente removida.')
      .addFields(
        { name: '📁 Canais Deletados', value: `${result.channelsDeleted}`, inline: true },
        { name: '👥 Cargos Deletados', value: `${result.rolesDeleted}`, inline: true },
        { name: '📍 Canal Preservado', value: `<#${currentChannel.id}>`, inline: true },
        { name: '👤 Executado por', value: `<@${userId}>`, inline: true }
      )
      .setColor('#10B981')
      .setTimestamp();

    if (result.errors.length > 0) {
      successEmbed.addFields({
        name: '⚠️ Erros',
        value: result.errors.slice(0, 3).join('\n'),
        inline: false
      });
    }

    await currentChannel.send({ embeds: [successEmbed] });

  } catch (error) {
    console.error('❌ [DeleteServer] Erro crítico:', error);
    
    await currentChannel.send({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Erro na Deleção')
          .setDescription(error.message)
          .setColor('#FF0000')
      ]
    });
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export default { data, execute, executeDelete };
