/**
 * Rias-Grimory-X - Comando /ask
 * Ativa/desativa canais para conversa com a IA
 * 
 * VERSÃO 5.0 - Sistema COMPLETO de gestão + Automação
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  MessageFlags
} from 'discord.js';
import { checkServerPermission } from '../utils/permissions.js';
import { 
  activateChannel, 
  deactivateChannel, 
  isChannelActive, 
  getActiveChannels,
  clearChannelContext,
  setChannelPrompt_Default,
  getChannelContextInfo,
  getServerSettings
} from '../utils/activeChannels.js';
import { buildPromptDefault } from '../utils/promptDefault.js';

export const data = new SlashCommandBuilder()
  .setName('ask')
  .setDescription('🤖 Ativa/desativa conversa com a IA em um canal')
  .addSubcommand(sub =>
    sub
      .setName('on')
      .setDescription('✅ Ativa a IA para conversar neste canal')
      .addChannelOption(opt =>
        opt
          .setName('canal')
          .setDescription('Canal para ativar (padrão: canal atual)')
          .setRequired(false)
      )
  )
  .addSubcommand(sub =>
    sub
      .setName('off')
      .setDescription('❌ Desativa a IA neste canal')
      .addChannelOption(opt =>
        opt
          .setName('canal')
          .setDescription('Canal para desativar (padrão: canal atual)')
          .setRequired(false)
      )
  )
  .addSubcommand(sub =>
    sub
      .setName('list')
      .setDescription('📋 Lista canais ativos no servidor')
  )
  .addSubcommand(sub =>
    sub
      .setName('clear')
      .setDescription('🗑️ Limpa o contexto/histórico do canal (mantém 60 msgs)')
      .addChannelOption(opt =>
        opt
          .setName('canal')
          .setDescription('Canal para limpar (padrão: canal atual)')
          .setRequired(false)
      )
  )
  .addSubcommand(sub =>
    sub
      .setName('stats')
      .setDescription('📊 Mostra estatísticas do contexto do canal')
  );

export async function execute(interaction) {
  const userId = interaction.user.id;
  const guild = interaction.guild;
  const member = interaction.member;
  
  // Verificar permissão no servidor específico
  const permCheck = checkServerPermission(guild, { id: userId }, member);
  
  if (!permCheck.authorized) {
    return interaction.reply({
      content: `❌ **Acesso Negado!**\n\n${permCheck.reason}\n\n💡 **Dica:** Se você é dono de um servidor, pode convidar o bot para ter acesso completo aos comandos!`,
      flags: MessageFlags.Ephemeral
    });
  }

  const subcommand = interaction.options.getSubcommand();

  switch (subcommand) {
    case 'on':
      await handleOn(interaction, guild);
      break;
    case 'off':
      await handleOff(interaction, guild);
      break;
    case 'list':
      await handleList(interaction, guild);
      break;
    case 'clear':
      await handleClear(interaction, guild);
      break;
    case 'stats':
      await handleStats(interaction, guild);
      break;
  }
}

/**
 * Ativa a IA em um canal
 */
async function handleOn(interaction, guild) {
  const channel = interaction.options.getChannel('canal') || interaction.channel;
  
  if (isChannelActive(guild.id, channel.id)) {
    return interaction.reply({
      content: `❌ A IA já está ativa em <#${channel.id}>`,
      flags: MessageFlags.Ephemeral
    });
  }

  // Obter configurações do servidor
  const settings = getServerSettings(guild.id);
  
  // Criar prompt_Default com contexto do servidor usando o novo módulo
  const prompt_Default = buildPromptDefault(guild, channel, settings.language);
  setChannelPrompt_Default(channel.id, prompt_Default, guild.id);
  
  activateChannel(guild.id, channel.id);

  const embed = new EmbedBuilder()
    .setTitle('🤖 IA Ativada!')
    .setDescription(`A **Rias-Grimory-X v5.0** agora está conversando em <#${channel.id}>!`)
    .addFields(
      { name: '💬 Como usar', value: 'Basta enviar mensagens no canal e a IA responderá!' },
      { name: '🧠 Memória', value: 'A IA lembra de até **60 mensagens** de conversa!' },
      { name: '🎯 Capacidades', value: '+60 ferramentas de gestão completa do servidor!' }
    )
    .setColor('#10B981')
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });

  // Enviar mensagem de boas-vindas no canal
  try {
    await channel.send({
      embeds: [
        new EmbedBuilder()
          .setTitle('👋 Olá! Sou a Rias-Grimory-X v5.0!')
          .setDescription('Estou aqui para ajudar com **CONTROLE TOTAL** do servidor! 🚀')
          .addFields(
            { name: '🎯 Canais', value: 'Criar, editar, deletar, clonar, trancar, esconder, permissões' },
            { name: '🎭 Cargos', value: 'Criar, editar, deletar, clonar, adicionar/remover de membros' },
            { name: '👥 Membros', value: 'Kick, ban, unban, mute, unmute, apelido, info' },
            { name: '💬 Mensagens', value: 'Deletar em massa, fixar, desfixar' },
            { name: '🪝 Webhooks', value: 'Criar com URL completa, token, editar, enviar mensagens' },
            { name: '🤖 Automação', value: 'Scripts automáticos que rodam em intervalos!' }
          )
          .setColor('#8B5CF6')
          .setTimestamp()
      ]
    });
  } catch (e) {
    console.error('Erro ao enviar mensagem de boas-vindas:', e.message);
  }
}

/**
 * Desativa a IA em um canal
 */
async function handleOff(interaction, guild) {
  const channel = interaction.options.getChannel('canal') || interaction.channel;
  
  if (!isChannelActive(guild.id, channel.id)) {
    return interaction.reply({
      content: `❌ A IA não está ativa em <#${channel.id}>`,
      flags: MessageFlags.Ephemeral
    });
  }

  deactivateChannel(guild.id, channel.id);

  const embed = new EmbedBuilder()
    .setTitle('🤖 IA Desativada')
    .setDescription(`A **Rias-Grimory-X** foi desativada em <#${channel.id}>`)
    .setColor('#EF4444')
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

/**
 * Lista canais ativos
 */
async function handleList(interaction, guild) {
  const channels = getActiveChannels(guild.id);

  if (channels.length === 0) {
    return interaction.reply({
      content: '❌ Nenhum canal ativo no servidor.',
      flags: MessageFlags.Ephemeral
    });
  }

  const channelList = channels.map(id => `<#${id}>`).join('\n');

  const embed = new EmbedBuilder()
    .setTitle('📋 Canais Ativos')
    .setDescription(channelList)
    .addFields({ name: 'Total', value: `${channels.length} canal(is)`, inline: true })
    .setColor('#8B5CF6')
    .setTimestamp();

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

/**
 * Limpa contexto do canal
 */
async function handleClear(interaction, guild) {
  const channel = interaction.options.getChannel('canal') || interaction.channel;
  
  if (!isChannelActive(guild.id, channel.id)) {
    return interaction.reply({
      content: `❌ A IA não está ativa em <#${channel.id}>`,
      flags: MessageFlags.Ephemeral
    });
  }

  // Limpar contexto
  clearChannelContext(channel.id, guild.id);

  const embed = new EmbedBuilder()
    .setTitle('🗑️ Contexto Limpo!')
    .setDescription(`O histórico de <#${channel.id}> foi resetado. A IA não lembrará mais das conversas anteriores.`)
    .addFields({ name: 'ℹ️ Info', value: 'A IA ainda pode guardar até 60 novas mensagens de conversa.' })
    .setColor('#10B981')
    .setTimestamp();

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

/**
 * Mostra estatísticas do contexto
 */
async function handleStats(interaction, guild) {
  const channel = interaction.channel;
  
  if (!isChannelActive(guild.id, channel.id)) {
    return interaction.reply({
      content: `❌ A IA não está ativa neste canal. Use \`/ask on\` para ativar.`,
      flags: MessageFlags.Ephemeral
    });
  }

  const info = getChannelContextInfo(channel.id);

  const embed = new EmbedBuilder()
    .setTitle('📊 Estatísticas do Contexto')
    .addFields(
      { name: '📝 Total de Mensagens', value: `${info.messages}`, inline: true },
      { name: '👤 Mensagens do Usuário', value: `${info.userMessages}`, inline: true },
      { name: '🤖 Mensagens da IA', value: `${info.aiMessages}`, inline: true },
      { name: '🧠 Limite', value: '60 mensagens', inline: true },
      { name: '⏰ Última Atividade', value: `<t:${Math.floor(info.lastActivity / 1000)}:R>`, inline: true }
    )
    .setColor('#8B5CF6')
    .setTimestamp();

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

export default { data, execute };
