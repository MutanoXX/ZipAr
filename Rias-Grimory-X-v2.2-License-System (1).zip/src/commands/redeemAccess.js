/**
 * Rias-Grimory-X - Comando /redeem-access
 * Ativa uma licença com código de acesso
 * 
 * @version 2.1.0
 * @author MutanoX
 * 
 * PÚBLICO - Qualquer usuário pode usar
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  MessageFlags
} from 'discord.js';
import licenseManager from '../utils/licenseManager.js';

export const data = new SlashCommandBuilder()
  .setName('redeem-access')
  .setDescription('🔑 Ativa sua licença com um código de acesso')
  .addStringOption(opt =>
    opt
      .setName('codigo')
      .setDescription('Código de acesso (ex: RIAS-XXXX-XXXX-XXXX-XXXX)')
      .setRequired(true)
  );

export async function execute(interaction) {
  const userId = interaction.user.id;
  const username = interaction.user.tag;
  const code = interaction.options.getString('codigo')?.toUpperCase().trim();

  // Validar formato do código
  if (!code || !code.startsWith('RIAS-')) {
    return interaction.reply({
      content: '❌ **Código inválido!** O código deve começar com `RIAS-` e ter o formato: `RIAS-XXXX-XXXX-XXXX-XXXX`',
      flags: MessageFlags.Ephemeral
    });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  try {
    const result = licenseManager.redeemAccessCode(code, userId, username);

    if (!result.success) {
      return interaction.editReply({
        content: `❌ **Erro ao ativar licença!**\n\n${result.error}`
      });
    }

    const license = result.license;

    // Criar embed de sucesso
    const embed = new EmbedBuilder()
      .setTitle('🎉 Licença Ativada com Sucesso!')
      .setDescription(result.message)
      .setColor('#10B981')
      .addFields(
        { name: '👤 Usuário', value: `<@${userId}>`, inline: true },
        { name: '📦 Tipo', value: license.type, inline: true },
        { name: '⏱️ Duração', value: `${license.durationDays} dias`, inline: true },
        { 
          name: '🔑 Código', 
          value: `\`${code}\``, 
          inline: false 
        },
        { 
          name: '⏰ Expira em', 
          value: `<t:${Math.floor(license.expiresAt / 1000)}:R> (<t:${Math.floor(license.expiresAt / 1000)}:F>)`, 
          inline: false 
        }
      )
      .addFields({
        name: '📋 Como usar',
        value: 'Agora você pode usar a IA em qualquer servidor onde você é **Administrador** ou **Dono**.\nUse `/ask on` em um canal para ativar a IA.',
        inline: false
      })
      .addFields({
        name: '🔄 Renovação',
        value: `Quando sua licença expirar, use \`/support\` para abrir um ticket de renovação.\n[Servidor de Suporte](${licenseManager.getSupportServerLink()})`,
        inline: false
      })
      .setThumbnail(interaction.user.displayAvatarURL({ size: 256 }))
      .setTimestamp()
      .setFooter({ text: '💎 Rias-Grimory-X Bot' });

    await interaction.editReply({ embeds: [embed] });

    console.log(`🔑 [RedeemAccess] Licença ativada para ${username} (${userId})`);

  } catch (error) {
    console.error('❌ [RedeemAccess] Erro:', error);
    await interaction.editReply({
      content: `❌ Erro ao processar código: ${error.message}`
    });
  }
}

export default { data, execute };
