/**
 * MutanoX Architect - Comando /remove-user
 * Remove um usuário da lista de autorizados (apenas o dono pode usar)
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  MessageFlags
} from 'discord.js';
import { isOwner, removeAuthorizedUser, isAuthorized } from '../utils/permissions.js';

export const data = new SlashCommandBuilder()
  .setName('remove-user')
  .setDescription('👑 Remove um usuário da lista de autorizados')
  .addUserOption(opt =>
    opt
      .setName('usuario')
      .setDescription('Usuário que será removido')
      .setRequired(true)
  );

export async function execute(interaction) {
  const userId = interaction.user.id;
  
  // Apenas o dono pode usar este comando
  if (!isOwner(userId)) {
    return interaction.reply({
      content: '❌ Apenas o dono do bot pode usar este comando.',
      flags: MessageFlags.Ephemeral
    });
  }

  const targetUser = interaction.options.getUser('usuario');

  // Verificar se está autorizado
  if (!isAuthorized(targetUser.id)) {
    return interaction.reply({
      content: `❌ O usuário ${targetUser.tag} não está na lista de autorizados.`,
      flags: MessageFlags.Ephemeral
    });
  }

  // Remover usuário
  const success = removeAuthorizedUser(targetUser.id);

  if (success) {
    const embed = new EmbedBuilder()
      .setTitle('✅ Usuário Removido')
      .setDescription(`${targetUser.tag} foi removido da lista de usuários autorizados.`)
      .addFields(
        { name: '👤 Usuário', value: `<@${targetUser.id}>`, inline: true },
        { name: '🆔 ID', value: targetUser.id, inline: true }
      )
      .setColor('#EF4444')
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  } else {
    await interaction.reply({
      content: '❌ Não foi possível remover o usuário.',
      flags: MessageFlags.Ephemeral
    });
  }
}

export default { data, execute };
