/**
 * MutanoX Architect - Comando /add-user
 * Adiciona um usuário à lista de autorizados (apenas o dono pode usar)
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  MessageFlags
} from 'discord.js';
import { isOwner, addAuthorizedUser, isAuthorized } from '../utils/permissions.js';

export const data = new SlashCommandBuilder()
  .setName('add-user')
  .setDescription('👑 Adiciona um usuário autorizado a usar os comandos')
  .addUserOption(opt =>
    opt
      .setName('usuario')
      .setDescription('Usuário que será autorizado')
      .setRequired(true)
  );

export async function execute(interaction) {
  const userId = interaction.user.id;
  
  // Apenas o dono pode usar este comando
  if (!isOwner(userId)) {
    return interaction.reply({
      content: '❌ Apenas o dono do bot pode usar este comando.',
      flags: MessageFlags.Ephemeral
    });
  }

  const targetUser = interaction.options.getUser('usuario');

  // Verificar se já está autorizado
  if (isAuthorized(targetUser.id)) {
    return interaction.reply({
      content: `❌ O usuário ${targetUser.tag} já está autorizado.`,
      flags: MessageFlags.Ephemeral
    });
  }

  // Adicionar usuário
  const success = addAuthorizedUser(targetUser.id);

  if (success) {
    const embed = new EmbedBuilder()
      .setTitle('✅ Usuário Autorizado')
      .setDescription(`${targetUser.tag} foi adicionado à lista de usuários autorizados!`)
      .addFields(
        { name: '👤 Usuário', value: `<@${targetUser.id}>`, inline: true },
        { name: '🆔 ID', value: targetUser.id, inline: true }
      )
      .setColor('#10B981')
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  } else {
    await interaction.reply({
      content: '❌ Não foi possível adicionar o usuário.',
      flags: MessageFlags.Ephemeral
    });
  }
}

export default { data, execute };
