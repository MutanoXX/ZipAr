/**
 * Rias-Grimory-X - Evento MessageCreate
 * VERSÃO 16.0 - Robusto e Funcional
 * 
 * FOCO:
 * - Parse de resposta mais robusto
 * - Fallback inteligente
 * - Mensagens úteis quando IA falha
 */

import { 
  EmbedBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle,
  StringSelectMenuBuilder,
  ChannelType,
  PermissionFlagsBits
} from 'discord.js';
import OpenAI from 'openai';
import { checkServerPermission } from '../utils/permissions.js';
import licenseManager from '../utils/licenseManager.js';
import { 
  isChannelActive, 
  getChannelContext, 
  addUserMessage,
  addAIMessage
} from '../utils/activeChannels.js';
import apiService from '../services/apiService.js';
import serverTools from '../utils/serverTools.js';
import automationManager from '../utils/automationManager.js';

// Módulos V6
import automodManager from '../utils/automodManager.js';
import logsManager from '../utils/logsManager.js';
import welcomeManager from '../utils/welcomeManager.js';
import ticketsManager from '../utils/ticketsManager.js';
import riasImages, { getRiasFooter, detectEmotion } from '../utils/riasImages.js';
import v6Handlers from '../utils/v6Handlers.js';

// Sistema de Mensagens da Rias
import { getRiasMessage, getRiasErrorMessage, sendRiasFollowUp } from '../utils/riasMessages.js';

// Referência global ao client do Discord
let discordClient = null;

export function setClient(client) {
  discordClient = client;
}

const NVIDIA_KEY = process.env.NVIDIA_API_KEY || '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';

const client = new OpenAI({
  baseURL: 'https://integrate.api.nvidia.com/v1',
  apiKey: NVIDIA_KEY,
  timeout: 45000,
  maxRetries: 2
});

export const name = 'messageCreate';

export async function execute(message) {
  if (message.author.bot || !message.guild) return;

  const guild = message.guild;
  const channel = message.channel;
  const userId = message.author.id;

  if (!isChannelActive(guild.id, channel.id)) return;
  
  // Verificar licença do usuário
  const licenseCheck = licenseManager.checkUserPermission(userId, guild, message.member);
  
  if (!licenseCheck.authorized) {
    // Se a licença expirou, avisar o usuário
    if (licenseCheck.licenseStatus === 'expired') {
      const expiredEmbed = new EmbedBuilder()
        .setTitle('⚠️ Licença Expirada!')
        .setDescription(licenseCheck.reason)
        .setColor('#EF4444')
        .setTimestamp()
        .setFooter({ text: '💎 Rias-Grimory-X Bot' });
      
      return await message.reply({ 
        embeds: [expiredEmbed], 
        allowedMentions: { repliedUser: false } 
      }).catch(() => {});
    }
    
    // Sem licença ou sem permissão no servidor
    return;
  }

  channel.sendTyping().catch(() => {});

  let thinkingMsg = null;

  try {
    let userContent = message.content;

    if (message.attachments.size > 0) {
      const attachmentsInfo = [];
      for (const attachment of message.attachments.values()) {
        attachmentsInfo.push(`[ANEXO: ${attachment.name}] - ${attachment.url}`);
      }
      userContent += "\n\nANEXOS:\n" + attachmentsInfo.join("\n");
    }

    addUserMessage(channel.id, userContent, message.author.tag);
    const messages = getChannelContext(channel.id);

    // Verificar se há mensagens de contexto
    if (!messages || messages.length === 0) {
      console.error('❌ [IA] Sem contexto de mensagens!');
      return await sendErrorEmbed(message, null, 'Canal não inicializado. Use /ask on primeiro!');
    }

    console.log(`🚀 [IA] Processando: ${userContent.substring(0, 50)}...`);

    const thinkingEmbed = new EmbedBuilder()
      .setTitle('🤔 Processando...')
      .setDescription('Estou trabalhando nisso! ✨')
      .setColor('#FBBF24')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();

    thinkingMsg = await message.reply({ 
      embeds: [thinkingEmbed], 
      allowedMentions: { repliedUser: false } 
    }).catch(() => null);

    let completion;
    try {
      completion = await client.chat.completions.create({
        model: 'stepfun-ai/step-3.5-flash',
        messages: messages,
        temperature: 0.7,
        max_tokens: 4000,
        stream: false
      });
    } catch (apiError) {
      console.error('❌ [IA] Erro API:', apiError.message);
      return await handleFallback(message, thinkingMsg, userContent);
    }

    const content = completion.choices[0]?.message?.content || '';
    
    console.log(`📝 [IA] Resposta (${content.length} chars):`, content.substring(0, 200));
    
    if (!content || content.trim() === '') {
      console.error('❌ [IA] Resposta vazia!');
      return await handleFallback(message, thinkingMsg, userContent);
    }
    
    const response = parseResponse(content);
    
    addAIMessage(channel.id, content);

    await handleResponse(message, response, guild, channel, thinkingMsg);

  } catch (error) {
    console.error('❌ [Erro]:', error);
    await sendErrorEmbed(message, thinkingMsg, error.message);
  }
}

/**
 * Parse robusto da resposta - MÚLTIPLAS TENTATIVAS
 */
function parseResponse(content) {
  if (!content) {
    return { type: 'message', content: 'Desculpe, não consegui processar isso.' };
  }
  
  try {
    // 1. Tentar extrair JSON de bloco de código
    const codeBlockRegex = /```(?:json)?\s*([\s\S]*?)```/g;
    let match = codeBlockRegex.exec(content);
    while (match) {
      try {
        const parsed = JSON.parse(match[1].trim());
        if (parsed && parsed.type) {
          console.log(`📦 [Parse] JSON de bloco de código`);
          return parsed;
        }
      } catch (e) {}
      match = codeBlockRegex.exec(content);
    }
    
    // 2. Tentar encontrar JSON no conteúdo
    const jsonMatches = content.match(/\{[\s\S]*?\}/g);
    if (jsonMatches) {
      for (const jsonStr of jsonMatches) {
        try {
          const parsed = JSON.parse(jsonStr);
          if (parsed && parsed.type) {
            console.log(`📦 [Parse] JSON encontrado no conteúdo`);
            return parsed;
          }
        } catch (e) {}
      }
    }
    
    // 3. Se parece ser um comando mas sem JSON
    const lowerContent = content.toLowerCase();
    if (lowerContent.includes('criar') || lowerContent.includes('deletar') || 
        lowerContent.includes('listar') || lowerContent.includes('mandar')) {
      // Tentar extrair tipo do texto
      const typeMatch = lowerContent.match(/(criar|deletar|listar|mandar|enviar|editar)/);
      if (typeMatch) {
        console.log(`⚠️ [Parse] Detectado comando sem JSON: ${typeMatch[1]}`);
        return { 
          type: 'message', 
          content: `Hmm, parece que você quer ${typeMatch[1]} algo, mas não entendi os detalhes! Pode ser mais específico? 🌹\n\nExemplo: "Crie um canal chamado memes"` 
        };
      }
    }
    
    // 4. Retornar como mensagem simples
    return { type: 'message', content: content };
    
  } catch (e) {
    console.log('⚠️ [Parse] Erro, usando texto');
    return { type: 'message', content: content };
  }
}

/**
 * Processa a resposta baseado no tipo
 */
async function handleResponse(message, response, guild, channel, thinkingMsg) {
  const type = response.type?.toLowerCase() || 'message';
  
  console.log(`📋 [Tipo] ${type}`);

  switch (type) {
    // === FERRAMENTAS EXTERNAS ===
    case 'consultar_cnpj':
    case 'consulta_cnpj':
      await handleCNPJ(message, response, thinkingMsg);
      break;
      
    case 'consultar_cpf':
    case 'consulta_cpf':
      await handleCPF(message, response, thinkingMsg);
      break;
      
    case 'buscar_imagens_google':
    case 'google_image':
    case 'busca_imagem':
      await handleImageSearch(message, response, guild, channel, thinkingMsg);
      break;
      
    case 'video_cosplay_anime':
    case 'cosplay_video':
      await handleCosplayVideo(message, thinkingMsg);
      break;
      
    case 'gerar_imagem':
    case 'dalle_nsfw':
    case 'dalle':
      await handleDalle(message, response, thinkingMsg);
      break;
      
    case 'gerar_arquivo':
    case 'generate_file':
      await handleFileGeneration(message, response, thinkingMsg);
      break;

    // === FERRAMENTAS DE CANAIS ===
    case 'criar_canal':
    case 'create_channel':
      await handleCreateChannel(message, response, guild, channel, thinkingMsg);
      break;
      
    case 'editar_canal':
    case 'edit_channel':
      await handleEditChannel(message, response, guild, thinkingMsg);
      break;
      
    case 'deletar_canal':
    case 'delete_channel':
      await handleDeleteChannel(message, response, guild, thinkingMsg);
      break;
      
    case 'clonar_canal':
    case 'clone_channel':
      await handleCloneChannel(message, response, guild, thinkingMsg);
      break;
      
    case 'trancar_canal':
    case 'lock_channel':
      await handleLockChannel(message, response, guild, thinkingMsg);
      break;
      
    case 'esconder_canal':
    case 'hide_channel':
      await handleHideChannel(message, response, guild, thinkingMsg);
      break;
      
    case 'permissao_canal':
    case 'channel_permission':
      await handleChannelPermission(message, response, guild, thinkingMsg);
      break;
      
    case 'criar_categoria':
    case 'create_category':
      await handleCreateCategory(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_canais':
    case 'list_channels':
      await handleListChannels(message, response, guild, thinkingMsg);
      break;

    // === FERRAMENTAS DE CARGOS ===
    case 'criar_cargo':
    case 'create_role':
      await handleCreateRole(message, response, guild, thinkingMsg);
      break;
      
    case 'editar_cargo':
    case 'edit_role':
      await handleEditRole(message, response, guild, thinkingMsg);
      break;
      
    case 'deletar_cargo':
    case 'delete_role':
      await handleDeleteRole(message, response, guild, thinkingMsg);
      break;
      
    case 'clonar_cargo':
    case 'clone_role':
      await handleCloneRole(message, response, guild, thinkingMsg);
      break;
      
    case 'adicionar_cargo':
    case 'add_role':
      await handleAddRole(message, response, guild, thinkingMsg);
      break;
      
    case 'remover_cargo':
    case 'remove_role':
      await handleRemoveRole(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_cargos':
    case 'list_roles':
      await handleListRoles(message, response, guild, thinkingMsg);
      break;

    // === FERRAMENTAS DE MEMBROS ===
    case 'expulsar':
    case 'kick':
      await handleKick(message, response, guild, thinkingMsg);
      break;
      
    case 'banir':
    case 'ban':
      await handleBan(message, response, guild, thinkingMsg);
      break;
      
    case 'desbanir':
    case 'unban':
      await handleUnban(message, response, guild, thinkingMsg);
      break;
      
    case 'mutar':
    case 'mute':
    case 'timeout':
      await handleMute(message, response, guild, thinkingMsg);
      break;
      
    case 'desmutar':
    case 'unmute':
      await handleUnmute(message, response, guild, thinkingMsg);
      break;
      
    case 'apelido':
    case 'nickname':
    case 'set_nickname':
      await handleNickname(message, response, guild, thinkingMsg);
      break;
      
    case 'info_membro':
    case 'member_info':
      await handleMemberInfo(message, response, guild, thinkingMsg);
      break;
      
    case 'membros_cargo':
    case 'members_by_role':
      await handleMembersByRole(message, response, guild, thinkingMsg);
      break;

    // === FERRAMENTAS DE MENSAGENS ===
    case 'deletar_mensagens':
    case 'bulk_delete':
    case 'clear':
      await handleBulkDelete(message, response, guild, channel, thinkingMsg);
      break;
      
    case 'fixar_mensagem':
    case 'pin_message':
      await handlePinMessage(message, response, channel, thinkingMsg);
      break;
      
    case 'desfixar_mensagem':
    case 'unpin_message':
      await handleUnpinMessage(message, response, channel, thinkingMsg);
      break;

    // === FERRAMENTAS DE WEBHOOKS ===
    case 'criar_webhook':
    case 'create_webhook':
      await handleCreateWebhook(message, response, channel, thinkingMsg);
      break;
      
    case 'listar_webhooks':
    case 'list_webhooks':
      await handleListWebhooks(message, channel, thinkingMsg);
      break;
      
    case 'listar_webhooks_servidor':
    case 'list_guild_webhooks':
      await handleListGuildWebhooks(message, guild, thinkingMsg);
      break;
      
    case 'info_webhook':
    case 'get_webhook':
      await handleGetWebhook(message, response, guild, thinkingMsg);
      break;
      
    case 'editar_webhook':
    case 'edit_webhook':
      await handleEditWebhook(message, response, channel, thinkingMsg);
      break;
      
    case 'deletar_webhook':
    case 'delete_webhook':
      await handleDeleteWebhook(message, response, channel, thinkingMsg);
      break;
      
    case 'enviar_webhook':
    case 'send_webhook':
      await handleSendWebhook(message, response, channel, thinkingMsg);
      break;

    // === FERRAMENTAS DE CONVITES ===
    case 'criar_convite':
    case 'create_invite':
      await handleCreateInvite(message, response, channel, thinkingMsg);
      break;
      
    case 'listar_convites':
    case 'list_invites':
      await handleListInvites(message, guild, thinkingMsg);
      break;
      
    case 'deletar_convite':
    case 'delete_invite':
      await handleDeleteInvite(message, response, guild, thinkingMsg);
      break;

    // === FERRAMENTAS DE EMOJIS ===
    case 'adicionar_emoji':
    case 'add_emoji':
      await handleAddEmoji(message, response, guild, thinkingMsg);
      break;
      
    case 'deletar_emoji':
    case 'delete_emoji':
      await handleDeleteEmoji(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_emojis':
    case 'list_emojis':
      await handleListEmojis(message, guild, thinkingMsg);
      break;

    // === SISTEMA DE AUTOMAÇÃO ===
    case 'criar_automacao':
    case 'create_automation':
      await handleCreateAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_automacoes':
    case 'list_automations':
      await handleListAutomations(message, guild, thinkingMsg);
      break;
      
    case 'pausar_automacao':
    case 'pause_automation':
      await handlePauseAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'retomar_automacao':
    case 'resume_automation':
      await handleResumeAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'deletar_automacao':
    case 'delete_automation':
      await handleDeleteAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'editar_automacao':
    case 'edit_automation':
      await handleEditAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'executar_automacao':
    case 'run_automation':
      await handleRunAutomation(message, response, guild, thinkingMsg);
      break;

    // === INFORMAÇÕES DO SERVIDOR ===
    case 'server_stats':
    case 'estatisticas':
    case 'info_servidor':
      await handleServerStats(message, guild, thinkingMsg);
      break;

    // === OUTRAS FERRAMENTAS ===
    case 'enviar_embed':
    case 'send_embed':
      await handleSendEmbed(message, response, guild, channel, thinkingMsg);
      break;
      
    case 'criar_enquete':
    case 'create_poll':
      await handlePoll(message, response, thinkingMsg);
      break;

    // === SISTEMAS V6.0 ===
    case 'config_automod':
    case 'configurar_automod':
      await v6Handlers.handleConfigAutomod(message, response, guild, thinkingMsg);
      break;
      
    case 'ver_automod':
    case 'listar_automod':
      await v6Handlers.handleVerAutomod(message, guild, thinkingMsg);
      break;
      
    case 'desativar_automod':
      await v6Handlers.handleDesativarAutomod(message, response, guild, thinkingMsg);
      break;
      
    case 'advertir':
    case 'avisar':
    case 'warn':
      await v6Handlers.handleAdvertir(message, response, guild, thinkingMsg);
      break;
      
    case 'ver_advertencias':
    case 'ver_warns':
      await v6Handlers.handleVerAdvertencias(message, response, guild, thinkingMsg);
      break;

    case 'config_logs':
    case 'configurar_logs':
      await v6Handlers.handleConfigLogs(message, response, guild, thinkingMsg);
      break;
      
    case 'ver_logs':
    case 'listar_logs':
      await v6Handlers.handleVerLogs(message, guild, thinkingMsg);
      break;
      
    case 'desativar_logs':
      await v6Handlers.handleDesativarLogs(message, guild, thinkingMsg);
      break;
      
    case 'logs_moderacao':
    case 'logs_mod':
      await v6Handlers.handleLogsModeracao(message, response, guild, thinkingMsg);
      break;
      
    case 'exportar_logs':
      await v6Handlers.handleExportarLogs(message, response, guild, thinkingMsg);
      break;

    case 'config_bemvindo':
    case 'config_welcome':
      await v6Handlers.handleConfigBemvindo(message, response, guild, thinkingMsg);
      break;
      
    case 'config_autorole':
      await v6Handlers.handleConfigAutorole(message, response, guild, thinkingMsg);
      break;
      
    case 'config_saida':
    case 'config_goodbye':
      await v6Handlers.handleConfigSaida(message, response, guild, thinkingMsg);
      break;
      
    case 'ver_bemvindo':
      await v6Handlers.handleVerBemvindo(message, guild, thinkingMsg);
      break;
      
    case 'testar_bemvindo':
      await v6Handlers.handleTestarBemvindo(message, guild, thinkingMsg);
      break;

    case 'criar_painel_tickets':
    case 'criar_painel':
      await v6Handlers.handleCriarPainelTickets(message, response, guild, thinkingMsg);
      break;
      
    case 'criar_ticket':
    case 'abrir_ticket':
      await v6Handlers.handleCriarTicket(message, response, guild, thinkingMsg);
      break;
      
    case 'fechar_ticket':
    case 'close_ticket':
      await v6Handlers.handleFecharTicket(message, response, guild, thinkingMsg);
      break;
      
    case 'adicionar_ticket':
    case 'add_ticket':
      await v6Handlers.handleAdicionarTicket(message, response, guild, thinkingMsg);
      break;
      
    case 'remover_ticket':
      await v6Handlers.handleRemoverTicket(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_tickets':
    case 'ver_tickets':
      await v6Handlers.handleListarTickets(message, guild, thinkingMsg);
      break;

    case 'saldo':
    case 'balance':
      await v6Handlers.handleSaldo(message, response, guild, thinkingMsg);
      break;
      
    case 'adicionar_moedas':
    case 'add_coins':
      await v6Handlers.handleAdicionarMoedas(message, response, guild, thinkingMsg);
      break;
      
    case 'transferir':
    case 'pay':
      await v6Handlers.handleTransferir(message, response, guild, thinkingMsg);
      break;
      
    case 'daily':
      await v6Handlers.handleDaily(message, guild, thinkingMsg);
      break;
      
    case 'trabalhar':
    case 'work':
      await v6Handlers.handleTrabalhar(message, guild, thinkingMsg);
      break;
      
    case 'ver_loja':
    case 'shop':
      await v6Handlers.handleVerLoja(message, guild, thinkingMsg);
      break;
      
    case 'criar_item':
    case 'add_item_loja':
      await v6Handlers.handleCriarItem(message, response, guild, thinkingMsg);
      break;
      
    case 'comprar':
    case 'buy':
      await v6Handlers.handleComprar(message, response, guild, thinkingMsg);
      break;
      
    case 'ranking_economia':
    case 'leaderboard':
      await v6Handlers.handleRankingEconomia(message, guild, thinkingMsg);
      break;

    case 'criar_giveaway':
    case 'sorteio':
      await v6Handlers.handleCriarGiveaway(message, response, guild, thinkingMsg);
      break;
      
    case 'encerrar_giveaway':
    case 'end_giveaway':
      await v6Handlers.handleEncerrarGiveaway(message, response, guild, thinkingMsg);
      break;
      
    case 'rerolar_giveaway':
    case 'reroll':
      await v6Handlers.handleRerolarGiveaway(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_giveaways':
      await v6Handlers.handleListarGiveaways(message, guild, thinkingMsg);
      break;

    case '8ball':
    case 'bola_magica':
      await v6Handlers.handle8ball(message, response, thinkingMsg);
      break;
      
    case 'roleta_russa':
      await v6Handlers.handleRoletaRussa(message, guild, thinkingMsg);
      break;
      
    case 'rps':
    case 'pedra_papel_tesoura':
      await v6Handlers.handleRPS(message, response, thinkingMsg);
      break;
      
    case 'casar':
    case 'marry':
      await v6Handlers.handleCasar(message, response, guild, thinkingMsg);
      break;
      
    case 'divorciar':
    case 'divorce':
      await v6Handlers.handleDivorciar(message, guild, thinkingMsg);
      break;
      
    case 'ship':
      await v6Handlers.handleShip(message, response, guild, thinkingMsg);
      break;
      
    case 'meme':
      await v6Handlers.handleMeme(message, thinkingMsg);
      break;
      
    case 'piada':
    case 'joke':
      await v6Handlers.handlePiada(message, thinkingMsg);
      break;
      
    case 'verdade_desafio':
    case 'truth_dare':
      await v6Handlers.handleVerdadeDesafio(message, response, thinkingMsg);
      break;

    case 'clima':
    case 'weather':
      await v6Handlers.handleClima(message, response, thinkingMsg);
      break;
      
    case 'traduzir':
    case 'translate':
      await v6Handlers.handleTraduzir(message, response, thinkingMsg);
      break;
      
    case 'wiki':
    case 'wikipedia':
      await v6Handlers.handleWiki(message, response, thinkingMsg);
      break;
      
    case 'filme':
    case 'movie':
      await v6Handlers.handleFilme(message, response, thinkingMsg);
      break;
      
    case 'crypto':
    case 'cripto':
      await v6Handlers.handleCrypto(message, response, thinkingMsg);
      break;
      
    case 'qrcode':
      await v6Handlers.handleQRCode(message, response, thinkingMsg);
      break;

    case 'nivel':
    case 'level':
    case 'rank':
      await v6Handlers.handleNivel(message, response, guild, thinkingMsg);
      break;
      
    case 'adicionar_xp':
    case 'add_xp':
      await v6Handlers.handleAdicionarXP(message, response, guild, thinkingMsg);
      break;
      
    case 'ranking_nivel':
    case 'ranking_level':
      await v6Handlers.handleRankingNivel(message, guild, thinkingMsg);
      break;
      
    case 'recompensa_nivel':
      await v6Handlers.handleRecompensaNivel(message, response, guild, thinkingMsg);
      break;

    // === TAREFA COMPLEXA - CORRIGIDO ===
    case 'complex_task':
    case 'tarefa_complexa':
      await handleComplexTask(message, response, guild, channel, thinkingMsg);
      break;

    // === MENSAGEM SIMPLES ===
    case 'message':
    default:
      await handleMessage(message, response, thinkingMsg);
  }
}

// ============================================
// FUNÇÕES AUXILIARES
// ============================================

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function editEmbed(thinkingMsg, titleOrEmbed, description, color) {
  if (!thinkingMsg) return;
  
  try {
    if (typeof titleOrEmbed === 'object' && titleOrEmbed.constructor?.name === 'EmbedBuilder') {
      await thinkingMsg.edit({ embeds: [titleOrEmbed] });
    } else {
      const embed = new EmbedBuilder()
        .setTitle(titleOrEmbed)
        .setDescription((description || '').trim() || 'Sem descrição')
        .setColor(color || '#8B5CF6')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      await thinkingMsg.edit({ embeds: [embed] });
    }
  } catch (e) {
    console.error('Erro ao editar embed:', e.message);
  }
}

async function sendErrorEmbed(message, thinkingMsg, errorText) {
  const embed = new EmbedBuilder()
    .setTitle('❌ Erro!')
    .setDescription(errorText || 'Ocorreu um erro desconhecido')
    .setColor('#EF4444')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  if (thinkingMsg) {
    await editEmbed(thinkingMsg, embed);
  } else {
    await message.reply({ embeds: [embed], allowedMentions: { repliedUser: false } });
  }
}

async function handleFallback(message, thinkingMsg, userContent) {
  const embed = new EmbedBuilder()
    .setTitle('⚠️ Modo Fallback')
    .setDescription('Tive problemas para processar sua solicitação. Pode tentar novamente? 💖')
    .setColor('#F59E0B')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
}

// ============================================
// FERRAMENTAS EXTERNAS - CPF/CNPJ
// ============================================

async function handleCNPJ(message, response, thinkingMsg) {
  const cnpj = response.cnpj || response.value || response.cnpj_number;
  if (!cnpj) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'CNPJ não informado!', '#EF4444');
  }
  
  const result = await apiService.consultaCNPJ(cnpj);
  
  if (result.status === 'success' || result.data) {
    const data = result.data || result;
    
    const embed = new EmbedBuilder()
      .setTitle('📋 Consulta CNPJ - Resultado')
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    if (data.razao_social || data['RAZÃO SOCIAL']) {
      embed.setDescription(`**${data.razao_social || data['RAZÃO SOCIAL']}**`);
    }
    
    const fields = [];
    const campos = {
      'Razão Social': data.razao_social || data['RAZÃO SOCIAL'],
      'Nome Fantasia': data.nome_fantasia || data['NOME FANTASIA'],
      'CNPJ': data.cnpj || data['CNPJ'] || cnpj,
      'Situação': data.situacao || data['SITUAÇÃO'],
      'Data Abertura': data.abertura || data.data_abertura || data['ABERTURA'],
      'Atividade Principal': data.atividade_principal?.[0]?.text || data['ATIVIDADE PRINCIPAL'],
      'Município': data.municipio || data['MUNICÍPIO'],
      'UF': data.uf || data['UF'],
      'Email': data.email || data['EMAIL'],
      'Telefone': data.telefone || data['TELEFONE']
    };
    
    for (const [name, value] of Object.entries(campos)) {
      if (value && value !== 'null' && value !== '') {
        fields.push({ name: `📝 ${name}`, value: String(value).substring(0, 500), inline: true });
      }
    }
    
    embed.addFields(fields.slice(0, 25));
    await editEmbed(thinkingMsg, embed);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', result.error || 'CNPJ não encontrado', '#EF4444');
  }
}

async function handleCPF(message, response, thinkingMsg) {
  const cpf = response.cpf || response.value;
  if (!cpf) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'CPF não informado!', '#EF4444');
  }
  
  const result = await apiService.consultaCPF(cpf);
  
  if (result.status === 'success' || result.nome || result.data) {
    const data = result.data || result;
    
    const embed = new EmbedBuilder()
      .setTitle('👤 Consulta CPF - Resultado')
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    if (result.nome || data.nome || data.NOME) {
      embed.setDescription(`**${result.nome || data.nome || data.NOME}**`);
    }
    
    const fields = [];
    const campos = {
      'Nome': result.nome || data.nome || data.NOME,
      'CPF': data.cpf || data.CPF || cpf,
      'Data de Nascimento': result.data_nascimento || data.data_nascimento,
      'Nome da Mãe': result.nome_mae || data.nome_mae,
      'Cidade': data.cidade || data.municipio,
      'UF': data.uf || data.UF
    };
    
    for (const [name, value] of Object.entries(campos)) {
      if (value && value !== 'null' && value !== '') {
        fields.push({ name: `📝 ${name}`, value: String(value).substring(0, 500), inline: true });
      }
    }
    
    embed.addFields(fields.slice(0, 25));
    await editEmbed(thinkingMsg, embed);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', result.error || 'CPF não encontrado', '#EF4444');
  }
}

// ============================================
// BUSCA DE IMAGENS - CORRIGIDO
// ============================================

async function handleImageSearch(message, response, guild, currentChannel, thinkingMsg) {
  const query = response.query || response.termo || response.busca;
  const quantidade = Math.min(response.quantidade || response.amount || 5, 20);
  const canalDestino = response.canal_destino || response.targetChannel;
  
  if (!query) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'Termo de busca não informado!', '#EF4444');
  }
  
  // Determinar canal de destino
  let targetChannel = currentChannel;
  
  if (canalDestino === 'auto' && global.lastCreatedChannel) {
    targetChannel = global.lastCreatedChannel;
  } else if (canalDestino && canalDestino !== 'auto') {
    const found = guild.channels.cache.find(c => 
      c.name.toLowerCase().includes(canalDestino.toLowerCase()) || c.id === canalDestino
    );
    if (found) targetChannel = found;
  }
  
  console.log(`🖼️ [ImageSearch] Buscando ${quantidade} imagens de: ${query}`);
  console.log(`🖼️ [ImageSearch] Canal de destino: ${targetChannel.name}`);
  
  const result = await apiService.searchGoogleImage(query);
  
  if (result.success && result.data?.result?.length > 0) {
    // ✅ CORREÇÃO: Remover duplicatas usando Set de URLs
    const seenUrls = new Set();
    const uniqueImages = [];
    
    // Pegar mais imagens para compensar possíveis duplicatas
    const allImages = result.data.result.slice(0, Math.min(quantidade * 2, 40));
    
    for (const img of allImages) {
      if (img?.url && !seenUrls.has(img.url)) {
        seenUrls.add(img.url);
        uniqueImages.push(img);
        
        // Parar quando tiver a quantidade desejada
        if (uniqueImages.length >= quantidade) break;
      }
    }
    
    const images = uniqueImages;
    
    if (images.length === 0) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'Nenhuma imagem válida encontrada', '#EF4444');
    }
    
    const embed = new EmbedBuilder()
      .setTitle('🖼️ Imagens Encontradas!')
      .setDescription(`Busca: **${query}**\n\n✨ Encontrei **${images.length}** imagem(ns) única(s)! Enviando em ${targetChannel}...`)
      .setColor('#8B5CF6')
      .setFooter({ text: `💎 Rias-Grimory-X | ${images.length} imagens` })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    // Enviar imagens com numeração correta
    for (let i = 0; i < images.length; i++) {
      if (images[i]?.url) {
        const numEmbed = new EmbedBuilder()
          .setTitle(`🖼️ Imagem ${i + 1}/${images.length}`)
          .setDescription(`**${query}**`)
          .setImage(images[i].url)
          .setColor('#8B5CF6')
          .setFooter({ text: '💎 Rias-Grimory-X' })
          .setTimestamp();
        
        await targetChannel.send({ embeds: [numEmbed] }).catch(e => {
          console.error(`Erro ao enviar imagem ${i + 1}:`, e.message);
        });
        
        await sleep(500); // Delay entre envios
      }
    }
    
    console.log(`✅ [ImageSearch] ${images.length} imagens únicas enviadas para ${targetChannel.name}`);
    
    // 🌹 Enviar mensagem personalizada da Rias no final
    await sendRiasFollowUp(targetChannel, 'google_image', true);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', 'Nenhuma imagem encontrada', '#EF4444');
    // 🌹 Enviar mensagem de erro da Rias
    await sendRiasFollowUp(currentChannel, 'google_image', false);
  }
}

async function handleCosplayVideo(message, thinkingMsg) {
  const result = await apiService.getCosplayVideo();
  
  if (result.status === 'success' && result.media?.url) {
    const embed = new EmbedBuilder()
      .setTitle('🎬 Vídeo de Cosplay!')
      .setDescription(`Aqui está seu vídeo! ✨🔥\n\n[▶️ Assistir Vídeo](${result.media.url})`)
      .setColor('#EC4899')
      .setFooter({ text: `Por: ${result.author || 'Cosplay'}` })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', 'Não foi possível obter o vídeo', '#EF4444');
  }
}

async function handleDalle(message, response, thinkingMsg) {
  const prompt = response.prompt || response.descricao;
  if (!prompt) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'Descrição não informada!', '#EF4444');
  }
  
  const result = await apiService.dalleXlloraText2image(prompt, response.negative || 'low quality');
  
  if (result.success && result.data?.result) {
    const embed = new EmbedBuilder()
      .setTitle('🎨 Imagem Gerada!')
      .setDescription(`Prompt: **${prompt.substring(0, 100)}**\n\nAqui está sua arte! ✨`)
      .setImage(result.data.result)
      .setColor('#F59E0B')
      .setFooter({ text: '💎 Rias-Grimory-X - Dalle' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    // 🌹 Enviar mensagem personalizada da Rias no final
    await sendRiasFollowUp(message.channel, 'dalle', true);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', result.error || 'Falha ao gerar imagem', '#EF4444');
    await sendRiasFollowUp(message.channel, 'dalle', false);
  }
}

async function handleFileGeneration(message, response, thinkingMsg) {
  const fileType = response.fileType || response.tipo || 'txt';
  const filename = response.filename || response.nome || `arquivo.${fileType === 'pdf' ? 'pdf' : 'txt'}`;
  const content = response.content || response.conteudo;
  
  if (!content) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'Conteúdo não informado!', '#EF4444');
  }
  
  try {
    let filePath;
    if (fileType === 'pdf') {
      filePath = await apiService.generatePDF(filename, content);
    } else {
      filePath = await apiService.generateTextFile(filename, content);
    }
    
    const uploadResult = await apiService.uploadFile(filePath);
    
    const embed = new EmbedBuilder()
      .setTitle('📄 Arquivo Criado!')
      .setDescription(`✅ Seu arquivo **${filename}** está pronto!\n\n${uploadResult.success ? `📥 [Download](${uploadResult.url})` : 'Arquivo gerado!'}`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    if (thinkingMsg) {
      await thinkingMsg.edit({ embeds: [embed], files: [filePath] }).catch(() => {
        message.channel.send({ embeds: [embed], files: [filePath] });
      });
    }
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao criar arquivo: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE CANAIS - CORRIGIDO
// ============================================

async function handleCreateChannel(message, response, guild, currentChannel, thinkingMsg) {
  try {
    // Verificar se há categoria para passar como parent
    let parentId = null;
    const categoriaNome = response.categoria || response.parent || response.parentId;
    
    if (categoriaNome) {
      // Buscar categoria por nome ou ID
      const category = guild.channels.cache.find(c => 
        c.type === ChannelType.GuildCategory && 
        (c.name.toLowerCase() === categoriaNome.toLowerCase() || 
         c.name.toLowerCase().includes(categoriaNome.toLowerCase()) ||
         c.id === categoriaNome)
      );
      
      if (category) {
        parentId = category.id;
        console.log(`📁 [CreateChannel] Categoria encontrada: ${category.name} (${category.id})`);
      } else {
        console.log(`⚠️ [CreateChannel] Categoria não encontrada: ${categoriaNome}`);
      }
    }
    
    const result = await serverTools.createChannel(guild, {
      name: response.name || response.nome,
      type: response.tipo || response.channelType || 'texto',
      parent: parentId, // Passar o ID da categoria
      topic: response.topico || response.topic,
      slowmode: response.slowmode,
      nsfw: response.nsfw,
      bitrate: response.bitrate,
      userLimit: response.userLimit || response.limite_usuarios,
      permissions: response.permissoes || response.permissions
    });
    
    // Armazenar o canal criado globalmente para tarefas complexas
    global.lastCreatedChannel = result.discordChannel;
    global.lastCreatedChannelId = result.channel.id;
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Canal Criado!')
      .setDescription(`Canal ${result.channel.mention} criado com sucesso! 🎉`)
      .addFields(
        { name: '📝 Nome', value: result.channel.name, inline: true },
        { name: '📁 Tipo', value: result.channel.type, inline: true },
        { name: '🆔 ID', value: result.channel.id, inline: true }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    // 🌹 Enviar mensagem personalizada da Rias no final
    await sendRiasFollowUp(message.channel, 'criar_canal', true);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao criar canal: ${error.message}`, '#EF4444');
    await sendRiasFollowUp(message.channel, 'criar_canal', false);
  }
}

async function handleEditChannel(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.editChannel(guild, {
      channel: response.canal || response.channel || response.channelId,
      name: response.nome || response.name,
      topic: response.topico || response.topic,
      slowmode: response.slowmode,
      nsfw: response.nsfw,
      bitrate: response.bitrate,
      userLimit: response.userLimit || response.limite_usuarios,
      position: response.posicao || response.position
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Canal Editado!')
      .setDescription(`Canal **${result.channel.name}** foi atualizado! 🎉`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao editar canal: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteChannel(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.deleteChannel(
      guild, 
      response.canal || response.channel || response.channelId || response.nome || response.name
    );
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Canal Deletado!')
      .setDescription(`Canal **#${result.name}** foi deletado! 🗑️`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao deletar canal: ${error.message}`, '#EF4444');
  }
}

async function handleCloneChannel(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.cloneChannel(
      guild, 
      response.canal || response.channel || response.channelId,
      response.novo_nome || response.newName
    );
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Canal Clonado!')
      .setDescription(`Canal **#${result.original}** foi clonado!`)
      .addFields({ name: '📝 Novo Canal', value: result.cloned.mention, inline: true })
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao clonar canal: ${error.message}`, '#EF4444');
  }
}

async function handleLockChannel(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.lockChannel(
      guild, 
      response.canal || response.channel || response.channelId,
      response.trancar !== false && response.lock !== false
    );
    
    const embed = new EmbedBuilder()
      .setTitle(result.locked ? '🔒 Canal Trancado!' : '🔓 Canal Destrancado!')
      .setDescription(`Canal **${result.channel}** foi ${result.locked ? 'trancado' : 'destrancado'}!`)
      .setColor(result.locked ? '#F59E0B' : '#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleHideChannel(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.hideChannelFromRole(guild, {
      channel: response.canal || response.channel,
      role: response.cargo || response.role,
      hidden: response.esconder !== false && response.hidden !== false
    });
    
    const embed = new EmbedBuilder()
      .setTitle(result.hidden ? '🙈 Canal Escondido!' : '👁️ Canal Visível!')
      .setDescription(`Canal **${result.channel}** ${result.hidden ? 'escondido de' : 'visível para'} **@${result.role}**!`)
      .setColor(result.hidden ? '#F59E0B' : '#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleChannelPermission(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.setChannelPermissions(guild, {
      channel: response.canal || response.channel,
      role: response.cargo || response.role,
      allow: response.permitir || response.allow || [],
      deny: response.negar || response.deny || []
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Permissões Atualizadas!')
      .setDescription(`Permissões de **@${result.role}** no canal **${result.channel}** foram atualizadas!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// CRIAR CATEGORIA - CORRIGIDO
// ============================================

async function handleCreateCategory(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.createCategory(guild, {
      name: response.nome || response.name,
      channels: response.canais || response.channels || [],
      permissions: response.permissoes || response.permissions || []
    });
    
    // Armazenar a categoria criada globalmente para tarefas complexas
    global.lastCreatedCategory = result.category;
    global.lastCreatedCategoryId = result.category.id;
    global.lastCreatedCategoryName = result.category.name; // Nome para matching parcial
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Categoria Criada!')
      .setDescription(`Categoria ${result.category.mention} criada! 🎉`)
      .addFields(
        { name: '📝 Nome', value: result.category.name, inline: true },
        { name: '🆔 ID', value: result.category.id, inline: true },
        { name: '📁 Canais Criados', value: result.channels.length > 0 ? result.channels.join(', ') : 'Nenhum', inline: false }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    // 🌹 Enviar mensagem personalizada da Rias no final
    await sendRiasFollowUp(message.channel, 'criar_categoria', true);
    
    console.log(`✅ [CreateCategory] Categoria criada: ${result.category.name} (${result.category.id})`);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao criar categoria: ${error.message}`, '#EF4444');
    await sendRiasFollowUp(message.channel, 'criar_categoria', false);
  }
}

async function handleListChannels(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.listChannels(guild, response.tipo || response.type || 'all');
    
    const channelList = result.channels.slice(0, 20).map(c => 
      `• ${c.type === 'categoria' ? '📁' : c.type === 'voz' ? '🔊' : '💬'} **${c.name}**`
    ).join('\n');
    
    const embed = new EmbedBuilder()
      .setTitle('📁 Canais do Servidor')
      .setDescription(channelList || 'Nenhum canal encontrado')
      .addFields({ name: '📊 Total', value: `${result.channels.length} canais`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE CARGOS
// ============================================

async function handleCreateRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.createRole(guild, {
      name: response.nome || response.name,
      color: response.cor || response.color,
      permissions: response.permissoes || response.permissions || [],
      hoist: response.separado || response.hoist,
      mentionable: response.mencionavel || response.mentionable
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Criado!')
      .setDescription(`Cargo ${result.role.mention} criado com sucesso! 🎉`)
      .addFields(
        { name: '📝 Nome', value: result.role.name, inline: true },
        { name: '🎨 Cor', value: result.role.color || 'Padrão', inline: true }
      )
      .setColor(result.role.color || '#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    // 🌹 Enviar mensagem personalizada da Rias no final
    await sendRiasFollowUp(message.channel, 'criar_cargo', true);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao criar cargo: ${error.message}`, '#EF4444');
    await sendRiasFollowUp(message.channel, 'criar_cargo', false);
  }
}

async function handleEditRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.editRole(guild, {
      role: response.cargo || response.role || response.roleId,
      name: response.nome || response.name,
      color: response.cor || response.color,
      permissions: response.permissoes || response.permissions,
      hoist: response.separado || response.hoist,
      mentionable: response.mencionavel || response.mentionable
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Editado!')
      .setDescription(`Cargo **${result.role.name}** foi atualizado!`)
      .setColor(result.role.color || '#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.deleteRole(
      guild, 
      response.cargo || response.role || response.roleId || response.nome || response.name
    );
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Deletado!')
      .setDescription(`Cargo **@${result.name}** foi deletado! 🗑️`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleCloneRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.cloneRole(
      guild, 
      response.cargo || response.role || response.roleId,
      response.novo_nome || response.newName
    );
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Clonado!')
      .setDescription(`Cargo **@${result.original}** foi clonado!`)
      .addFields({ name: '📝 Novo Cargo', value: result.cloned.mention, inline: true })
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleAddRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.addRoleToMember(guild, {
      member: response.membro || response.member || response.userId,
      role: response.cargo || response.role,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Adicionado!')
      .setDescription(`Cargo **@${result.role}** adicionado a **${result.member}**!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleRemoveRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.removeRoleFromMember(guild, {
      member: response.membro || response.member || response.userId,
      role: response.cargo || response.role,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Removido!')
      .setDescription(`Cargo **@${result.role}** removido de **${result.member}**!`)
      .setColor('#F59E0B')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListRoles(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.listRoles(guild);
    
    const roleList = result.roles.slice(0, 20).map(r => 
      `• <@&${r.id}> (${r.members} membros)`
    ).join('\n');
    
    const embed = new EmbedBuilder()
      .setTitle('🎭 Cargos do Servidor')
      .setDescription(roleList || 'Nenhum cargo encontrado')
      .addFields({ name: '📊 Total', value: `${result.roles.length} cargos`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE MEMBROS
// ============================================

async function handleKick(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.kickMember(guild, {
      member: response.membro || response.member || response.userId,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('👢 Membro Expulso!')
      .setDescription(`**${result.tag}** foi expulso do servidor!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleBan(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.banMember(guild, {
      member: response.membro || response.member || response.userId,
      reason: response.motivo || response.reason,
      deleteMessageDays: response.deletar_dias || response.deleteMessageDays || 1
    });
    
    const embed = new EmbedBuilder()
      .setTitle('🔨 Membro Banido!')
      .setDescription(`**${result.tag}** foi banido do servidor!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleUnban(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.unbanMember(guild, {
      userId: response.usuario || response.userId || response.user,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Membro Desbanido!')
      .setDescription(`Usuário **${result.userId}** foi desbanido!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleMute(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.muteMember(guild, {
      member: response.membro || response.member || response.userId,
      duration: response.duracao || response.duration || 60,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('🔇 Membro Mutado!')
      .setDescription(`**${result.tag}** foi mutado por **${result.duration}**!`)
      .setColor('#F59E0B')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleUnmute(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.unmuteMember(guild, {
      member: response.membro || response.member || response.userId,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('🔊 Membro Desmutado!')
      .setDescription(`**${result.tag}** foi desmutado!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleNickname(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.setNickname(guild, {
      member: response.membro || response.member || response.userId,
      nickname: response.apelido || response.nickname,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✏️ Apelido Alterado!')
      .setDescription(`Apelido de **${result.tag}** alterado para **${result.newNickname || 'Sem apelido'}**!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleMemberInfo(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.getMemberInfo(
      guild, 
      response.membro || response.member || response.userId
    );
    
    const m = result.member;
    
    const embed = new EmbedBuilder()
      .setTitle(`👤 Info: ${m.tag}`)
      .setDescription(`${m.isOwner ? '👑 **DONO DO SERVIDOR**' : ''}`)
      .addFields(
        { name: '🆔 ID', value: m.id, inline: true },
        { name: '📝 Apelido', value: m.nickname || 'Nenhum', inline: true },
        { name: '📅 Entrou em', value: `<t:${Math.floor(new Date(m.joinedAt) / 1000)}:d>`, inline: true },
        { name: '🎭 Cargos', value: m.roles.slice(0, 10).join(', ') || 'Nenhum', inline: false },
        { name: '🤖 Bot', value: m.isBot ? 'Sim' : 'Não', inline: true }
      )
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleMembersByRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.listMembersByRole(
      guild, 
      response.cargo || response.role,
      response.limite || response.limit || 20
    );
    
    const memberList = result.members.map(m => 
      `• **${m.tag}** ${m.nickname ? `(${m.nickname})` : ''}`
    ).join('\n');
    
    const embed = new EmbedBuilder()
      .setTitle(`👥 Membros com @${result.role}`)
      .setDescription(memberList || 'Nenhum membro encontrado')
      .addFields({ name: '📊 Total', value: `${result.count} membros`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE MENSAGENS
// ============================================

async function handleBulkDelete(message, response, guild, channel, thinkingMsg) {
  try {
    const result = await serverTools.bulkDeleteMessages(channel, {
      amount: response.quantidade || response.amount || 10,
      userId: response.usuario || response.userId
    });
    
    const embed = new EmbedBuilder()
      .setTitle('🗑️ Mensagens Deletadas!')
      .setDescription(`**${result.deleted}** mensagens foram deletadas!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handlePinMessage(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.pinMessage(
      channel, 
      response.messageId || response.mensagem
    );
    
    const embed = new EmbedBuilder()
      .setTitle('📌 Mensagem Fixada!')
      .setDescription(`[Mensagem](${result.url}) foi fixada!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleUnpinMessage(message, response, channel, thinkingMsg) {
  try {
    await serverTools.unpinMessage(
      channel, 
      response.messageId || response.mensagem
    );
    
    const embed = new EmbedBuilder()
      .setTitle('📌 Mensagem Desfixada!')
      .setDescription('Mensagem foi desfixada!')
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE WEBHOOKS
// ============================================

async function handleCreateWebhook(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.createWebhook(channel, {
      name: response.nome || response.name || 'Rias-Grimory-X Webhook',
      avatar: response.avatar
    });
    
    const w = result.webhook;
    
    const embed = new EmbedBuilder()
      .setTitle('🪝 Webhook Criado!')
      .setDescription(`Webhook **${w.name}** criado com sucesso!`)
      .addFields(
        { name: '🆔 ID', value: w.id, inline: true },
        { name: '📝 Nome', value: w.name, inline: true },
        { name: '📺 Canal', value: w.channel, inline: true },
        { name: '🔗 URL Completa', value: `\`${w.url}\``, inline: false },
        { name: '🔑 Token', value: `\`${w.token}\``, inline: false }
      )
      .setColor('#10B981')
      .setFooter({ text: '⚠️ Guarde a URL com segurança! | 💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListWebhooks(message, channel, thinkingMsg) {
  try {
    const result = await serverTools.listWebhooks(channel);
    
    if (result.webhooks.length === 0) {
      const embed = new EmbedBuilder()
        .setTitle('🪝 Webhooks do Canal')
        .setDescription('Nenhum webhook encontrado neste canal.')
        .setColor('#8B5CF6')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      
      return await editEmbed(thinkingMsg, embed);
    }
    
    const webhookList = result.webhooks.map(w => {
      let desc = `**${w.name}** (ID: ${w.id})\n`;
      desc += `📺 Canal: ${w.channel}\n`;
      if (w.url) desc += `🔗 URL: \`${w.url}\`\n`;
      if (w.owner) desc += `👤 Dono: ${w.owner}`;
      return desc;
    }).join('\n\n');
    
    const embed = new EmbedBuilder()
      .setTitle('🪝 Webhooks do Canal')
      .setDescription(webhookList.substring(0, 2000))
      .addFields({ name: '📊 Total', value: `${result.count} webhook(s)`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListGuildWebhooks(message, guild, thinkingMsg) {
  try {
    const result = await serverTools.listGuildWebhooks(guild);
    
    if (result.webhooks.length === 0) {
      const embed = new EmbedBuilder()
        .setTitle('🪝 Webhooks do Servidor')
        .setDescription('Nenhum webhook encontrado no servidor.')
        .setColor('#8B5CF6')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      
      return await editEmbed(thinkingMsg, embed);
    }
    
    const webhookList = result.webhooks.slice(0, 10).map(w => {
      let desc = `**${w.name}** (ID: ${w.id})\n`;
      desc += `📺 Canal: ${w.channel}\n`;
      if (w.url) desc += `🔗 \`${w.url}\`\n`;
      if (w.owner) desc += `👤 ${w.owner}`;
      return desc;
    }).join('\n\n');
    
    const embed = new EmbedBuilder()
      .setTitle('🪝 Webhooks do Servidor')
      .setDescription(webhookList.substring(0, 2000))
      .addFields({ name: '📊 Total', value: `${result.count} webhook(s)`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleGetWebhook(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.getWebhook(
      guild, 
      response.webhookId || response.webhook || response.id
    );
    
    const w = result.webhook;
    
    const embed = new EmbedBuilder()
      .setTitle('🪝 Informações do Webhook')
      .addFields(
        { name: '🆔 ID', value: w.id, inline: true },
        { name: '📝 Nome', value: w.name, inline: true },
        { name: '📺 Canal', value: w.channel, inline: true },
        { name: '🔗 URL', value: w.url ? `\`${w.url}\`` : 'Indisponível', inline: false },
        { name: '🔑 Token', value: w.token ? `\`${w.token}\`` : 'Indisponível', inline: false },
        { name: '👤 Dono', value: w.owner || 'Desconhecido', inline: true }
      )
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleEditWebhook(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.editWebhook(channel, {
      webhookId: response.webhookId || response.webhook,
      name: response.nome || response.name,
      avatar: response.avatar
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Webhook Editado!')
      .setDescription(`Webhook **${result.webhook.name}** foi atualizado!`)
      .addFields({ name: '🔗 URL', value: result.webhook.url ? `\`${result.webhook.url}\`` : 'Indisponível' })
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteWebhook(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.deleteWebhook(
      channel, 
      response.webhookId || response.webhook
    );
    
    const embed = new EmbedBuilder()
      .setTitle('🗑️ Webhook Deletado!')
      .setDescription(`Webhook **${result.name}** foi deletado!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleSendWebhook(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.sendWebhookMessage(channel, {
      webhookId: response.webhookId || response.webhook,
      content: response.content || response.conteudo,
      username: response.username || response.nome,
      avatarURL: response.avatarURL || response.avatar,
      embeds: response.embeds
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Mensagem Enviada!')
      .setDescription('Mensagem enviada via webhook com sucesso!')
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE CONVITES
// ============================================

async function handleCreateInvite(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.createInvite(channel, {
      maxAge: response.maxAge || response.tempo || 86400,
      maxUses: response.maxUses || response.usos || 0,
      temporary: response.temporary || response.temporario || false,
      unique: response.unique || response.unico || false
    });
    
    const embed = new EmbedBuilder()
      .setTitle('📨 Convite Criado!')
      .setDescription(`**${result.invite.url}**`)
      .addFields({ name: '🔑 Código', value: result.invite.code, inline: true })
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListInvites(message, guild, thinkingMsg) {
  try {
    const result = await serverTools.listInvites(guild);
    
    const inviteList = result.invites.slice(0, 15).map(i => 
      `• **${i.code}** - ${i.channel} (${i.uses}/${i.maxUses || '∞'})`
    ).join('\n') || 'Nenhum convite encontrado';
    
    const embed = new EmbedBuilder()
      .setTitle('📨 Convites do Servidor')
      .setDescription(inviteList)
      .addFields({ name: '📊 Total', value: `${result.invites.length} convites`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteInvite(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.deleteInvite(
      guild, 
      response.codigo || response.code
    );
    
    const embed = new EmbedBuilder()
      .setTitle('🗑️ Convite Deletado!')
      .setDescription(`Convite **${result.code}** foi deletado!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE EMOJIS
// ============================================

async function handleAddEmoji(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.addEmoji(guild, {
      name: response.nome || response.name,
      url: response.url || response.imagem,
      roles: response.cargos || response.roles || []
    });
    
    const embed = new EmbedBuilder()
      .setTitle('😀 Emoji Adicionado!')
      .setDescription(`Emoji ${result.emoji.string} foi adicionado!`)
      .addFields(
        { name: '📝 Nome', value: result.emoji.name, inline: true },
        { name: '🆔 ID', value: result.emoji.id, inline: true }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteEmoji(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.deleteEmoji(
      guild, 
      response.emojiId || response.emoji || response.id
    );
    
    const embed = new EmbedBuilder()
      .setTitle('🗑️ Emoji Deletado!')
      .setDescription(`Emoji **${result.name}** foi deletado!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListEmojis(message, guild, thinkingMsg) {
  try {
    const result = await serverTools.listEmojis(guild);
    
    const emojiList = result.emojis.slice(0, 30).map(e => 
      `${e.string} **${e.name}**`
    ).join(' ') || 'Nenhum emoji encontrado';
    
    const embed = new EmbedBuilder()
      .setTitle('😀 Emojis do Servidor')
      .setDescription(emojiList.substring(0, 2000))
      .addFields({ name: '📊 Total', value: `${result.count} emojis`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// INFORMAÇÕES DO SERVIDOR
// ============================================

async function handleServerStats(message, guild, thinkingMsg) {
  try {
    const result = await serverTools.getServerStats(guild);
    const s = result.server;
    
    const embed = new EmbedBuilder()
      .setTitle(`📊 ${s.name}`)
      .setThumbnail(s.icon)
      .setDescription(`**ID:** ${s.id}\n**Dono:** <@${s.ownerId}>`)
      .addFields(
        { name: '👥 Membros', value: `${s.memberCount} (${s.online} online)`, inline: true },
        { name: '🤖 Bots', value: `${s.bots}`, inline: true },
        { name: '📁 Canais', value: `${s.channels.total} (${s.channels.text} texto, ${s.channels.voice} voz)`, inline: true },
        { name: '🎭 Cargos', value: `${s.roles}`, inline: true },
        { name: '😀 Emojis', value: `${s.emojis}`, inline: true },
        { name: '💎 Boost', value: `Nível ${s.boost.level} (${s.boost.count} boosts)`, inline: true },
        { name: '📅 Criado em', value: `<t:${Math.floor(new Date(s.createdAt) / 1000)}:d>`, inline: true }
      )
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X v7.0' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// OUTRAS FERRAMENTAS
// ============================================

async function handleSendEmbed(message, response, guild, channel, thinkingMsg) {
  const colorMap = {
    'roxo': '#8B5CF6', 'purple': '#8B5CF6',
    'vermelho': '#EF4444', 'red': '#EF4444',
    'verde': '#10B981', 'green': '#10B981',
    'azul': '#3B82F6', 'blue': '#3B82F6',
    'amarelo': '#F59E0B', 'yellow': '#F59E0B',
    'laranja': '#F97316', 'orange': '#F97316',
    'rosa': '#EC4899', 'pink': '#EC4899',
    'dourado': '#FFD700', 'gold': '#FFD700'
  };
  
  let color = response.color || '#8B5CF6';
  if (colorMap[color.toLowerCase()]) {
    color = colorMap[color.toLowerCase()];
  }
  
  const embed = new EmbedBuilder()
    .setTitle(response.title || response.titulo || 'Embed')
    .setDescription(response.description || response.descricao || '')
    .setColor(color)
    .setFooter({ text: response.footer || '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  if (response.image || response.imagem) {
    embed.setImage(response.image || response.imagem);
  }
  if (response.thumbnail) {
    embed.setThumbnail(response.thumbnail);
  }
  
  if (response.fields && Array.isArray(response.fields)) {
    response.fields.forEach(field => {
      embed.addFields({
        name: field.name || 'Campo',
        value: field.value || 'Valor',
        inline: field.inline || false
      });
    });
  }
  
  let targetChannel = channel;
  if (response.targetChannel || response.canal) {
    const targetName = response.targetChannel || response.canal;
    const found = guild.channels.cache.find(c => 
      c.name.toLowerCase().includes(targetName.toLowerCase()) || c.id === targetName
    );
    if (found) targetChannel = found;
  }
  
  if (targetChannel.id !== channel.id) {
    await targetChannel.send({ embeds: [embed] });
    await editEmbed(thinkingMsg, '✅ Enviado!', `Embed enviado para ${targetChannel}!`, '#10B981');
  } else {
    await editEmbed(thinkingMsg, embed);
  }
}

async function handlePoll(message, response, thinkingMsg) {
  const question = response.question || response.pergunta || 'Enquete';
  const options = response.options || response.opcoes || ['Sim', 'Não'];
  
  const embed = new EmbedBuilder()
    .setTitle(`📊 ${question}`)
    .setDescription(options.map((opt, i) => `**${i + 1}.** ${opt}`).join('\n'))
    .setColor('#8B5CF6')
    .setFooter({ text: 'Clique para votar! | 💎 Rias-Grimory-X' })
    .setTimestamp();
  
  const row = new ActionRowBuilder();
  options.forEach((_, i) => {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(`poll_${i}`)
        .setLabel(`${i + 1}`)
        .setStyle(ButtonStyle.Primary)
    );
  });
  
  await message.channel.send({ embeds: [embed], components: [row] });
  await editEmbed(thinkingMsg, '✅ Enquete Criada!', 'A enquete foi enviada!', '#10B981');
}

// ============================================
// TAREFA COMPLEXA - CORRIGIDO COM CONTEXTO
// ============================================

async function handleComplexTask(message, response, guild, channel, thinkingMsg) {
  const steps = response.steps || response.etapas || [];
  
  if (!steps || steps.length === 0) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'Nenhuma etapa definida!', '#EF4444');
  }
  
  // ============================================
  // DETECÇÃO DE PROBLEMA: múltiplos google_image
  // ============================================
  const googleImageSteps = steps.filter(s => 
    (s.type || s.tipo || '').toLowerCase().includes('google_image') ||
    (s.type || s.tipo || '').toLowerCase().includes('busca_imagem')
  );
  
  if (googleImageSteps.length > 1) {
    console.log(`⚠️ [ComplexTask] Detectado ${googleImageSteps.length} chamadas google_image - consolidando...`);
    
    // Consolidar todas as chamadas em uma única com quantidade total
    const totalQuantidade = googleImageSteps.reduce((sum, s) => 
      sum + (s.quantidade || s.amount || 1), 0
    );
    const query = googleImageSteps[0].query || googleImageSteps[0].termo || 'imagens';
    
    // Remover todas as chamadas google_image duplicadas
    const consolidatedSteps = steps.filter(s => 
      !(s.type || s.tipo || '').toLowerCase().includes('google_image') &&
      !(s.type || s.tipo || '').toLowerCase().includes('busca_imagem')
    );
    
    // Adicionar única chamada consolidada
    consolidatedSteps.push({
      type: 'google_image',
      query: query,
      quantidade: Math.min(totalQuantidade, 20),
      canal_destino: googleImageSteps[0].canal_destino || 'auto'
    });
    
    console.log(`✅ [ComplexTask] Consolidado: 1 chamada com quantidade ${Math.min(totalQuantidade, 20)}`);
    steps.length = 0;
    steps.push(...consolidatedSteps);
  }
  
  // ============================================
  // CONTEXTO ENTRE ETAPAS
  // ============================================
  global.lastCreatedChannel = null;
  global.lastCreatedChannelId = null;
  global.lastCreatedCategory = null;
  global.lastCreatedCategoryId = null;
  global.lastCreatedCategoryName = null;
  
  const embed = new EmbedBuilder()
    .setTitle('🧠 Tarefa Complexa')
    .setDescription(`⚙️ Executando **${steps.length}** etapas...\n\n*Vou fazer tudo certinho para você!* 💖`)
    .setColor('#FBBF24')
    .setFooter({ text: '💎 Rias-Grimory-X v8.0' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
  
  let successCount = 0;
  let errorCount = 0;
  const errors = [];
  
  for (let i = 0; i < steps.length; i++) {
    const step = steps[i];
    const stepType = (step.type || step.tipo || 'desconhecido').toLowerCase();
    
    // Embed de progresso
    const stepEmbed = new EmbedBuilder()
      .setTitle(`⚙️ Etapa ${i + 1}/${steps.length}`)
      .setDescription(`Executando: **${stepType}**...`)
      .setColor('#FBBF24')
      .setTimestamp();
    
    await editEmbed(thinkingMsg, stepEmbed);
    
    try {
      console.log(`📋 [ComplexTask] Etapa ${i + 1}/${steps.length}: ${stepType}`);
      
      // ============================================
      // INJEÇÃO DE CONTEXTO AUTOMÁTICA
      // ============================================
      
      // Para criar_canal: usar categoria criada anteriormente
      if (stepType === 'criar_canal' || stepType === 'create_channel') {
        // Se mencionou categoria pelo nome parcial, buscar pelo nome salvo
        if (step.categoria && global.lastCreatedCategoryName) {
          const catName = step.categoria.toLowerCase();
          const lastCatName = global.lastCreatedCategoryName.toLowerCase();
          if (catName.includes(lastCatName) || lastCatName.includes(catName)) {
            step.categoria = global.lastCreatedCategoryId;
            console.log(`📁 [ComplexTask] Categoria encontrada por nome: ${global.lastCreatedCategoryName}`);
          }
        }
        // Se não tem categoria mas existe uma criada
        if (!step.categoria && !step.parent && global.lastCreatedCategoryId) {
          step.categoria = global.lastCreatedCategoryId;
          console.log(`📁 [ComplexTask] Auto-injetando categoria: ${global.lastCreatedCategoryId}`);
        }
      }
      
      // Para google_image: verificar canal_destino
      if (stepType === 'google_image' || stepType === 'busca_imagem' || stepType === 'buscar_imagens_google') {
        // Garantir que quantidade está definido
        if (!step.quantidade && !step.amount) {
          step.quantidade = 5;
          console.log(`🖼️ [ComplexTask] Quantidade padrão: 5`);
        }
        
        // Log do canal de destino
        if (step.canal_destino === 'auto' && global.lastCreatedChannel) {
          console.log(`🖼️ [ComplexTask] Imagens vão para: ${global.lastCreatedChannel.name}`);
        }
      }
      
      // Executar etapa
      await handleResponse(message, step, guild, channel, null);
      successCount++;
      
      // Delay inteligente baseado no tipo de operação
      const delayMap = {
        'criar_categoria': 1200,
        'criar_canal': 1000,
        'google_image': 500,
        'create_channel': 1000,
        'create_category': 1200
      };
      const delay = delayMap[stepType] || 600;
      await sleep(delay);
      
      console.log(`✅ [ComplexTask] Etapa ${i + 1} OK`);
    } catch (error) {
      errorCount++;
      errors.push(`Etapa ${i + 1}: ${error.message.substring(0, 100)}`);
      console.error(`❌ [ComplexTask] Erro etapa ${i + 1}:`, error.message);
      
      // Continuar executando próximas etapas mesmo com erro
    }
  }
  
  // Embed final
  const finalEmbed = new EmbedBuilder()
    .setTitle(errorCount > 0 ? '⚠️ Tarefa Parcialmente Concluída' : '🎉 Tarefa Concluída!')
    .setDescription(
      `✅ **${successCount}** etapas executadas!\n` +
      (errorCount > 0 ? `❌ **${errorCount}** etapas falharam.` : '*Tudo pronto para você, amor!* 💖')
    )
    .setColor(errorCount > 0 ? '#F59E0B' : '#10B981')
    .setFooter({ text: '💎 Rias-Grimory-X v8.0' })
    .setTimestamp();
  
  if (errors.length > 0) {
    finalEmbed.addFields({
      name: '⚠️ Erros',
      value: errors.slice(0, 3).join('\n').substring(0, 900)
    });
  }
  
  await editEmbed(thinkingMsg, finalEmbed);
  
  // Limpar contexto após conclusão
  global.lastCreatedChannel = null;
  global.lastCreatedChannelId = null;
  global.lastCreatedCategory = null;
  global.lastCreatedCategoryId = null;
  global.lastCreatedCategoryName = null;
}

// ============================================
// MENSAGEM SIMPLES
// ============================================

async function handleMessage(message, response, thinkingMsg) {
  let content = response.content || response.mensagem || response.text || '';
  
  // Se conteúdo vazio, dar resposta útil
  if (!content || content.trim() === '') {
    content = `Não entendi muito bem o que você quis dizer! 😅 Pode reformular? 🌹

**Coisas que posso fazer:**
• Criar/editar/deletar canais e categorias
• Criar/editar/deletar cargos  
• Buscar imagens no Google
• Criar automações
• Moderar membros

**Exemplo:** "Crie um canal chamado memes"`;
  }
  
  const embed = new EmbedBuilder()
    .setDescription(content.substring(0, 4000))
    .setColor('#DC143C')
    .setFooter({ text: '🌹 Rias Gremory', iconURL: 'https://i.imgur.com/eEsH9NF.jpeg' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
}

// ============================================
// AUTOMAÇÃO
// ============================================

async function handleCreateAutomation(message, response, guild, thinkingMsg) {
  try {
    const channelId = response.canal || response.channel;
    
    // Resolver ID do canal se for nome
    let resolvedChannelId = channelId;
    if (channelId && !/^\d+$/.test(channelId)) {
      const foundChannel = guild.channels.cache.find(c => 
        c.name.toLowerCase().includes(channelId.toLowerCase())
      );
      if (foundChannel) {
        resolvedChannelId = foundChannel.id;
      }
    }
    
    const result = automationManager.createAutomation(guild.id, {
      name: response.nome || response.name,
      description: response.descricao || response.description,
      channelId: resolvedChannelId,
      interval: response.intervalo || response.interval || 60,
      task: response.tarefa || response.task
    });
    
    // 🚀 INICIAR A AUTOMAÇÃO IMEDIATAMENTE!
    if (discordClient && result.active !== false) {
      result.start(discordClient);
      console.log(`🚀 [Automação] Iniciada imediatamente: ${result.name}`);
    }
    
    const embed = new EmbedBuilder()
      .setTitle('🤖 Automação Criada e Iniciada!')
      .setDescription(`Script **${result.name}** criado com sucesso e já está rodando! 🚀`)
      .addFields(
        { name: '📝 Nome', value: result.name, inline: true },
        { name: '⏱️ Intervalo', value: `${result.interval} minutos`, inline: true },
        { name: '🆔 ID', value: `\`${result.id}\``, inline: true },
        { name: '📺 Canal', value: `<#${resolvedChannelId}>`, inline: true },
        { name: '📋 Tarefa', value: result.task || 'Não definida', inline: false }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X | Automação ativa!' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    // 🌹 Enviar mensagem personalizada da Rias
    await sendRiasFollowUp(message.channel, 'criar_automacao', true);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
    await sendRiasFollowUp(message.channel, 'criar_automacao', false);
  }
}

async function handleListAutomations(message, guild, thinkingMsg) {
  const automations = automationManager.listAutomations(guild.id);
  
  if (automations.length === 0) {
    const embed = new EmbedBuilder()
      .setTitle('🤖 Automações')
      .setDescription('Nenhuma automação configurada.')
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    return await editEmbed(thinkingMsg, embed);
  }
  
  const list = automations.map(a => 
    `• **${a.name}** (${a.id})\n  ⏱️ ${a.interval}min | ${a.active ? '✅ Ativo' : '⏸️ Pausado'}`
  ).join('\n');
  
  const embed = new EmbedBuilder()
    .setTitle('🤖 Automações')
    .setDescription(list)
    .addFields({ name: '📊 Total', value: `${automations.length} scripts`, inline: true })
    .setColor('#8B5CF6')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
}

async function handlePauseAutomation(message, response, guild, thinkingMsg) {
  try {
    automationManager.pauseAutomation(guild.id, response.id);
    
    const embed = new EmbedBuilder()
      .setTitle('⏸️ Automação Pausada!')
      .setDescription(`A automação foi pausada.`)
      .setColor('#F59E0B')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleResumeAutomation(message, response, guild, thinkingMsg) {
  try {
    // Passar discordClient para reiniciar a automação
    automationManager.resumeAutomation(guild.id, response.id, discordClient);
    
    const embed = new EmbedBuilder()
      .setTitle('▶️ Automação Retomada!')
      .setDescription(`A automação foi retomada e está rodando novamente! 🚀`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    await sendRiasFollowUp(message.channel, 'retomar_automacao', true);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteAutomation(message, response, guild, thinkingMsg) {
  try {
    automationManager.deleteAutomation(guild.id, response.id);
    
    const embed = new EmbedBuilder()
      .setTitle('🗑️ Automação Deletada!')
      .setDescription(`A automação foi removida.`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleEditAutomation(message, response, guild, thinkingMsg) {
  try {
    const scriptId = response.id || response.automacao_id || response.automation_id;
    
    if (!scriptId) {
      return await editEmbed(thinkingMsg, '❌ Erro', 'ID da automação não informado! Use `listar_automacoes` para ver os IDs.', '#EF4444');
    }
    
    const newConfig = {
      name: response.nome || response.name,
      description: response.descricao || response.description,
      interval: response.intervalo || response.interval,
      task: response.tarefa || response.task,
      channelId: response.canal || response.channel
    };
    
    // Remover propriedades undefined
    Object.keys(newConfig).forEach(key => {
      if (newConfig[key] === undefined) delete newConfig[key];
    });
    
    // Passar client para reiniciar automação após edição
    const result = automationManager.editAutomation(guild.id, scriptId, newConfig, discordClient);
    
    if (!result) {
      return await editEmbed(thinkingMsg, '❌ Erro', `Automação com ID "${scriptId}" não encontrada!`, '#EF4444');
    }
    
    const embed = new EmbedBuilder()
      .setTitle('✏️ Automação Editada e Reiniciada!')
      .setDescription(`Script **${result.name}** foi atualizado e reiniciado! 🔄`)
      .addFields(
        { name: '📝 Nome', value: result.name, inline: true },
        { name: '⏱️ Intervalo', value: `${result.interval} minutos`, inline: true },
        { name: '🆔 ID', value: `\`${result.id}\``, inline: true },
        { name: '📺 Canal', value: result.channelMention || 'Não alterado', inline: true },
        { name: '📊 Execuções', value: `${result.runCount || 0}`, inline: true },
        { name: '🔄 Status', value: result.active ? '✅ Ativo' : '⏸️ Pausado', inline: true }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X | Automação atualizada!' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    
    // 🌹 Enviar mensagem personalizada da Rias
    await sendRiasFollowUp(message.channel, 'editar_automacao', true);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao editar automação: ${error.message}`, '#EF4444');
    await sendRiasFollowUp(message.channel, 'editar_automacao', false);
  }
}

async function handleRunAutomation(message, response, guild, thinkingMsg) {
  try {
    // Usar runAutomationNow que é a função correta
    await automationManager.runAutomationNow(guild.id, response.id, discordClient);
    
    const embed = new EmbedBuilder()
      .setTitle('⚡ Automação Executada!')
      .setDescription(`A automação foi executada manualmente com sucesso! 🚀`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
    await sendRiasFollowUp(message.channel, 'executar_automacao', true);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

export default { name, execute, setClient };
