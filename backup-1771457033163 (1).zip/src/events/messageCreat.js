/**
 * Rias-Grimory-X - Evento MessageCreate
 * VERSÃO 5.0 - Sistema COMPLETO de Gestão de Servidor
 * 
 * ✅ CORREÇÕES V5.0:
 * - Nome alterado para Rias-Grimory-X
 * - Webhooks mostram URL completa e token
 * - CPF/CNPJ com todas informações formatadas
 * - BulkDelete corrigido (Collection para Array)
 * - Sistema de automação
 * 
 * ✅ CORREÇÃO V5.0.1:
 * - Removido código duplicado na função parseResponse()
 */

import { 
  EmbedBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle
} from 'discord.js';
import OpenAI from 'openai';
import { checkServerPermission } from '../utils/permissions.js';
import { 
  isChannelActive, 
  getChannelContext, 
  addUserMessage,
  addAIMessage
} from '../utils/activeChannels.js';
import apiService from '../services/apiService.js';
import serverTools from '../utils/serverTools.js';
import automationManager from '../utils/automationManager.js';


// Referência global ao client do Discord
let discordClient = null;

export function setClient(client) {
  discordClient = client;
}

const NVIDIA_KEY = process.env.NVIDIA_API_KEY || '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';

const client = new OpenAI({
  baseURL: 'https://integrate.api.nvidia.com/v1',
  apiKey: NVIDIA_KEY,
  timeout: 45000,
  maxRetries: 2
});

export const name = 'messageCreate';

export async function execute(message) {
  if (message.author.bot || !message.guild) return;

  const guild = message.guild;
  const channel = message.channel;

  if (!isChannelActive(guild.id, channel.id)) return;
  
  const permCheck = checkServerPermission(guild, { id: message.author.id }, message.member);
  if (!permCheck.authorized) return;

  channel.sendTyping().catch(() => {});

  // thinkingMsg precisa estar no escopo da função (acessível no catch)
  let thinkingMsg = null;

  try {
    let userContent = message.content;

    if (message.attachments.size > 0) {
      const attachmentsInfo = [];
      for (const attachment of message.attachments.values()) {
        attachmentsInfo.push(`[ANEXO: ${attachment.name}] - ${attachment.url}`);
      }
      userContent += "\n\nANEXOS:\n" + attachmentsInfo.join("\n");
    }

    addUserMessage(channel.id, userContent, message.author.tag);
    const messages = getChannelContext(channel.id);

    console.log(`🚀 [IA] Processando: ${userContent.substring(0, 50)}...`);

    // Embed de pensando
    const thinkingEmbed = new EmbedBuilder()
      .setTitle('🤔 Processando...')
      .setDescription('Estou trabalhando nisso! ✨\n*Aguarde um momentinho...*')
      .setColor('#FBBF24')
      .setFooter({ text: '💎 Rias-Grimory-X v5.0' })
      .setTimestamp();

    thinkingMsg = await message.reply({ 
      embeds: [thinkingEmbed], 
      allowedMentions: { repliedUser: false } 
    }).catch(() => null);

    // Chamar IA
    let completion;
    try {
      completion = await client.chat.completions.create({
        model: 'stepfun-ai/step-3.5-flash',
        messages: messages,
        temperature: 0.8,
        max_tokens: 4000,
        stream: false
      });
    } catch (apiError) {
      console.error('❌ [IA] Erro:', apiError.message);
      return await handleFallback(message, thinkingMsg, userContent);
    }

    const content = completion.choices[0]?.message?.content || '';
    
    // PARSE CORRETO - extrair JSON da resposta
    const response = parseResponse(content);
    
    addAIMessage(channel.id, content);

    // Processar baseado no tipo
    await handleResponse(message, response, guild, channel, thinkingMsg);

  } catch (error) {
    console.error('❌ [Erro]:', error);
    await sendErrorEmbed(message, thinkingMsg, error.message);
  }
}

/**
 * Parse correto da resposta - não mostrar JSON como texto
 * ✅ CORRIGIDO: Removido código duplicado
 */
function parseResponse(content) {
  try {
    // 1. Extrair de blocos de código markdown (```json ... ```)
    const codeBlockRegex = /```(?:json)?\s*([\s\S]*?)```/g;
    let match = codeBlockRegex.exec(content);
    if (match && match[1]) {
      try {
        const parsed = JSON.parse(match[1]);
        console.log(`📦 [IA] JSON extraído de bloco de código`);
        return parsed;
      } catch (e2) {
        console.log('⚠️ Conteúdo do bloco de código não é JSON válido');
      }
    }

    // 2. Procurar primeiro objeto JSON válido no conteúdo
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      try {
        const parsed = JSON.parse(jsonMatch[0]);
        console.log(`📦 [IA] JSON extraído do conteúdo`);
        return parsed;
      } catch (e) {
        console.log('⚠️ Match JSON não é válido');
      }
    }
  } catch (e) {
    console.log('⚠️ Parse JSON falhou, usando como texto');
  }

  return { type: 'message', content: content };
}

/**
 * Processa a resposta baseado no tipo
 */
async function handleResponse(message, response, guild, channel, thinkingMsg) {
  const type = response.type?.toLowerCase() || 'message';
  
  console.log(`📋 [Tipo] ${type}`);

  switch (type) {
    // === FERRAMENTAS EXTERNAS ===
    case 'consultar_cnpj':
    case 'consulta_cnpj':
      await handleCNPJ(message, response, thinkingMsg);
      break;
      
    case 'consultar_cpf':
    case 'consulta_cpf':
      await handleCPF(message, response, thinkingMsg);
      break;
      
    case 'buscar_imagens_google':
    case 'google_image':
    case 'busca_imagem':
      await handleImageSearch(message, response, thinkingMsg);
      break;
      
    case 'video_cosplay_anime':
    case 'cosplay_video':
      await handleCosplayVideo(message, thinkingMsg);
      break;
      
    case 'gerar_imagem':
    case 'dalle_nsfw':
    case 'dalle':
      await handleDalle(message, response, thinkingMsg);
      break;
      
    case 'gerar_arquivo':
    case 'generate_file':
      await handleFileGeneration(message, response, thinkingMsg);
      break;

    // === FERRAMENTAS DE CANAIS ===
    case 'criar_canal':
    case 'create_channel':
      await handleCreateChannel(message, response, guild, thinkingMsg);
      break;
      
    case 'editar_canal':
    case 'edit_channel':
      await handleEditChannel(message, response, guild, thinkingMsg);
      break;
      
    case 'deletar_canal':
    case 'delete_channel':
      await handleDeleteChannel(message, response, guild, thinkingMsg);
      break;
      
    case 'clonar_canal':
    case 'clone_channel':
      await handleCloneChannel(message, response, guild, thinkingMsg);
      break;
      
    case 'trancar_canal':
    case 'lock_channel':
      await handleLockChannel(message, response, guild, thinkingMsg);
      break;
      
    case 'esconder_canal':
    case 'hide_channel':
      await handleHideChannel(message, response, guild, thinkingMsg);
      break;
      
    case 'permissao_canal':
    case 'channel_permission':
      await handleChannelPermission(message, response, guild, thinkingMsg);
      break;
      
    case 'criar_categoria':
    case 'create_category':
      await handleCreateCategory(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_canais':
    case 'list_channels':
      await handleListChannels(message, response, guild, thinkingMsg);
      break;

    // === FERRAMENTAS DE CARGOS ===
    case 'criar_cargo':
    case 'create_role':
      await handleCreateRole(message, response, guild, thinkingMsg);
      break;
      
    case 'editar_cargo':
    case 'edit_role':
      await handleEditRole(message, response, guild, thinkingMsg);
      break;
      
    case 'deletar_cargo':
    case 'delete_role':
      await handleDeleteRole(message, response, guild, thinkingMsg);
      break;
      
    case 'clonar_cargo':
    case 'clone_role':
      await handleCloneRole(message, response, guild, thinkingMsg);
      break;
      
    case 'adicionar_cargo':
    case 'add_role':
      await handleAddRole(message, response, guild, thinkingMsg);
      break;
      
    case 'remover_cargo':
    case 'remove_role':
      await handleRemoveRole(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_cargos':
    case 'list_roles':
      await handleListRoles(message, response, guild, thinkingMsg);
      break;

    // === FERRAMENTAS DE MEMBROS ===
    case 'expulsar':
    case 'kick':
      await handleKick(message, response, guild, thinkingMsg);
      break;
      
    case 'banir':
    case 'ban':
      await handleBan(message, response, guild, thinkingMsg);
      break;
      
    case 'desbanir':
    case 'unban':
      await handleUnban(message, response, guild, thinkingMsg);
      break;
      
    case 'mutar':
    case 'mute':
    case 'timeout':
      await handleMute(message, response, guild, thinkingMsg);
      break;
      
    case 'desmutar':
    case 'unmute':
      await handleUnmute(message, response, guild, thinkingMsg);
      break;
      
    case 'apelido':
    case 'nickname':
    case 'set_nickname':
      await handleNickname(message, response, guild, thinkingMsg);
      break;
      
    case 'info_membro':
    case 'member_info':
      await handleMemberInfo(message, response, guild, thinkingMsg);
      break;
      
    case 'membros_cargo':
    case 'members_by_role':
      await handleMembersByRole(message, response, guild, thinkingMsg);
      break;

    // === FERRAMENTAS DE MENSAGENS ===
    case 'deletar_mensagens':
    case 'bulk_delete':
    case 'clear':
      await handleBulkDelete(message, response, guild, channel, thinkingMsg);
      break;
      
    case 'fixar_mensagem':
    case 'pin_message':
      await handlePinMessage(message, response, channel, thinkingMsg);
      break;
      
    case 'desfixar_mensagem':
    case 'unpin_message':
      await handleUnpinMessage(message, response, channel, thinkingMsg);
      break;

    // === FERRAMENTAS DE WEBHOOKS - MELHORADO ===
    case 'criar_webhook':
    case 'create_webhook':
      await handleCreateWebhook(message, response, channel, thinkingMsg);
      break;
      
    case 'listar_webhooks':
    case 'list_webhooks':
      await handleListWebhooks(message, channel, thinkingMsg);
      break;
      
    case 'listar_webhooks_servidor':
    case 'list_guild_webhooks':
      await handleListGuildWebhooks(message, guild, thinkingMsg);
      break;
      
    case 'info_webhook':
    case 'get_webhook':
      await handleGetWebhook(message, response, guild, thinkingMsg);
      break;
      
    case 'editar_webhook':
    case 'edit_webhook':
      await handleEditWebhook(message, response, channel, thinkingMsg);
      break;
      
    case 'deletar_webhook':
    case 'delete_webhook':
      await handleDeleteWebhook(message, response, channel, thinkingMsg);
      break;
      
    case 'enviar_webhook':
    case 'send_webhook':
      await handleSendWebhook(message, response, channel, thinkingMsg);
      break;

    // === FERRAMENTAS DE CONVITES ===
    case 'criar_convite':
    case 'create_invite':
      await handleCreateInvite(message, response, channel, thinkingMsg);
      break;
      
    case 'listar_convites':
    case 'list_invites':
      await handleListInvites(message, guild, thinkingMsg);
      break;
      
    case 'deletar_convite':
    case 'delete_invite':
      await handleDeleteInvite(message, response, guild, thinkingMsg);
      break;

    // === FERRAMENTAS DE EMOJIS ===
    case 'adicionar_emoji':
    case 'add_emoji':
      await handleAddEmoji(message, response, guild, thinkingMsg);
      break;
      
    case 'deletar_emoji':
    case 'delete_emoji':
      await handleDeleteEmoji(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_emojis':
    case 'list_emojis':
      await handleListEmojis(message, guild, thinkingMsg);
      break;

    // === SISTEMA DE AUTOMAÇÃO ===
    case 'criar_automacao':
    case 'create_automation':
      await handleCreateAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'listar_automacoes':
    case 'list_automations':
      await handleListAutomations(message, guild, thinkingMsg);
      break;
      
    case 'pausar_automacao':
    case 'pause_automation':
      await handlePauseAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'retomar_automacao':
    case 'resume_automation':
      await handleResumeAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'deletar_automacao':
    case 'delete_automation':
      await handleDeleteAutomation(message, response, guild, thinkingMsg);
      break;
      
    case 'executar_automacao':
    case 'run_automation':
      await handleRunAutomation(message, response, guild, thinkingMsg);
      break;

    // === INFORMAÇÕES DO SERVIDOR ===
    case 'server_stats':
    case 'estatisticas':
    case 'info_servidor':
      await handleServerStats(message, guild, thinkingMsg);
      break;

    // === OUTRAS FERRAMENTAS ===
    case 'enviar_embed':
    case 'send_embed':
      await handleSendEmbed(message, response, guild, channel, thinkingMsg);
      break;
      
    case 'criar_enquete':
    case 'create_poll':
      await handlePoll(message, response, thinkingMsg);
      break;

    // === TAREFA COMPLEXA ===
    case 'complex_task':
    case 'tarefa_complexa':
      await handleComplexTask(message, response, guild, channel, thinkingMsg);
      break;

    // === MENSAGEM SIMPLES ===
    case 'message':
    default:
      await handleMessage(message, response, thinkingMsg);
  }
}

// ============================================
// FERRAMENTAS EXTERNAS - CPF/CNPJ MELHORADO
// ============================================

async function handleCNPJ(message, response, thinkingMsg) {
  const cnpj = response.cnpj || response.value || response.cnpj_number;
  if (!cnpj) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'CNPJ não informado!', '#EF4444');
  }
  
  const result = await apiService.consultaCNPJ(cnpj);
  
  if (result.status === 'success' || result.data) {
    const data = result.data || result;
    
    // Criar embed com TODAS as informações
    const embed = new EmbedBuilder()
      .setTitle('📋 Consulta CNPJ - Resultado')
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    // Dados principais
    const fields = [];
    
    if (data.razao_social || data['RAZÃO SOCIAL']) {
      embed.setDescription(`**${data.razao_social || data['RAZÃO SOCIAL']}**`);
    }
    
    // Adicionar todos os campos disponíveis
    const campos = {
      'Razão Social': data.razao_social || data['RAZÃO SOCIAL'],
      'Nome Fantasia': data.nome_fantasia || data['NOME FANTASIA'],
      'CNPJ': data.cnpj || data['CNPJ'] || cnpj,
      'Situação': data.situacao || data['SITUAÇÃO'],
      'Situação Cadastral': data.situacao_cadastral,
      'Data Situação': data.data_situacao || data['DATA SITUAÇÃO'],
      'Tipo': data.tipo || data['TIPO'],
      'Porte': data.porte || data['PORTE'],
      'Natureza Jurídica': data.natureza_juridica || data['NATUREZA JURÍDICA'],
      'Data Abertura': data.abertura || data.data_abertura || data['ABERTURA'],
      'Capital Social': data.capital_social || data['CAPITAL SOCIAL'],
      'Atividade Principal': data.atividade_principal?.[0]?.text || data['ATIVIDADE PRINCIPAL'],
      'Atividades Secundárias': data.atividades_secundarias?.map(a => a.text).join('\n') || data['ATIVIDADES SECUNDÁRIAS'],
      'Logradouro': data.logradouro || data['LOGRADOURO'],
      'Número': data.numero || data['NUMERO'],
      'Complemento': data.complemento || data['COMPLEMENTO'],
      'Bairro': data.bairro || data['BAIRRO'],
      'Município': data.municipio || data['MUNICÍPIO'],
      'UF': data.uf || data['UF'],
      'CEP': data.cep || data['CEP'],
      'Email': data.email || data['EMAIL'],
      'Telefone': data.telefone || data['TELEFONE'],
      'Quadro de Sócios': data.qsa?.map(s => `${s.nome} (${s.qual})`).join('\n') || data['QSA'],
      'Data da Última Atualização': data.ultima_atualizacao || data['ÚLTIMA ATUALIZAÇÃO']
    };
    
    for (const [name, value] of Object.entries(campos)) {
      if (value && value !== 'null' && value !== '') {
        const displayValue = String(value).substring(0, 500);
        fields.push({ 
          name: `📝 ${name}`, 
          value: displayValue, 
          inline: ['CEP', 'UF', 'Número', 'Porte', 'Tipo'].includes(name)
        });
      }
    }
    
    // Adicionar fields em grupos de 25 (limite do Discord)
    embed.addFields(fields.slice(0, 25));
    
    await editEmbed(thinkingMsg, embed);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', result.error || 'CNPJ não encontrado', '#EF4444');
  }
}

async function handleCPF(message, response, thinkingMsg) {
  const cpf = response.cpf || response.value;
  if (!cpf) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'CPF não informado!', '#EF4444');
  }
  
  const result = await apiService.consultaCPF(cpf);
  
  if (result.status === 'success' || result.nome || result.data) {
    const data = result.data || result;
    
    // Criar embed com TODAS as informações
    const embed = new EmbedBuilder()
      .setTitle('👤 Consulta CPF - Resultado')
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    // Dados principais
    if (result.nome || data.nome || data.NOME) {
      embed.setDescription(`**${result.nome || data.nome || data.NOME}**`);
    }
    
    // Adicionar todos os campos disponíveis
    const campos = {
      'Nome': result.nome || data.nome || data.NOME,
      'CPF': data.cpf || data.CPF || cpf,
      'Data de Nascimento': result.data_nascimento || data.data_nascimento || data.NASCIMENTO || data['DATA DE NASCIMENTO'],
      'Idade': data.idade || data.IDADE,
      'Signo': data.signo || data.SIGNO,
      'Sexo': data.sexo || data.SEXO,
      'Nome da Mãe': result.nome_mae || data.nome_mae || data['NOME DA MÃE'] || data.MAE,
      'Nome do Pai': data.nome_pai || data['NOME DO PAI'] || data.PAI,
      'RG': data.rg || data.RG,
      'Órgão Emissor': data.orgao_emissor || data['ÓRGÃO EMISSOR'],
      'Data de Emissão RG': data.data_emissao_rg || data['DATA EMISSÃO RG'],
      'Estado Civil': data.estado_civil || data['ESTADO CIVIL'],
      'Escolaridade': data.escolaridade || data.ESCOLARIDADE,
      'Renda': data.renda || data.RENDA,
      'Renda Presumida': data.renda_presumida || data['RENDA PRESUMIDA'],
      'CEP': data.cep || data.CEP,
      'Logradouro': data.logradouro || data.LOGRADOURO,
      'Número': data.numero || data.NUMERO,
      'Complemento': data.complemento || data['COMPLEMENTO'],
      'Bairro': data.bairro || data['BAIRRO'],
      'Cidade': data.cidade || data.municipio || data.CIDADE || data.MUNICÍPIO,
      'UF': data.uf || data.UF,
      'Email': data.email || data.EMAIL,
      'Telefone': data.telefone || data.TELEFONE,
      'Situação Cadastral': data.situacao_cadastral || data['SITUAÇÃO CADASTRAL'],
      'Data da Última Atualização': data.ultima_atualizacao || data['ÚLTIMA ATUALIZAÇÃO']
    };
    
    const fields = [];
    for (const [name, value] of Object.entries(campos)) {
      if (value && value !== 'null' && value !== '') {
        const displayValue = String(value).substring(0, 500);
        fields.push({ 
          name: `📝 ${name}`, 
          value: displayValue, 
          inline: ['CPF', 'Sexo', 'Idade', 'UF', 'CEP'].includes(name)
        });
      }
    }
    
    embed.addFields(fields.slice(0, 25));
    
    await editEmbed(thinkingMsg, embed);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', result.error || 'CPF não encontrado', '#EF4444');
  }
}

async function handleImageSearch(message, response, thinkingMsg) {
  const query = response.query || response.termo || response.busca;
  if (!query) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'Termo de busca não informado!', '#EF4444');
  }
  
  const result = await apiService.searchGoogleImage(query);
  
  if (result.success && result.data?.result?.[0]?.url) {
    const imageUrl = result.data.result[0].url;
    
    const embed = new EmbedBuilder()
      .setTitle('🖼️ Imagem Encontrada!')
      .setDescription(`Busca: **${query}**\n\nAqui está sua imagem! ✨`)
      .setImage(imageUrl)
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', 'Nenhuma imagem encontrada', '#EF4444');
  }
}

async function handleCosplayVideo(message, thinkingMsg) {
  const result = await apiService.getCosplayVideo();
  
  if (result.status === 'success' && result.media?.url) {
    const embed = new EmbedBuilder()
      .setTitle('🎬 Vídeo de Cosplay!')
      .setDescription(`Aqui está seu vídeo! ✨🔥\n\n[▶️ Assistir Vídeo](${result.media.url})`)
      .setColor('#EC4899')
      .setFooter({ text: `Por: ${result.author || 'Cosplay'}` })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', 'Não foi possível obter o vídeo', '#EF4444');
  }
}

async function handleDalle(message, response, thinkingMsg) {
  const prompt = response.prompt || response.descricao;
  if (!prompt) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'Descrição não informada!', '#EF4444');
  }
  
  const result = await apiService.dalleXlloraText2image(prompt, response.negative || 'low quality');
  
  if (result.success && result.data?.result) {
    const embed = new EmbedBuilder()
      .setTitle('🎨 Imagem Gerada!')
      .setDescription(`Prompt: **${prompt.substring(0, 100)}**\n\nAqui está sua arte! ✨`)
      .setImage(result.data.result)
      .setColor('#F59E0B')
      .setFooter({ text: '💎 Rias-Grimory-X - Dalle' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', result.error || 'Falha ao gerar imagem', '#EF4444');
  }
}

async function handleFileGeneration(message, response, thinkingMsg) {
  const fileType = response.fileType || response.tipo || 'txt';
  const filename = response.filename || response.nome || `arquivo.${fileType === 'pdf' ? 'pdf' : 'txt'}`;
  const content = response.content || response.conteudo;
  
  if (!content) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'Conteúdo não informado!', '#EF4444');
  }
  
  let filePath;
  try {
    if (fileType === 'pdf') {
      filePath = await apiService.generatePDF(filename, content);
    } else {
      filePath = await apiService.generateTextFile(filename, content);
    }
    
    const uploadResult = await apiService.uploadFile(filePath);
    
    const embed = new EmbedBuilder()
      .setTitle('📄 Arquivo Criado!')
      .setDescription(`✅ Seu arquivo **${filename}** está pronto!\n\n${uploadResult.success ? `📥 [Download](${uploadResult.url})\n*(Expira em 60 min)*` : 'Arquivo gerado!'}`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    if (thinkingMsg) {
      await thinkingMsg.edit({ 
        embeds: [embed],
        files: [filePath]
      }).catch(() => {
        message.channel.send({ embeds: [embed], files: [filePath] });
      });
    } else {
      await message.reply({ 
        embeds: [embed], 
        files: [filePath],
        allowedMentions: { repliedUser: false }
      });
    }
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao criar arquivo: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE CANAIS
// ============================================

async function handleCreateChannel(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.createChannel(guild, {
      name: response.name || response.nome,
      type: response.tipo || response.channelType || 'texto',
      parent: response.categoria || response.parent || response.parentId,
      topic: response.topico || response.topic,
      slowmode: response.slowmode,
      nsfw: response.nsfw,
      bitrate: response.bitrate,
      userLimit: response.userLimit || response.limite_usuarios,
      permissions: response.permissoes || response.permissions
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Canal Criado!')
      .setDescription(`Canal ${result.channel.mention} criado com sucesso! 🎉`)
      .addFields(
        { name: '📝 Nome', value: result.channel.name, inline: true },
        { name: '📁 Tipo', value: result.channel.type, inline: true }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao criar canal: ${error.message}`, '#EF4444');
  }
}

async function handleEditChannel(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.editChannel(guild, {
      channel: response.canal || response.channel || response.channelId,
      name: response.nome || response.name,
      topic: response.topico || response.topic,
      slowmode: response.slowmode,
      nsfw: response.nsfw,
      bitrate: response.bitrate,
      userLimit: response.userLimit || response.limite_usuarios,
      position: response.posicao || response.position
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Canal Editado!')
      .setDescription(`Canal **${result.channel.name}** foi atualizado! 🎉`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao editar canal: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteChannel(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.deleteChannel(
      guild, 
      response.canal || response.channel || response.channelId || response.nome || response.name
    );
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Canal Deletado!')
      .setDescription(`Canal **#${result.name}** foi deletado! 🗑️`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao deletar canal: ${error.message}`, '#EF4444');
  }
}

async function handleCloneChannel(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.cloneChannel(
      guild, 
      response.canal || response.channel || response.channelId,
      response.novo_nome || response.newName
    );
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Canal Clonado!')
      .setDescription(`Canal **#${result.original}** foi clonado!`)
      .addFields({ name: '📝 Novo Canal', value: result.cloned.mention, inline: true })
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao clonar canal: ${error.message}`, '#EF4444');
  }
}

async function handleLockChannel(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.lockChannel(
      guild, 
      response.canal || response.channel || response.channelId,
      response.trancar !== false && response.lock !== false
    );
    
    const embed = new EmbedBuilder()
      .setTitle(result.locked ? '🔒 Canal Trancado!' : '🔓 Canal Destrancado!')
      .setDescription(`Canal **${result.channel}** foi ${result.locked ? 'trancado' : 'destrancado'}!`)
      .setColor(result.locked ? '#F59E0B' : '#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleHideChannel(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.hideChannelFromRole(guild, {
      channel: response.canal || response.channel,
      role: response.cargo || response.role,
      hidden: response.esconder !== false && response.hidden !== false
    });
    
    const embed = new EmbedBuilder()
      .setTitle(result.hidden ? '🙈 Canal Escondido!' : '👁️ Canal Visível!')
      .setDescription(`Canal **${result.channel}** ${result.hidden ? 'escondido de' : 'visível para'} **@${result.role}**!`)
      .setColor(result.hidden ? '#F59E0B' : '#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleChannelPermission(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.setChannelPermissions(guild, {
      channel: response.canal || response.channel,
      role: response.cargo || response.role,
      allow: response.permitir || response.allow || [],
      deny: response.negar || response.deny || []
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Permissões Atualizadas!')
      .setDescription(`Permissões de **@${result.role}** no canal **${result.channel}** foram atualizadas!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleCreateCategory(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.createCategory(guild, {
      name: response.nome || response.name,
      channels: response.canais || response.channels || [],
      permissions: response.permissoes || response.permissions || []
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Categoria Criada!')
      .setDescription(`Categoria ${result.category.mention} criada com **${result.channels.length}** canais! 🎉`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListChannels(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.listChannels(guild, response.tipo || response.type || 'all');
    
    const channelList = result.channels.slice(0, 20).map(c => 
      `• ${c.type === 'categoria' ? '📁' : c.type === 'voz' ? '🔊' : '💬'} **${c.name}**`
    ).join('\n');
    
    const embed = new EmbedBuilder()
      .setTitle('📁 Canais do Servidor')
      .setDescription(channelList || 'Nenhum canal encontrado')
      .addFields({ name: '📊 Total', value: `${result.channels.length} canais`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE CARGOS
// ============================================

async function handleCreateRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.createRole(guild, {
      name: response.nome || response.name,
      color: response.cor || response.color,
      permissions: response.permissoes || response.permissions || [],
      hoist: response.separado || response.hoist,
      mentionable: response.mencionavel || response.mentionable
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Criado!')
      .setDescription(`Cargo ${result.role.mention} criado com sucesso! 🎉`)
      .addFields(
        { name: '📝 Nome', value: result.role.name, inline: true },
        { name: '🎨 Cor', value: result.role.color || 'Padrão', inline: true }
      )
      .setColor(result.role.color || '#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao criar cargo: ${error.message}`, '#EF4444');
  }
}

async function handleEditRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.editRole(guild, {
      role: response.cargo || response.role || response.roleId,
      name: response.nome || response.name,
      color: response.cor || response.color,
      permissions: response.permissoes || response.permissions,
      hoist: response.separado || response.hoist,
      mentionable: response.mencionavel || response.mentionable
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Editado!')
      .setDescription(`Cargo **${result.role.name}** foi atualizado!`)
      .setColor(result.role.color || '#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.deleteRole(
      guild, 
      response.cargo || response.role || response.roleId || response.nome || response.name
    );
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Deletado!')
      .setDescription(`Cargo **@${result.name}** foi deletado! 🗑️`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleCloneRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.cloneRole(
      guild, 
      response.cargo || response.role || response.roleId,
      response.novo_nome || response.newName
    );
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Clonado!')
      .setDescription(`Cargo **@${result.original}** foi clonado!`)
      .addFields({ name: '📝 Novo Cargo', value: result.cloned.mention, inline: true })
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleAddRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.addRoleToMember(guild, {
      member: response.membro || response.member || response.userId,
      role: response.cargo || response.role,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Adicionado!')
      .setDescription(`Cargo **@${result.role}** adicionado a **${result.member}**!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleRemoveRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.removeRoleFromMember(guild, {
      member: response.membro || response.member || response.userId,
      role: response.cargo || response.role,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Cargo Removido!')
      .setDescription(`Cargo **@${result.role}** removido de **${result.member}**!`)
      .setColor('#F59E0B')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListRoles(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.listRoles(guild);
    
    const roleList = result.roles.slice(0, 20).map(r => 
      `• <@&${r.id}> (${r.members} membros)`
    ).join('\n');
    
    const embed = new EmbedBuilder()
      .setTitle('🎭 Cargos do Servidor')
      .setDescription(roleList || 'Nenhum cargo encontrado')
      .addFields({ name: '📊 Total', value: `${result.roles.length} cargos`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE MEMBROS
// ============================================

async function handleKick(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.kickMember(guild, {
      member: response.membro || response.member || response.userId,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('👢 Membro Expulso!')
      .setDescription(`**${result.tag}** foi expulso do servidor!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleBan(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.banMember(guild, {
      member: response.membro || response.member || response.userId,
      reason: response.motivo || response.reason,
      deleteMessageDays: response.deletar_dias || response.deleteMessageDays || 1
    });
    
    const embed = new EmbedBuilder()
      .setTitle('🔨 Membro Banido!')
      .setDescription(`**${result.tag}** foi banido do servidor!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleUnban(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.unbanMember(guild, {
      userId: response.usuario || response.userId || response.user,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Membro Desbanido!')
      .setDescription(`Usuário **${result.userId}** foi desbanido!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleMute(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.muteMember(guild, {
      member: response.membro || response.member || response.userId,
      duration: response.duracao || response.duration || 60,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('🔇 Membro Mutado!')
      .setDescription(`**${result.tag}** foi mutado por **${result.duration}**!`)
      .setColor('#F59E0B')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleUnmute(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.unmuteMember(guild, {
      member: response.membro || response.member || response.userId,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('🔊 Membro Desmutado!')
      .setDescription(`**${result.tag}** foi desmutado!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleNickname(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.setNickname(guild, {
      member: response.membro || response.member || response.userId,
      nickname: response.apelido || response.nickname,
      reason: response.motivo || response.reason
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✏️ Apelido Alterado!')
      .setDescription(`Apelido de **${result.tag}** alterado para **${result.newNickname || 'Sem apelido'}**!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleMemberInfo(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.getMemberInfo(
      guild, 
      response.membro || response.member || response.userId
    );
    
    const m = result.member;
    
    const embed = new EmbedBuilder()
      .setTitle(`👤 Info: ${m.tag}`)
      .setDescription(`${m.isOwner ? '👑 **DONO DO SERVIDOR**' : ''}`)
      .addFields(
        { name: '🆔 ID', value: m.id, inline: true },
        { name: '📝 Apelido', value: m.nickname || 'Nenhum', inline: true },
        { name: '📅 Entrou em', value: `<t:${Math.floor(new Date(m.joinedAt) / 1000)}:d>`, inline: true },
        { name: '🎭 Cargos', value: m.roles.slice(0, 10).join(', ') || 'Nenhum', inline: false },
        { name: '🤖 Bot', value: m.isBot ? 'Sim' : 'Não', inline: true }
      )
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleMembersByRole(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.listMembersByRole(
      guild, 
      response.cargo || response.role,
      response.limite || response.limit || 20
    );
    
    const memberList = result.members.map(m => 
      `• **${m.tag}** ${m.nickname ? `(${m.nickname})` : ''}`
    ).join('\n');
    
    const embed = new EmbedBuilder()
      .setTitle(`👥 Membros com @${result.role}`)
      .setDescription(memberList || 'Nenhum membro encontrado')
      .addFields({ name: '📊 Total', value: `${result.count} membros`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE MENSAGENS
// ============================================

async function handleBulkDelete(message, response, guild, channel, thinkingMsg) {
  try {
    const result = await serverTools.bulkDeleteMessages(channel, {
      amount: response.quantidade || response.amount || 10,
      userId: response.usuario || response.userId
    });
    
    const embed = new EmbedBuilder()
      .setTitle('🗑️ Mensagens Deletadas!')
      .setDescription(`**${result.deleted}** mensagens foram deletadas!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handlePinMessage(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.pinMessage(
      channel, 
      response.messageId || response.mensagem
    );
    
    const embed = new EmbedBuilder()
      .setTitle('📌 Mensagem Fixada!')
      .setDescription(`[Mensagem](${result.url}) foi fixada!`)
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleUnpinMessage(message, response, channel, thinkingMsg) {
  try {
    await serverTools.unpinMessage(
      channel, 
      response.messageId || response.mensagem
    );
    
    const embed = new EmbedBuilder()
      .setTitle('📌 Mensagem Desfixada!')
      .setDescription('Mensagem foi desfixada!')
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE WEBHOOKS - MELHORADO V5.0
// ============================================

async function handleCreateWebhook(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.createWebhook(channel, {
      name: response.nome || response.name || 'Rias-Grimory-X Webhook',
      avatar: response.avatar
    });
    
    const w = result.webhook;
    
    const embed = new EmbedBuilder()
      .setTitle('🪝 Webhook Criado!')
      .setDescription(`Webhook **${w.name}** criado com sucesso!`)
      .addFields(
        { name: '🆔 ID', value: w.id, inline: true },
        { name: '📝 Nome', value: w.name, inline: true },
        { name: '📺 Canal', value: w.channel, inline: true },
        { name: '🔗 URL Completa', value: `\`${w.url}\``, inline: false },
        { name: '🔑 Token', value: `\`${w.token}\``, inline: false }
      )
      .setColor('#10B981')
      .setFooter({ text: '⚠️ Guarde a URL com segurança! | 💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListWebhooks(message, channel, thinkingMsg) {
  try {
    const result = await serverTools.listWebhooks(channel);
    
    if (result.webhooks.length === 0) {
      const embed = new EmbedBuilder()
        .setTitle('🪝 Webhooks do Canal')
        .setDescription('Nenhum webhook encontrado neste canal.')
        .setColor('#8B5CF6')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      
      return await editEmbed(thinkingMsg, embed);
    }
    
    const webhookList = result.webhooks.map(w => {
      let desc = `**${w.name}** (ID: ${w.id})\n`;
      desc += `📺 Canal: ${w.channel}\n`;
      if (w.url) desc += `🔗 URL: \`${w.url}\`\n`;
      if (w.owner) desc += `👤 Dono: ${w.owner}`;
      return desc;
    }).join('\n\n');
    
    const embed = new EmbedBuilder()
      .setTitle('🪝 Webhooks do Canal')
      .setDescription(webhookList.substring(0, 2000))
      .addFields({ name: '📊 Total', value: `${result.count} webhook(s)`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListGuildWebhooks(message, guild, thinkingMsg) {
  try {
    const result = await serverTools.listGuildWebhooks(guild);
    
    if (result.webhooks.length === 0) {
      const embed = new EmbedBuilder()
        .setTitle('🪝 Webhooks do Servidor')
        .setDescription('Nenhum webhook encontrado no servidor.')
        .setColor('#8B5CF6')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      
      return await editEmbed(thinkingMsg, embed);
    }
    
    const webhookList = result.webhooks.slice(0, 10).map(w => {
      let desc = `**${w.name}** (ID: ${w.id})\n`;
      desc += `📺 Canal: ${w.channel}\n`;
      if (w.url) desc += `🔗 \`${w.url}\`\n`;
      if (w.owner) desc += `👤 ${w.owner}`;
      return desc;
    }).join('\n\n');
    
    const embed = new EmbedBuilder()
      .setTitle('🪝 Webhooks do Servidor')
      .setDescription(webhookList.substring(0, 2000))
      .addFields({ name: '📊 Total', value: `${result.count} webhook(s)`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleGetWebhook(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.getWebhook(
      guild, 
      response.webhookId || response.webhook || response.id
    );
    
    const w = result.webhook;
    
    const embed = new EmbedBuilder()
      .setTitle('🪝 Informações do Webhook')
      .addFields(
        { name: '🆔 ID', value: w.id, inline: true },
        { name: '📝 Nome', value: w.name, inline: true },
        { name: '📺 Canal', value: w.channel, inline: true },
        { name: '🔗 URL', value: w.url ? `\`${w.url}\`` : 'Indisponível', inline: false },
        { name: '🔑 Token', value: w.token ? `\`${w.token}\`` : 'Indisponível', inline: false },
        { name: '👤 Dono', value: w.owner || 'Desconhecido', inline: true }
      )
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleEditWebhook(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.editWebhook(channel, {
      webhookId: response.webhookId || response.webhook,
      name: response.nome || response.name,
      avatar: response.avatar
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Webhook Editado!')
      .setDescription(`Webhook **${result.webhook.name}** foi atualizado!`)
      .addFields({ name: '🔗 URL', value: result.webhook.url ? `\`${result.webhook.url}\`` : 'Indisponível' })
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteWebhook(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.deleteWebhook(
      channel, 
      response.webhookId || response.webhook
    );
    
    const embed = new EmbedBuilder()
      .setTitle('🗑️ Webhook Deletado!')
      .setDescription(`Webhook **${result.name}** foi deletado!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleSendWebhook(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.sendWebhookMessage(channel, {
      webhookId: response.webhookId || response.webhook,
      content: response.content || response.conteudo,
      username: response.username || response.nome,
      avatarURL: response.avatarURL || response.avatar,
      embeds: response.embeds
    });
    
    const embed = new EmbedBuilder()
      .setTitle('✅ Mensagem Enviada!')
      .setDescription('Mensagem enviada via webhook com sucesso!')
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE CONVITES
// ============================================

async function handleCreateInvite(message, response, channel, thinkingMsg) {
  try {
    const result = await serverTools.createInvite(channel, {
      maxAge: response.maxAge || response.tempo || 86400,
      maxUses: response.maxUses || response.usos || 0,
      temporary: response.temporary || response.temporario || false,
      unique: response.unique || response.unico || false
    });
    
    const embed = new EmbedBuilder()
      .setTitle('📨 Convite Criado!')
      .setDescription(`**${result.invite.url}**`)
      .addFields({ name: '🔑 Código', value: result.invite.code, inline: true })
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListInvites(message, guild, thinkingMsg) {
  try {
    const result = await serverTools.listInvites(guild);
    
    const inviteList = result.invites.slice(0, 15).map(i => 
      `• **${i.code}** - ${i.channel} (${i.uses}/${i.maxUses || '∞'})`
    ).join('\n') || 'Nenhum convite encontrado';
    
    const embed = new EmbedBuilder()
      .setTitle('📨 Convites do Servidor')
      .setDescription(inviteList)
      .addFields({ name: '📊 Total', value: `${result.invites.length} convites`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteInvite(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.deleteInvite(
      guild, 
      response.codigo || response.code
    );
    
    const embed = new EmbedBuilder()
      .setTitle('🗑️ Convite Deletado!')
      .setDescription(`Convite **${result.code}** foi deletado!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FERRAMENTAS DE EMOJIS
// ============================================

async function handleAddEmoji(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.addEmoji(guild, {
      name: response.nome || response.name,
      url: response.url || response.imagem,
      roles: response.cargos || response.roles || []
    });
    
    const embed = new EmbedBuilder()
      .setTitle('😀 Emoji Adicionado!')
      .setDescription(`Emoji ${result.emoji.string} foi adicionado!`)
      .addFields(
        { name: '📝 Nome', value: result.emoji.name, inline: true },
        { name: '🆔 ID', value: result.emoji.id, inline: true }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteEmoji(message, response, guild, thinkingMsg) {
  try {
    const result = await serverTools.deleteEmoji(
      guild, 
      response.emojiId || response.emoji || response.id
    );
    
    const embed = new EmbedBuilder()
      .setTitle('🗑️ Emoji Deletado!')
      .setDescription(`Emoji **${result.name}** foi deletado!`)
      .setColor('#EF4444')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListEmojis(message, guild, thinkingMsg) {
  try {
    const result = await serverTools.listEmojis(guild);
    
    const emojiList = result.emojis.slice(0, 30).map(e => 
      `${e.string} **${e.name}**`
    ).join(' ') || 'Nenhum emoji encontrado';
    
    const embed = new EmbedBuilder()
      .setTitle('😀 Emojis do Servidor')
      .setDescription(emojiList.substring(0, 2000))
      .addFields({ name: '📊 Total', value: `${result.count} emojis`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// INFORMAÇÕES DO SERVIDOR
// ============================================

async function handleServerStats(message, guild, thinkingMsg) {
  try {
    const result = await serverTools.getServerStats(guild);
    const s = result.server;
    
    const embed = new EmbedBuilder()
      .setTitle(`📊 ${s.name}`)
      .setThumbnail(s.icon)
      .setDescription(`**ID:** ${s.id}\n**Dono:** <@${s.ownerId}>`)
      .addFields(
        { name: '👥 Membros', value: `${s.memberCount} (${s.online} online)`, inline: true },
        { name: '🤖 Bots', value: `${s.bots}`, inline: true },
        { name: '📁 Canais', value: `${s.channels.total} (${s.channels.text} texto, ${s.channels.voice} voz)`, inline: true },
        { name: '🎭 Cargos', value: `${s.roles}`, inline: true },
        { name: '😀 Emojis', value: `${s.emojis}`, inline: true },
        { name: '💎 Boost', value: `Nível ${s.boost.level} (${s.boost.count} boosts)`, inline: true },
        { name: '📅 Criado em', value: `<t:${Math.floor(new Date(s.createdAt) / 1000)}:d>`, inline: true }
      )
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X v5.0' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// OUTRAS FERRAMENTAS
// ============================================

async function handleSendEmbed(message, response, guild, channel, thinkingMsg) {
  const colorMap = {
    'roxo': '#8B5CF6', 'purple': '#8B5CF6',
    'vermelho': '#EF4444', 'red': '#EF4444',
    'verde': '#10B981', 'green': '#10B981',
    'azul': '#3B82F6', 'blue': '#3B82F6',
    'amarelo': '#F59E0B', 'yellow': '#F59E0B',
    'laranja': '#F97316', 'orange': '#F97316',
    'rosa': '#EC4899', 'pink': '#EC4899',
    'dourado': '#FFD700', 'gold': '#FFD700'
  };
  
  let color = response.color || '#8B5CF6';
  if (colorMap[color.toLowerCase()]) {
    color = colorMap[color.toLowerCase()];
  }
  
  const embed = new EmbedBuilder()
    .setTitle(response.title || response.titulo || 'Embed')
    .setDescription(response.description || response.descricao || '')
    .setColor(color)
    .setFooter({ text: response.footer || '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  if (response.image || response.imagem) {
    embed.setImage(response.image || response.imagem);
  }
  if (response.thumbnail) {
    embed.setThumbnail(response.thumbnail);
  }
  
  if (response.fields && Array.isArray(response.fields)) {
    response.fields.forEach(field => {
      embed.addFields({
        name: field.name || 'Campo',
        value: field.value || 'Valor',
        inline: field.inline || false
      });
    });
  }
  
  let targetChannel = channel;
  if (response.targetChannel || response.canal) {
    const targetName = response.targetChannel || response.canal;
    const found = guild.channels.cache.find(c => 
      c.name.toLowerCase().includes(targetName.toLowerCase()) || c.id === targetName
    );
    if (found) targetChannel = found;
  }
  
  if (targetChannel.id !== channel.id) {
    await targetChannel.send({ embeds: [embed] });
    await editEmbed(thinkingMsg, '✅ Enviado!', `Embed enviado para ${targetChannel}!`, '#10B981');
  } else {
    await editEmbed(thinkingMsg, embed);
  }
}

async function handlePoll(message, response, thinkingMsg) {
  const question = response.question || response.pergunta || 'Enquete';
  const options = response.options || response.opcoes || ['Sim', 'Não'];
  
  const embed = new EmbedBuilder()
    .setTitle(`📊 ${question}`)
    .setDescription(options.map((opt, i) => `**${i + 1}.** ${opt}`).join('\n'))
    .setColor('#8B5CF6')
    .setFooter({ text: 'Clique para votar! | 💎 Rias-Grimory-X' })
    .setTimestamp();
  
  const row = new ActionRowBuilder();
  options.forEach((_, i) => {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(`poll_${i}`)
        .setLabel(`${i + 1}`)
        .setStyle(ButtonStyle.Primary)
    );
  });
  
  await message.channel.send({ embeds: [embed], components: [row] });
  await editEmbed(thinkingMsg, '✅ Enquete Criada!', 'A enquete foi enviada!', '#10B981');
}

async function handleComplexTask(message, response, guild, channel, thinkingMsg) {
  const steps = response.steps || response.etapas || [];
  
  const embed = new EmbedBuilder()
    .setTitle('🧠 Tarefa Complexa')
    .setDescription(`Executando **${steps.length}** etapas...`)
    .setColor('#FBBF24')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
  
  for (let i = 0; i < steps.length; i++) {
    const step = steps[i];
    const stepEmbed = new EmbedBuilder()
      .setTitle(`⚙️ Etapa ${i + 1}/${steps.length}`)
      .setDescription(`Executando...`)
      .setColor('#FBBF24')
      .setTimestamp();
    
    await editEmbed(thinkingMsg, stepEmbed);
    
    await handleResponse(message, step, guild, channel, null);
    await sleep(500);
  }
  
  const finalEmbed = new EmbedBuilder()
    .setTitle('🎉 Concluído!')
    .setDescription(`Todas as etapas foram executadas!`)
    .setColor('#10B981')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, finalEmbed);
}

async function handleMessage(message, response, thinkingMsg) {
  const content = response.content || response.mensagem || response.text || '';
  
  // Evitar string vazia no embed (Discord não aceita setDescription(''))
  const displayContent = (content.length > 2000 ? content.substring(0, 1997) + '...' : content) || 'Nenhum conteúdo retornado';
  
  const embed = new EmbedBuilder()
    .setDescription(displayContent)
    .setColor('#8B5CF6')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
}

// ============================================
// SISTEMA DE AUTOMAÇÃO
// ============================================

async function handleCreateAutomation(message, response, guild, thinkingMsg) {
  try {
    const channelIdentifier = response.canal || response.channel || response.channelId;
    const targetChannel = serverTools.findChannel(guild, channelIdentifier) || message.channel;
    
    const interval = Math.max(10, parseInt(response.intervalo || response.interval) || 60);
    
    const script = automationManager.createAutomation(guild.id, {
      name: response.nome || response.name || 'Automação',
      description: response.descricao || response.description || '',
      channelId: targetChannel.id,
      interval: interval,
      task: response.tarefa || response.task || 'Gerar conteúdo automaticamente'
    });
    
    // Iniciar automação
    if (discordClient) {
      script.start(discordClient);
    }
    
    const embed = new EmbedBuilder()
      .setTitle('🤖 Automação Criada!')
      .setDescription(`Script **${script.name}** criado com sucesso!`)
      .addFields(
        { name: '📝 Nome', value: script.name, inline: true },
        { name: '📺 Canal', value: `<#${script.channelId}>`, inline: true },
        { name: '⏱️ Intervalo', value: `${script.interval} minutos`, inline: true },
        { name: '📋 Tarefa', value: script.task.substring(0, 100) }
      )
      .setColor('#10B981')
      .setFooter({ text: '💎 Rias-Grimory-X | Automação' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleListAutomations(message, guild, thinkingMsg) {
  try {
    const automations = automationManager.listAutomations(guild.id);
    
    if (automations.length === 0) {
      const embed = new EmbedBuilder()
        .setTitle('🤖 Automações')
        .setDescription('Nenhuma automação configurada neste servidor.')
        .setColor('#8B5CF6')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      
      return await editEmbed(thinkingMsg, embed);
    }
    
    const autoList = automations.map(a => {
      const status = a.active ? '✅' : '⏸️';
      return `${status} **${a.name}**\n📺 ${a.channelMention} | ⏱️ ${a.interval}min | 🔄 ${a.runCount} execuções`;
    }).join('\n\n');
    
    const embed = new EmbedBuilder()
      .setTitle('🤖 Automações do Servidor')
      .setDescription(autoList.substring(0, 2000))
      .addFields({ name: '📊 Total', value: `${automations.length} script(s)`, inline: true })
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, embed);
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handlePauseAutomation(message, response, guild, thinkingMsg) {
  try {
    const scriptId = response.id || response.scriptId || response.automacao;
    const result = automationManager.pauseAutomation(guild.id, scriptId);
    
    if (result) {
      const embed = new EmbedBuilder()
        .setTitle('⏸️ Automação Pausada!')
        .setDescription('O script foi pausado e não executará mais.')
        .setColor('#F59E0B')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      
      await editEmbed(thinkingMsg, embed);
    } else {
      await editEmbed(thinkingMsg, '❌ Erro', 'Automação não encontrada!', '#EF4444');
    }
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleResumeAutomation(message, response, guild, thinkingMsg) {
  try {
    const scriptId = response.id || response.scriptId || response.automacao;
    const result = automationManager.resumeAutomation(guild.id, scriptId, discordClient);
    
    if (result) {
      const embed = new EmbedBuilder()
        .setTitle('▶️ Automação Retomada!')
        .setDescription('O script voltou a executar automaticamente!')
        .setColor('#10B981')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      
      await editEmbed(thinkingMsg, embed);
    } else {
      await editEmbed(thinkingMsg, '❌ Erro', 'Automação não encontrada!', '#EF4444');
    }
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleDeleteAutomation(message, response, guild, thinkingMsg) {
  try {
    const scriptId = response.id || response.scriptId || response.automacao;
    const result = automationManager.deleteAutomation(guild.id, scriptId);
    
    if (result) {
      const embed = new EmbedBuilder()
        .setTitle('🗑️ Automação Deletada!')
        .setDescription('O script foi removido permanentemente.')
        .setColor('#EF4444')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      
      await editEmbed(thinkingMsg, embed);
    } else {
      await editEmbed(thinkingMsg, '❌ Erro', 'Automação não encontrada!', '#EF4444');
    }
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

async function handleRunAutomation(message, response, guild, thinkingMsg) {
  try {
    const scriptId = response.id || response.scriptId || response.automacao;
    const result = await automationManager.runAutomationNow(guild.id, scriptId, discordClient);
    
    if (result) {
      const embed = new EmbedBuilder()
        .setTitle('⚡ Automação Executada!')
        .setDescription('O script foi executado manualmente!')
        .setColor('#10B981')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      
      await editEmbed(thinkingMsg, embed);
    } else {
      await editEmbed(thinkingMsg, '❌ Erro', 'Automação não encontrada!', '#EF4444');
    }
  } catch (error) {
    await editEmbed(thinkingMsg, '❌ Erro', `Falha: ${error.message}`, '#EF4444');
  }
}

// ============================================
// FUNÇÕES AUXILIARES
// ============================================

async function editEmbed(thinkingMsg, titleOrEmbed, description, color) {
  if (!thinkingMsg) return;
  
  try {
    if (typeof titleOrEmbed === 'object' && titleOrEmbed.constructor?.name === 'EmbedBuilder') {
      await thinkingMsg.edit({ embeds: [titleOrEmbed] });
    } else {
      const embed = new EmbedBuilder()
        .setTitle(titleOrEmbed)
        .setDescription((description || '').trim() || 'Sem descrição')
        .setColor(color || '#8B5CF6')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      await thinkingMsg.edit({ embeds: [embed] });
    }
  } catch (e) {
    console.error('Erro ao editar embed:', e.message);
  }
}

async function sendErrorEmbed(message, thinkingMsg, error) {
  const embed = new EmbedBuilder()
    .setTitle('😅 Ops!')
    .setDescription(`Ocorreu um erro:\n\`\`\`${error?.substring(0, 100)}\`\`\``)
    .setColor('#EF4444')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  if (thinkingMsg) {
    await editEmbed(thinkingMsg, embed);
  } else {
    await message.reply({ embeds: [embed], allowedMentions: { repliedUser: false } }).catch(() => {});
  }
}

async function handleFallback(message, thinkingMsg, content) {
  const embed = new EmbedBuilder()
    .setTitle('⚠️ Problema na IA')
    .setDescription('Estou com dificuldades técnicas agora! 😅\n\nTente novamente em alguns segundos!')
    .setColor('#F59E0B')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  if (thinkingMsg) {
    await editEmbed(thinkingMsg, embed);
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export default { name, execute, setClient };
