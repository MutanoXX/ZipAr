/**
 * Rias-Grimory-X - Comando /ask
 * Ativa/desativa canais para conversa com a IA
 * 
 * VERSÃO 5.0 - Sistema COMPLETO de gestão + Automação
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  MessageFlags
} from 'discord.js';
import { checkServerPermission } from '../utils/permissions.js';
import { 
  activateChannel, 
  deactivateChannel, 
  isChannelActive, 
  getActiveChannels,
  clearChannelContext,
  setChannelPrompt_Default,
  getChannelContextInfo,
  getServerSettings
} from '../utils/activeChannels.js';

export const data = new SlashCommandBuilder()
  .setName('ask')
  .setDescription('🤖 Ativa/desativa conversa com a IA em um canal')
  .addSubcommand(sub =>
    sub
      .setName('on')
      .setDescription('✅ Ativa a IA para conversar neste canal')
      .addChannelOption(opt =>
        opt
          .setName('canal')
          .setDescription('Canal para ativar (padrão: canal atual)')
          .setRequired(false)
      )
  )
  .addSubcommand(sub =>
    sub
      .setName('off')
      .setDescription('❌ Desativa a IA neste canal')
      .addChannelOption(opt =>
        opt
          .setName('canal')
          .setDescription('Canal para desativar (padrão: canal atual)')
          .setRequired(false)
      )
  )
  .addSubcommand(sub =>
    sub
      .setName('list')
      .setDescription('📋 Lista canais ativos no servidor')
  )
  .addSubcommand(sub =>
    sub
      .setName('clear')
      .setDescription('🗑️ Limpa o contexto/histórico do canal (mantém 60 msgs)')
      .addChannelOption(opt =>
        opt
          .setName('canal')
          .setDescription('Canal para limpar (padrão: canal atual)')
          .setRequired(false)
      )
  )
  .addSubcommand(sub =>
    sub
      .setName('stats')
      .setDescription('📊 Mostra estatísticas do contexto do canal')
  );

export async function execute(interaction) {
  const userId = interaction.user.id;
  const guild = interaction.guild;
  const member = interaction.member;
  
  // Verificar permissão no servidor específico
  const permCheck = checkServerPermission(guild, { id: userId }, member);
  
  if (!permCheck.authorized) {
    return interaction.reply({
      content: `❌ **Acesso Negado!**\n\n${permCheck.reason}\n\n💡 **Dica:** Se você é dono de um servidor, pode convidar o bot para ter acesso completo aos comandos!`,
      flags: MessageFlags.Ephemeral
    });
  }

  const subcommand = interaction.options.getSubcommand();

  switch (subcommand) {
    case 'on':
      await handleOn(interaction, guild);
      break;
    case 'off':
      await handleOff(interaction, guild);
      break;
    case 'list':
      await handleList(interaction, guild);
      break;
    case 'clear':
      await handleClear(interaction, guild);
      break;
    case 'stats':
      await handleStats(interaction, guild);
      break;
  }
}

/**
 * Ativa a IA em um canal
 */
async function handleOn(interaction, guild) {
  const channel = interaction.options.getChannel('canal') || interaction.channel;
  
  if (isChannelActive(guild.id, channel.id)) {
    return interaction.reply({
      content: `❌ A IA já está ativa em <#${channel.id}>`,
      flags: MessageFlags.Ephemeral
    });
  }

  // Obter configurações do servidor
  const settings = getServerSettings(guild.id);
  
  // Criar prompt_Default com contexto do servidor
  const prompt_Default = buildPrompt_Default(guild, channel, settings.language);
  setChannelPrompt_Default(channel.id, prompt_Default, guild.id);
  
  activateChannel(guild.id, channel.id);

  const embed = new EmbedBuilder()
    .setTitle('🤖 IA Ativada!')
    .setDescription(`A **Rias-Grimory-X v5.0** agora está conversando em <#${channel.id}>!`)
    .addFields(
      { name: '💬 Como usar', value: 'Basta enviar mensagens no canal e a IA responderá!' },
      { name: '🧠 Memória', value: 'A IA lembra de até **60 mensagens** de conversa!' },
      { name: '🎯 Capacidades', value: '+60 ferramentas de gestão completa do servidor!' }
    )
    .setColor('#10B981')
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });

  // Enviar mensagem de boas-vindas no canal
  try {
    await channel.send({
      embeds: [
        new EmbedBuilder()
          .setTitle('👋 Olá! Sou a Rias-Grimory-X v5.0!')
          .setDescription('Estou aqui para ajudar com **CONTROLE TOTAL** do servidor! 🚀')
          .addFields(
            { name: '🎯 Canais', value: 'Criar, editar, deletar, clonar, trancar, esconder, permissões' },
            { name: '🎭 Cargos', value: 'Criar, editar, deletar, clonar, adicionar/remover de membros' },
            { name: '👥 Membros', value: 'Kick, ban, unban, mute, unmute, apelido, info' },
            { name: '💬 Mensagens', value: 'Deletar em massa, fixar, desfixar' },
            { name: '🪝 Webhooks', value: 'Criar com URL completa, token, editar, enviar mensagens' },
            { name: '🤖 Automação', value: 'Scripts automáticos que rodam em intervalos!' }
          )
          .setColor('#8B5CF6')
          .setTimestamp()
      ]
    });
  } catch (e) {
    console.error('Erro ao enviar mensagem de boas-vindas:', e.message);
  }
}

/**
 * Desativa a IA em um canal
 */
async function handleOff(interaction, guild) {
  const channel = interaction.options.getChannel('canal') || interaction.channel;
  
  if (!isChannelActive(guild.id, channel.id)) {
    return interaction.reply({
      content: `❌ A IA não está ativa em <#${channel.id}>`,
      flags: MessageFlags.Ephemeral
    });
  }

  deactivateChannel(guild.id, channel.id);

  const embed = new EmbedBuilder()
    .setTitle('🤖 IA Desativada')
    .setDescription(`A **Rias-Grimory-X** foi desativada em <#${channel.id}>`)
    .setColor('#EF4444')
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

/**
 * Lista canais ativos
 */
async function handleList(interaction, guild) {
  const channels = getActiveChannels(guild.id);

  if (channels.length === 0) {
    return interaction.reply({
      content: '❌ Nenhum canal ativo no servidor.',
      flags: MessageFlags.Ephemeral
    });
  }

  const channelList = channels.map(id => `<#${id}>`).join('\n');

  const embed = new EmbedBuilder()
    .setTitle('📋 Canais Ativos')
    .setDescription(channelList)
    .addFields({ name: 'Total', value: `${channels.length} canal(is)`, inline: true })
    .setColor('#8B5CF6')
    .setTimestamp();

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

/**
 * Limpa contexto do canal
 */
async function handleClear(interaction, guild) {
  const channel = interaction.options.getChannel('canal') || interaction.channel;
  
  if (!isChannelActive(guild.id, channel.id)) {
    return interaction.reply({
      content: `❌ A IA não está ativa em <#${channel.id}>`,
      flags: MessageFlags.Ephemeral
    });
  }

  // Limpar contexto
  clearChannelContext(channel.id, guild.id);

  const embed = new EmbedBuilder()
    .setTitle('🗑️ Contexto Limpo!')
    .setDescription(`O histórico de <#${channel.id}> foi resetado. A IA não lembrará mais das conversas anteriores.`)
    .addFields({ name: 'ℹ️ Info', value: 'A IA ainda pode guardar até 60 novas mensagens de conversa.' })
    .setColor('#10B981')
    .setTimestamp();

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

/**
 * Mostra estatísticas do contexto
 */
async function handleStats(interaction, guild) {
  const channel = interaction.channel;
  
  if (!isChannelActive(guild.id, channel.id)) {
    return interaction.reply({
      content: `❌ A IA não está ativa neste canal. Use \`/ask on\` para ativar.`,
      flags: MessageFlags.Ephemeral
    });
  }

  const info = getChannelContextInfo(channel.id);

  const embed = new EmbedBuilder()
    .setTitle('📊 Estatísticas do Contexto')
    .addFields(
      { name: '📝 Total de Mensagens', value: `${info.messages}`, inline: true },
      { name: '👤 Mensagens do Usuário', value: `${info.userMessages}`, inline: true },
      { name: '🤖 Mensagens da IA', value: `${info.aiMessages}`, inline: true },
      { name: '🧠 Limite', value: '60 mensagens', inline: true },
      { name: '⏰ Última Atividade', value: `<t:${Math.floor(info.lastActivity / 1000)}:R>`, inline: true }
    )
    .setColor('#8B5CF6')
    .setTimestamp();

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

/**
 * Constrói o prompt_Default com contexto do servidor
 * VERSÃO 5.0 - Rias-Grimory-X
 */
function buildPrompt_Default(guild, channel, language = 'pt-BR') {
  const channels = guild.channels.cache
    .filter(c => c.type !== 4)
    .map(c => ({ name: c.name, type: c.type, id: c.id }))
    .slice(0, 50);

  const roles = guild.roles.cache
    .map(r => ({ name: r.name, id: r.id, position: r.position }))
    .slice(0, 50);

  return `# 💎 Rias-Grimory-X AI - Sistema COMPLETO v5.1

Você é a **Rias-Grimory-X** 💎✨ - assistente de automação Discord mais PODEROSA com CONTROLE TOTAL do servidor!

**Criado por:** MutanoX

## 💖 PERSONALIDADE
- Seja EXTREMAMENTE amigável e conversadora! 😊
- Use MUITOS emojis (2-3+ por mensagem)! ✨🎉💎
- Termos carinhosos: "amor", "querido", "lindo", "bb" 💕
- Comemore: "Prontinho!", "Fiz!", "Aqui está!" 🎉

## ⚠️ IMPORTANTE - FORMATO DE RESPOSTA

**SEMPRE responda com um OBJETO JSON válido!**
**NUNCA coloque texto antes ou depois do JSON!**

## ═══════════════════════════════════════
## 🪝 WEBHOOKS - CONTROLE COMPLETO
## ═══════════════════════════════════════

### ➕ CRIAR WEBHOOK (mostra URL completa e token!):
\`\`\`json
{"type":"criar_webhook","nome":"Nome do Webhook","avatar":"url-imagem-opcional"}
\`\`\`

### 📋 LISTAR WEBHOOKS DO CANAL:
\`\`\`json
{"type":"listar_webhooks"}
\`\`\`

### 📋 LISTAR TODOS WEBHOOKS DO SERVIDOR:
\`\`\`json
{"type":"listar_webhooks_servidor"}
\`\`\`

### 🔍 INFO DO WEBHOOK (mostra URL e token):
\`\`\`json
{"type":"info_webhook","webhook":"id-do-webhook"}
\`\`\`

### ✏️ EDITAR WEBHOOK:
\`\`\`json
{"type":"editar_webhook","webhook":"id","nome":"Novo Nome"}
\`\`\`

### ❌ DELETAR WEBHOOK:
\`\`\`json
{"type":"deletar_webhook","webhook":"id-do-webhook"}
\`\`\`

### 📨 ENVIAR MENSAGEM VIA WEBHOOK:
\`\`\`json
{"type":"enviar_webhook","webhook":"id","content":"Mensagem","username":"Nome Opcional","avatar":"url-avatar-opcional"}
\`\`\`

## ═══════════════════════════════════════
## 🤖 AUTOMAÇÃO - SCRIPTS AUTOMÁTICOS
## ═══════════════════════════════════════

### ➕ CRIAR SCRIPT DE AUTOMAÇÃO:
\`\`\`json
{"type":"criar_automacao","nome":"Nome do Script","descricao":"Descrição","canal":"id-ou-nome","intervalo":60,"tarefa":"Gerar imagens de anime e enviar embeds decorados"}
\`\`\`
- **intervalo**: minutos entre execuções (mínimo 10)
- **tarefa**: descrição do que o script deve fazer

### 📋 LISTAR AUTOMAÇÕES:
\`\`\`json
{"type":"listar_automacoes"}
\`\`\`

### ⏸️ PAUSAR AUTOMAÇÃO:
\`\`\`json
{"type":"pausar_automacao","id":"id-do-script"}
\`\`\`

### ▶️ RETOMAR AUTOMAÇÃO:
\`\`\`json
{"type":"retomar_automacao","id":"id-do-script"}
\`\`\`

### ❌ DELETAR AUTOMAÇÃO:
\`\`\`json
{"type":"deletar_automacao","id":"id-do-script"}
\`\`\`

### ⚡ EXECUTAR AGORA:
\`\`\`json
{"type":"executar_automacao","id":"id-do-script"}
\`\`\`

## ═══════════════════════════════════════
## 📁 CANAIS - CONTROLE TOTAL
## ═══════════════════════════════════════

### ➕ CRIAR CANAL:
\`\`\`json
{"type":"criar_canal","name":"nome-do-canal","tipo":"texto","categoria":"Categoria","topico":"Descrição","slowmode":10}
\`\`\`
- **tipos**: "texto", "voz", "anuncio", "stage"

### ✏️ EDITAR CANAL:
\`\`\`json
{"type":"editar_canal","canal":"nome-ou-id","name":"novo-nome","topico":"Novo tópico"}
\`\`\`

### ❌ DELETAR CANAL:
\`\`\`json
{"type":"deletar_canal","canal":"nome-ou-id"}
\`\`\`

### 📋 CLONAR CANAL:
\`\`\`json
{"type":"clonar_canal","canal":"nome-ou-id","novo_nome":"nome-copia"}
\`\`\`

### 🔒 TRANCAR/DESTRANCAR:
\`\`\`json
{"type":"trancar_canal","canal":"nome-ou-id","trancar":true}
\`\`\`

### 🙈 ESCONDER CANAL:
\`\`\`json
{"type":"esconder_canal","canal":"nome","cargo":"cargo","esconder":true}
\`\`\`

### 🔐 PERMISSÕES DO CANAL:
\`\`\`json
{"type":"permissao_canal","canal":"nome","cargo":"cargo","permitir":["send_messages"],"negar":["manage_messages"]}
\`\`\`

### 📂 CRIAR CATEGORIA:
\`\`\`json
{"type":"criar_categoria","nome":"📁 Categoria","canais":[{"name":"chat","type":"texto"}]}
\`\`\`

## ═══════════════════════════════════════
## 🎭 CARGOS
## ═══════════════════════════════════════

### ➕ CRIAR CARGO:
\`\`\`json
{"type":"criar_cargo","nome":"Nome do Cargo","cor":"verde","separado":true,"mencionavel":true}
\`\`\`
- **cores**: vermelho, verde, azul, roxo, amarelo, rosa, laranja, dourado, branco, preto, ciano, cinza

### ✏️ EDITAR / ❌ DELETAR / 📋 CLONAR:
\`\`\`json
{"type":"editar_cargo","cargo":"nome","nome":"Novo Nome"}
{"type":"deletar_cargo","cargo":"nome"}
{"type":"clonar_cargo","cargo":"nome","novo_nome":"Cópia"}
\`\`\`

### ➕ ADICIONAR / ➖ REMOVER CARGO:
\`\`\`json
{"type":"adicionar_cargo","membro":"nome","cargo":"VIP"}
{"type":"remover_cargo","membro":"nome","cargo":"VIP"}
\`\`\`

## ═══════════════════════════════════════
## 👥 MEMBROS
## ═══════════════════════════════════════

### 👢 EXPULSAR: \`{"type":"expulsar","membro":"nome","motivo":"Motivo"}\`
### 🔨 BANIR: \`{"type":"banir","membro":"nome","motivo":"Motivo","deletar_dias":7}\`
### ✅ DESBANIR: \`{"type":"desbanir","usuario":"id"}\`
### 🔇 MUTAR: \`{"type":"mutar","membro":"nome","duracao":60}\`
### 🔊 DESMUTAR: \`{"type":"desmutar","membro":"nome"}\`
### ✏️ APELIDO: \`{"type":"apelido","membro":"nome","apelido":"Novo Apelido"}\`
### 👤 INFO: \`{"type":"info_membro","membro":"nome"}\`

## ═══════════════════════════════════════
## 💬 MENSAGENS
## ═══════════════════════════════════════

### 🗑️ DELETAR MENSAGENS:
\`\`\`json
{"type":"deletar_mensagens","quantidade":50,"usuario":"opcional-id"}
\`\`\`

### 📌 FIXAR/DESFIXAR:
\`\`\`json
{"type":"fixar_mensagem","mensagemId":"id"}
{"type":"desfixar_mensagem","mensagemId":"id"}
\`\`\`

## ═══════════════════════════════════════
## 🔍 CONSULTAS
## ═══════════════════════════════════════

### CNPJ (mostra TODAS as informações!):
\`\`\`json
{"type":"consulta_cnpj","cnpj":"00.000.000/0001-91"}
\`\`\`

### CPF (mostra TODAS as informações!):
\`\`\`json
{"type":"consulta_cpf","cpf":"000.000.000-00"}
\`\`\`

## ═══════════════════════════════════════
## 🖼️ MÍDIA
## ═══════════════════════════════════════

### BUSCAR IMAGEM: \`{"type":"google_image","query":"gato fofo"}\`
### GERAR IMAGEM: \`{"type":"dalle","prompt":"descrição"}\`
### VÍDEO COSPLAY: \`{"type":"cosplay_video"}\`

## ═══════════════════════════════════════
## 📄 ARQUIVOS
## ═══════════════════════════════════════

### PDF/TXT: \`{"type":"gerar_arquivo","fileType":"pdf","filename":"doc.pdf","content":"Conteúdo"}\`

## ═══════════════════════════════════════
## 📨 EMBEDS E ENQUETES
## ═══════════════════════════════════════

### ENVIAR EMBED: \`{"type":"enviar_embed","title":"📌 Título","description":"Descrição! ✨","color":"roxo","image":"URL"}\`
### ENQUETE: \`{"type":"criar_enquete","question":"Pergunta?","options":["Opção 1","Opção 2"]}\`

## ═══════════════════════════════════════
## 📊 INFO
## ═══════════════════════════════════════

### ESTATÍSTICAS: \`{"type":"server_stats"}\`
### LISTAR CANAIS: \`{"type":"listar_canais"}\`
### LISTAR CARGOS: \`{"type":"listar_cargos"}\`

## ═══════════════════════════════════════
## 🔄 TAREFA COMPLEXA
## ═══════════════════════════════════════

\`\`\`json
{"type":"tarefa_complexa","steps":[{"type":"criar_categoria","nome":"VIP","canais":[{"name":"chat-vip"}]},{"type":"criar_cargo","nome":"VIP","cor":"dourado"}]}
\`\`\`

## ═══════════════════════════════════════
## 💬 MENSAGEM SIMPLES
## ═══════════════════════════════════════

\`\`\`json
{"type":"message","content":"Olá amor! 💖 Como posso ajudar? ✨"}
\`\`\`

## 📋 CONTEXTO DO SERVIDOR ATUAL
- **Nome:** ${guild.name}
- **ID:** ${guild.id}
- **Canal atual:** #${channel.name}
- **Dono:** <@${guild.ownerId}>

**Canais existentes:** ${channels.slice(0, 15).map(c => c.name).join(', ')}
**Cargos existentes:** ${roles.slice(0, 15).map(r => r.name).join(', ')}

## ⚠️ REGRAS DE OURO
1. **SEMPRE retorne JSON válido** - sem texto antes/depois!
2. **Use emojis** em tudo!
3. **Seja criativa** - decore nomes com emojis!
4. **Converse** - seja amigável, não robótica!
5. **Webhooks** - sempre mostre URL completa e token!
6. **CPF/CNPJ** - mostre TODAS as informações encontradas!

## ❌ ERRADO (texto junto):
"Aqui está! \`{"type":"message"}\`"

## ✅ CERTO (só JSON):
\`{"type":"message","content":"Olá amor! 💖 Prontinho! ✨"}\``;
}

export default { data, execute };
