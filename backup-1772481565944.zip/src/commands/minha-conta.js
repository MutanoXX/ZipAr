/**
 * Rias-Grimory-X - Comando /minha-conta
 * Mostra informações da conta do usuário
 *
 * @version 1.0.0
 * @author MutanoX
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags
} from 'discord.js';
import accountManager from '../utils/accountManager.js';

export const data = new SlashCommandBuilder()
  .setName('minha-conta')
  .setDescription('👤 Visualize informações sobre sua conta e plano');

export async function execute(interaction) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  try {
    const userId = interaction.user.id;
    const username = interaction.user.username;

    // Obter ou criar conta
    const account = accountManager.getOrCreateAccount(userId, username);

    // Verificar se está vinculado
    const linkedInfo = accountManager.isLinked(userId);

    // Obter informações do plano
    const planInfo = accountManager.getPlanTimeRemaining(userId);

    // Criar embed
    const embed = new EmbedBuilder()
      .setTitle(`👤 Minha Conta - ${username}`)
      .setColor('#8B5CF6')
      .setThumbnail(interaction.user.displayAvatarURL())
      .addFields(
        {
          name: '💰 Saldo Disponível',
          value: `R$ ${account.balance.toFixed(2)}`,
          inline: true
        },
        {
          name: '📅 Plano Ativo',
          value: account.planType 
            ? (account.planType === 'semanal' ? '📅 Semanal (7 dias)' : '📅 Mensal (30 dias)')
            : '❌ Nenhum plano',
          inline: true
        }
      );

    // Adicionar informações do plano
    if (planInfo.valid && !planInfo.isOwner) {
      embed.addFields({
        name: '⏰ Tempo Restante',
        value: planInfo.formatted,
        inline: true
      });

      if (planInfo.expiresAt) {
        embed.addFields({
          name: '📆 Expira em',
          value: new Date(planInfo.expiresAt).toLocaleString('pt-BR'),
          inline: true
        });
      }

      embed.addFields({
        name: '🔄 Renovação Automática',
        value: account.autoRenew ? '✅ Ativada' : '❌ Desativada',
        inline: true
      });
    } else if (planInfo.isOwner) {
      embed.addFields({
        name: '👑 Status',
        value: 'Dono do Bot - Acesso Permanente',
        inline: true
      });
    } else {
      embed.addFields({
        name: '⚠️ Aviso',
        value: '❌ Seu plano expirou! Use `/renov` para renovar.',
        inline: false
      });
    }

    // Adicionar informações de vinculação
    if (linkedInfo.isLinked) {
      embed.addFields({
        name: '🔗 Status de Vinculação',
        value: `Você está vinculado a uma conta principal.\nUse \`/desvincar\` para se desvinolar e criar sua própria conta.`,
        inline: false
      });
    } else {
      const linkedUsers = accountManager.getLinkedUsers(userId);
      if (linkedUsers.length > 0) {
        embed.addFields({
          name: '🔗 Usuários Vinculados',
          value: `**Total:** ${linkedUsers.length}/${accountManager.MAX_LINKED_USERS}\n${linkedUsers.map(id => `<@${id}>`).join('\n')}`,
          inline: false
        });
      }
    }

    // Adicionar informações de conta
    const createdDate = new Date(account.createdAt).toLocaleString('pt-BR');
    embed.addFields({
      name: '📋 Informações da Conta',
      value: `**Criada em:** ${createdDate}\n**ID:** ${userId}`,
      inline: false
    });

    // Botões de ação
    const buttons = [];

    if (!account.activePlan || !planInfo.valid) {
      buttons.push(
        new ButtonBuilder()
          .setCustomId('open_renov')
          .setLabel('💳 Renovar Plano')
          .setStyle(ButtonStyle.Primary)
      );
    }

    buttons.push(
      new ButtonBuilder()
        .setCustomId('open_adicionar_saldo')
        .setLabel('➕ Adicionar Saldo')
        .setStyle(ButtonStyle.Success)
    );

    if (!linkedInfo.isLinked && linkedUsers.length < accountManager.MAX_LINKED_USERS) {
      buttons.push(
        new ButtonBuilder()
          .setCustomId('open_vincular')
          .setLabel('🔗 Vincular Usuário')
          .setStyle(ButtonStyle.Secondary)
      );
    }

    let actionRow = null;
    if (buttons.length > 0) {
      // Discord permite máximo 5 botões por linha
      const firstRow = buttons.slice(0, 5);
      const secondRow = buttons.slice(5, 10);

      actionRow = [new ActionRowBuilder().addComponents(firstRow)];
      if (secondRow.length > 0) {
        actionRow.push(new ActionRowBuilder().addComponents(secondRow));
      }
    }

    if (actionRow) {
      await interaction.editReply({ embeds: [embed], components: actionRow });
    } else {
      await interaction.editReply({ embeds: [embed] });
    }

  } catch (error) {
    console.error('❌ Erro no comando /minha-conta:', error.message);

    const errorEmbed = new EmbedBuilder()
      .setTitle('❌ Erro ao carregar conta')
      .setDescription('Ocorreu um erro ao carregar suas informações. Tente novamente mais tarde.')
      .setColor('#EF4444');

    await interaction.editReply({ embeds: [errorEmbed] });
  }
}

export default { data, execute };
