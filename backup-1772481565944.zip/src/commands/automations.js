/**
 * RIAS GREMORY X AI - Comando /automations
 * Gerenciamento de Automações Event-Driven
 * 
 * @version 1.0.0
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ChannelType,
  PermissionFlagsBits
} from 'discord.js';
import {
  createEventAutomation,
  listEventAutomations,
  deleteEventAutomation,
  toggleEventAutomation,
  getEventAutomation,
  getEventAutomationStats,
  TRIGGER_TYPES,
  ACTION_TYPES,
  AUTOMATION_TEMPLATES
} from '../utils/eventAutomationEngine.js';

export const data = new SlashCommandBuilder()
  .setName('automations')
  .setDescription('🎯 Gerencie automações baseadas em eventos')
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .addSubcommand(sub =>
    sub.setName('listar')
      .setDescription('📋 Lista todas as automações do servidor')
  )
  .addSubcommand(sub =>
    sub.setName('templates')
      .setDescription('📚 Ver templates de automações prontos')
  )
  .addSubcommand(sub =>
    sub.setName('criar')
      .setDescription('➕ Criar nova automação')
      .addStringOption(opt =>
        opt.setName('template')
          .setDescription('Template pré-definido para usar')
          .setRequired(false)
          .addChoices(
            { name: '🛡️ Anti-Spam', value: 'antiSpam' },
            { name: '👋 Boas-vindas', value: 'welcomeMessage' },
            { name: '🚪 Despedida', value: 'farewellMessage' },
            { name: '💎 Recompensa Boost', value: 'boosterReward' },
            { name: '🎭 Reaction Role', value: 'reactionRole' },
            { name: '📋 Log Edições', value: 'logEdit' },
            { name: '🗑️ Log Deleções', value: 'logDelete' },
            { name: '📢 Canal Restrito', value: 'announcementOnly' },
            { name: '🔇 Mute Automático', value: 'autoMute' }
          )
      )
      .addChannelOption(opt =>
        opt.setName('canal')
          .setDescription('Canal para a automação')
          .setRequired(false)
      )
      .addRoleOption(opt =>
        opt.setName('cargo')
          .setDescription('Cargo para a automação')
          .setRequired(false)
      )
  )
  .addSubcommand(sub =>
    sub.setName('toggle')
      .setDescription('⏯️ Ativar/Desativar uma automação')
      .addStringOption(opt =>
        opt.setName('id')
          .setDescription('ID da automação')
          .setRequired(true)
          .setAutocomplete(true)
      )
  )
  .addSubcommand(sub =>
    sub.setName('deletar')
      .setDescription('🗑️ Deletar uma automação')
      .addStringOption(opt =>
        opt.setName('id')
          .setDescription('ID da automação')
          .setRequired(true)
          .setAutocomplete(true)
      )
  )
  .addSubcommand(sub =>
    sub.setName('info')
      .setDescription('ℹ️ Ver detalhes de uma automação')
      .addStringOption(opt =>
        opt.setName('id')
          .setDescription('ID da automação')
          .setRequired(true)
          .setAutocomplete(true)
      )
  )
  .addSubcommand(sub =>
    sub.setName('stats')
      .setDescription('📊 Ver estatísticas das automações')
  );

export async function execute(interaction, client) {
  const subcommand = interaction.options.getSubcommand();
  const guildId = interaction.guild.id;

  try {
    switch (subcommand) {
      case 'listar':
        await handleList(interaction, guildId);
        break;
      case 'templates':
        await handleTemplates(interaction);
        break;
      case 'criar':
        await handleCreate(interaction, guildId, client);
        break;
      case 'toggle':
        await handleToggle(interaction, guildId);
        break;
      case 'deletar':
        await handleDelete(interaction, guildId);
        break;
      case 'info':
        await handleInfo(interaction, guildId);
        break;
      case 'stats':
        await handleStats(interaction, guildId);
        break;
    }
  } catch (error) {
    console.error('❌ [Automations] Erro:', error);
    
    const errorEmbed = new EmbedBuilder()
      .setTitle('❌ Erro')
      .setDescription(`Falha ao executar comando: ${error.message}`)
      .setColor('#EF4444')
      .setTimestamp();
    
    if (interaction.replied || interaction.deferred) {
      await interaction.editReply({ embeds: [errorEmbed] });
    } else {
      await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
    }
  }
}

/**
 * Lista todas as automações
 */
async function handleList(interaction, guildId) {
  await interaction.deferReply();
  
  const automations = listEventAutomations(guildId);
  
  if (automations.length === 0) {
    const emptyEmbed = new EmbedBuilder()
      .setTitle('📋 Automações do Servidor')
      .setDescription('Nenhuma automação configurada.\n\nUse `/automations templates` para ver exemplos prontos!')
      .setColor('#F59E0B')
      .setTimestamp();
    
    return await interaction.editReply({ embeds: [emptyEmbed] });
  }
  
  const embed = new EmbedBuilder()
    .setTitle('📋 Automações do Servidor')
    .setDescription(`Total: **${automations.length}** automação(ões)`)
    .setColor('#8B5CF6')
    .setTimestamp();
  
  // Agrupar por status
  const active = automations.filter(a => a.enabled);
  const inactive = automations.filter(a => !a.enabled);
  
  if (active.length > 0) {
    const activeList = active.map(a => 
      `**${a.name}**\n└ Trigger: ${TRIGGER_TYPES[a.trigger]?.name || a.trigger}\n└ Status: ✅ Ativa\n└ Execuções: ${a.triggerCount}`
    ).join('\n\n');
    
    embed.addFields({ name: `✅ Ativas (${active.length})`, value: activeList.substring(0, 1024), inline: false });
  }
  
  if (inactive.length > 0) {
    const inactiveList = inactive.map(a => 
      `**${a.name}**\n└ Trigger: ${TRIGGER_TYPES[a.trigger]?.name || a.trigger}\n└ Status: ⏸️ Pausada`
    ).join('\n\n');
    
    embed.addFields({ name: `⏸️ Pausadas (${inactive.length})`, value: inactiveList.substring(0, 1024), inline: false });
  }
  
  embed.setFooter({ text: '💡 Use /automations info [id] para ver detalhes' });
  
  await interaction.editReply({ embeds: [embed] });
}

/**
 * Mostra templates disponíveis
 */
async function handleTemplates(interaction) {
  await interaction.deferReply();
  
  const embed = new EmbedBuilder()
    .setTitle('📚 Templates de Automações')
    .setDescription('Aqui estão os templates prontos para usar:')
    .setColor('#8B5CF6')
    .setTimestamp();
  
  const templates = [
    {
      name: '🛡️ Anti-Spam',
      value: 'Deleta mensagens com links/spam e avisa o usuário por DM',
      template: 'antiSpam'
    },
    {
      name: '👋 Boas-vindas',
      value: 'Envia mensagem de boas-vindas quando alguém entra no servidor',
      template: 'welcomeMessage'
    },
    {
      name: '🚪 Despedida',
      value: 'Envia mensagem quando alguém sai do servidor',
      template: 'farewellMessage'
    },
    {
      name: '💎 Recompensa Boost',
      value: 'Dá cargo especial quando alguém dá boost no servidor',
      template: 'boosterReward'
    },
    {
      name: '🎭 Reaction Role',
      value: 'Dá cargo quando alguém reage a uma mensagem específica',
      template: 'reactionRole'
    },
    {
      name: '📋 Log Edições',
      value: 'Registra mensagens editadas em canal de logs',
      template: 'logEdit'
    },
    {
      name: '🗑️ Log Deleções',
      value: 'Registra mensagens deletadas em canal de logs',
      template: 'logDelete'
    },
    {
      name: '📢 Canal Restrito',
      value: 'Deleta mensagens de não-admins em canal de avisos',
      template: 'announcementOnly'
    },
    {
      name: '🔇 Mute Automático',
      value: 'Muta usuários automaticamente por flood/spam',
      template: 'autoMute'
    }
  ];
  
  templates.forEach(t => {
    embed.addFields({
      name: t.name,
      value: t.value,
      inline: false
    });
  });
  
  embed.setFooter({ text: '💡 Use /automations criar template:[nome] para criar' });
  
  await interaction.editReply({ embeds: [embed] });
}

/**
 * Cria nova automação
 */
async function handleCreate(interaction, guildId, client) {
  await interaction.deferReply();
  
  const templateKey = interaction.options.getString('template');
  const channel = interaction.options.getChannel('canal');
  const role = interaction.options.getRole('cargo');
  
  if (!templateKey) {
    // Mostrar menu de criação
    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('automation_select_template')
      .setPlaceholder('Selecione um template...')
      .addOptions(
        { label: '🛡️ Anti-Spam', value: 'antiSpam', description: 'Deleta mensagens com links/spam' },
        { label: '👋 Boas-vindas', value: 'welcomeMessage', description: 'Mensagem de boas-vindas automática' },
        { label: '🚪 Despedida', value: 'farewellMessage', description: 'Mensagem de despedida automática' },
        { label: '💎 Recompensa Boost', value: 'boosterReward', description: 'Cargo para quem dá boost' },
        { label: '🎭 Reaction Role', value: 'reactionRole', description: 'Cargo por reação' },
        { label: '📋 Log Edições', value: 'logEdit', description: 'Log de mensagens editadas' },
        { label: '🗑️ Log Deleções', value: 'logDelete', description: 'Log de mensagens deletadas' }
      );
    
    const row = new ActionRowBuilder().addComponents(selectMenu);
    
    const embed = new EmbedBuilder()
      .setTitle('➕ Criar Automação')
      .setDescription('Selecione um template para criar sua automação:')
      .setColor('#8B5CF6')
      .setTimestamp();
    
    return await interaction.editReply({ embeds: [embed], components: [row] });
  }
  
  // Criar a partir do template
  const template = AUTOMATION_TEMPLATES[templateKey];
  
  if (!template) {
    return await interaction.editReply({
      content: '❌ Template não encontrado!'
    });
  }
  
  // Aplicar configurações personalizadas
  const config = {
    ...template,
    createdBy: interaction.user.id
  };
  
  // Substituir placeholders de canal/cargo se fornecidos
  if (channel) {
    config.triggerConfig = config.triggerConfig || {};
    if (template.trigger === 'message_in_channel') {
      config.triggerConfig.channelId = channel.id;
    }
    if (config.actions) {
      config.actions = config.actions.map(action => {
        if (action.channelId === 'CANAL_BOAS_VINDAS_ID' || 
            action.channelId === 'CANAL_SAIDA_ID' || 
            action.channelId === 'CANAL_AVISOS_ID' ||
            action.channelId === 'CANAL_LOGS_ID') {
          return { ...action, channelId: channel.id };
        }
        if (action.logChannelId === 'CANAL_LOGS_ID') {
          return { ...action, logChannelId: channel.id };
        }
        return action;
      });
    }
  }
  
  if (role) {
    config.actions = config.actions?.map(action => {
      if (action.roleId === 'ROLE_ID_AQUI' || 
          action.roleId === 'ROLE_ID' || 
          action.roleId === 'ID_CARGO_BOOSTER' ||
          action.roleId === 'ID_CARGO_MEMBRO') {
        return { ...action, roleId: role.id };
      }
      return action;
    });
  }
  
  const automation = createEventAutomation(guildId, config);
  
  const successEmbed = new EmbedBuilder()
    .setTitle('✅ Automação Criada!')
    .setDescription(`**${automation.name}** foi criada com sucesso!`)
    .addFields(
      { name: '🎯 Trigger', value: TRIGGER_TYPES[automation.trigger]?.name || automation.trigger, inline: true },
      { name: '📊 Status', value: automation.enabled ? '✅ Ativa' : '⏸️ Pausada', inline: true },
      { name: '🆔 ID', value: `\`${automation.id}\``, inline: true }
    )
    .setColor('#10B981')
    .setTimestamp()
    .setFooter({ text: '💡 A automação já está funcionando!' });
  
  await interaction.editReply({ embeds: [successEmbed] });
}

/**
 * Ativa/Desativa uma automação
 */
async function handleToggle(interaction, guildId) {
  await interaction.deferReply();
  
  const automationId = interaction.options.getString('id');
  const automation = toggleEventAutomation(guildId, automationId);
  
  if (!automation) {
    return await interaction.editReply({
      content: '❌ Automação não encontrada!'
    });
  }
  
  const embed = new EmbedBuilder()
    .setTitle(automation.enabled ? '✅ Automação Ativada' : '⏸️ Automação Pausada')
    .setDescription(`**${automation.name}** foi ${automation.enabled ? 'ativada' : 'pausada'}.`)
    .setColor(automation.enabled ? '#10B981' : '#F59E0B')
    .setTimestamp();
  
  await interaction.editReply({ embeds: [embed] });
}

/**
 * Deleta uma automação
 */
async function handleDelete(interaction, guildId) {
  await interaction.deferReply();
  
  const automationId = interaction.options.getString('id');
  
  // Buscar antes de deletar
  const automation = getEventAutomation(guildId, automationId);
  
  if (!automation) {
    return await interaction.editReply({
      content: '❌ Automação não encontrada!'
    });
  }
  
  const name = automation.name;
  deleteEventAutomation(guildId, automationId);
  
  const embed = new EmbedBuilder()
    .setTitle('🗑️ Automação Deletada')
    .setDescription(`**${name}** foi removida permanentemente.`)
    .setColor('#EF4444')
    .setTimestamp();
  
  await interaction.editReply({ embeds: [embed] });
}

/**
 * Mostra detalhes de uma automação
 */
async function handleInfo(interaction, guildId) {
  await interaction.deferReply();
  
  const automationId = interaction.options.getString('id');
  const automation = getEventAutomation(guildId, automationId);
  
  if (!automation) {
    return await interaction.editReply({
      content: '❌ Automação não encontrada!'
    });
  }
  
  const embed = new EmbedBuilder()
    .setTitle(`ℹ️ ${automation.name}`)
    .setDescription(automation.description || 'Sem descrição')
    .addFields(
      { name: '🎯 Trigger', value: TRIGGER_TYPES[automation.trigger]?.name || automation.trigger, inline: true },
      { name: '📊 Status', value: automation.enabled ? '✅ Ativa' : '⏸️ Pausada', inline: true },
      { name: '🔄 Execuções', value: `${automation.triggerCount}`, inline: true },
      { name: '🆔 ID', value: `\`${automation.id}\``, inline: true },
      { name: '📅 Criada em', value: new Date(automation.createdAt).toLocaleDateString('pt-BR'), inline: true },
      { name: '⏰ Última execução', value: automation.lastTriggered ? new Date(automation.lastTriggered).toLocaleString('pt-BR') : 'Nunca', inline: true }
    )
    .setColor(automation.enabled ? '#10B981' : '#F59E0B')
    .setTimestamp();
  
  // Mostrar ações
  if (automation.actions && automation.actions.length > 0) {
    const actionsList = automation.actions.map((a, i) => 
      `${i + 1}. **${ACTION_TYPES[a.type]?.name || a.type}**`
    ).join('\n');
    
    embed.addFields({ name: '⚡ Ações', value: actionsList, inline: false });
  }
  
  await interaction.editReply({ embeds: [embed] });
}

/**
 * Mostra estatísticas
 */
async function handleStats(interaction, guildId) {
  await interaction.deferReply();
  
  const stats = getEventAutomationStats(guildId);
  
  const embed = new EmbedBuilder()
    .setTitle('📊 Estatísticas de Automações')
    .addFields(
      { name: '📋 Total', value: `${stats.total}`, inline: true },
      { name: '✅ Ativas', value: `${stats.enabled}`, inline: true },
      { name: '⏸️ Pausadas', value: `${stats.disabled}`, inline: true },
      { name: '🔄 Execuções Totais', value: `${stats.totalTriggers}`, inline: true }
    )
    .setColor('#8B5CF6')
    .setTimestamp();
  
  await interaction.editReply({ embeds: [embed] });
}

/**
 * Autocomplete para IDs de automações
 */
export async function autocomplete(interaction) {
  const focused = interaction.options.getFocused(true);
  
  if (focused.name === 'id') {
    const automations = listEventAutomations(interaction.guild.id);
    const filtered = automations
      .filter(a => a.name.toLowerCase().includes(focused.value.toLowerCase()) ||
                   a.id.toLowerCase().includes(focused.value.toLowerCase()))
      .slice(0, 25)
      .map(a => ({ name: `${a.name} (${a.id.slice(0, 8)}...)`, value: a.id }));
    
    await interaction.respond(filtered);
  }
}

export default {
  data,
  execute,
  autocomplete
};
