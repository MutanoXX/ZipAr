/**
 * RIAS GREMORY X AI - Comando /support
 * Cria um canal de suporte
 * 
 * @version 3.0.0
 * @author MutanoX
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
  ChannelType,
  PermissionFlagsBits
} from 'discord.js';
import accountManager from '../utils/accountManager.js';

const BOT_OWNER_ID = '1387242867700924568';

export const data = new SlashCommandBuilder()
  .setName('support')
  .setDescription('🎫 Abre um canal de suporte');

export async function execute(interaction) {
  const userId = interaction.user.id;
  const user = interaction.user;
  const guild = interaction.guild;
  const member = interaction.member;

  // Verificar se está em servidor
  if (!guild) {
    return interaction.reply({
      content: '❌ Este comando só pode ser usado em um servidor.',
      flags: MessageFlags.Ephemeral
    });
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  try {
    // Criar categoria de suporte se não existir
    let category = guild.channels.cache.find(
      c => c.type === ChannelType.GuildCategory && c.name.toLowerCase().includes('suporte')
    );

    if (!category) {
      category = await guild.channels.create({
        name: '🎫 │ SUPORTE',
        type: ChannelType.GuildCategory,
        permissionOverwrites: [
          {
            id: guild.roles.everyone.id,
            deny: [PermissionFlagsBits.ViewChannel]
          },
          {
            id: guild.client.user.id,
            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels]
          }
        ]
      });
    }

    // Criar canal de suporte
    const channel = await guild.channels.create({
      name: `suporte-${user.username}`,
      type: ChannelType.GuildText,
      parent: category.id,
      permissionOverwrites: [
        {
          id: guild.roles.everyone.id,
          deny: [PermissionFlagsBits.ViewChannel]
        },
        {
          id: userId,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages]
        },
        {
          id: guild.client.user.id,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels]
        }
      ]
    });

    // Obter informações da conta
    const account = accountManager.getAccount(userId);
    const planTime = accountManager.getPlanTimeRemaining(userId);

    // Embed de boas-vindas
    const welcomeEmbed = new EmbedBuilder()
      .setTitle('🎫 Canal de Suporte')
      .setDescription(`Olá <@${userId}>! Este é seu canal de suporte.`)
      .setColor(planTime.valid ? '#10B981' : '#8B5CF6')
      .addFields(
        { 
          name: '👤 Usuário', 
          value: `${user.tag}\n<@${userId}>`, 
          inline: true 
        },
        { 
          name: '📦 Status', 
          value: planTime.valid ? `✅ Ativo - ${planTime.formatted}` : '🆓 Gratuito', 
          inline: true 
        },
        {
          name: '📋 Como posso ajudar?',
          value: 'Descreva o que você precisa abaixo.',
          inline: false
        }
      )
      .setThumbnail(user.displayAvatarURL({ size: 256 }))
      .setTimestamp()
      .setFooter({ text: '🌹 Rias Gremory X AI' });

    // Botões
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('support_close')
          .setLabel('❌ Fechar Ticket')
          .setStyle(ButtonStyle.Danger)
      );

    await channel.send({
      content: `<@${userId}>`,
      embeds: [welcomeEmbed],
      components: [row]
    });

    // Responder ao usuário
    const replyEmbed = new EmbedBuilder()
      .setTitle('✅ Canal de Suporte Criado!')
      .setDescription(`Seu canal de suporte foi criado: ${channel}`)
      .setColor('#10B981')
      .setTimestamp();

    await interaction.editReply({ embeds: [replyEmbed] });

    console.log(`🎫 [Support] Canal criado para ${user.tag} (${userId}) em ${guild.name}`);

  } catch (error) {
    console.error('❌ [Support] Erro:', error);
    await interaction.editReply({
      content: `❌ Erro ao criar canal de suporte: ${error.message}\n\nVerifique se o bot tem permissão para criar canais.`
    });
  }
}

/**
 * Handler para botões do suporte
 */
export async function handleSupportButton(interaction) {
  const customId = interaction.customId;
  const channel = interaction.channel;

  if (customId === 'support_close') {
    await interaction.reply({
      content: '🔒 Fechando ticket em 5 segundos...'
    });

    setTimeout(async () => {
      try {
        await channel.delete('Ticket fechado pelo usuário');
      } catch (error) {
        console.error('Erro ao fechar ticket:', error.message);
      }
    }, 5000);
  }
}

export default { data, execute, handleSupportButton };
