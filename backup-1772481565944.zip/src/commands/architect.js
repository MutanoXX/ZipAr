/**
 * RIAS GREMORY X AI - Comando /architect
 * Sistema de criação de servidores com menus interativos
 * 
 * @version 3.0.0
 * @author MutanoX
 * 
 * Features:
 * - Menu principal com botões interativos
 * - Preview antes de executar
 * - Sistema de uso limitado (3 grátis, 1 por servidor)
 * - Webhooks automáticos para logs
 * - Canal Updates-Rias obrigatório
 * - DM com resumo após criação
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
  ChannelType,
  PermissionsBitField
} from 'discord.js';
import aiService from '../services/aiService.js';
import { applyPlan } from '../utils/serverManager.js';
import { isAuthorized, isBotOwner } from '../utils/permissions.js';
import { 
  incrementServerUsage, 
  canUseServer, 
  savePlan, 
  getPlan,
  registerServer,
  registerWebhook,
  getGuildWebhook
} from '../utils/storageManager.js';
import accountManager from '../utils/accountManager.js';

// Templates pré-definidos
const TEMPLATES = {
  gaming: {
    name: '🎮 Gaming',
    description: 'Servidor para comunidade de games',
    goal: 'Um servidor de games com canais para diferentes jogos, vento de voz e sistema de roles'
  },
  loja: {
    name: '🏪 Loja/E-commerce',
    description: 'Servidor para vendas e atendimento',
    goal: 'Um servidor de loja com categorias de produtos, suporte, pedidos e pagamentos'
  },
  comunidade: {
    name: '👥 Comunidade',
    description: 'Servidor para comunidade geral',
    goal: 'Um servidor de comunidade com áreas de chat, eventos, mídia e interação'
  },
  roleplay: {
    name: '🎭 Roleplay',
    description: 'Servidor para RP',
    goal: 'Um servidor de roleplay com sistema de fichas, cidades, profissões e economia'
  },
  musica: {
    name: '🎵 Música',
    description: 'Servidor para amantes de música',
    goal: 'Um servidor de música com canais de compartilhamento, colaboração e eventos'
  },
  educacao: {
    name: '📚 Educação',
    description: 'Servidor educacional',
    goal: 'Um servidor educacional com áreas de estudo, materiais, dúvidas e aulas'
  },
  empresarial: {
    name: '💼 Empresarial',
    description: 'Servidor para empresas',
    goal: 'Um servidor empresarial com departamentos, reuniões, projetos e documentos'
  },
  criativo: {
    name: '🎨 Criativo/Arte',
    description: 'Servidor para artistas',
    goal: 'Um servidor de arte com galerias, tutoriais, colaborações e portfólio'
  }
};

export const data = new SlashCommandBuilder()
  .setName('architect')
  .setDescription('🏗️ Crie e estruture seu servidor com IA');

export async function execute(interaction) {
  // Verificar permissão
  if (!isAuthorized(interaction.user.id)) {
    return interaction.reply({
      content: '❌ Você não tem permissão para usar este comando.',
      flags: MessageFlags.Ephemeral
    });
  }

  // Mostrar menu principal
  await showMainMenu(interaction);
}

/**
 * Mostra o menu principal com botões
 */
async function showMainMenu(interaction) {
  const userId = interaction.user.id;
  const guildId = interaction.guild.id;
  const isPremium = accountManager.hasActivePlan(userId) || isBotOwner(userId);

  // Verificar uso disponível
  const usageCheck = canUseServer(guildId, userId, isPremium);

  // Embed principal
  const embed = new EmbedBuilder()
    .setTitle('🏗️ Rias Architect - Criador de Servidores')
    .setDescription(`Olá, meu bem! 🌹✨

Sou a **Rias Gremory**, sua arquiteta de servidores! Vou te ajudar a criar a estrutura perfeita para seu servidor.

**💎 Seu Status:**
${isPremium ? '👑 **Premium** - Usos ilimitados!' : `🆓 **Gratuito** - ${usageCheck.usesLeft} uso(s) restante(s) neste servidor`}

**📌 Como funciona:**
1. Escolha uma opção abaixo
2. Personalize conforme sua necessidade
3. Confirme e veja a mágica acontecer! ✨`)
    .setColor('#8B5CF6')
    .setThumbnail(interaction.client.user.displayAvatarURL({ size: 256 }))
    .addFields(
      { 
        name: '🆕 Criar Novo Servidor', 
        value: 'Estrutura completa do zero com categorias, canais e cargos', 
        inline: true 
      },
      { 
        name: '📋 Templates Rápidos', 
        value: 'Modelos prontos para diferentes tipos de servidor', 
        inline: true 
      },
      { 
        name: '📊 Ver Uso', 
        value: 'Consulte seus usos restantes', 
        inline: true 
      }
    )
    .setFooter({ text: 'Rias Gremory Architect v3.0 | Sistema Multi-Agente' })
    .setTimestamp();

  // Linha 1 - Botões principais
  const row1 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('arch_create_new')
        .setLabel('🆕 Criar Servidor')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('arch_templates')
        .setLabel('📋 Templates')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('arch_usage')
        .setLabel('📊 Ver Uso')
        .setStyle(ButtonStyle.Secondary)
    );

  // Linha 2 - Ações extras (apenas premium)
  const row2 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('arch_restructure')
        .setLabel('🔄 Reestruturar')
        .setStyle(ButtonStyle.Success)
        .setDisabled(!isPremium),
      new ButtonBuilder()
        .setCustomId('arch_load_plan')
        .setLabel('📂 Carregar Plano')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(!getPlan(guildId))
    );

  // Se for reply de interação
  if (interaction.replied || interaction.deferred) {
    await interaction.editReply({
      embeds: [embed],
      components: [row1, row2]
    });
  } else {
    await interaction.reply({
      embeds: [embed],
      components: [row1, row2],
      flags: MessageFlags.Ephemeral
    });
  }
}

/**
 * Handler para interações de botão do architect
 */
export async function handleArchitectButton(interaction) {
  const customId = interaction.customId;
  const userId = interaction.user.id;
  const guildId = interaction.guild.id;
  const isPremium = accountManager.hasActivePlan(userId) || isBotOwner(userId);

  switch (customId) {
    case 'arch_create_new':
      await showCreateMenu(interaction, isPremium);
      break;
    case 'arch_templates':
      await showTemplatesMenu(interaction, isPremium);
      break;
    case 'arch_usage':
      await showUsageInfo(interaction, guildId, userId, isPremium);
      break;
    case 'arch_restructure':
      await showRestructureMenu(interaction, isPremium);
      break;
    case 'arch_load_plan':
      await loadSavedPlan(interaction, guildId);
      break;
    default:
      if (customId.startsWith('arch_template_')) {
        const templateKey = customId.replace('arch_template_', '');
        await handleTemplateSelect(interaction, templateKey, isPremium);
      } else if (customId.startsWith('arch_confirm_')) {
        const planId = customId.replace('arch_confirm_', '');
        await confirmAndExecute(interaction, planId, isPremium);
      }
  }
}

/**
 * Mostra menu de criação
 */
async function showCreateMenu(interaction, isPremium) {
  const embed = new EmbedBuilder()
    .setTitle('🆕 Criar Novo Servidor')
    .setDescription(`Perfeito, meu bem! 🌹✨

Vou criar uma estrutura completa para seu servidor!

**Informe:**
- O objetivo do servidor
- Que tipo de estrutura você precisa
- Preferências de estilo

Seja detalhado para que eu possa criar algo incrível!`)
    .setColor('#8B5CF6')
    .addFields(
      { name: '💡 Dica', value: 'Descreva o propósito do servidor. Ex: "Uma loja de produtos digitais com suporte, pedidos e pagamentos"' }
    );

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('arch_open_modal_create')
        .setLabel('✍️ Descrever Objetivo')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('arch_back')
        .setLabel('⬅️ Voltar')
        .setStyle(ButtonStyle.Secondary)
    );

  await interaction.update({
    embeds: [embed],
    components: [row]
  });
}

/**
 * Mostra menu de templates
 */
async function showTemplatesMenu(interaction, isPremium) {
  const embed = new EmbedBuilder()
    .setTitle('📋 Templates Rápidos')
    .setDescription(`Escolha um template pré-definido, meu bem! 🌹✨

Cada template cria uma estrutura otimizada para o tipo de servidor.`)
    .setColor('#8B5CF6');

  // Listar templates
  const templateList = Object.entries(TEMPLATES)
    .map(([key, t]) => `**${t.name}** - ${t.description}`)
    .join('\n');
  
  embed.addFields({ name: '📁 Templates Disponíveis:', value: templateList });

  // Criar botões para cada template (máximo 5 por linha)
  const rows = [];
  const templateKeys = Object.keys(TEMPLATES);
  
  for (let i = 0; i < templateKeys.length; i += 5) {
    const row = new ActionRowBuilder();
    const slice = templateKeys.slice(i, i + 5);
    
    slice.forEach(key => {
      const t = TEMPLATES[key];
      row.addComponents(
        new ButtonBuilder()
          .setCustomId(`arch_template_${key}`)
          .setLabel(t.name.substring(0, 20))
          .setStyle(ButtonStyle.Secondary)
      );
    });
    
    rows.push(row);
  }

  // Adicionar botão voltar
  const backRow = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('arch_back')
        .setLabel('⬅️ Voltar')
        .setStyle(ButtonStyle.Secondary)
    );
  rows.push(backRow);

  await interaction.update({
    embeds: [embed],
    components: rows
  });
}

/**
 * Mostra informações de uso
 */
async function showUsageInfo(interaction, guildId, userId, isPremium) {
  const { getServerUsage } = await import('../utils/storageManager.js');
  const usage = getServerUsage(guildId);
  const userUsage = usage.usedByUsers[userId] || { uses: 0 };

  const embed = new EmbedBuilder()
    .setTitle('📊 Seu Uso no Servidor')
    .setColor('#8B5CF6')
    .setTimestamp();

  if (isPremium) {
    embed.setDescription(`👑 **Status: Premium**\n\nVocê tem acesso ilimitado a todos os recursos!`)
      .addFields(
        { name: '💎 Benefícios Premium', value: '• Usos ilimitados\n• Reestruturação de servidores\n• Suporte prioritário\n• Templates exclusivos' }
      );
  } else {
    embed.setDescription(`🆓 **Status: Gratuito**`)
      .addFields(
        { name: '📊 Usos no Servidor', value: `${usage.freeUses}/${usage.maxFreeUses} usados`, inline: true },
        { name: '👤 Seus Usos Aqui', value: `${userUsage.uses}/1 usado`, inline: true },
        { name: '💎 Restantes', value: `${usage.maxFreeUses - usage.freeUses} usos`, inline: true },
        { name: '⬆️ Upgrade para Premium', value: 'Use `/renov` para assinar e ter usos ilimitados!' }
      );
  }

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('arch_back')
        .setLabel('⬅️ Voltar')
        .setStyle(ButtonStyle.Secondary)
    );

  await interaction.update({
    embeds: [embed],
    components: [row]
  });
}

/**
 * Handler para seleção de template
 */
async function handleTemplateSelect(interaction, templateKey, isPremium) {
  const template = TEMPLATES[templateKey];
  
  if (!template) {
    return interaction.update({
      embeds: [new EmbedBuilder().setTitle('❌ Template não encontrado').setColor('#EF4444')],
      components: []
    });
  }

  const guildId = interaction.guild.id;
  const userId = interaction.user.id;

  // Verificar uso
  const usageCheck = canUseServer(guildId, userId, isPremium);
  if (!usageCheck.canUse && !isPremium) {
    const embed = new EmbedBuilder()
      .setTitle('⚠️ Limite Atingido')
      .setDescription(`Você já usou todos os seus usos gratuitos neste servidor!

💎 **Assine o premium** para usos ilimitados!`)
      .setColor('#F59E0B');

    return interaction.update({ embeds: [embed], components: [] });
  }

  // Mostrar preview do template
  const embed = new EmbedBuilder()
    .setTitle(`📋 Template: ${template.name}`)
    .setDescription(`**${template.description}**

🎯 **Objetivo:** ${template.goal}

Deseja criar este template?`)
    .setColor('#8B5CF6')
    .setFooter({ text: isPremium ? '💎 Premium - Uso ilimitado' : `🆓 Gratuito - ${usageCheck.usesLeft} uso(s) restante(s)` });

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId(`arch_confirm_${templateKey}`)
        .setLabel('✅ Criar Template')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('arch_templates')
        .setLabel('⬅️ Outros Templates')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('arch_back')
        .setLabel('🏠 Menu Principal')
        .setStyle(ButtonStyle.Secondary)
    );

  await interaction.update({
    embeds: [embed],
    components: [row]
  });
}

/**
 * Confirma e executa a criação
 */
async function confirmAndExecute(interaction, planKey, isPremium) {
  const guild = interaction.guild;
  const userId = interaction.user.id;
  const guildId = guild.id;

  // Verificar/incrementar uso
  const usageResult = incrementServerUsage(guildId, userId, isPremium);
  
  if (!usageResult.success && !isPremium) {
    const embed = new EmbedBuilder()
      .setTitle('⚠️ Limite Atingido')
      .setDescription(usageResult.message)
      .setColor('#F59E0B');

    return interaction.update({ embeds: [embed], components: [] });
  }

  // Mostrar status de processamento
  await interaction.update({
    embeds: [
      new EmbedBuilder()
        .setTitle('⏳ Criando Estrutura...')
        .setDescription('Estou trabalhando na mágica! ✨\n\nIsso pode levar alguns segundos...')
        .setColor('#8B5CF6')
    ],
    components: []
  });

  try {
    // Obter objetivo
    let goal = 'Um servidor completo e decorado';
    
    if (TEMPLATES[planKey]) {
      goal = TEMPLATES[planKey].goal;
    } else if (planKey === 'custom') {
      // Obter do storage
      const savedPlan = getPlan(guildId);
      if (savedPlan?.customGoal) {
        goal = savedPlan.customGoal;
      }
    }

    // Chamar IA para gerar plano
    const plan = await aiService.analyzeServer({
      guildName: guild.name,
      channels: [],
      roles: [],
      userGoal: goal,
      mode: 'fresh'
    });

    // Aplicar o plano
    const result = await applyEnhancedPlan(guild, plan, userId);

    // Criar embed de sucesso
    const embed = new EmbedBuilder()
      .setTitle('✅ Servidor Criado com Sucesso!')
      .setDescription(`Seu servidor foi estruturado, meu bem! 🌹✨`)
      .setColor('#10B981')
      .addFields(
        { name: '📁 Categorias', value: `${result.categories} criadas`, inline: true },
        { name: '📝 Canais', value: `${result.channels} criados`, inline: true },
        { name: '👥 Cargos', value: `${result.roles} criados`, inline: true }
      )
      .setTimestamp();

    if (result.webhook) {
      embed.addFields({ name: '🔔 Webhooks', value: 'Canal de logs configurado', inline: true });
    }

    if (result.updatesChannel) {
      embed.addFields({ name: '📢 Updates', value: 'Canal de updates criado', inline: true });
    }

    // Adicionar info de uso restante
    if (!isPremium) {
      embed.setFooter({ text: `${usageResult.usesLeft} uso(s) gratuito(s) restante(s)` });
    }

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('arch_back')
          .setLabel('🏠 Menu Principal')
          .setStyle(ButtonStyle.Primary)
      );

    await interaction.editReply({
      embeds: [embed],
      components: [row]
    });

    // Enviar resumo por DM
    await sendDMSummary(interaction.user, guild.name, result);

  } catch (error) {
    console.error('❌ Erro ao criar servidor:', error);

    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Erro ao Criar')
          .setDescription(`Ocorreu um erro: ${error.message}`)
          .setColor('#EF4444')
      ],
      components: []
    });
  }
}

/**
 * Aplica plano com recursos extras (webhooks, updates channel)
 */
async function applyEnhancedPlan(guild, plan, userId) {
  // Aplicar plano básico
  const result = await applyPlan(guild, plan);

  // Criar categoria de logs se não existir
  let logsCategory = guild.channels.cache.find(
    c => c.type === ChannelType.GuildCategory && 
    c.name.toLowerCase().includes('logs')
  );

  if (!logsCategory) {
    logsCategory = await guild.channels.create({
      name: '📊 │ LOGS',
      type: ChannelType.GuildCategory,
      permissionOverwrites: [
        {
          id: guild.roles.everyone.id,
          deny: [PermissionsBitField.Flags.ViewChannel]
        },
        {
          id: guild.client.user.id,
          allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages]
        }
      ]
    });
    result.categories++;
  }

  // Criar canal de logs principal
  let logsChannel = guild.channels.cache.find(
    c => c.parentId === logsCategory?.id && c.name.toLowerCase().includes('registros')
  );

  if (!logsChannel) {
    logsChannel = await guild.channels.create({
      name: '📋・registros',
      type: ChannelType.GuildText,
      parent: logsCategory.id,
      topic: 'Logs do sistema Rias Architect'
    });
    result.channels++;

    // Criar webhook
    try {
      const webhook = await logsChannel.createWebhook({
        name: 'Rias Logs',
        avatar: guild.client.user.displayAvatarURL()
      });

      registerWebhook(guild.id, logsChannel.id, webhook.url, 'logs');
      result.webhook = true;
    } catch (e) {
      console.error('Erro ao criar webhook:', e.message);
    }
  }

  // Criar canal de Updates-Rias
  let updatesCategory = guild.channels.cache.find(
    c => c.type === ChannelType.GuildCategory && 
    c.name.toLowerCase().includes('informações')
  );

  if (!updatesCategory) {
    updatesCategory = await guild.channels.create({
      name: '📢 │ INFORMAÇÕES',
      type: ChannelType.GuildCategory
    });
    result.categories++;
  }

  let updatesChannel = guild.channels.cache.find(
    c => c.parentId === updatesCategory?.id && c.name.toLowerCase().includes('updates')
  );

  if (!updatesChannel) {
    updatesChannel = await guild.channels.create({
      name: '🔔・updates-rias',
      type: ChannelType.GuildText,
      parent: updatesCategory.id,
      topic: 'Updates e novidades da Rias Gremory'
    });
    result.channels++;
    result.updatesChannel = true;

    // Criar webhook para updates
    try {
      const webhook = await updatesChannel.createWebhook({
        name: 'Rias Updates',
        avatar: guild.client.user.displayAvatarURL()
      });

      registerWebhook(guild.id, updatesChannel.id, webhook.url, 'updates');
    } catch (e) {
      console.error('Erro ao criar webhook de updates:', e.message);
    }

    // Enviar mensagem inicial
    await updatesChannel.send({
      embeds: [
        new EmbedBuilder()
          .setTitle('🌹 Rias Gremory - Updates')
          .setDescription('Este canal receberá atualizações e novidades sobre o bot!\n\nO dono do servidor pode pedir para eu enviar updates usando linguagem natural.')
          .setColor('#8B5CF6')
          .setFooter({ text: 'Rias Gremory Architect' })
          .setTimestamp()
      ]
    });
  }

  // Registrar servidor no storage
  registerServer(guild.id, {
    name: guild.name,
    ownerId: guild.ownerId,
    createdAt: Date.now(),
    createdBy: userId,
    hasUpdatesChannel: true,
    hasLogsChannel: true
  });

  return result;
}

/**
 * Envia resumo por DM
 */
async function sendDMSummary(user, guildName, result) {
  try {
    const dmChannel = await user.createDM();

    const embed = new EmbedBuilder()
      .setTitle('🌹 Rias Architect - Resumo')
      .setDescription(`Seu servidor **${guildName}** foi criado com sucesso! ✨`)
      .addFields(
        { name: '📁 Categorias', value: `${result.categories}`, inline: true },
        { name: '📝 Canais', value: `${result.channels}`, inline: true },
        { name: '👥 Cargos', value: `${result.roles}`, inline: true }
      )
      .setColor('#8B5CF6')
      .setFooter({ text: 'Obrigado por usar a Rias Gremory! 💜' })
      .setTimestamp();

    await dmChannel.send({ embeds: [embed] });
  } catch (e) {
    console.error('Erro ao enviar DM:', e.message);
  }
}

/**
 * Carrega plano salvo
 */
async function loadSavedPlan(interaction, guildId) {
  const plan = getPlan(guildId);

  if (!plan) {
    return interaction.update({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Nenhum Plano Salvo')
          .setDescription('Não há planos salvos para este servidor.')
          .setColor('#EF4444')
      ],
      components: []
    });
  }

  // Mostrar plano e botão para aplicar
  const embed = new EmbedBuilder()
    .setTitle('📂 Plano Salvo Encontrado')
    .setDescription(`Encontrei um plano salvo para este servidor!`)
    .setColor('#8B5CF6')
    .addFields(
      { name: '📅 Salvo em', value: new Date(plan.savedAt).toLocaleString('pt-BR'), inline: true }
    )
    .setTimestamp();

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId(`arch_confirm_custom`)
        .setLabel('✅ Aplicar Plano')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('arch_back')
        .setLabel('⬅️ Voltar')
        .setStyle(ButtonStyle.Secondary)
    );

  await interaction.update({
    embeds: [embed],
    components: [row]
  });
}

/**
 * Mostra menu de reestruturação (premium)
 */
async function showRestructureMenu(interaction, isPremium) {
  if (!isPremium) {
    const embed = new EmbedBuilder()
      .setTitle('👑 Recurso Premium')
      .setDescription('A reestruturação de servidores é um recurso exclusivo para assinantes!\n\nUse `/renov` para assinar.')
      .setColor('#F59E0B');

    return interaction.update({ embeds: [embed], components: [] });
  }

  const embed = new EmbedBuilder()
    .setTitle('🔄 Reestruturar Servidor')
    .setDescription(`Perfeito, meu bem premium! 🌹✨

Vou analisar a estrutura atual do servidor e sugerir melhorações mantendo o que já existe.`)
    .setColor('#8B5CF6');

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('arch_open_modal_restructure')
        .setLabel('✍️ Descrever Mudanças')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('arch_back')
        .setLabel('⬅️ Voltar')
        .setStyle(ButtonStyle.Secondary)
    );

  await interaction.update({ embeds: [embed], components: [row] });
}

/**
 * Handler para modals
 */
export async function handleArchitectModal(interaction) {
  const customId = interaction.customId;

  if (customId === 'arch_open_modal_create') {
    const goal = interaction.fields.getTextInputValue('arch_goal');
    
    // Salvar objetivo customizado
    savePlan(interaction.guild.id, { customGoal: goal });
    
    // Mostrar preview
    const embed = new EmbedBuilder()
      .setTitle('🆕 Criar Servidor Personalizado')
      .setDescription(`**Objetivo:** ${goal}

Confira se está correto e confirme para criar!`)
      .setColor('#8B5CF6');

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('arch_confirm_custom')
          .setLabel('✅ Criar Agora')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('arch_create_new')
          .setLabel('✏️ Editar')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('arch_back')
          .setLabel('❌ Cancelar')
          .setStyle(ButtonStyle.Danger)
      );

    await interaction.reply({
      embeds: [embed],
      components: [row],
      flags: MessageFlags.Ephemeral
    });
  }
}

/**
 * Exporta handlers
 */
export const handlers = {
  button: handleArchitectButton,
  modal: handleArchitectModal
};

export default { data, execute, handlers };
