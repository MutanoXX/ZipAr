/**
 * Rias-Grimory-X - Comando /vincular
 * Vincula um usuário à sua conta
 *
 * @version 1.0.0
 * @author MutanoX
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags
} from 'discord.js';
import accountManager from '../utils/accountManager.js';

export const data = new SlashCommandBuilder()
  .setName('vincular')
  .setDescription('🔗 Vincula um usuário à sua conta para usar o bot')
  .addUserOption(opt =>
    opt
      .setName('usuario')
      .setDescription('Usuário que deseja vincular')
      .setRequired(true)
  );

export async function execute(interaction) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  try {
    const userId = interaction.user.id;
    const username = interaction.user.username;
    const targetUser = interaction.options.getUser('usuario');
    const targetUserId = targetUser.id;
    const targetUsername = targetUser.username;

    // Validações
    if (userId === targetUserId) {
      const errorEmbed = new EmbedBuilder()
        .setTitle('❌ Erro')
        .setDescription('Você não pode vincular a si mesmo!')
        .setColor('#EF4444');

      return interaction.editReply({ embeds: [errorEmbed] });
    }

    // Obter contas
    const account = accountManager.getOrCreateAccount(userId, username);

    // Verificar se não está vinculado
    const linkedInfo = accountManager.isLinked(userId);
    if (linkedInfo.isLinked) {
      const errorEmbed = new EmbedBuilder()
        .setTitle('❌ Você está vinculado')
        .setDescription('Você não pode vincular outros usuários porque está vinculado a outra conta.\n\nUse `/desvincar` primeiro.')
        .setColor('#EF4444');

      return interaction.editReply({ embeds: [errorEmbed] });
    }

    // Verificar se tem plano ativo
    if (!account.planType || !account.planExpiresAt || account.planExpiresAt <= Date.now()) {
      const errorEmbed = new EmbedBuilder()
        .setTitle('❌ Sem plano ativo')
        .setDescription('Você precisa ter um plano ativo para vincular usuários!\n\nUse `/renov` para ativar seu plano.')
        .setColor('#EF4444');

      return interaction.editReply({ embeds: [errorEmbed] });
    }

    // Tentar vincular
    const linkResult = accountManager.linkUser(userId, targetUserId, targetUsername);

    if (!linkResult.success) {
      const errorEmbed = new EmbedBuilder()
        .setTitle('❌ Erro ao vincular')
        .setDescription(linkResult.error)
        .setColor('#EF4444');

      return interaction.editReply({ embeds: [errorEmbed] });
    }

    // Sucesso
    const successEmbed = new EmbedBuilder()
      .setTitle('✅ Usuário Vinculado com Sucesso!')
      .setDescription(`${targetUser} foi vinculado à sua conta`)
      .setColor('#10B981')
      .addFields(
        {
          name: '👤 Usuário Vinculado',
          value: `${targetUser}`,
          inline: true
        },
        {
          name: '🔗 Vínculo Ativo',
          value: '✅ Sim',
          inline: true
        },
        {
          name: '💡 O que isso significa?',
          value: `${targetUsername} pode usar o bot em seus servidores enquanto você tiver um plano ativo.\n\nO plano será compartilhado com os usuários vinculados.`,
          inline: false
        }
      );

    // Obter informações atualizadas
    const updatedAccount = accountManager.getAccount(userId);
    const linkedUsers = accountManager.getLinkedUsers(userId);

    successEmbed.addFields({
      name: '📊 Suas Vinculações',
      value: `${linkedUsers.length}/${accountManager.MAX_LINKED_USERS}\n${linkedUsers.map(id => `<@${id}>`).join('\n')}`,
      inline: false
    });

    const button = new ButtonBuilder()
      .setCustomId('close')
      .setLabel('Fechar')
      .setStyle(ButtonStyle.Secondary);

    const row = new ActionRowBuilder().addComponents(button);

    await interaction.editReply({ embeds: [successEmbed], components: [row] });

  } catch (error) {
    console.error('❌ Erro no comando /vincular:', error.message);

    const errorEmbed = new EmbedBuilder()
      .setTitle('❌ Erro ao vincular usuário')
      .setDescription('Ocorreu um erro ao tentar vincular o usuário. Tente novamente mais tarde.')
      .setColor('#EF4444');

    await interaction.editReply({ embeds: [errorEmbed] });
  }
}

export default { data, execute };
