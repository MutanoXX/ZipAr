/**
 * Rias-Grimory-X - Comando /desvincar
 * Desvincula o usuário de uma conta ou desvincula um usuário de sua conta
 *
 * @version 1.0.0
 * @author MutanoX
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags
} from 'discord.js';
import accountManager from '../utils/accountManager.js';

export const data = new SlashCommandBuilder()
  .setName('desvincar')
  .setDescription('🔗 Desvincula você de uma conta ou um usuário de sua conta')
  .addUserOption(opt =>
    opt
      .setName('usuario')
      .setDescription('(Opcional) Usuário a desvincar de sua conta')
      .setRequired(false)
  );

export async function execute(interaction) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  try {
    const userId = interaction.user.id;
    const username = interaction.user.username;
    const targetUser = interaction.options.getUser('usuario');

    // Caso 1: Desvincar outro usuário da própria conta
    if (targetUser) {
      const targetUserId = targetUser.id;
      const targetUsername = targetUser.username;

      // Verificar se tem uma conta própria
      const account = accountManager.getAccount(userId);
      if (!account) {
        const errorEmbed = new EmbedBuilder()
          .setTitle('❌ Erro')
          .setDescription('Você não possui uma conta própria!')
          .setColor('#EF4444');

        return interaction.editReply({ embeds: [errorEmbed] });
      }

      // Tentar desvincar
      const unlinkResult = accountManager.unlinkUser(userId, targetUserId);

      if (!unlinkResult.success) {
        const errorEmbed = new EmbedBuilder()
          .setTitle('❌ Erro ao desvincar')
          .setDescription(unlinkResult.error)
          .setColor('#EF4444');

        return interaction.editReply({ embeds: [errorEmbed] });
      }

      // Sucesso
      const successEmbed = new EmbedBuilder()
        .setTitle('✅ Usuário Desvinado com Sucesso!')
        .setDescription(`${targetUser} foi desvinculado de sua conta`)
        .setColor('#10B981')
        .addFields(
          {
            name: '👤 Usuário Desvinado',
            value: `${targetUser}`,
            inline: true
          },
          {
            name: '💡 Próximos Passos',
            value: `${targetUsername} pode agora criar sua própria conta ou ser vinculado a outro usuário.`,
            inline: false
          }
        );

      // Obter informações atualizadas
      const linkedUsers = accountManager.getLinkedUsers(userId);
      if (linkedUsers.length > 0) {
        successEmbed.addFields({
          name: '📊 Seus Usuários Vinculados Restantes',
          value: `${linkedUsers.length}/${accountManager.MAX_LINKED_USERS}\n${linkedUsers.map(id => `<@${id}>`).join('\n')}`,
          inline: false
        });
      }

      const button = new ButtonBuilder()
        .setCustomId('close')
        .setLabel('Fechar')
        .setStyle(ButtonStyle.Secondary);

      const row = new ActionRowBuilder().addComponents(button);

      return interaction.editReply({ embeds: [successEmbed], components: [row] });
    }

    // Caso 2: Se o próprio usuário quer se desvincar de uma conta
    const linkedInfo = accountManager.isLinked(userId);

    if (!linkedInfo.isLinked) {
      const errorEmbed = new EmbedBuilder()
        .setTitle('❌ Você não está vinculado')
        .setDescription('Você não está vinculado a nenhuma conta.')
        .setColor('#EF4444');

      return interaction.editReply({ embeds: [errorEmbed] });
    }

    // Criar confirmação
    const confirmEmbed = new EmbedBuilder()
      .setTitle('⚠️ Confirmar Desvinculação')
      .setDescription('Você tem certeza que deseja se desvinular?')
      .setColor('#F59E0B')
      .addFields(
        {
          name: 'O que acontecerá?',
          value: `✓ Você será desvinculado da conta principal
✓ Você poderá criar sua própria assinatura
✗ Perderá acesso ao plano compartilhado`,
          inline: false
        },
        {
          name: '💡 Nota',
          value: 'Após desvinular, você precisará de seu próprio plano para usar o bot.',
          inline: false
        }
      );

    const confirmButton = new ButtonBuilder()
      .setCustomId(`confirm_unlink_${linkedInfo.parentId}`)
      .setLabel('✅ Desvinular')
      .setStyle(ButtonStyle.Danger);

    const cancelButton = new ButtonBuilder()
      .setCustomId('cancel')
      .setLabel('❌ Cancelar')
      .setStyle(ButtonStyle.Secondary);

    const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

    return interaction.editReply({ embeds: [confirmEmbed], components: [row] });

  } catch (error) {
    console.error('❌ Erro no comando /desvincar:', error.message);

    const errorEmbed = new EmbedBuilder()
      .setTitle('❌ Erro ao desvincar')
      .setDescription('Ocorreu um erro ao tentar desvincar. Tente novamente mais tarde.')
      .setColor('#EF4444');

    await interaction.editReply({ embeds: [errorEmbed] });
  }
}

export default { data, execute };
