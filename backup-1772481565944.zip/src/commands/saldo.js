/**
 * Rias-Grimory-X - Comando /saldo
 * Gerencia saldo da conta (depósito)
 *
 * @version 1.0.0
 * @author MutanoX
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags
} from 'discord.js';
import paymentManager from '../services/paymentManager.js';
import accountManager from '../utils/accountManager.js';

export const data = new SlashCommandBuilder()
  .setName('saldo')
  .setDescription('💰 Gerencia seu saldo - adicione dinheiro para renovações automáticas')
  .addSubcommand(sub =>
    sub
      .setName('ver')
      .setDescription('Visualize seu saldo atual')
  )
  .addSubcommand(sub =>
    sub
      .setName('adicionar')
      .setDescription('Adicione dinheiro ao seu saldo via PIX')
      .addNumberOption(opt =>
        opt
          .setName('valor')
          .setDescription('Valor em reais (mínimo: R$ 5,00)')
          .setRequired(false)
          .setMinValue(5.00)
          .setMaxValue(10000.00)
      )
  );

export async function execute(interaction) {
  const subcommand = interaction.options.getSubcommand();

  if (subcommand === 'ver') {
    await handleViewBalance(interaction);
  } else if (subcommand === 'adicionar') {
    await handleAddBalance(interaction);
  }
}

async function handleViewBalance(interaction) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  try {
    const userId = interaction.user.id;
    const username = interaction.user.username;

    const account = accountManager.getOrCreateAccount(userId, username);

    const embed = new EmbedBuilder()
      .setTitle(`💰 Seu Saldo`)
      .setColor('#10B981')
      .addFields(
        {
          name: 'Saldo Disponível',
          value: `R$ ${account.balance.toFixed(2)}`,
          inline: false
        },
        {
          name: '💡 Para que serve?',
          value: `Seu saldo pode ser usado para:
• Renovação automática do plano
• Compra futura de planos sem PIX`,
          inline: false
        }
      );

    // Obter últimas transações
    const transactions = accountManager.getUserTransactions(userId, 5);
    if (transactions.length > 0) {
      let txnText = '';
      transactions.forEach(txn => {
        const date = new Date(txn.createdAt).toLocaleString('pt-BR');
        const type = txn.type === 'deposit' ? '➕' : '➖';
        const amount = txn.type === 'deposit' 
          ? `+R$ ${txn.amount.toFixed(2)}` 
          : `-R$ ${Math.abs(txn.amount).toFixed(2)}`;
        txnText += `${type} ${amount} - ${date}\n`;
      });

      embed.addFields({
        name: '📋 Últimas Transações',
        value: txnText,
        inline: false
      });
    }

    const addButton = new ButtonBuilder()
      .setCustomId('open_adicionar_saldo')
      .setLabel('➕ Adicionar Saldo')
      .setStyle(ButtonStyle.Primary);

    const row = new ActionRowBuilder().addComponents(addButton);

    await interaction.editReply({ embeds: [embed], components: [row] });

  } catch (error) {
    console.error('❌ Erro ao visualizar saldo:', error.message);

    const errorEmbed = new EmbedBuilder()
      .setTitle('❌ Erro')
      .setDescription('Erro ao carregar saldo. Tente novamente mais tarde.')
      .setColor('#EF4444');

    await interaction.editReply({ embeds: [errorEmbed] });
  }
}

async function handleAddBalance(interaction) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  try {
    const userId = interaction.user.id;
    const username = interaction.user.username;
    const amount = interaction.options.getNumber('valor');

    let depositAmount = amount;

    // Se não foi fornecido valor, mostrar modal para input
    if (!depositAmount) {
      const modal = new ModalBuilder()
        .setCustomId(`deposit_modal_${userId}`)
        .setTitle('Adicionar Saldo');

      const valueInput = new TextInputBuilder()
        .setCustomId('deposit_value')
        .setLabel('Valor em Reais (mínimo: R$ 5,00)')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('Ex: 50.00')
        .setRequired(true);

      const row1 = new ActionRowBuilder().addComponents(valueInput);
      modal.addComponents(row1);

      return interaction.showModal(modal);
    }

    // Validar valor
    const validation = paymentManager.validateDepositAmount(depositAmount);
    if (!validation.valid) {
      const errorEmbed = new EmbedBuilder()
        .setTitle('❌ Valor inválido')
        .setDescription(validation.error)
        .setColor('#EF4444');

      return interaction.editReply({ embeds: [errorEmbed] });
    }

    // Criar pagamento de depósito
    const paymentResult = await paymentManager.createDepositPayment(
      userId,
      username,
      depositAmount
    );

    if (!paymentResult.success) {
      const errorEmbed = new EmbedBuilder()
        .setTitle('❌ Erro ao criar pagamento')
        .setDescription(paymentResult.error)
        .setColor('#EF4444');

      return interaction.editReply({ embeds: [errorEmbed] });
    }

    const payment = paymentResult.payment;

    // Criar embed com informações do pagamento
    const embed = new EmbedBuilder()
      .setTitle(`💳 Depósito de Saldo`)
      .setDescription('Escaneie o QR Code ou use o código PIX')
      .setColor('#8B5CF6')
      .addFields(
        {
          name: '💰 Valor do Depósito',
          value: `R$ ${depositAmount.toFixed(2)}`,
          inline: false
        },
        {
          name: '📋 Código PIX (Copiar e colar)',
          value: `\`\`\`${payment.copyPaste}\`\`\``,
          inline: false
        },
        {
          name: '⏰ QR Code expira em',
          value: new Date(payment.expirationDate).toLocaleString('pt-BR'),
          inline: false
        },
        {
          name: '🆔 ID da Transação',
          value: `\`${payment.transactionId}\``,
          inline: false
        }
      )
      .setImage(`https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(payment.copyPaste)}`)
      .setFooter({
        text: 'Após fazer a transferência PIX, clique no botão "Pago" para confirmar'
      })
      .setTimestamp();

    // Botões
    const confirmButton = new ButtonBuilder()
      .setCustomId(`confirm_payment_${payment.transactionId}`)
      .setLabel('✅ Já fiz o pagamento')
      .setStyle(ButtonStyle.Success);

    const cancelButton = new ButtonBuilder()
      .setCustomId('cancel_payment')
      .setLabel('❌ Cancelar')
      .setStyle(ButtonStyle.Secondary);

    const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

    // Enviar por DM se possível
    try {
      const dmChannel = await interaction.user.createDM();
      await dmChannel.send({
        embeds: [embed],
        components: [row]
      });

      const confirmEmbed = new EmbedBuilder()
        .setTitle('✅ QR Code enviado por DM')
        .setDescription(`Um QR code foi enviado para seu DM.\n\n**Valor:** R$ ${depositAmount.toFixed(2)}`)
        .setColor('#10B981');

      await interaction.editReply({ embeds: [confirmEmbed] });
    } catch (error) {
      console.error('❌ Erro ao enviar DM, enviando na guild:', error.message);
      await interaction.editReply({ embeds: [embed], components: [row] });
    }

  } catch (error) {
    console.error('❌ Erro ao adicionar saldo:', error.message);

    const errorEmbed = new EmbedBuilder()
      .setTitle('❌ Erro ao processar depósito')
      .setDescription('Ocorreu um erro. Tente novamente mais tarde.')
      .setColor('#EF4444');

    await interaction.editReply({ embeds: [errorEmbed] });
  }
}

export default { data, execute };
