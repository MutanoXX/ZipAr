/**
 * RIAS GREMORY X AI - Image Tools Handler
 * Handler para as novas ferramentas de geração de imagens
 * 
 * @version 1.0.0
 */

import { EmbedBuilder } from 'discord.js';
import imageGenerationService from '../services/imageGenerationService.js';

// ============================================
// HANDLER PRINCIPAL DE FERRAMENTAS DE IMAGEM
// ============================================

/**
 * Gera imagem usando a API própria
 */
export async function handleGenerateImage(message, response, channel, thinkingMsg) {
  const prompt = response.prompt || response.descricao || response.query;
  const model = response.model || response.modelo || 'flux';
  const style = response.style || response.estilo || null;
  const size = response.size || response.tamanho || '1024x1024';
  const n = Math.min(response.n || response.quantidade || 1, 4);
  
  if (!prompt) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'Descrição da imagem não informada!', '#EF4444');
  }
  
  console.log(`🎨 [ImageGen] Gerando: "${prompt.substring(0, 50)}..."`);
  console.log(`📊 [ImageGen] Modelo: ${model}, Estilo: ${style || 'auto'}, Tamanho: ${size}`);
  
  try {
    const result = await imageGenerationService.generateImage({
      prompt,
      model,
      style,
      size,
      n,
      enhance: true
    });
    
    if (result.success && result.images.length > 0) {
      // Se gerou múltiplas imagens
      if (result.images.length > 1) {
        const listEmbed = new EmbedBuilder()
          .setTitle('🎨 Imagens Geradas!')
          .setDescription(`**Prompt:** ${prompt.substring(0, 100)}\n\n✨ **${result.images.length}** imagens geradas! Enviando...`)
          .addFields(
            { name: '🤖 Modelo', value: model, inline: true },
            { name: '🎨 Estilo', value: style || 'Automático', inline: true },
            { name: '⏱️ Tempo', value: `${result.elapsed}ms`, inline: true }
          )
          .setColor('#F59E0B')
          .setFooter({ text: '💎 Rias-Grimory-X - Image AI' })
          .setTimestamp();
        
        await editEmbed(thinkingMsg, listEmbed);
        
        // Enviar cada imagem
        for (let i = 0; i < result.images.length; i++) {
          const imgEmbed = new EmbedBuilder()
            .setTitle(`🖼️ Imagem ${i + 1}/${result.images.length}`)
            .setDescription(`**${prompt.substring(0, 50)}...`)
            .setImage(result.images[i].url)
            .setColor('#F59E0B')
            .setFooter({ text: '💎 Rias-Grimory-X' })
            .setTimestamp();
          
          await channel.send({ embeds: [imgEmbed] });
          await sleep(500);
        }
      } else {
        // Uma única imagem
        const embed = new EmbedBuilder()
          .setTitle('🎨 Imagem Gerada!')
          .setDescription(`**Prompt:** ${prompt.substring(0, 150)}\n\n✨ Aqui está sua arte!`)
          .setImage(result.images[0].url)
          .addFields(
            { name: '🤖 Modelo', value: model, inline: true },
            { name: '🎨 Estilo', value: style || 'Automático', inline: true },
            { name: '⏱️ Tempo', value: `${result.elapsed}ms`, inline: true }
          )
          .setColor('#F59E0B')
          .setFooter({ text: '💎 Rias-Grimory-X - Image AI' })
          .setTimestamp();
        
        await editEmbed(thinkingMsg, embed);
      }
    } else {
      // Fallback
      const fallbackUrl = result.fallback?.url;
      
      const embed = new EmbedBuilder()
        .setTitle('🎨 Imagem Gerada!')
        .setDescription(`**Prompt:** ${prompt.substring(0, 150)}\n\n✨ Aqui está sua arte!`)
        .setImage(fallbackUrl)
        .addFields(
          { name: '⚠️ Modo Fallback', value: 'Usando serviço alternativo', inline: true }
        )
        .setColor('#F59E0B')
        .setFooter({ text: '💎 Rias-Grimory-X - Image AI (Fallback)' })
        .setTimestamp();
      
      await editEmbed(thinkingMsg, embed);
    }
  } catch (error) {
    console.error('❌ [ImageGen] Erro:', error.message);
    await editEmbed(thinkingMsg, '❌ Erro', `Falha ao gerar imagem: ${error.message}`, '#EF4444');
  }
}

/**
 * Gera variações de uma imagem
 */
export async function handleGenerateVariations(message, response, channel, thinkingMsg) {
  const prompt = response.prompt || response.descricao;
  const count = Math.min(response.count || response.quantidade || 4, 4);
  const style = response.style || null;
  
  if (!prompt) {
    return await editEmbed(thinkingMsg, '❌ Erro', 'Descrição não informada!', '#EF4444');
  }
  
  console.log(`🎨 [ImageGen] Gerando ${count} variações de: "${prompt.substring(0, 50)}..."`);
  
  const embed = new EmbedBuilder()
    .setTitle('🎨 Gerando Variações...')
    .setDescription(`**Prompt:** ${prompt.substring(0, 100)}\n\n✨ Gerando **${count}** variações...`)
    .setColor('#F59E0B')
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
  
  const variations = await imageGenerationService.generateVariations(prompt, count, style);
  
  if (variations.length > 0) {
    for (let i = 0; i < variations.length; i++) {
      const imgEmbed = new EmbedBuilder()
        .setTitle(`🖼️ Variação ${i + 1}/${variations.length}`)
        .setDescription(`**${prompt.substring(0, 50)}...`)
        .setImage(variations[i].url)
        .setColor('#F59E0B')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      
      await channel.send({ embeds: [imgEmbed] });
      await sleep(500);
    }
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', 'Não foi possível gerar variações', '#EF4444');
  }
}

/**
 * Gera imagem da Rias Gremory
 */
export async function handleGenerateRias(message, response, channel, thinkingMsg) {
  const scene = response.scene || 'portrait';
  const outfit = response.outfit || 'default';
  const expression = response.expression || 'confident';
  const background = response.background || 'elegant';
  
  console.log(`🌹 [ImageGen] Gerando Rias - Cena: ${scene}, Roupa: ${outfit}`);
  
  const embed = new EmbedBuilder()
    .setTitle('🌹 Gerando Rias...')
    .setDescription(`**Cena:** ${scene}\n**Roupa:** ${outfit}\n**Expressão:** ${expression}\n\n✨ Criando sua Rias personalizada...`)
    .setColor('#DC143C')
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
  
  const result = await imageGenerationService.generateRiasImage({
    scene,
    outfit,
    expression,
    background
  });
  
  if (result.success && result.images.length > 0) {
    const finalEmbed = new EmbedBuilder()
      .setTitle('🌹 Rias Gremory')
      .setDescription(`✨ Aqui está sua Rias personalizada!`)
      .setImage(result.images[0].url)
      .addFields(
        { name: '🎭 Cena', value: scene, inline: true },
        { name: '👗 Roupa', value: outfit, inline: true },
        { name: '😊 Expressão', value: expression, inline: true }
      )
      .setColor('#DC143C')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, finalEmbed);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', 'Falha ao gerar imagem da Rias', '#EF4444');
  }
}

/**
 * Gera asset para servidor (logo/banner)
 */
export async function handleGenerateServerAsset(message, response, guild, channel, thinkingMsg) {
  const type = response.type || 'logo';
  const theme = response.theme || 'gaming';
  const name = response.name || guild.name;
  const colors = response.colors || [];
  const style = response.style || 'modern';
  
  console.log(`🎨 [ImageGen] Gerando ${type} para: ${name}`);
  
  const embed = new EmbedBuilder()
    .setTitle(`🎨 Gerando ${type}...`)
    .setDescription(`**Tema:** ${theme}\n**Nome:** ${name}\n**Estilo:** ${style}\n\n✨ Criando seu asset personalizado...`)
    .setColor('#8B5CF6')
    .setTimestamp();
  
  await editEmbed(thinkingMsg, embed);
  
  const result = await imageGenerationService.generateServerAsset({
    type,
    theme,
    name,
    colors,
    style
  });
  
  if (result.success && result.images.length > 0) {
    const finalEmbed = new EmbedBuilder()
      .setTitle(`✨ ${type.charAt(0).toUpperCase() + type.slice(1)} Gerado!`)
      .setDescription(`**${name}** - ${theme} themed ${type}`)
      .setImage(result.images[0].url)
      .addFields(
        { name: '🎨 Tema', value: theme, inline: true },
        { name: '✏️ Estilo', value: style, inline: true }
      )
      .setColor('#8B5CF6')
      .setFooter({ text: '💎 Rias-Grimory-X' })
      .setTimestamp();
    
    await editEmbed(thinkingMsg, finalEmbed);
  } else {
    await editEmbed(thinkingMsg, '❌ Erro', 'Falha ao gerar asset', '#EF4444');
  }
}

/**
 * Mostra modelos e estilos disponíveis
 */
export async function handleImageModels(message, thinkingMsg) {
  const models = imageGenerationService.getAvailableModels();
  const styles = imageGenerationService.getAvailableStyles();
  const sizes = imageGenerationService.getAvailableSizes();
  
  const embed = new EmbedBuilder()
    .setTitle('🎨 Sistema de Geração de Imagens')
    .setDescription('Use a API própria para gerar imagens incríveis!')
    .setColor('#8B5CF6')
    .setFooter({ text: '💎 Rias-Grimory-X' })
    .setTimestamp();
  
  // Modelos
  const modelsList = models.map(m => `• **${m.name}** (${m.id})`).join('\n');
  embed.addFields({ name: '🤖 Modelos', value: modelsList, inline: false });
  
  // Estilos
  const stylesList = styles.slice(0, 8).map(s => `• ${s.name} (\`${s.id}\`)`).join('\n');
  embed.addFields({ name: '🎨 Estilos', value: stylesList, inline: true });
  
  // Tamanhos
  const sizesList = sizes.map(s => `• ${s.name} (\`${s.id}\`)`).join('\n');
  embed.addFields({ name: '📐 Tamanhos', value: sizesList, inline: true });
  
  await editEmbed(thinkingMsg, embed);
}

// ============================================
// FUNÇÕES AUXILIARES
// ============================================

async function editEmbed(thinkingMsg, titleOrEmbed, description, color) {
  if (!thinkingMsg) return;
  
  try {
    if (typeof titleOrEmbed === 'object' && titleOrEmbed.constructor?.name === 'EmbedBuilder') {
      await thinkingMsg.edit({ embeds: [titleOrEmbed] });
    } else {
      const embed = new EmbedBuilder()
        .setTitle(titleOrEmbed)
        .setDescription((description || '').trim() || 'Sem descrição')
        .setColor(color || '#8B5CF6')
        .setFooter({ text: '💎 Rias-Grimory-X' })
        .setTimestamp();
      await thinkingMsg.edit({ embeds: [embed] });
    }
  } catch (e) {
    console.error('Erro ao editar embed:', e.message);
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export default {
  handleGenerateImage,
  handleGenerateVariations,
  handleGenerateRias,
  handleGenerateServerAsset,
  handleImageModels
};
