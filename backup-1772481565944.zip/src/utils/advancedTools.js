/**
 * RIAS GREMORY X AI - Advanced Tools System
 * Sistema de Ferramentas Avançadas com Parâmetros Expandidos
 * 
 * @version 1.0.0
 * @description Ferramentas com todos os parâmetros do Discord API
 */

import {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ChannelType,
  PermissionFlagsBits,
  WebhookClient
} from 'discord.js';

/**
 * ============================================
 * EMBED BUILDER AVANÇADO
 * ============================================
 */

/**
 * Cria um embed com TODOS os parâmetros disponíveis
 * @param {Object} config - Configuração do embed
 * @returns {EmbedBuilder}
 */
export function createAdvancedEmbed(config) {
  const embed = new EmbedBuilder();
  
  // Título
  if (config.title) {
    embed.setTitle(config.title.substring(0, 256));
  }
  
  // Descrição
  if (config.description) {
    embed.setDescription(config.description.substring(0, 4096));
  }
  
  // URL (para título clicável)
  if (config.url) {
    embed.setURL(config.url);
  }
  
  // Cor (suporta hex, nome, ou número)
  if (config.color) {
    let color = config.color;
    
    // Nomes de cores
    const colorNames = {
      'vermelho': '#DC143C',
      'verde': '#10B981',
      'azul': '#3B82F6',
      'amarelo': '#F59E0B',
      'roxo': '#8B5CF6',
      'rosa': '#EC4899',
      'laranja': '#F97316',
      'branco': '#FFFFFF',
      'preto': '#000000',
      'cinza': '#6B7280',
      'crimson': '#DC143C',
      'gold': '#FFD700',
      'silver': '#C0C0C0',
      'bronze': '#CD7F32',
      'ciano': '#06B6D4',
      'lime': '#84CC16',
      'indigo': '#6366F1',
      'purple': '#A855F7',
      'pink': '#EC4899',
      'teal': '#14B8A6',
      'cyan': '#06B6D4',
      'random': Math.floor(Math.random() * 16777215)
    };
    
    if (colorNames[color?.toLowerCase()]) {
      color = colorNames[color.toLowerCase()];
    }
    
    if (typeof color === 'string') {
      color = color.replace('#', '');
      if (!/^[0-9A-Fa-f]{6}$/.test(color)) {
        color = '8B5CF6'; // Default roxo
      }
      color = parseInt(color, 16);
    }
    
    embed.setColor(color);
  } else {
    embed.setColor('#8B5CF6'); // Default
  }
  
  // Timestamp
  if (config.timestamp === true || config.timestamp === 'now') {
    embed.setTimestamp();
  } else if (config.timestamp) {
    embed.setTimestamp(new Date(config.timestamp));
  }
  
  // Thumbnail
  if (config.thumbnail) {
    embed.setThumbnail(config.thumbnail);
  }
  
  // Image
  if (config.image) {
    embed.setImage(config.image);
  }
  
  // Video (URL de vídeo)
  if (config.video) {
    // Note: EmbedBuilder doesn't have setVideo, but we can add it as a field or description
    // For now, this is just stored for reference
  }
  
  // Author
  if (config.author) {
    const authorConfig = {
      name: (config.author.name || config.author).substring(0, 256)
    };
    if (config.author.iconURL || config.author.iconUrl || config.author.icon) {
      authorConfig.iconURL = config.author.iconURL || config.author.iconUrl || config.author.icon;
    }
    if (config.author.url) {
      authorConfig.url = config.author.url;
    }
    embed.setAuthor(authorConfig);
  }
  
  // Footer
  if (config.footer) {
    const footerConfig = {
      text: (config.footer.text || config.footer).substring(0, 2048)
    };
    if (config.footer.iconURL || config.footer.iconUrl || config.footer.icon) {
      footerConfig.iconURL = config.footer.iconURL || config.footer.iconUrl || config.footer.icon;
    }
    embed.setFooter(footerConfig);
  }
  
  // Fields
  if (config.fields && Array.isArray(config.fields)) {
    // Máximo 25 fields
    const fields = config.fields.slice(0, 25);
    
    fields.forEach(field => {
      embed.addFields({
        name: (field.name || '━━━━').substring(0, 256),
        value: (field.value || '•').substring(0, 1024),
        inline: field.inline === true
      });
    });
  }
  
  // Provider (para embeds de tipo rich)
  if (config.provider) {
    // Not directly supported in EmbedBuilder
  }
  
  return embed;
}

/**
 * ============================================
 * COMPONENTS BUILDER AVANÇADO
 * ============================================
 */

/**
 * Cria linhas de ação com botões e menus
 * @param {Array} components - Array de componentes
 * @returns {Array<ActionRowBuilder>}
 */
export function createAdvancedComponents(components) {
  const rows = [];
  
  // Máximo 5 ActionRows
  const componentRows = components.slice(0, 5);
  
  for (const rowData of componentRows) {
    const actionRow = new ActionRowBuilder();
    
    // Botões (máximo 5 por row)
    if (rowData.buttons && Array.isArray(rowData.buttons)) {
      const buttons = rowData.buttons.slice(0, 5);
      
      buttons.forEach(btn => {
        const button = new ButtonBuilder();
        
        // Custom ID ou URL
        if (btn.url) {
          button.setURL(btn.url);
          button.setStyle(ButtonStyle.Link);
        } else {
          button.setCustomId(btn.customId || btn.id || `btn_${Date.now()}`);
          
          // Estilo do botão
          const styleMap = {
            'primary': ButtonStyle.Primary,
            'secondary': ButtonStyle.Secondary,
            'success': ButtonStyle.Success,
            'danger': ButtonStyle.Danger,
            'link': ButtonStyle.Link,
            'verde': ButtonStyle.Success,
            'vermelho': ButtonStyle.Danger,
            'azul': ButtonStyle.Primary,
            'cinza': ButtonStyle.Secondary
          };
          
          button.setStyle(styleMap[btn.style?.toLowerCase()] || ButtonStyle.Primary);
        }
        
        // Label
        if (btn.label) {
          button.setLabel(btn.label.substring(0, 80));
        }
        
        // Emoji
        if (btn.emoji) {
          if (typeof btn.emoji === 'string') {
            // Se for um ID de emoji customizado
            if (/^\d+$/.test(btn.emoji)) {
              button.setEmoji({ id: btn.emoji });
            } else {
              button.setEmoji(btn.emoji);
            }
          } else {
            button.setEmoji(btn.emoji);
          }
        }
        
        // Desabilitado
        if (btn.disabled === true) {
          button.setDisabled(true);
        }
        
        actionRow.addComponents(button);
      });
    }
    
    // Select Menu (apenas 1 por row)
    if (rowData.selectMenu || rowData.select || rowData.menu) {
      const menuData = rowData.selectMenu || rowData.select || rowData.menu;
      
      const select = new StringSelectMenuBuilder()
        .setCustomId(menuData.customId || menuData.id || `menu_${Date.now()}`);
      
      // Placeholder
      if (menuData.placeholder) {
        select.setPlaceholder(menuData.placeholder.substring(0, 150));
      }
      
      // Opções (máximo 25)
      if (menuData.options && Array.isArray(menuData.options)) {
        const options = menuData.options.slice(0, 25).map(opt => ({
          label: (opt.label || opt.name || '').substring(0, 100),
          value: (opt.value || opt.id || opt.label || '').substring(0, 100),
          description: opt.description?.substring(0, 100),
          emoji: opt.emoji,
          default: opt.default === true
        }));
        
        select.addOptions(options);
      }
      
      // Min/Max valores selecionáveis
      if (menuData.minValues !== undefined) {
        select.setMinValues(Math.max(0, Math.min(25, menuData.minValues)));
      }
      if (menuData.maxValues !== undefined) {
        select.setMaxValues(Math.max(1, Math.min(25, menuData.maxValues)));
      }
      
      // Desabilitado
      if (menuData.disabled === true) {
        select.setDisabled(true);
      }
      
      actionRow.addComponents(select);
    }
    
    // Channel Select Menu
    if (rowData.channelSelect || rowData.channelMenu) {
      const channelData = rowData.channelSelect || rowData.channelMenu;
      // Note: Would need ChannelSelectMenuBuilder from discord.js v14
    }
    
    // User Select Menu
    if (rowData.userSelect || rowData.userMenu) {
      const userData = rowData.userSelect || rowData.userMenu;
      // Note: Would need UserSelectMenuBuilder from discord.js v14
    }
    
    // Role Select Menu
    if (rowData.roleSelect || rowData.roleMenu) {
      const roleData = rowData.roleSelect || rowData.roleMenu;
      // Note: Would need RoleSelectMenuBuilder from discord.js v14
    }
    
    // Mentionable Select Menu
    if (rowData.mentionableSelect || rowData.mentionableMenu) {
      const mentionableData = rowData.mentionableSelect || rowData.mentionableMenu;
      // Note: Would need MentionableSelectMenuBuilder from discord.js v14
    }
    
    rows.push(actionRow);
  }
  
  return rows;
}

/**
 * ============================================
 * CHANNEL TOOLS AVANÇADAS
 * ============================================
 */

/**
 * Cria canal com todos os parâmetros
 */
export async function createAdvancedChannel(guild, options) {
  const channelData = {
    name: options.name?.substring(0, 100) || 'novo-canal',
    type: parseChannelType(options.type),
    topic: options.topic?.substring(0, 1024),
    nsfw: options.nsfw === true,
    parent: options.parentId || options.category || options.parent,
    position: options.position,
    rateLimitPerUser: options.slowmode || options.rateLimitPerUser,
    bitrate: options.bitrate ? Math.max(8000, Math.min(96000, options.bitrate)) : undefined,
    userLimit: options.userLimit !== undefined ? Math.min(99, options.userLimit) : undefined,
    permissionOverwrites: [],
    rtcRegion: options.rtcRegion,
    videoQualityMode: options.videoQualityMode
  };
  
  // Processar permissões
  if (options.permissions && Array.isArray(options.permissions)) {
    channelData.permissionOverwrites = options.permissions.map(p => ({
      id: p.roleId || p.userId || p.id,
      allow: parsePermissions(p.allow || p.permissions?.allow || []),
      deny: parsePermissions(p.deny || p.permissions?.deny || [])
    }));
  }
  
  // Default auto-archive duration for threads
  if (options.defaultAutoArchiveDuration) {
    channelData.defaultAutoArchiveDuration = options.defaultAutoArchiveDuration;
  }
  
  // Available tags for forums
  if (options.availableTags) {
    channelData.availableTags = options.availableTags;
  }
  
  // Default reaction emoji for forums
  if (options.defaultReactionEmoji) {
    channelData.defaultReactionEmoji = options.defaultReactionEmoji;
  }
  
  const channel = await guild.channels.create(channelData);
  
  return {
    success: true,
    channel: {
      id: channel.id,
      name: channel.name,
      type: channel.type,
      mention: channel.toString(),
      url: channel.url
    },
    discordChannel: channel
  };
}

/**
 * Parse de tipo de canal
 */
function parseChannelType(type) {
  if (typeof type === 'number') return type;
  
  const types = {
    'texto': ChannelType.GuildText,
    'text': ChannelType.GuildText,
    'voz': ChannelType.GuildVoice,
    'voice': ChannelType.GuildVoice,
    'categoria': ChannelType.GuildCategory,
    'category': ChannelType.GuildCategory,
    'anuncio': ChannelType.GuildAnnouncement,
    'announcement': ChannelType.GuildAnnouncement,
    'news': ChannelType.GuildAnnouncement,
    'stage': ChannelType.GuildStageVoice,
    'forum': ChannelType.GuildForum,
    'direto': ChannelType.DM,
    'dm': ChannelType.DM,
    'grupo': ChannelType.GroupDM,
    'thread': ChannelType.PublicThread,
    'thread_publica': ChannelType.PublicThread,
    'thread_privada': ChannelType.PrivateThread,
    'private_thread': ChannelType.PrivateThread
  };
  
  return types[type?.toLowerCase()] || ChannelType.GuildText;
}

/**
 * Parse de permissões
 */
function parsePermissions(perms) {
  if (typeof perms === 'number') return perms;
  if (!Array.isArray(perms)) return 0n;
  
  let permissions = 0n;
  
  const permMap = {
    'createinstantinvite': PermissionFlagsBits.CreateInstantInvite,
    'kickmembers': PermissionFlagsBits.KickMembers,
    'banmembers': PermissionFlagsBits.BanMembers,
    'administrator': PermissionFlagsBits.Administrator,
    'managechannels': PermissionFlagsBits.ManageChannels,
    'manageguild': PermissionFlagsBits.ManageGuild,
    'addreactions': PermissionFlagsBits.AddReactions,
    'viewauditlog': PermissionFlagsBits.ViewAuditLog,
    'priorityspeaker': PermissionFlagsBits.PrioritySpeaker,
    'stream': PermissionFlagsBits.Stream,
    'viewchannel': PermissionFlagsBits.ViewChannel,
    'sendmessages': PermissionFlagsBits.SendMessages,
    'sendttsmessages': PermissionFlagsBits.SendTTSMessages,
    'managemessages': PermissionFlagsBits.ManageMessages,
    'embedlinks': PermissionFlagsBits.EmbedLinks,
    'attachfiles': PermissionFlagsBits.AttachFiles,
    'readmessagehistory': PermissionFlagsBits.ReadMessageHistory,
    'mentioneveryone': PermissionFlagsBits.MentionEveryone,
    'useexternalemojis': PermissionFlagsBits.UseExternalEmojis,
    'viewguildinsights': PermissionFlagsBits.ViewGuildInsights,
    'connect': PermissionFlagsBits.Connect,
    'speak': PermissionFlagsBits.Speak,
    'mutemembers': PermissionFlagsBits.MuteMembers,
    'deafenmembers': PermissionFlagsBits.DeafenMembers,
    'movemembers': PermissionFlagsBits.MoveMembers,
    'usevad': PermissionFlagsBits.UseVAD,
    'changenickname': PermissionFlagsBits.ChangeNickname,
    'managenicknames': PermissionFlagsBits.ManageNicknames,
    'manageroles': PermissionFlagsBits.ManageRoles,
    'managewebhooks': PermissionFlagsBits.ManageWebhooks,
    'manageemojisandstickers': PermissionFlagsBits.ManageEmojisAndStickers,
    'useapplicationcommands': PermissionFlagsBits.UseApplicationCommands,
    'requesttospeak': PermissionFlagsBits.RequestToSpeak,
    'manageevents': PermissionFlagsBits.ManageEvents,
    'managethreads': PermissionFlagsBits.ManageThreads,
    'createpublicthreads': PermissionFlagsBits.CreatePublicThreads,
    'createprivatethreads': PermissionFlagsBits.CreatePrivateThreads,
    'useexternalstickers': PermissionFlagsBits.UseExternalStickers,
    'sendmessagesinthreads': PermissionFlagsBits.SendMessagesInThreads,
    'useembeddedactivities': PermissionFlagsBits.UseEmbeddedActivities,
    'moderatemembers': PermissionFlagsBits.ModerateMembers
  };
  
  for (const perm of perms) {
    const permName = perm?.toLowerCase().replace(/[^a-z]/g, '');
    if (permMap[permName]) {
      permissions |= permMap[permName];
    }
  }
  
  return permissions;
}

/**
 * ============================================
 * ROLE TOOLS AVANÇADAS
 * ============================================
 */

/**
 * Cria cargo com todos os parâmetros
 */
export async function createAdvancedRole(guild, options) {
  const roleData = {
    name: options.name?.substring(0, 100) || 'Novo Cargo',
    color: parseColor(options.color),
    hoist: options.hoist === true || options.separate === true,
    position: options.position,
    permissions: parsePermissions(options.permissions || []),
    mentionable: options.mentionable === true || options.mention === true,
    icon: options.icon,
    unicodeEmoji: options.unicodeEmoji || options.emoji
  };
  
  const role = await guild.roles.create(roleData);
  
  return {
    success: true,
    role: {
      id: role.id,
      name: role.name,
      color: role.hexColor,
      mention: role.toString(),
      position: role.position
    },
    discordRole: role
  };
}

/**
 * Parse de cor
 */
function parseColor(color) {
  if (!color) return undefined;
  
  const colorNames = {
    'vermelho': 0xDC143C,
    'verde': 0x10B981,
    'azul': 0x3B82F6,
    'amarelo': 0xF59E0B,
    'roxo': 0x8B5CF6,
    'rosa': 0xEC4899,
    'laranja': 0xF97316,
    'branco': 0xFFFFFF,
    'preto': 0x000000,
    'cinza': 0x6B7280,
    'crimson': 0xDC143C,
    'gold': 0xFFD700,
    'silver': 0xC0C0C0,
    'bronze': 0xCD7F32,
    'ciano': 0x06B6D4,
    'lime': 0x84CC16,
    'indigo': 0x6366F1,
    'purple': 0xA855F7,
    'pink': 0xEC4899,
    'teal': 0x14B8A6,
    'random': Math.floor(Math.random() * 16777215)
  };
  
  if (typeof color === 'number') return color;
  
  if (colorNames[color?.toLowerCase()]) {
    return colorNames[color.toLowerCase()];
  }
  
  if (typeof color === 'string') {
    color = color.replace('#', '');
    if (/^[0-9A-Fa-f]{6}$/.test(color)) {
      return parseInt(color, 16);
    }
  }
  
  return undefined;
}

/**
 * ============================================
 * WEBHOOK TOOLS AVANÇADAS
 * ============================================
 */

/**
 * Envia mensagem via webhook com todos os parâmetros
 */
export async function sendAdvancedWebhook(webhookUrl, options) {
  const webhook = new WebhookClient({ url: webhookUrl });
  
  const messageData = {
    content: options.content?.substring(0, 2000),
    username: options.username?.substring(0, 80),
    avatarURL: options.avatarUrl || options.avatar,
    tts: options.tts === true,
    threadId: options.threadId || options.thread
  };
  
  // Embeds (máximo 10)
  if (options.embeds && Array.isArray(options.embeds)) {
    messageData.embeds = options.embeds.slice(0, 10).map(e => createAdvancedEmbed(e).toJSON());
  }
  
  // Components
  if (options.components && Array.isArray(options.components)) {
    messageData.components = createAdvancedComponents(options.components);
  }
  
  // Files
  if (options.files) {
    messageData.files = options.files;
  }
  
  // Allowed mentions
  if (options.allowedMentions) {
    messageData.allowedMentions = options.allowedMentions;
  }
  
  const message = await webhook.send(messageData);
  
  return {
    success: true,
    messageId: message.id,
    channelId: message.channelId
  };
}

/**
 * ============================================
 * MESSAGE TOOLS AVANÇADAS
 * ============================================
 */

/**
 * Envia mensagem avançada com todos os parâmetros
 */
export async function sendAdvancedMessage(channel, options) {
  const messageData = {
    content: options.content?.substring(0, 2000),
    tts: options.tts === true,
    nonce: options.nonce,
    enforceNonce: options.enforceNonce
  };
  
  // Embeds (máximo 10)
  if (options.embeds && Array.isArray(options.embeds)) {
    messageData.embeds = options.embeds.slice(0, 10).map(e => createAdvancedEmbed(e));
  }
  
  // Single embed compatibility
  if (options.embed && !options.embeds) {
    messageData.embeds = [createAdvancedEmbed(options.embed)];
  }
  
  // Components
  if (options.components && Array.isArray(options.components)) {
    messageData.components = createAdvancedComponents(options.components);
  }
  
  // Files
  if (options.files) {
    messageData.files = options.files;
  }
  
  // Reply
  if (options.replyTo || options.reference) {
    messageData.reply = {
      messageReference: options.replyTo || options.reference,
      failIfNotExists: options.failIfNotExists !== false
    };
  }
  
  // Allowed mentions
  if (options.allowedMentions || options.mentions) {
    messageData.allowedMentions = options.allowedMentions || options.mentions;
  }
  
  // Stickers
  if (options.stickers) {
    messageData.stickers = options.stickers;
  }
  
  // Flags
  if (options.flags) {
    messageData.flags = options.flags;
  }
  
  const message = await channel.send(messageData);
  
  return {
    success: true,
    messageId: message.id,
    url: message.url,
    discordMessage: message
  };
}

/**
 * ============================================
 * THREAD TOOLS AVANÇADAS
 * ============================================
 */

/**
 * Cria thread com todos os parâmetros
 */
export async function createAdvancedThread(channel, options) {
  const threadData = {
    name: options.name?.substring(0, 100) || 'Nova Thread',
    autoArchiveDuration: options.autoArchiveDuration || 60,
    type: options.type === 'private' ? ChannelType.PrivateThread : ChannelType.PublicThread,
    invitable: options.invitable !== false,
    rateLimitPerUser: options.slowmode || options.rateLimitPerUser,
    reason: options.reason
  };
  
  let thread;
  
  if (options.messageId || options.startMessage) {
    thread = await channel.threads.create({
      ...threadData,
      startMessage: options.messageId || options.startMessage
    });
  } else {
    thread = await channel.threads.create(threadData);
  }
  
  return {
    success: true,
    thread: {
      id: thread.id,
      name: thread.name,
      url: thread.url,
      mention: thread.toString()
    },
    discordThread: thread
  };
}

/**
 * ============================================
 * INVITE TOOLS AVANÇADAS
 * ============================================
 */

/**
 * Cria convite com todos os parâmetros
 */
export async function createAdvancedInvite(channel, options) {
  const inviteData = {
    maxAge: options.maxAge ?? 86400,
    maxUses: options.maxUses ?? 0,
    temporary: options.temporary === true,
    unique: options.unique === true,
    targetType: options.targetType,
    targetUserId: options.targetUserId,
    targetApplicationId: options.targetApplicationId,
    reason: options.reason
  };
  
  const invite = await channel.createInvite(inviteData);
  
  return {
    success: true,
    invite: {
      code: invite.code,
      url: invite.url,
      expiresAt: invite.expiresAt,
      maxUses: invite.maxUses,
      uses: invite.uses
    },
    discordInvite: invite
  };
}

/**
 * ============================================
 * MODERATION TOOLS AVANÇADAS
 * ============================================
 */

/**
 * Aplica timeout com todos os parâmetros
 */
export async function applyTimeout(member, options) {
  const duration = parseDuration(options.duration);
  const reason = options.reason || 'Automação';
  
  await member.timeout(duration, reason);
  
  // Enviar DM se especificado
  if (options.dmMessage) {
    try {
      const dm = await member.createDM();
      await dm.send(options.dmMessage);
    } catch (e) {
      // DM pode estar fechada
    }
  }
  
  return {
    success: true,
    userId: member.id,
    duration: options.duration,
    reason
  };
}

/**
 * Parse de duração para timeout
 */
export function parseDuration(duration) {
  if (typeof duration === 'number') return duration;
  
  if (typeof duration === 'string') {
    const match = duration.match(/^(\d+)(s|m|h|d|w)$/);
    if (match) {
      const value = parseInt(match[1]);
      const unit = match[2];
      
      const multipliers = {
        's': 1000,
        'm': 60000,
        'h': 3600000,
        'd': 86400000,
        'w': 604800000
      };
      
      const ms = value * multipliers[unit];
      
      // Discord tem limite de 28 dias para timeout
      const maxTimeout = 28 * 24 * 60 * 60 * 1000;
      return Math.min(ms, maxTimeout);
    }
    
    // Formato legado "1d 2h 3m"
    const parts = duration.match(/(\d+)([smhd])/g);
    if (parts) {
      let total = 0;
      for (const part of parts) {
        total += parseDuration(part);
      }
      return total;
    }
  }
  
  return 60000; // Default 1 minuto
}

/**
 * ============================================
 * EXPORTS
 * ============================================
 */

export default {
  createAdvancedEmbed,
  createAdvancedComponents,
  createAdvancedChannel,
  createAdvancedRole,
  sendAdvancedWebhook,
  sendAdvancedMessage,
  createAdvancedThread,
  createAdvancedInvite,
  applyTimeout,
  parseDuration,
  parseColor,
  parsePermissions
};
