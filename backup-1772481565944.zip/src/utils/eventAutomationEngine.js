/**
 * RIAS GREMORY X AI - Event-Driven Automation Engine v2.0
 * Sistema Avançado de Automações com Condições, Filtros e Parâmetros Expandidos
 * 
 * @version 2.0.0 - TURBINADO
 * @author MutanoX
 * 
 * MELHORIAS v2.0:
 * - 25+ Tipos de Triggers (eventos)
 * - 35+ Tipos de Ações
 * - Sistema de Condições (if/else/and/or)
 * - Sistema de Variáveis e Contexto
 * - Filtros Avançados (regex, palavras, regex de cargo, etc.)
 * - Cooldowns e Rate Limits
 * - Execução em Cadeia (chain actions)
 * - Placeholders Dinâmicos Expandidos
 * - Sistema de Permissões por Automação
 * - Logs e Auditoria
 */

import fs from 'fs';
import path from 'path';
import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, ChannelType, PermissionFlagsBits } from 'discord.js';

// Diretório para salvar as automações (caminho relativo para compatibilidade com hospedagem)
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const AUTOMATION_DIR = path.join(__dirname, '../../Storage/event-automations');

// Store de automações ativas por servidor
const guildAutomations = new Map();

// Store de cooldowns
const cooldownStore = new Map();

// Store de variáveis globais por servidor
const guildVariables = new Map();

// Contador de execuções para rate limiting
const executionCounter = new Map();

// Garantir que o diretório existe
function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

ensureDir(AUTOMATION_DIR);

/**
 * ============================================
 * DEFINIÇÃO DE TRIGGERS - EXPANDIDO
 * ============================================
 */
const TRIGGER_TYPES = {
  // === MENSAGENS ===
  message_in_channel: {
    name: 'Mensagem em Canal',
    description: 'Quando alguém envia mensagem em um canal específico',
    category: 'messages',
    requires: [],
    optional: ['channelId', 'channelIds', 'filters', 'ignoreBots', 'ignoreRoles', 'ignoreUsers', 'requireRoles', 'requirePermissions', 'timeRange', 'minLength', 'maxLength', 'containsAttachment', 'attachmentType', 'messageType']
  },
  message_anywhere: {
    name: 'Mensagem em Qualquer Lugar',
    description: 'Quando alguém envia mensagem em qualquer canal',
    category: 'messages',
    requires: [],
    optional: ['filters', 'ignoreBots', 'ignoreRoles', 'ignoreChannels', 'ignoreUsers']
  },
  message_edit: {
    name: 'Mensagem Editada',
    description: 'Quando uma mensagem é editada',
    category: 'messages',
    requires: [],
    optional: ['channelId', 'ignoreBots', 'logOriginal', 'filters']
  },
  message_delete: {
    name: 'Mensagem Deletada',
    description: 'Quando uma mensagem é deletada',
    category: 'messages',
    requires: [],
    optional: ['channelId', 'ignoreBots', 'logContent', 'saveDeleted']
  },
  message_pin: {
    name: 'Mensagem Fixada',
    description: 'Quando uma mensagem é fixada',
    category: 'messages',
    requires: [],
    optional: ['channelId']
  },
  message_unpin: {
    name: 'Mensagem Desfixada',
    description: 'Quando uma mensagem é desfixada',
    category: 'messages',
    requires: [],
    optional: ['channelId']
  },
  
  // === REAÇÕES ===
  reaction_add: {
    name: 'Reação Adicionada',
    description: 'Quando alguém adiciona uma reação',
    category: 'reactions',
    requires: [],
    optional: ['emoji', 'emojis', 'messageId', 'channelId', 'roleId', 'removeReaction', 'exclusive']
  },
  reaction_remove: {
    name: 'Reação Removida',
    description: 'Quando alguém remove uma reação',
    category: 'reactions',
    requires: [],
    optional: ['emoji', 'messageId', 'channelId']
  },
  reaction_remove_all: {
    name: 'Todas Reações Removidas',
    description: 'Quando todas reações de uma mensagem são removidas',
    category: 'reactions',
    requires: [],
    optional: ['messageId', 'channelId']
  },
  
  // === MEMBROS ===
  member_join: {
    name: 'Membro Entrou',
    description: 'Quando um novo membro entra no servidor',
    category: 'members',
    requires: [],
    optional: ['filters', 'welcomeMessage', 'autoRole', 'minAccountAge', 'requireAvatar']
  },
  member_leave: {
    name: 'Membro Saiu',
    description: 'Quando um membro sai do servidor',
    category: 'members',
    requires: [],
    optional: ['logChannel', 'farewellMessage', 'includeRoles', 'saveData']
  },
  member_kick: {
    name: 'Membro Expulso',
    description: 'Quando um membro é expulso',
    category: 'members',
    requires: [],
    optional: ['logChannel', 'includeReason']
  },
  member_ban: {
    name: 'Membro Banido',
    description: 'Quando um membro é banido',
    category: 'members',
    requires: [],
    optional: ['logChannel', 'includeReason']
  },
  member_unban: {
    name: 'Membro Desbanido',
    description: 'Quando um membro é desbanido',
    category: 'members',
    requires: [],
    optional: ['logChannel']
  },
  member_update: {
    name: 'Membro Atualizado',
    description: 'Quando dados do membro são atualizados (nickname, avatar, etc)',
    category: 'members',
    requires: [],
    optional: ['trackNickname', 'trackAvatar', 'trackTimeout', 'logChannel']
  },
  
  // === CARGOS ===
  role_add: {
    name: 'Cargo Adicionado',
    description: 'Quando um membro recebe um cargo',
    category: 'roles',
    requires: [],
    optional: ['roleId', 'roleIds', 'ignoreBots', 'logChannel', 'triggerActions']
  },
  role_remove: {
    name: 'Cargo Removido',
    description: 'Quando um membro perde um cargo',
    category: 'roles',
    requires: [],
    optional: ['roleId', 'roleIds', 'logChannel']
  },
  role_create: {
    name: 'Cargo Criado',
    description: 'Quando um cargo é criado no servidor',
    category: 'roles',
    requires: [],
    optional: ['logChannel']
  },
  role_delete: {
    name: 'Cargo Deletado',
    description: 'Quando um cargo é deletado do servidor',
    category: 'roles',
    requires: [],
    optional: ['logChannel']
  },
  role_update: {
    name: 'Cargo Atualizado',
    description: 'Quando um cargo é editado',
    category: 'roles',
    requires: [],
    optional: ['roleId', 'logChannel', 'trackPermissions', 'trackName', 'trackColor']
  },
  
  // === VOZ ===
  voice_join: {
    name: 'Entrou em Voz',
    description: 'Quando alguém entra em canal de voz',
    category: 'voice',
    requires: [],
    optional: ['channelId', 'channelIds', 'categoryIds', 'logChannel', 'autoRole', 'temporaryChannel']
  },
  voice_leave: {
    name: 'Saiu de Voz',
    description: 'Quando alguém sai de canal de voz',
    category: 'voice',
    requires: [],
    optional: ['channelId', 'logChannel', 'removeRole', 'deleteTemporary']
  },
  voice_switch: {
    name: 'Mudou de Canal de Voz',
    description: 'Quando alguém muda de canal de voz',
    category: 'voice',
    requires: [],
    optional: ['fromChannelId', 'toChannelId', 'logChannel']
  },
  voice_mute: {
    name: 'Mutou/Desmutou Microfone',
    description: 'Quando alguém muta ou desmuta o microfone',
    category: 'voice',
    requires: [],
    optional: ['channelId']
  },
  voice_deafen: {
    name: 'Mutou/Desmutou Áudio',
    description: 'Quando alguém muta ou desmuta o áudio (ouvidos)',
    category: 'voice',
    requires: [],
    optional: ['channelId']
  },
  voice_stream: {
    name: 'Iniciou/Parou Stream',
    description: 'Quando alguém inicia ou para uma live em voz',
    category: 'voice',
    requires: [],
    optional: ['channelId', 'logChannel']
  },
  voice_video: {
    name: 'Ligou/Desligou Câmera',
    description: 'Quando alguém liga ou desliga a câmera',
    category: 'voice',
    requires: [],
    optional: ['channelId']
  },
  
  // === CANAIS ===
  channel_create: {
    name: 'Canal Criado',
    description: 'Quando um canal é criado',
    category: 'channels',
    requires: [],
    optional: ['logChannel', 'channelType']
  },
  channel_delete: {
    name: 'Canal Deletado',
    description: 'Quando um canal é deletado',
    category: 'channels',
    requires: [],
    optional: ['logChannel', 'saveData']
  },
  channel_update: {
    name: 'Canal Atualizado',
    description: 'Quando um canal é editado',
    category: 'channels',
    requires: [],
    optional: ['channelId', 'logChannel', 'trackName', 'trackPermissions', 'trackTopic']
  },
  channel_pins_update: {
    name: 'Pins Atualizados',
    description: 'Quando mensagens fixadas são atualizadas',
    category: 'channels',
    requires: [],
    optional: ['channelId', 'logChannel']
  },
  
  // === BOOST ===
  boost_add: {
    name: 'Membro Deu Boost',
    description: 'Quando um membro impulsiona o servidor',
    category: 'server',
    requires: [],
    optional: ['rewardRole', 'rewardMessage', 'logChannel', 'giveCoins', 'giveXP']
  },
  boost_remove: {
    name: 'Membro Removeu Boost',
    description: 'Quando um membro remove o boost',
    category: 'server',
    requires: [],
    optional: ['removeRole', 'logChannel']
  },
  server_boost_level: {
    name: 'Nível de Boost Alcançado',
    description: 'Quando o servidor alcança um novo nível de boost',
    category: 'server',
    requires: ['level'],
    optional: ['logChannel', 'rewardRole', 'announce']
  },
  
  // === SERVIDOR ===
  server_update: {
    name: 'Servidor Atualizado',
    description: 'Quando configurações do servidor são alteradas',
    category: 'server',
    requires: [],
    optional: ['logChannel', 'trackName', 'trackIcon', 'trackBanner', 'trackDescription']
  },
  emoji_create: {
    name: 'Emoji Criado',
    description: 'Quando um emoji é adicionado ao servidor',
    category: 'server',
    requires: [],
    optional: ['logChannel']
  },
  emoji_delete: {
    name: 'Emoji Deletado',
    description: 'Quando um emoji é removido do servidor',
    category: 'server',
    requires: [],
    optional: ['logChannel']
  },
  emoji_update: {
    name: 'Emoji Atualizado',
    description: 'Quando um emoji é renomeado',
    category: 'server',
    requires: [],
    optional: ['logChannel']
  },
  sticker_create: {
    name: 'Sticker Criado',
    description: 'Quando um sticker é adicionado',
    category: 'server',
    requires: [],
    optional: ['logChannel']
  },
  sticker_delete: {
    name: 'Sticker Deletado',
    description: 'Quando um sticker é removido',
    category: 'server',
    requires: [],
    optional: ['logChannel']
  },
  
  // === INTERAÇÕES ===
  button_click: {
    name: 'Botão Clicado',
    description: 'Quando alguém clica em um botão',
    category: 'interactions',
    requires: ['buttonId'],
    optional: ['channelId', 'userId', 'roleId']
  },
  select_menu: {
    name: 'Menu Selecionado',
    description: 'Quando alguém seleciona uma opção em um menu',
    category: 'interactions',
    requires: ['menuId'],
    optional: ['channelId', 'values']
  },
  modal_submit: {
    name: 'Modal Enviado',
    description: 'Quando alguém envia um formulário modal',
    category: 'interactions',
    requires: ['modalId'],
    optional: ['channelId']
  },
  
  // === THREADS ===
  thread_create: {
    name: 'Thread Criada',
    description: 'Quando uma thread é criada',
    category: 'threads',
    requires: [],
    optional: ['channelId', 'logChannel', 'autoJoin']
  },
  thread_delete: {
    name: 'Thread Deletada',
    description: 'Quando uma thread é deletada',
    category: 'threads',
    requires: [],
    optional: ['logChannel']
  },
  thread_update: {
    name: 'Thread Atualizada',
    description: 'Quando uma thread é atualizada',
    category: 'threads',
    requires: [],
    optional: ['logChannel']
  },
  thread_member_join: {
    name: 'Entrou na Thread',
    description: 'Quando alguém entra em uma thread',
    category: 'threads',
    requires: [],
    optional: ['threadId']
  },
  thread_member_leave: {
    name: 'Saiu da Thread',
    description: 'Quando alguém sai de uma thread',
    category: 'threads',
    requires: [],
    optional: ['threadId']
  },
  
  // === INVITES ===
  invite_create: {
    name: 'Convite Criado',
    description: 'Quando um convite é criado',
    category: 'invites',
    requires: [],
    optional: ['logChannel', 'trackUses']
  },
  invite_delete: {
    name: 'Convite Deletado',
    description: 'Quando um convite é deletado',
    category: 'invites',
    requires: [],
    optional: ['logChannel']
  },
  
  // === WEBHOOKS ===
  webhook_create: {
    name: 'Webhook Criado',
    description: 'Quando um webhook é criado',
    category: 'webhooks',
    requires: [],
    optional: ['logChannel']
  },
  webhook_delete: {
    name: 'Webhook Deletado',
    description: 'Quando um webhook é deletado',
    category: 'webhooks',
    requires: [],
    optional: ['logChannel']
  },
  webhook_update: {
    name: 'Webhook Atualizado',
    description: 'Quando um webhook é atualizado',
    category: 'webhooks',
    requires: [],
    optional: ['logChannel']
  },
  
  // === AGENDADO ===
  scheduled: {
    name: 'Agendado',
    description: 'Executa em horário específico ou intervalo',
    category: 'scheduled',
    requires: [],
    optional: ['cron', 'interval', 'timezone', 'startTime', 'endTime']
  },
  
  // === CUSTOM ===
  custom_command: {
    name: 'Comando Customizado',
    description: 'Quando um comando customizado é usado',
    category: 'custom',
    requires: ['commandName'],
    optional: ['aliases', 'cooldown', 'permissions', 'roles']
  },
  api_webhook: {
    name: 'API Webhook',
    description: 'Quando recebe uma requisição via API webhook',
    category: 'custom',
    requires: ['endpoint'],
    optional: ['method', 'auth', 'rateLimit']
  }
};

/**
 * ============================================
 * DEFINIÇÃO DE AÇÕES - EXPANDIDO
 * ============================================
 */
const ACTION_TYPES = {
  // === MENSAGENS ===
  delete_message: {
    name: 'Deletar Mensagem',
    description: 'Remove a mensagem que triggered a automação',
    category: 'messages',
    params: ['reason', 'delay'],
    timeout: false
  },
  send_dm: {
    name: 'Enviar DM',
    description: 'Envia mensagem privada para o usuário',
    category: 'messages',
    params: ['message', 'embed', 'components', 'files', 'tts'],
    timeout: false
  },
  send_channel: {
    name: 'Enviar no Canal',
    description: 'Envia mensagem em um canal específico',
    category: 'messages',
    params: ['channelId', 'message', 'embed', 'components', 'files', 'tts', 'threadId'],
    timeout: false
  },
  reply_message: {
    name: 'Responder Mensagem',
    description: 'Responde a mensagem que triggered',
    category: 'messages',
    params: ['message', 'embed', 'components', 'mention', 'tts'],
    timeout: false
  },
  edit_message: {
    name: 'Editar Mensagem',
    description: 'Edita uma mensagem existente',
    category: 'messages',
    params: ['messageId', 'channelId', 'message', 'embed'],
    timeout: false
  },
  pin_message: {
    name: 'Fixar Mensagem',
    description: 'Fixa a mensagem no canal',
    category: 'messages',
    params: ['reason'],
    timeout: false
  },
  unpin_message: {
    name: 'Desfixar Mensagem',
    description: 'Remove a fixação da mensagem',
    category: 'messages',
    params: ['messageId', 'channelId'],
    timeout: false
  },
  react_message: {
    name: 'Reagir à Mensagem',
    description: 'Adiciona reações à mensagem',
    category: 'messages',
    params: ['emojis', 'channelId', 'messageId'],
    timeout: false
  },
  remove_reaction: {
    name: 'Remover Reação',
    description: 'Remove uma reação da mensagem',
    category: 'messages',
    params: ['emoji', 'userId', 'channelId', 'messageId'],
    timeout: false
  },
  crosspost_message: {
    name: 'Publicar Mensagem (Anúncio)',
    description: 'Publica mensagem em canais que seguem',
    category: 'messages',
    params: ['messageId', 'channelId'],
    timeout: false
  },
  
  // === CANAIS ===
  create_thread: {
    name: 'Criar Thread',
    description: 'Cria uma thread na mensagem ou canal',
    category: 'channels',
    params: ['threadName', 'channelId', 'messageId', 'autoArchiveDuration', 'type', 'invitable', 'slowmode'],
    timeout: false
  },
  delete_thread: {
    name: 'Deletar Thread',
    description: 'Deleta uma thread',
    category: 'channels',
    params: ['threadId'],
    timeout: false
  },
  lock_thread: {
    name: 'Trancar Thread',
    description: 'Tranca uma thread para novas mensagens',
    category: 'channels',
    params: ['threadId', 'reason'],
    timeout: false
  },
  unlock_thread: {
    name: 'Destrancar Thread',
    description: 'Destranca uma thread',
    category: 'channels',
    params: ['threadId'],
    timeout: false
  },
  set_slowmode: {
    name: 'Definir Slowmode',
    description: 'Define o slowmode do canal',
    category: 'channels',
    params: ['seconds', 'channelId', 'reason'],
    timeout: false
  },
  lock_channel: {
    name: 'Trancar Canal',
    description: 'Tranca o canal para @everyone',
    category: 'channels',
    params: ['channelId', 'roleId', 'reason'],
    timeout: false
  },
  unlock_channel: {
    name: 'Destravar Canal',
    description: 'Destrava o canal para @everyone',
    category: 'channels',
    params: ['channelId', 'roleId', 'reason'],
    timeout: false
  },
  create_channel: {
    name: 'Criar Canal',
    description: 'Cria um novo canal',
    category: 'channels',
    params: ['name', 'type', 'parentId', 'topic', 'slowmode', 'nsfw', 'position', 'permissions'],
    timeout: false
  },
  delete_channel: {
    name: 'Deletar Canal',
    description: 'Deleta um canal',
    category: 'channels',
    params: ['channelId', 'reason'],
    timeout: false
  },
  edit_channel: {
    name: 'Editar Canal',
    description: 'Edita configurações do canal',
    category: 'channels',
    params: ['channelId', 'name', 'topic', 'slowmode', 'nsfw', 'position', 'parentId'],
    timeout: false
  },
  create_category: {
    name: 'Criar Categoria',
    description: 'Cria uma nova categoria',
    category: 'channels',
    params: ['name', 'position', 'permissions'],
    timeout: false
  },
  
  // === CARGOS ===
  add_role: {
    name: 'Adicionar Cargo',
    description: 'Adiciona um cargo ao usuário',
    category: 'roles',
    params: ['roleId', 'roleIds', 'reason', 'removeOthers'],
    timeout: false
  },
  remove_role: {
    name: 'Remover Cargo',
    description: 'Remove um cargo do usuário',
    category: 'roles',
    params: ['roleId', 'roleIds', 'reason'],
    timeout: false
  },
  create_role: {
    name: 'Criar Cargo',
    description: 'Cria um novo cargo no servidor',
    category: 'roles',
    params: ['name', 'color', 'hoist', 'mentionable', 'permissions', 'position', 'icon', 'unicodeEmoji'],
    timeout: false
  },
  delete_role: {
    name: 'Deletar Cargo',
    description: 'Deleta um cargo do servidor',
    category: 'roles',
    params: ['roleId', 'reason'],
    timeout: false
  },
  edit_role: {
    name: 'Editar Cargo',
    description: 'Edita configurações de um cargo',
    category: 'roles',
    params: ['roleId', 'name', 'color', 'hoist', 'mentionable', 'permissions'],
    timeout: false
  },
  
  // === MEMBROS ===
  kick: {
    name: 'Expulsar',
    description: 'Expulsa o usuário do servidor',
    category: 'members',
    params: ['reason', 'dmMessage'],
    timeout: false
  },
  ban: {
    name: 'Banir',
    description: 'Bane o usuário do servidor',
    category: 'members',
    params: ['reason', 'deleteMessageDays', 'dmMessage'],
    timeout: false
  },
  unban: {
    name: 'Desbanir',
    description: 'Remove o ban do usuário',
    category: 'members',
    params: ['userId', 'reason'],
    timeout: false
  },
  mute: {
    name: 'Mutear (Timeout)',
    description: 'Coloca o usuário em timeout',
    category: 'members',
    params: ['duration', 'reason', 'dmMessage'],
    timeout: false
  },
  unmute: {
    name: 'Desmutear',
    description: 'Remove o timeout do usuário',
    category: 'members',
    params: ['reason'],
    timeout: false
  },
  change_nickname: {
    name: 'Mudar Apelido',
    description: 'Altera o apelido do usuário',
    category: 'members',
    params: ['nickname', 'reason'],
    timeout: false
  },
  deafen: {
    name: 'Ensurdecer',
    description: 'Muta o áudio do usuário em voz',
    category: 'members',
    params: ['reason'],
    timeout: false
  },
  undeafen: {
    name: 'Desensurdecer',
    description: 'Desmuta o áudio do usuário em voz',
    category: 'members',
    params: ['reason'],
    timeout: false
  },
  disconnect_voice: {
    name: 'Desconectar de Voz',
    description: 'Desconecta o usuário do canal de voz',
    category: 'members',
    params: ['reason'],
    timeout: false
  },
  move_voice: {
    name: 'Mover de Voz',
    description: 'Move o usuário para outro canal de voz',
    category: 'members',
    params: ['targetChannelId', 'reason'],
    timeout: false
  },
  add_xp: {
    name: 'Adicionar XP',
    description: 'Adiciona XP ao usuário (sistema de níveis)',
    category: 'members',
    params: ['amount'],
    timeout: false
  },
  add_coins: {
    name: 'Adicionar Moedas',
    description: 'Adiciona moedas ao usuário (economia)',
    category: 'members',
    params: ['amount'],
    timeout: false
  },
  warn: {
    name: 'Dar Aviso',
    description: 'Adiciona um aviso ao usuário',
    category: 'members',
    params: ['reason', 'dmMessage'],
    timeout: false
  },
  
  // === MODERAÇÃO ===
  bulk_delete: {
    name: 'Deletar Múltiplas Mensagens',
    description: 'Deleta várias mensagens de uma vez',
    category: 'moderation',
    params: ['count', 'channelId', 'userId', 'before', 'after'],
    timeout: false
  },
  lock_server: {
    name: 'Trancar Servidor',
    description: 'Tranca todos os canais para @everyone',
    category: 'moderation',
    params: ['reason', 'ignoreChannels'],
    timeout: false
  },
  unlock_server: {
    name: 'Destravar Servidor',
    description: 'Destrava todos os canais',
    category: 'moderation',
    params: ['reason'],
    timeout: false
  },
  
  // === LOGS ===
  log: {
    name: 'Registrar Log',
    description: 'Registra a ação em um canal de logs',
    category: 'logs',
    params: ['logChannelId', 'embed', 'message'],
    timeout: false
  },
  save_to_database: {
    name: 'Salvar no Banco',
    description: 'Salva dados em arquivo JSON',
    category: 'logs',
    params: ['key', 'value', 'table'],
    timeout: false
  },
  
  // === WEBHOOKS ===
  send_webhook: {
    name: 'Enviar via Webhook',
    description: 'Envia mensagem usando um webhook',
    category: 'webhooks',
    params: ['webhookUrl', 'message', 'embed', 'username', 'avatarUrl', 'threadName'],
    timeout: false
  },
  create_webhook: {
    name: 'Criar Webhook',
    description: 'Cria um novo webhook no canal',
    category: 'webhooks',
    params: ['name', 'channelId', 'avatar'],
    timeout: false
  },
  
  // === CONVITES ===
  create_invite: {
    name: 'Criar Convite',
    description: 'Cria um convite para o canal',
    category: 'invites',
    params: ['channelId', 'maxAge', 'maxUses', 'temporary', 'unique'],
    timeout: false
  },
  delete_invite: {
    name: 'Deletar Convite',
    description: 'Deleta um convite existente',
    category: 'invites',
    params: ['code'],
    timeout: false
  },
  
  // === EMBEDS COMPONENTES ===
  send_embed: {
    name: 'Enviar Embed',
    description: 'Envia um embed avançado',
    category: 'embeds',
    params: ['channelId', 'embed', 'components', 'threadId'],
    timeout: false
  },
  send_buttons: {
    name: 'Enviar com Botões',
    description: 'Envia mensagem com botões interativos',
    category: 'embeds',
    params: ['channelId', 'message', 'embed', 'buttons', 'threadId'],
    timeout: false
  },
  send_select_menu: {
    name: 'Enviar com Menu',
    description: 'Envia mensagem com menu de seleção',
    category: 'embeds',
    params: ['channelId', 'message', 'embed', 'selectMenu', 'threadId'],
    timeout: false
  },
  send_modal: {
    name: 'Mostrar Modal',
    description: 'Mostra um formulário modal para o usuário',
    category: 'embeds',
    params: ['title', 'customId', 'components'],
    timeout: false
  },
  
  // === CONDICIONAIS ===
  condition: {
    name: 'Condição (If/Else)',
    description: 'Executa ações baseado em condições',
    category: 'logic',
    params: ['conditions', 'thenActions', 'elseActions'],
    timeout: false
  },
  random_action: {
    name: 'Ação Aleatória',
    description: 'Executa uma ação aleatória de uma lista',
    category: 'logic',
    params: ['actions', 'weights'],
    timeout: false
  },
  wait: {
    name: 'Aguardar',
    description: 'Aguarda antes de executar próxima ação',
    category: 'logic',
    params: ['duration'],
    timeout: false
  },
  loop: {
    name: 'Repetir',
    description: 'Repete ações um número de vezes',
    category: 'logic',
    params: ['count', 'actions', 'delay'],
    timeout: false
  },
  
  // === VARIÁVEIS ===
  set_variable: {
    name: 'Definir Variável',
    description: 'Define uma variável para uso posterior',
    category: 'variables',
    params: ['name', 'value', 'scope'],
    timeout: false
  },
  increment_variable: {
    name: 'Incrementar Variável',
    description: 'Incrementa uma variável numérica',
    category: 'variables',
    params: ['name', 'amount'],
    timeout: false
  },
  
  // === EXTERNAS ===
  http_request: {
    name: 'Requisição HTTP',
    description: 'Faz uma requisição HTTP',
    category: 'external',
    params: ['url', 'method', 'headers', 'body', 'saveResponse'],
    timeout: true
  }
};

/**
 * ============================================
 * SISTEMA DE CONDIÇÕES
 * ============================================
 */
const CONDITION_OPERATORS = {
  // Comparação
  equals: (a, b) => a === b,
  not_equals: (a, b) => a !== b,
  contains: (a, b) => String(a).includes(String(b)),
  not_contains: (a, b) => !String(a).includes(String(b)),
  starts_with: (a, b) => String(a).startsWith(String(b)),
  ends_with: (a, b) => String(a).endsWith(String(b)),
  
  // Numéricos
  greater_than: (a, b) => Number(a) > Number(b),
  less_than: (a, b) => Number(a) < Number(b),
  greater_or_equal: (a, b) => Number(a) >= Number(b),
  less_or_equal: (a, b) => Number(a) <= Number(b),
  between: (a, b, c) => Number(a) >= Number(b) && Number(a) <= Number(c),
  
  // Listas
  in_list: (a, b) => Array.isArray(b) && b.includes(a),
  not_in_list: (a, b) => Array.isArray(b) && !b.includes(a),
  
  // Regex
  matches_regex: (a, b) => new RegExp(b).test(String(a)),
  not_matches_regex: (a, b) => !new RegExp(b).test(String(a)),
  
  // Discord específico
  has_role: (member, roleId) => member?.roles?.cache?.has(roleId),
  not_has_role: (member, roleId) => !member?.roles?.cache?.has(roleId),
  has_any_role: (member, roleIds) => roleIds?.some(r => member?.roles?.cache?.has(r)),
  has_all_roles: (member, roleIds) => roleIds?.every(r => member?.roles?.cache?.has(r)),
  has_permission: (member, permission) => member?.permissions?.has(permission),
  in_channel: (channel, channelId) => channel?.id === channelId,
  is_bot: (user) => user?.bot === true,
  is_nitro: (user) => user?.premiumType !== null,
  is_boosting: (member) => member?.premiumSince !== null,
  
  // Tempo
  is_weekend: () => [0, 6].includes(new Date().getDay()),
  is_weekday: () => ![0, 6].includes(new Date().getDay()),
  time_between: (start, end) => {
    const now = new Date().getHours() * 60 + new Date().getMinutes();
    return now >= start && now <= end;
  },
  
  // Contadores
  message_count_above: (count, context) => (context?.messageCount || 0) >= count,
  user_message_count_above: (userId, count, context) => (context?.userMessageCounts?.[userId] || 0) >= count
};

/**
 * ============================================
 * SISTEMA DE PLACEHOLDERS EXPANDIDO
 * ============================================
 */
const PLACEHOLDERS = {
  // Usuário
  '{user}': (data) => data.user?.toString() || 'Usuário',
  '{user.id}': (data) => data.user?.id || '0',
  '{user.name}': (data) => data.user?.username || 'Desconhecido',
  '{user.tag}': (data) => data.user?.tag || 'Desconhecido#0000',
  '{user.discriminator}': (data) => data.user?.discriminator || '0000',
  '{user.avatar}': (data) => data.user?.displayAvatarURL({ size: 512 }) || '',
  '{user.banner}': (data) => data.user?.bannerURL() || '',
  '{user.mention}': (data) => `<@${data.user?.id}>`,
  '{user.bot}': (data) => data.user?.bot ? 'Sim' : 'Não',
  '{user.createdAt}': (data) => data.user?.createdAt ? new Date(data.user.createdAt).toLocaleDateString('pt-BR') : '',
  '{user.createdTimestamp}': (data) => data.user?.createdTimestamp || 0,
  '{user.accountAge}': (data) => {
    if (!data.user?.createdTimestamp) return 'Desconhecido';
    const age = Date.now() - data.user.createdTimestamp;
    const days = Math.floor(age / (1000 * 60 * 60 * 24));
    return `${days} dias`;
  },
  
  // Membro
  '{member.nickname}': (data) => data.member?.nickname || data.user?.username || '',
  '{member.joinedAt}': (data) => data.member?.joinedAt ? new Date(data.member.joinedAt).toLocaleDateString('pt-BR') : '',
  '{member.joinedTimestamp}': (data) => data.member?.joinedTimestamp || 0,
  '{member.premiumSince}': (data) => data.member?.premiumSince ? new Date(data.member.premiumSince).toLocaleDateString('pt-BR') : 'Não',
  '{member.highestRole}': (data) => data.member?.roles?.highest?.name || 'Nenhum',
  '{member.highestRole.mention}': (data) => data.member?.roles?.highest?.toString() || '',
  '{member.colorRole}': (data) => data.member?.roles?.color?.name || 'Nenhum',
  '{member.displayColor}': (data) => data.member?.displayHexColor || '#000000',
  '{member.roles.count}': (data) => data.member?.roles?.cache?.size || 0,
  '{member.roles.list}': (data) => data.member?.roles?.cache?.map(r => r.name).join(', ') || '',
  '{member.roles.mentions}': (data) => data.member?.roles?.cache?.map(r => r.toString()).join(' ') || '',
  
  // Servidor
  '{server}': (data) => data.guild?.name || 'Servidor',
  '{server.id}': (data) => data.guild?.id || '0',
  '{server.icon}': (data) => data.guild?.iconURL({ size: 512 }) || '',
  '{server.banner}': (data) => data.guild?.bannerURL() || '',
  '{server.splash}': (data) => data.guild?.splashURL() || '',
  '{server.members}': (data) => data.guild?.memberCount || 0,
  '{server.members.online}': (data) => data.guild?.presences?.cache?.size || 0,
  '{server.channels}': (data) => data.guild?.channels?.cache?.size || 0,
  '{server.roles}': (data) => data.guild?.roles?.cache?.size || 0,
  '{server.emojis}': (data) => data.guild?.emojis?.cache?.size || 0,
  '{server.boostLevel}': (data) => data.guild?.premiumTier || 0,
  '{server.boostCount}': (data) => data.guild?.premiumSubscriptionCount || 0,
  '{server.createdAt}': (data) => data.guild?.createdAt ? new Date(data.guild.createdAt).toLocaleDateString('pt-BR') : '',
  '{server.owner}': (data) => `<@${data.guild?.ownerId}>`,
  '{server.ownerId}': (data) => data.guild?.ownerId || '',
  '{server.vanityURL}': (data) => data.guild?.vanityURLCode ? `discord.gg/${data.guild.vanityURLCode}` : '',
  '{server.description}': (data) => data.guild?.description || '',
  
  // Canal
  '{channel}': (data) => data.channel?.toString() || 'Canal',
  '{channel.id}': (data) => data.channel?.id || '0',
  '{channel.name}': (data) => data.channel?.name || 'Desconhecido',
  '{channel.topic}': (data) => data.channel?.topic || '',
  '{channel.type}': (data) => {
    const types = { 0: 'Texto', 2: 'Voz', 4: 'Categoria', 5: 'Anúncio', 10: 'Thread', 11: 'Thread Pública', 12: 'Thread Privada', 13: 'Stage' };
    return types[data.channel?.type] || 'Desconhecido';
  },
  '{channel.mention}': (data) => `<#${data.channel?.id}>`,
  '{channel.nsfw}': (data) => data.channel?.nsfw ? 'Sim' : 'Não',
  '{channel.slowmode}': (data) => data.channel?.rateLimitPerUser ? `${data.channel.rateLimitPerUser}s` : 'Desativado',
  '{channel.parent}': (data) => data.channel?.parent?.name || 'Nenhuma',
  '{channel.position}': (data) => data.channel?.position || 0,
  
  // Mensagem
  '{message}': (data) => data.message?.content || '',
  '{message.id}': (data) => data.message?.id || '0',
  '{message.content}': (data) => data.message?.content || '',
  '{message.cleanContent}': (data) => data.message?.cleanContent || '',
  '{message.length}': (data) => data.message?.content?.length || 0,
  '{message.createdAt}': (data) => data.message?.createdAt ? new Date(data.message.createdAt).toLocaleString('pt-BR') : '',
  '{message.url}': (data) => data.message?.url || '',
  '{message.attachments}': (data) => data.message?.attachments?.size || 0,
  '{message.attachmentUrls}': (data) => data.message?.attachments?.map(a => a.url).join('\n') || '',
  '{message.mentions.users}': (data) => data.message?.mentions?.users?.map(u => u.toString()).join(' ') || '',
  '{message.mentions.roles}': (data) => data.message?.mentions?.roles?.map(r => r.toString()).join(' ') || '',
  '{message.mentions.channels}': (data) => data.message?.mentions?.channels?.map(c => c.toString()).join(' ') || '',
  '{message.reactions.count}': (data) => data.message?.reactions?.cache?.reduce((acc, r) => acc + r.count, 0) || 0,
  '{message.editedAt}': (data) => data.message?.editedAt ? new Date(data.message.editedAt).toLocaleString('pt-BR') : 'Nunca',
  
  // Mensagem Antiga (para edits)
  '{oldMessage}': (data) => data.oldMessage?.content || '',
  '{oldMessage.length}': (data) => data.oldMessage?.content?.length || 0,
  
  // Reação
  '{reaction.emoji}': (data) => data.reaction?.emoji?.toString() || '',
  '{reaction.emoji.name}': (data) => data.reaction?.emoji?.name || '',
  '{reaction.emoji.id}': (data) => data.reaction?.emoji?.id || '',
  '{reaction.count}': (data) => data.reaction?.count || 0,
  
  // Voz
  '{voice.channel}': (data) => data.voiceState?.channel?.toString() || '',
  '{voice.channel.name}': (data) => data.voiceState?.channel?.name || '',
  '{voice.channel.id}': (data) => data.voiceState?.channelId || '',
  '{voice.mute}': (data) => data.voiceState?.mute ? 'Sim' : 'Não',
  '{voice.deaf}': (data) => data.voiceState?.deaf ? 'Sim' : 'Não',
  '{voice.selfMute}': (data) => data.voiceState?.selfMute ? 'Sim' : 'Não',
  '{voice.selfDeaf}': (data) => data.voiceState?.selfDeaf ? 'Sim' : 'Não',
  '{voice.streaming}': (data) => data.voiceState?.streaming ? 'Sim' : 'Não',
  '{voice.video}': (data) => data.voiceState?.selfVideo ? 'Sim' : 'Não',
  
  // Cargo
  '{role}': (data) => data.role?.toString() || '',
  '{role.name}': (data) => data.role?.name || '',
  '{role.id}': (data) => data.role?.id || '',
  '{role.color}': (data) => data.role?.hexColor || '#000000',
  '{role.position}': (data) => data.role?.position || 0,
  '{role.members}': (data) => data.role?.members?.size || 0,
  
  // Tempo
  '{date}': () => new Date().toLocaleDateString('pt-BR'),
  '{time}': () => new Date().toLocaleTimeString('pt-BR'),
  '{datetime}': () => new Date().toLocaleString('pt-BR'),
  '{timestamp}': () => `<t:${Math.floor(Date.now() / 1000)}:R>`,
  '{timestamp.short}': () => `<t:${Math.floor(Date.now() / 1000)}:t>`,
  '{timestamp.long}': () => `<t:${Math.floor(Date.now() / 1000)}:T>`,
  '{timestamp.date}': () => `<t:${Math.floor(Date.now() / 1000)}:d>`,
  '{timestamp.full}': () => `<t:${Math.floor(Date.now() / 1000)}:F>`,
  '{year}': () => new Date().getFullYear().toString(),
  '{month}': () => (new Date().getMonth() + 1).toString().padStart(2, '0'),
  '{day}': () => new Date().getDate().toString().padStart(2, '0'),
  '{hour}': () => new Date().getHours().toString().padStart(2, '0'),
  '{minute}': () => new Date().getMinutes().toString().padStart(2, '0'),
  '{weekday}': () => ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'][new Date().getDay()],
  
  // Automação
  '{automation}': (data) => data.automation?.name || '',
  '{automation.id}': (data) => data.automation?.id || '',
  '{automation.trigger}': (data) => data.automation?.trigger || '',
  '{automation.executions}': (data) => data.automation?.triggerCount || 0,
  
  // Variáveis customizadas
  '{var:': (data, name) => data.variables?.[name] || '',
  
  // Random
  '{random}': () => Math.random().toString(36).substring(7),
  '{random.number}': () => Math.floor(Math.random() * 10000).toString(),
  '{random.uuid}': () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => (Math.random() * 16 | 0).toString(16))
};

/**
 * Classe que representa uma Automação Event-Driven Avançada
 */
class EventAutomation {
  constructor(guildId, config) {
    this.id = config.id || `${guildId}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    this.guildId = guildId;
    this.name = config.name || 'Automação sem nome';
    this.description = config.description || '';
    this.trigger = config.trigger;
    this.triggerConfig = config.triggerConfig || {};
    this.conditions = config.conditions || []; // Novo: condições para executar
    this.actions = config.actions || [];
    this.elseActions = config.elseActions || []; // Novo: ações se condição falhar
    this.enabled = config.enabled !== false;
    this.cooldown = config.cooldown || 0; // Novo: cooldown em segundos
    this.cooldownPerUser = config.cooldownPerUser || false; // Novo: cooldown por usuário
    this.maxExecutions = config.maxExecutions || 0; // Novo: máximo de execuções (0 = ilimitado)
    this.executionWindow = config.executionWindow || null; // Novo: janela de tempo para maxExecutions
    this.requirePermissions = config.requirePermissions || []; // Novo: permissões necessárias
    this.requireRoles = config.requireRoles || []; // Novo: cargos necessários
    this.ignoreRoles = config.ignoreRoles || [];
    this.ignoreUsers = config.ignoreUsers || [];
    this.priority = config.priority || 0; // Novo: prioridade de execução
    this.logExecutions = config.logExecutions || false; // Novo: log de execuções
    this.variables = config.variables || {}; // Novo: variáveis da automação
    this.createdAt = config.createdAt || new Date().toISOString();
    this.triggerCount = config.triggerCount || 0;
    this.lastTriggered = config.lastTriggered || null;
    this.createdBy = config.createdBy || null;
  }

  /**
   * Salva a automação no disco
   */
  save() {
    const guildDir = path.join(AUTOMATION_DIR, this.guildId);
    ensureDir(guildDir);
    
    const filePath = path.join(guildDir, `${this.id}.json`);
    
    const data = {
      id: this.id,
      guildId: this.guildId,
      name: this.name,
      description: this.description,
      trigger: this.trigger,
      triggerConfig: this.triggerConfig,
      conditions: this.conditions,
      actions: this.actions,
      elseActions: this.elseActions,
      enabled: this.enabled,
      cooldown: this.cooldown,
      cooldownPerUser: this.cooldownPerUser,
      maxExecutions: this.maxExecutions,
      executionWindow: this.executionWindow,
      requirePermissions: this.requirePermissions,
      requireRoles: this.requireRoles,
      ignoreRoles: this.ignoreRoles,
      ignoreUsers: this.ignoreUsers,
      priority: this.priority,
      logExecutions: this.logExecutions,
      variables: this.variables,
      createdAt: this.createdAt,
      triggerCount: this.triggerCount,
      lastTriggered: this.lastTriggered,
      createdBy: this.createdBy
    };
    
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  }

  /**
   * Remove a automação
   */
  delete() {
    const filePath = path.join(AUTOMATION_DIR, this.guildId, `${this.id}.json`);
    
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
    
    const automations = guildAutomations.get(this.guildId);
    if (automations) {
      automations.delete(this.id);
    }
  }

  /**
   * Verifica cooldown
   */
  checkCooldown(userId = null) {
    if (this.cooldown <= 0) return true;
    
    const key = this.cooldownPerUser ? `${this.id}_${userId}` : this.id;
    const lastExecution = cooldownStore.get(key);
    
    if (!lastExecution) return true;
    
    const elapsed = (Date.now() - lastExecution) / 1000;
    return elapsed >= this.cooldown;
  }

  /**
   * Define cooldown
   */
  setCooldown(userId = null) {
    if (this.cooldown <= 0) return;
    
    const key = this.cooldownPerUser ? `${this.id}_${userId}` : this.id;
    cooldownStore.set(key, Date.now());
  }

  /**
   * Verifica rate limit (maxExecutions)
   */
  checkRateLimit() {
    if (this.maxExecutions <= 0 || !this.executionWindow) return true;
    
    const now = Date.now();
    const windowMs = this.parseDuration(this.executionWindow);
    
    if (!executionCounter.has(this.id)) {
      executionCounter.set(this.id, []);
    }
    
    const executions = executionCounter.get(this.id);
    
    // Remover execuções antigas
    const validExecutions = executions.filter(t => now - t < windowMs);
    executionCounter.set(this.id, validExecutions);
    
    return validExecutions.length < this.maxExecutions;
  }

  /**
   * Registra execução para rate limit
   */
  recordExecution() {
    if (this.maxExecutions <= 0 || !this.executionWindow) return;
    
    if (!executionCounter.has(this.id)) {
      executionCounter.set(this.id, []);
    }
    
    executionCounter.get(this.id).push(Date.now());
  }

  /**
   * Verifica se o trigger deve ser acionado
   */
  shouldTrigger(event, data) {
    if (!this.enabled) return false;
    
    const { message, user, member } = data;
    
    // Verificar ignorados
    if (this.ignoreUsers?.length > 0 && user?.id && this.ignoreUsers.includes(user.id)) {
      return false;
    }
    
    if (this.ignoreRoles?.length > 0 && member) {
      const memberRoles = member.roles.cache.map(r => r.id);
      if (this.ignoreRoles.some(r => memberRoles.includes(r))) {
        return false;
      }
    }
    
    // Verificar permissões necessárias
    if (this.requirePermissions?.length > 0 && member) {
      const hasPerms = this.requirePermissions.every(perm => 
        member.permissions.has(perm)
      );
      if (!hasPerms) return false;
    }
    
    // Verificar cargos necessários
    if (this.requireRoles?.length > 0 && member) {
      const hasRole = this.requireRoles.some(roleId => 
        member.roles.cache.has(roleId)
      );
      if (!hasRole) return false;
    }
    
    // Verificar cooldown
    if (!this.checkCooldown(user?.id)) return false;
    
    // Verificar rate limit
    if (!this.checkRateLimit()) return false;
    
    // Verificar trigger específico
    return this.checkSpecificTrigger(event, data);
  }

  /**
   * Verifica trigger específico
   */
  checkSpecificTrigger(event, data) {
    const config = this.triggerConfig;
    
    switch (this.trigger) {
      case 'message_in_channel':
      case 'message_anywhere':
        return this.checkMessageTrigger(data);
        
      case 'member_join':
        return this.checkMemberJoin(data);
        
      case 'member_leave':
        return this.checkMemberLeave(data);
        
      case 'reaction_add':
      case 'reaction_remove':
        return this.checkReactionTrigger(data);
        
      case 'voice_join':
      case 'voice_leave':
      case 'voice_switch':
        return this.checkVoiceTrigger(data);
        
      case 'boost_add':
      case 'boost_remove':
        return true;
        
      case 'role_add':
      case 'role_remove':
        return this.checkRoleTrigger(data);
        
      case 'message_edit':
      case 'message_delete':
        return this.checkMessageEditDelete(data);
        
      case 'button_click':
      case 'select_menu':
        return this.checkInteractionTrigger(data);
        
      default:
        return this.checkGenericTrigger(data);
    }
  }

  checkMessageTrigger(data) {
    const { message } = data;
    const config = this.triggerConfig;
    
    if (!message) return false;
    
    // Verificar canal específico
    if (config.channelId && message.channel.id !== config.channelId) {
      // Verificar lista de canais
      if (config.channelIds && !config.channelIds.includes(message.channel.id)) {
        return false;
      }
      if (!config.channelIds) return false;
    }
    
    // Ignorar bots?
    if (config.ignoreBots && message.author.bot) return false;
    
    // Verificar tipo de mensagem
    if (config.messageType) {
      const types = {
        'text': !message.attachments.size && !message.embeds.length,
        'image': message.attachments.some(a => a.contentType?.startsWith('image/')),
        'video': message.attachments.some(a => a.contentType?.startsWith('video/')),
        'audio': message.attachments.some(a => a.contentType?.startsWith('audio/')),
        'file': message.attachments.size > 0,
        'embed': message.embeds.length > 0,
        'reply': message.reference !== null,
        'forward': message.type === 'FORWARD'
      };
      if (!types[config.messageType]) return false;
    }
    
    // Verificar filtros de conteúdo
    if (config.filters) {
      const content = message.content.toLowerCase();
      
      // Palavras bloqueadas/obrigatórias
      if (config.filters.blockedWords?.length > 0) {
        if (config.filters.blockedWords.some(w => content.includes(w.toLowerCase()))) {
          return config.filters.triggerOnMatch !== false;
        }
        if (config.filters.triggerOnMatch === false) return false;
      }
      
      if (config.filters.requiredWords?.length > 0) {
        if (!config.filters.requiredWords.some(w => content.includes(w.toLowerCase()))) {
          return false;
        }
      }
      
      // Regex
      if (config.filters.regex) {
        try {
          const regex = new RegExp(config.filters.regex, config.filters.regexFlags || 'gi');
          if (!regex.test(content) && !config.filters.regexInverted) return false;
          if (regex.test(content) && config.filters.regexInverted) return false;
        } catch (e) {}
      }
      
      // Links
      if (config.filters.blockLinks) {
        const urlRegex = /(https?:\/\/[^\s]+)/gi;
        if (urlRegex.test(content)) return true;
      }
      
      // Menções
      if (config.filters.blockMentions && message.mentions.users.size > 0) return true;
      if (config.filters.maxMentions && message.mentions.users.size > config.filters.maxMentions) return true;
      
      // Anexos
      if (config.filters.blockAttachments && message.attachments.size > 0) return true;
      if (config.filters.requireAttachment && message.attachments.size === 0) return false;
      if (config.filters.attachmentType) {
        const hasType = message.attachments.some(a => 
          a.contentType?.includes(config.filters.attachmentType)
        );
        if (!hasType) return false;
      }
      
      // Tamanho da mensagem
      if (config.filters.minLength && content.length < config.filters.minLength) return false;
      if (config.filters.maxLength && content.length > config.filters.maxLength) return true;
      
      // Caps lock
      if (config.filters.maxCapsPercent) {
        const capsCount = (content.match(/[A-Z]/g) || []).length;
        const capsPercent = (capsCount / content.length) * 100;
        if (capsPercent > config.filters.maxCapsPercent) return true;
      }
      
      // Emojis
      if (config.filters.maxEmojis) {
        const emojiCount = (content.match(/[\p{Emoji}]/gu) || []).length;
        if (emojiCount > config.filters.maxEmojis) return true;
      }
      
      // Spam de repetição
      if (config.filters.blockRepeated) {
        // Seria necessário contexto adicional
      }
    }
    
    // Verificar se requer anexo
    if (config.containsAttachment !== undefined) {
      const hasAttachment = message.attachments.size > 0;
      if (config.containsAttachment !== hasAttachment) return false;
    }
    
    // Verificar tipo de anexo
    if (config.attachmentType && message.attachments.size > 0) {
      const hasType = message.attachments.some(a => 
        a.contentType?.includes(config.attachmentType)
      );
      if (!hasType) return false;
    }
    
    // Verificar tamanho da mensagem
    if (config.minLength && message.content?.length < config.minLength) return false;
    if (config.maxLength && message.content?.length > config.maxLength) return true;
    
    // Verificar horário
    if (config.timeRange) {
      const now = new Date();
      const currentMinutes = now.getHours() * 60 + now.getMinutes();
      const [startH, startM] = config.timeRange.start.split(':').map(Number);
      const [endH, endM] = config.timeRange.end.split(':').map(Number);
      const startMinutes = startH * 60 + startM;
      const endMinutes = endH * 60 + endM;
      
      if (startMinutes < endMinutes) {
        if (currentMinutes < startMinutes || currentMinutes > endMinutes) return false;
      } else {
        if (currentMinutes < startMinutes && currentMinutes > endMinutes) return false;
      }
    }
    
    return true;
  }

  checkMemberJoin(data) {
    const { member } = data;
    const config = this.triggerConfig;
    
    if (!member) return false;
    
    // Verificar idade mínima da conta
    if (config.minAccountAge) {
      const accountAge = Date.now() - member.user.createdTimestamp;
      const minAge = this.parseDuration(config.minAccountAge);
      if (accountAge < minAge) return false;
    }
    
    // Verificar se tem avatar
    if (config.requireAvatar && !member.user.avatar) return false;
    
    return true;
  }

  checkMemberLeave(data) {
    return true;
  }

  checkReactionTrigger(data) {
    const { reaction, user } = data;
    const config = this.triggerConfig;
    
    if (!reaction) return false;
    
    // Verificar emoji específico
    if (config.emoji) {
      const emojiName = reaction.emoji.name;
      const emojiId = reaction.emoji.id;
      const fullEmoji = emojiId ? `<:${emojiName}:${emojiId}>` : emojiName;
      
      if (config.emoji !== emojiName && config.emoji !== emojiId && 
          config.emoji !== fullEmoji && config.emoji !== reaction.emoji.toString()) {
        return false;
      }
    }
    
    // Verificar lista de emojis
    if (config.emojis?.length > 0) {
      const emojiName = reaction.emoji.name;
      const emojiId = reaction.emoji.id;
      const fullEmoji = emojiId ? `<:${emojiName}:${emojiId}>` : emojiName;
      
      if (!config.emojis.includes(emojiName) && 
          !config.emojis.includes(emojiId) &&
          !config.emojis.includes(fullEmoji)) {
        return false;
      }
    }
    
    // Verificar mensagem específica
    if (config.messageId && reaction.message.id !== config.messageId) return false;
    
    // Verificar canal
    if (config.channelId && reaction.message.channel.id !== config.channelId) return false;
    
    return true;
  }

  checkVoiceTrigger(data) {
    const { oldState, newState } = data;
    const config = this.triggerConfig;
    
    // Verificar canal específico
    if (config.channelId) {
      if (this.trigger === 'voice_join' && newState.channelId !== config.channelId) return false;
      if (this.trigger === 'voice_leave' && oldState.channelId !== config.channelId) return false;
    }
    
    // Verificar lista de canais
    if (config.channelIds?.length > 0) {
      if (this.trigger === 'voice_join' && !config.channelIds.includes(newState.channelId)) return false;
      if (this.trigger === 'voice_leave' && !config.channelIds.includes(oldState.channelId)) return false;
    }
    
    // Verificar categoria
    if (config.categoryIds?.length > 0) {
      const channel = newState.channel || oldState.channel;
      if (channel && !config.categoryIds.includes(channel.parentId)) return false;
    }
    
    return true;
  }

  checkRoleTrigger(data) {
    const { role } = data;
    const config = this.triggerConfig;
    
    if (!role) return false;
    
    // Verificar cargo específico
    if (config.roleId && role.id !== config.roleId) return false;
    
    // Verificar lista de cargos
    if (config.roleIds?.length > 0 && !config.roleIds.includes(role.id)) return false;
    
    return true;
  }

  checkMessageEditDelete(data) {
    const { message, oldMessage, newMessage } = data;
    const config = this.triggerConfig;
    
    const targetMessage = message || oldMessage || newMessage;
    
    if (!targetMessage) return false;
    
    // Ignorar bots
    if (config.ignoreBots && targetMessage.author?.bot) return false;
    
    // Verificar canal
    if (config.channelId && targetMessage.channel?.id !== config.channelId) return false;
    
    return true;
  }

  checkInteractionTrigger(data) {
    const { interaction } = data;
    const config = this.triggerConfig;
    
    if (!interaction) return false;
    
    if (this.trigger === 'button_click') {
      if (config.buttonId && interaction.customId !== config.buttonId) return false;
    }
    
    if (this.trigger === 'select_menu') {
      if (config.menuId && interaction.customId !== config.menuId) return false;
    }
    
    return true;
  }

  checkGenericTrigger(data) {
    return true;
  }

  /**
   * Verifica condições adicionais
   */
  checkConditions(data) {
    if (!this.conditions || this.conditions.length === 0) return true;
    
    return this.evaluateConditionGroup(this.conditions, data);
  }

  /**
   * Avalia grupo de condições
   */
  evaluateConditionGroup(conditions, data) {
    const logic = conditions.logic || 'and';
    const results = [];
    
    for (const condition of conditions.conditions || conditions) {
      let result;
      
      if (condition.conditions) {
        // Grupo aninhado
        result = this.evaluateConditionGroup(condition, data);
      } else {
        // Condição individual
        result = this.evaluateCondition(condition, data);
      }
      
      results.push(result);
      
      // Short-circuit para OR
      if (logic === 'or' && result) return true;
      // Short-circuit para AND
      if (logic === 'and' && !result) return false;
    }
    
    return logic === 'or' ? results.some(r => r) : results.every(r => r);
  }

  /**
   * Avalia uma condição individual
   */
  evaluateCondition(condition, data) {
    const { type, operator, value, value2 } = condition;
    
    let actualValue;
    
    // Obter valor atual baseado no tipo
    switch (type) {
      case 'user.id':
        actualValue = data.user?.id;
        break;
      case 'user.name':
        actualValue = data.user?.username;
        break;
      case 'user.bot':
        actualValue = data.user?.bot;
        break;
      case 'member.nickname':
        actualValue = data.member?.nickname;
        break;
      case 'member.roles':
        actualValue = data.member?.roles?.cache?.map(r => r.id);
        break;
      case 'message.content':
        actualValue = data.message?.content;
        break;
      case 'message.length':
        actualValue = data.message?.content?.length;
        break;
      case 'channel.id':
        actualValue = data.channel?.id;
        break;
      case 'channel.name':
        actualValue = data.channel?.name;
        break;
      case 'server.members':
        actualValue = data.guild?.memberCount;
        break;
      case 'server.boostLevel':
        actualValue = data.guild?.premiumTier;
        break;
      case 'variable':
        actualValue = this.variables[condition.variableName] || data.variables?.[condition.variableName];
        break;
      case 'random':
        actualValue = Math.random() * 100;
        break;
      case 'time.hour':
        actualValue = new Date().getHours();
        break;
      case 'time.minute':
        actualValue = new Date().getMinutes();
        break;
      case 'day_of_week':
        actualValue = new Date().getDay();
        break;
      default:
        actualValue = data[type];
    }
    
    // Avaliar com operador
    const evaluator = CONDITION_OPERATORS[operator];
    if (!evaluator) return false;
    
    try {
      if (operator === 'between') {
        return evaluator(actualValue, value, value2);
      }
      if (['has_role', 'not_has_role', 'has_any_role', 'has_all_roles', 'has_permission'].includes(operator)) {
        return evaluator(data.member, value);
      }
      if (['in_channel', 'is_bot', 'is_nitro', 'is_boosting'].includes(operator)) {
        return evaluator(data.channel || data.user || data.member, value);
      }
      return evaluator(actualValue, value);
    } catch (e) {
      return false;
    }
  }

  /**
   * Executa as ações da automação
   */
  async execute(client, data) {
    console.log(`⚡ [EventAutomation] Executando: ${this.name} (${this.trigger})`);
    
    const context = {
      ...data,
      automation: this.toObject(),
      variables: { ...this.variables, ...(data.variables || {}) }
    };
    
    // Verificar condições
    const conditionsMet = this.checkConditions(data);
    
    const actionsToExecute = conditionsMet ? this.actions : this.elseActions;
    
    if (!actionsToExecute || actionsToExecute.length === 0) {
      if (!conditionsMet) {
        console.log(`⏭️ [EventAutomation] Condições não atendidas: ${this.name}`);
      }
      return [];
    }
    
    const results = [];
    
    for (const action of actionsToExecute) {
      try {
        // Verificar se é ação condicional
        if (action.type === 'condition') {
          const conditionResult = this.evaluateConditionGroup(action.conditions, context);
          const subActions = conditionResult ? action.thenActions : action.elseActions;
          
          if (subActions) {
            for (const subAction of subActions) {
              const result = await this.executeAction(client, subAction, context);
              results.push({ action: subAction.type, success: true, result });
            }
          }
        }
        // Verificar se é ação de loop
        else if (action.type === 'loop') {
          const count = Math.min(action.count || 1, 10); // Max 10 iterações
          for (let i = 0; i < count; i++) {
            for (const subAction of action.actions || []) {
              const result = await this.executeAction(client, subAction, {
                ...context,
                loopIndex: i,
                loopCount: count
              });
              results.push({ action: subAction.type, success: true, result, loop: i });
            }
            if (action.delay) await this.sleep(this.parseDuration(action.delay));
          }
        }
        // Verificar se é ação aleatória
        else if (action.type === 'random_action') {
          const weights = action.weights || action.actions?.map(() => 1);
          const totalWeight = weights.reduce((a, b) => a + b, 0);
          let random = Math.random() * totalWeight;
          
          let selectedIndex = 0;
          for (let i = 0; i < weights.length; i++) {
            random -= weights[i];
            if (random <= 0) {
              selectedIndex = i;
              break;
            }
          }
          
          const selectedAction = action.actions?.[selectedIndex];
          if (selectedAction) {
            const result = await this.executeAction(client, selectedAction, context);
            results.push({ action: selectedAction.type, success: true, result, randomIndex: selectedIndex });
          }
        }
        // Verificar se é wait
        else if (action.type === 'wait') {
          await this.sleep(this.parseDuration(action.duration));
          results.push({ action: 'wait', success: true, result: `Waited ${action.duration}` });
        }
        // Ação normal
        else {
          const result = await this.executeAction(client, action, context);
          results.push({ action: action.type, success: true, result });
        }
      } catch (error) {
        console.error(`❌ [EventAutomation] Erro na ação ${action.type}:`, error.message);
        results.push({ action: action.type, success: false, error: error.message });
      }
    }
    
    // Atualizar estatísticas
    this.triggerCount++;
    this.lastTriggered = new Date().toISOString();
    this.setCooldown(data.user?.id);
    this.recordExecution();
    this.save();
    
    return results;
  }

  /**
   * Executa uma ação específica
   */
  async executeAction(client, action, context) {
    const guild = client.guilds.cache.get(this.guildId);
    if (!guild) throw new Error('Servidor não encontrado');
    
    const { message, member, user, reaction, oldState, newState, role, interaction } = context;
    const targetUser = user || message?.author || member?.user;
    const targetMember = member || message?.member;
    
    // Substituir placeholders em todos os parâmetros string
    const params = this.processActionParams(action, context);
    
    switch (action.type) {
      // === MENSAGENS ===
      case 'delete_message':
        if (message && !message.deleted) {
          if (params.delay) await this.sleep(this.parseDuration(params.delay));
          await message.delete().catch(e => console.error('Erro ao deletar:', e.message));
          return 'Mensagem deletada';
        }
        break;
        
      case 'send_dm':
        if (targetUser) {
          const dmChannel = await targetUser.createDM().catch(() => null);
          if (dmChannel) {
            const messageData = {};
            if (params.message) messageData.content = params.message;
            if (params.embed) messageData.embeds = [this.buildEmbed(params.embed, context)];
            if (params.components) messageData.components = this.buildComponents(params.components);
            if (params.files) messageData.files = params.files;
            if (params.tts) messageData.tts = params.tts;
            
            await dmChannel.send(messageData);
            return 'DM enviada';
          }
        }
        break;
        
      case 'send_channel':
        if (params.channelId) {
          const targetChannel = guild.channels.cache.get(params.channelId);
          if (targetChannel) {
            const messageData = {};
            if (params.message) messageData.content = params.message;
            if (params.embed) messageData.embeds = [this.buildEmbed(params.embed, context)];
            if (params.components) messageData.components = this.buildComponents(params.components);
            if (params.files) messageData.files = params.files;
            if (params.tts) messageData.tts = params.tts;
            
            if (params.threadId) {
              const thread = targetChannel.threads.cache.get(params.threadId);
              if (thread) {
                await thread.send(messageData);
                return 'Mensagem enviada na thread';
              }
            }
            
            await targetChannel.send(messageData);
            return 'Mensagem enviada no canal';
          }
        }
        break;
        
      case 'reply_message':
        if (message) {
          const messageData = {};
          if (params.message) messageData.content = params.message;
          if (params.embed) messageData.embeds = [this.buildEmbed(params.embed, context)];
          if (params.components) messageData.components = this.buildComponents(params.components);
          messageData.allowedMentions = { repliedUser: params.mention !== false };
          
          await message.reply(messageData);
          return 'Resposta enviada';
        }
        break;
        
      case 'edit_message':
        if (params.channelId && params.messageId) {
          const channel = guild.channels.cache.get(params.channelId);
          if (channel) {
            const msg = await channel.messages.fetch(params.messageId).catch(() => null);
            if (msg) {
              const messageData = {};
              if (params.message) messageData.content = params.message;
              if (params.embed) messageData.embeds = [this.buildEmbed(params.embed, context)];
              
              await msg.edit(messageData);
              return 'Mensagem editada';
            }
          }
        }
        break;
        
      case 'pin_message':
        if (message) {
          await message.pin(params.reason || 'Automação');
          return 'Mensagem fixada';
        }
        break;
        
      case 'unpin_message':
        if (params.channelId && params.messageId) {
          const channel = guild.channels.cache.get(params.channelId);
          if (channel) {
            const msg = await channel.messages.fetch(params.messageId).catch(() => null);
            if (msg) {
              await msg.unpin();
              return 'Mensagem desfixada';
            }
          }
        }
        break;
        
      case 'react_message':
        const reactChannel = params.channelId ? guild.channels.cache.get(params.channelId) : message?.channel;
        const reactMessage = params.messageId ? 
          await reactChannel?.messages.fetch(params.messageId).catch(() => null) : message;
        
        if (reactMessage && params.emojis) {
          const emojis = Array.isArray(params.emojis) ? params.emojis : [params.emojis];
          for (const emoji of emojis) {
            await reactMessage.react(emoji).catch(() => {});
          }
          return `${emojis.length} reação(ões) adicionada(s)`;
        }
        break;
        
      // === CANAIS ===
      case 'create_thread':
        const threadChannel = params.channelId ? guild.channels.cache.get(params.channelId) : message?.channel;
        if (threadChannel) {
          const threadData = {
            name: params.threadName || 'Nova Thread',
            autoArchiveDuration: params.autoArchiveDuration || 60,
            type: params.type || undefined,
            invitable: params.invitable,
            rateLimitPerUser: params.slowmode
          };
          
          let thread;
          if (params.messageId || message) {
            thread = await threadChannel.threads.create({
              ...threadData,
              startMessage: params.messageId || message.id
            });
          } else {
            thread = await threadChannel.threads.create(threadData);
          }
          
          return `Thread criada: ${thread.name}`;
        }
        break;
        
      case 'set_slowmode':
        const slowChannel = params.channelId ? guild.channels.cache.get(params.channelId) : message?.channel;
        if (slowChannel) {
          await slowChannel.setRateLimitPerUser(params.seconds || 0, params.reason || 'Automação');
          return `Slowmode definido para ${params.seconds}s`;
        }
        break;
        
      case 'lock_channel':
        const lockChannel = params.channelId ? guild.channels.cache.get(params.channelId) : message?.channel;
        if (lockChannel) {
          const roleId = params.roleId || guild.roles.everyone.id;
          await lockChannel.permissionOverwrites.edit(roleId, {
            SendMessages: false,
            AddReactions: false
          }, { reason: params.reason || 'Automação - Lock' });
          return 'Canal trancado';
        }
        break;
        
      case 'unlock_channel':
        const unlockChannel = params.channelId ? guild.channels.cache.get(params.channelId) : message?.channel;
        if (unlockChannel) {
          const roleId = params.roleId || guild.roles.everyone.id;
          await unlockChannel.permissionOverwrites.edit(roleId, {
            SendMessages: null,
            AddReactions: null
          }, { reason: params.reason || 'Automação - Unlock' });
          return 'Canal destravado';
        }
        break;
        
      case 'create_channel':
        const channelData = {
          name: params.name,
          type: params.type === 'voz' ? 2 : params.type === 'categoria' ? 4 : params.type === 'anuncio' ? 5 : 0,
          parent: params.parentId,
          topic: params.topic,
          rateLimitPerUser: params.slowmode,
          nsfw: params.nsfw,
          position: params.position
        };
        
        const newChannel = await guild.channels.create(channelData);
        
        if (params.permissions) {
          for (const perm of params.permissions) {
            await newChannel.permissionOverwrites.edit(perm.roleId || perm.userId, perm.permissions);
          }
        }
        
        return `Canal criado: ${newChannel.name}`;
        
      case 'create_category':
        const categoryData = {
          name: params.name,
          type: 4,
          position: params.position
        };
        
        const newCategory = await guild.channels.create(categoryData);
        
        if (params.permissions) {
          for (const perm of params.permissions) {
            await newCategory.permissionOverwrites.edit(perm.roleId || perm.userId, perm.permissions);
          }
        }
        
        return `Categoria criada: ${newCategory.name}`;
        
      // === CARGOS ===
      case 'add_role':
        if (targetMember) {
          const roleIds = params.roleIds || (params.roleId ? [params.roleId] : []);
          
          for (const roleId of roleIds) {
            const roleToAdd = guild.roles.cache.get(roleId);
            if (roleToAdd) {
              await targetMember.roles.add(roleToAdd, params.reason || 'Automação');
            }
          }
          
          // Remover outros cargos se especificado
          if (params.removeOthers && roleIds.length > 0) {
            const rolesToRemove = targetMember.roles.cache
              .filter(r => r.id !== guild.roles.everyone.id && !roleIds.includes(r.id))
              .map(r => r.id);
            
            for (const rId of rolesToRemove) {
              await targetMember.roles.remove(rId, 'Removendo cargos antigos');
            }
          }
          
          return `${roleIds.length} cargo(s) adicionado(s)`;
        }
        break;
        
      case 'remove_role':
        if (targetMember) {
          const roleIds = params.roleIds || (params.roleId ? [params.roleId] : []);
          
          for (const roleId of roleIds) {
            await targetMember.roles.remove(roleId, params.reason || 'Automação');
          }
          
          return `${roleIds.length} cargo(s) removido(s)`;
        }
        break;
        
      case 'create_role':
        const roleData = {
          name: params.name || 'Novo Cargo',
          color: params.color,
          hoist: params.hoist,
          mentionable: params.mentionable,
          permissions: params.permissions,
          position: params.position,
          icon: params.icon,
          unicodeEmoji: params.unicodeEmoji
        };
        
        const newRole = await guild.roles.create(roleData);
        return `Cargo criado: ${newRole.name}`;
        
      case 'delete_role':
        if (params.roleId) {
          const roleToDelete = guild.roles.cache.get(params.roleId);
          if (roleToDelete) {
            await roleToDelete.delete(params.reason || 'Automação');
            return `Cargo deletado: ${roleToDelete.name}`;
          }
        }
        break;
        
      // === MEMBROS ===
      case 'kick':
        if (targetMember) {
          if (params.dmMessage) {
            const dm = await targetMember.createDM().catch(() => null);
            if (dm) await dm.send(params.dmMessage);
          }
          await targetMember.kick(params.reason || 'Automação');
          return `${targetMember.user.tag} expulso`;
        }
        break;
        
      case 'ban':
        if (targetMember || params.userId) {
          const banTarget = targetMember || params.userId;
          if (params.dmMessage && targetMember) {
            const dm = await targetMember.createDM().catch(() => null);
            if (dm) await dm.send(params.dmMessage);
          }
          await guild.members.ban(banTarget, {
            reason: params.reason || 'Automação',
            deleteMessageDays: params.deleteMessageDays || 0
          });
          return `Banido`;
        }
        break;
        
      case 'unban':
        if (params.userId) {
          await guild.members.unban(params.userId, params.reason || 'Automação');
          return 'Usuário desbanido';
        }
        break;
        
      case 'mute':
        if (targetMember) {
          const duration = this.parseDuration(params.duration);
          if (params.dmMessage) {
            const dm = await targetMember.createDM().catch(() => null);
            if (dm) await dm.send(params.dmMessage);
          }
          await targetMember.timeout(duration, params.reason || 'Automação');
          return `${targetMember.user.tag} mutado por ${params.duration}`;
        }
        break;
        
      case 'unmute':
        if (targetMember && targetMember.communicationDisabledUntil) {
          await targetMember.timeout(null, params.reason || 'Automação');
          return `${targetMember.user.tag} desmutado`;
        }
        break;
        
      case 'change_nickname':
        if (targetMember) {
          await targetMember.setNickname(params.nickname || null, params.reason || 'Automação');
          return `Apelido alterado para: ${params.nickname || 'Removido'}`;
        }
        break;
        
      case 'deafen':
        if (targetMember?.voice?.channel) {
          await targetMember.voice.setDeaf(true, params.reason || 'Automação');
          return 'Usuário ensurdecido';
        }
        break;
        
      case 'undeafen':
        if (targetMember?.voice?.channel) {
          await targetMember.voice.setDeaf(false, params.reason || 'Automação');
          return 'Usuário desensurdecido';
        }
        break;
        
      case 'disconnect_voice':
        if (targetMember?.voice?.channel) {
          await targetMember.voice.disconnect(params.reason || 'Automação');
          return 'Usuário desconectado de voz';
        }
        break;
        
      case 'move_voice':
        if (targetMember?.voice?.channel && params.targetChannelId) {
          await targetMember.voice.setChannel(params.targetChannelId, params.reason || 'Automação');
          return 'Usuário movido de canal de voz';
        }
        break;
        
      // === LOGS ===
      case 'log':
        if (params.logChannelId) {
          const logChannel = guild.channels.cache.get(params.logChannelId);
          if (logChannel) {
            const logData = {};
            if (params.message) logData.content = params.message;
            if (params.embed) logData.embeds = [this.buildEmbed(params.embed, context)];
            
            await logChannel.send(logData);
            return 'Log registrado';
          }
        }
        break;
        
      // === WEBHOOKS ===
      case 'send_webhook':
        if (params.webhookUrl) {
          const { WebhookClient } = await import('discord.js');
          const webhook = new WebhookClient({ url: params.webhookUrl });
          const webhookData = {
            content: params.message,
            username: params.username || guild.name,
            avatarURL: params.avatarUrl || guild.iconURL(),
            threadId: params.threadId
          };
          if (params.embed) webhookData.embeds = [this.buildEmbed(params.embed, context)];
          
          await webhook.send(webhookData);
          return 'Webhook enviado';
        }
        break;
        
      // === VARIÁVEIS ===
      case 'set_variable':
        if (params.name) {
          this.variables[params.name] = params.value;
          if (params.scope === 'guild') {
            if (!guildVariables.has(this.guildId)) {
              guildVariables.set(this.guildId, {});
            }
            guildVariables.get(this.guildId)[params.name] = params.value;
          }
          this.save();
          return `Variável ${params.name} = ${params.value}`;
        }
        break;
        
      case 'increment_variable':
        if (params.name) {
          const current = Number(this.variables[params.name]) || 0;
          this.variables[params.name] = current + (params.amount || 1);
          this.save();
          return `Variável ${params.name} = ${this.variables[params.name]}`;
        }
        break;
        
      // === HTTP ===
      case 'http_request':
        try {
          const response = await fetch(params.url, {
            method: params.method || 'GET',
            headers: params.headers || {},
            body: params.body ? JSON.stringify(params.body) : undefined
          });
          
          let result = await response.text();
          
          if (params.saveResponse) {
            try {
              const json = JSON.parse(result);
              this.variables[params.saveResponse] = json;
              this.save();
            } catch (e) {
              this.variables[params.saveResponse] = result;
              this.save();
            }
          }
          
          return `HTTP ${params.method}: ${response.status}`;
        } catch (e) {
          throw new Error(`HTTP request failed: ${e.message}`);
        }
    }
    
    return 'Ação executada';
  }

  /**
   * Processa parâmetros da ação substituindo placeholders
   */
  processActionParams(action, context) {
    const params = {};
    
    for (const [key, value] of Object.entries(action)) {
      if (key === 'type') continue;
      
      if (typeof value === 'string') {
        params[key] = this.replacePlaceholders(value, context);
      } else if (Array.isArray(value)) {
        params[key] = value.map(v => 
          typeof v === 'string' ? this.replacePlaceholders(v, context) : v
        );
      } else if (typeof value === 'object' && value !== null) {
        params[key] = this.processActionParams(value, context);
      } else {
        params[key] = value;
      }
    }
    
    return params;
  }

  /**
   * Constrói um embed a partir de parâmetros
   */
  buildEmbed(embedConfig, context) {
    const embed = new EmbedBuilder();
    
    if (embedConfig.title) {
      embed.setTitle(this.replacePlaceholders(embedConfig.title, context));
    }
    
    if (embedConfig.description) {
      embed.setDescription(this.replacePlaceholders(embedConfig.description, context));
    }
    
    if (embedConfig.url) {
      embed.setURL(embedConfig.url);
    }
    
    if (embedConfig.color) {
      const color = typeof embedConfig.color === 'string' && embedConfig.color.startsWith('#') 
        ? parseInt(embedConfig.color.replace('#', ''), 16)
        : embedConfig.color;
      embed.setColor(color);
    } else {
      embed.setColor('#8B5CF6');
    }
    
    if (embedConfig.timestamp === true || embedConfig.timestamp === 'now') {
      embed.setTimestamp();
    } else if (embedConfig.timestamp) {
      embed.setTimestamp(new Date(embedConfig.timestamp));
    }
    
    if (embedConfig.thumbnail) {
      embed.setThumbnail(this.replacePlaceholders(embedConfig.thumbnail, context));
    }
    
    if (embedConfig.image) {
      embed.setImage(this.replacePlaceholders(embedConfig.image, context));
    }
    
    if (embedConfig.author) {
      embed.setAuthor({
        name: this.replacePlaceholders(embedConfig.author.name || embedConfig.author, context),
        iconURL: embedConfig.author.iconURL || embedConfig.author.iconUrl,
        url: embedConfig.author.url
      });
    }
    
    if (embedConfig.footer) {
      embed.setFooter({
        text: this.replacePlaceholders(embedConfig.footer.text || embedConfig.footer, context),
        iconURL: embedConfig.footer.iconURL || embedConfig.footer.iconUrl
      });
    }
    
    if (embedConfig.fields && Array.isArray(embedConfig.fields)) {
      embedConfig.fields.forEach(field => {
        embed.addFields({
          name: this.replacePlaceholders(field.name, context),
          value: this.replacePlaceholders(field.value, context),
          inline: field.inline || false
        });
      });
    }
    
    return embed;
  }

  /**
   * Constrói componentes (botões, menus)
   */
  buildComponents(components) {
    const rows = [];
    
    for (const row of components) {
      const actionRow = new ActionRowBuilder();
      
      if (row.buttons) {
        row.buttons.forEach(btn => {
          const button = new ButtonBuilder()
            .setCustomId(btn.customId || btn.id)
            .setLabel(btn.label)
            .setStyle(ButtonStyle[btn.style] || ButtonStyle.Primary);
          
          if (btn.emoji) button.setEmoji(btn.emoji);
          if (btn.url) button.setURL(btn.url).setStyle(ButtonStyle.Link);
          if (btn.disabled) button.setDisabled(true);
          
          actionRow.addComponents(button);
        });
      }
      
      if (row.selectMenu) {
        const menu = row.selectMenu;
        const select = new StringSelectMenuBuilder()
          .setCustomId(menu.customId || menu.id)
          .setPlaceholder(menu.placeholder || 'Selecione...')
          .addOptions(menu.options.map(opt => ({
            label: opt.label,
            value: opt.value,
            description: opt.description,
            emoji: opt.emoji,
            default: opt.default
          })));
        
        if (menu.minValues) select.setMinValues(menu.minValues);
        if (menu.maxValues) select.setMaxValues(menu.maxValues);
        if (menu.disabled) select.setDisabled(true);
        
        actionRow.addComponents(select);
      }
      
      rows.push(actionRow);
    }
    
    return rows;
  }

  /**
   * Substitui placeholders em strings
   */
  replacePlaceholders(text, context) {
    if (!text || typeof text !== 'string') return text;
    
    let result = text;
    
    // Placeholders simples
    for (const [placeholder, getter] of Object.entries(PLACEHOLDERS)) {
      if (placeholder.startsWith('{var:')) continue;
      try {
        const value = getter(context);
        if (value !== undefined && value !== null) {
          result = result.split(placeholder).join(String(value));
        }
      } catch (e) {}
    }
    
    // Placeholders de variáveis customizadas {var:nome}
    const varMatches = result.match(/\{var:([^}]+)\}/g);
    if (varMatches) {
      for (const match of varMatches) {
        const varName = match.replace('{var:', '').replace('}', '');
        const value = this.variables[varName] || context.variables?.[varName] || '';
        result = result.split(match).join(String(value));
      }
    }
    
    // Placeholders com formato especial {timestamp:X}
    const timestampMatch = result.match(/\{timestamp:([^}]+)\}/g);
    if (timestampMatch) {
      for (const match of timestampMatch) {
        const format = match.replace('{timestamp:', '').replace('}', '');
        const timestamp = Math.floor(Date.now() / 1000);
        result = result.split(match).join(`<t:${timestamp}:${format}>`);
      }
    }
    
    return result;
  }

  /**
   * Parse de duração
   */
  parseDuration(duration) {
    if (typeof duration === 'number') return duration * 1000;
    
    if (typeof duration === 'string') {
      const match = duration.match(/^(\d+)(s|m|h|d|w)$/);
      if (match) {
        const value = parseInt(match[1]);
        const unit = match[2];
        
        switch (unit) {
          case 's': return value * 1000;
          case 'm': return value * 60 * 1000;
          case 'h': return value * 60 * 60 * 1000;
          case 'd': return value * 24 * 60 * 60 * 1000;
          case 'w': return value * 7 * 24 * 60 * 60 * 1000;
        }
      }
    }
    
    return 60000; // Default 1 minuto
  }

  /**
   * Sleep utility
   */
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Converte para objeto simples
   */
  toObject() {
    return {
      id: this.id,
      guildId: this.guildId,
      name: this.name,
      description: this.description,
      trigger: this.trigger,
      triggerConfig: this.triggerConfig,
      conditions: this.conditions,
      actions: this.actions,
      elseActions: this.elseActions,
      enabled: this.enabled,
      cooldown: this.cooldown,
      cooldownPerUser: this.cooldownPerUser,
      maxExecutions: this.maxExecutions,
      executionWindow: this.executionWindow,
      requirePermissions: this.requirePermissions,
      requireRoles: this.requireRoles,
      ignoreRoles: this.ignoreRoles,
      ignoreUsers: this.ignoreUsers,
      priority: this.priority,
      logExecutions: this.logExecutions,
      variables: this.variables,
      createdAt: this.createdAt,
      triggerCount: this.triggerCount,
      lastTriggered: this.lastTriggered,
      createdBy: this.createdBy
    };
  }
}

// ============================================
// FUNÇÕES DE GERENCIAMENTO
// ============================================

export function createEventAutomation(guildId, config) {
  const automation = new EventAutomation(guildId, config);
  automation.save();
  
  if (!guildAutomations.has(guildId)) {
    guildAutomations.set(guildId, new Map());
  }
  guildAutomations.get(guildId).set(automation.id, automation);
  
  console.log(`✅ [EventAutomation] Criada: ${automation.name} (${automation.trigger})`);
  
  return automation;
}

export function getEventAutomation(guildId, automationId) {
  const automations = guildAutomations.get(guildId);
  if (!automations) return null;
  return automations.get(automationId);
}

export function listEventAutomations(guildId) {
  const automations = guildAutomations.get(guildId);
  if (!automations) return [];
  return Array.from(automations.values()).map(a => a.toObject());
}

export function deleteEventAutomation(guildId, automationId) {
  const automation = getEventAutomation(guildId, automationId);
  if (!automation) return false;
  
  automation.delete();
  console.log(`🗑️ [EventAutomation] Deletada: ${automation.name}`);
  
  return true;
}

export function toggleEventAutomation(guildId, automationId, enabled = null) {
  const automation = getEventAutomation(guildId, automationId);
  if (!automation) return null;
  
  automation.enabled = enabled !== null ? enabled : !automation.enabled;
  automation.save();
  
  console.log(`${automation.enabled ? '✅' : '⏸️'} [EventAutomation] ${automation.name} ${automation.enabled ? 'ativada' : 'desativada'}`);
  
  return automation;
}

export function editEventAutomation(guildId, automationId, newConfig) {
  const automation = getEventAutomation(guildId, automationId);
  if (!automation) return null;
  
  Object.keys(newConfig).forEach(key => {
    if (newConfig[key] !== undefined) {
      automation[key] = newConfig[key];
    }
  });
  
  automation.save();
  
  console.log(`📝 [EventAutomation] Editada: ${automation.name}`);
  
  return automation;
}

export function loadGuildAutomations(guildId) {
  const guildDir = path.join(AUTOMATION_DIR, guildId);
  
  if (!fs.existsSync(guildDir)) return;
  
  const files = fs.readdirSync(guildDir).filter(f => f.endsWith('.json'));
  
  if (files.length === 0) return;
  
  if (!guildAutomations.has(guildId)) {
    guildAutomations.set(guildId, new Map());
  }
  
  for (const file of files) {
    try {
      const filePath = path.join(guildDir, file);
      const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      
      const automation = new EventAutomation(guildId, data);
      guildAutomations.get(guildId).set(automation.id, automation);
      
      console.log(`📂 [EventAutomation] Carregada: ${automation.name} (${automation.enabled ? 'ativa' : 'inativa'})`);
    } catch (error) {
      console.error(`❌ [EventAutomation] Erro ao carregar ${file}:`, error.message);
    }
  }
}

export async function processEvent(client, event, data) {
  const guild = data.guild || data.message?.guild;
  if (!guild) return;
  
  const automations = guildAutomations.get(guild.id);
  if (!automations || automations.size === 0) return;
  
  // Ordenar por prioridade
  const sortedAutomations = Array.from(automations.values())
    .filter(a => a.trigger === event && a.enabled)
    .sort((a, b) => b.priority - a.priority);
  
  for (const automation of sortedAutomations) {
    try {
      if (automation.shouldTrigger(event, data)) {
        await automation.execute(client, data);
      }
    } catch (error) {
      console.error(`❌ [EventAutomation] Erro ao processar ${automation.name}:`, error.message);
    }
  }
}

export function getEventAutomationStats(guildId) {
  const automations = listEventAutomations(guildId);
  
  return {
    total: automations.length,
    enabled: automations.filter(a => a.enabled).length,
    disabled: automations.filter(a => !a.enabled).length,
    totalTriggers: automations.reduce((sum, a) => sum + (a.triggerCount || 0), 0),
    byCategory: {
      messages: automations.filter(a => TRIGGER_TYPES[a.trigger]?.category === 'messages').length,
      members: automations.filter(a => TRIGGER_TYPES[a.trigger]?.category === 'members').length,
      roles: automations.filter(a => TRIGGER_TYPES[a.trigger]?.category === 'roles').length,
      voice: automations.filter(a => TRIGGER_TYPES[a.trigger]?.category === 'voice').length,
      channels: automations.filter(a => TRIGGER_TYPES[a.trigger]?.category === 'channels').length,
      server: automations.filter(a => TRIGGER_TYPES[a.trigger]?.category === 'server').length,
      reactions: automations.filter(a => TRIGGER_TYPES[a.trigger]?.category === 'reactions').length,
      interactions: automations.filter(a => TRIGGER_TYPES[a.trigger]?.category === 'interactions').length,
      threads: automations.filter(a => TRIGGER_TYPES[a.trigger]?.category === 'threads').length,
      webhooks: automations.filter(a => TRIGGER_TYPES[a.trigger]?.category === 'webhooks').length,
      invites: automations.filter(a => TRIGGER_TYPES[a.trigger]?.category === 'invites').length,
      custom: automations.filter(a => TRIGGER_TYPES[a.trigger]?.category === 'custom').length
    }
  };
}

// Templates de automação pré-definidos
const AUTOMATION_TEMPLATES = {
  antiSpam: {
    name: 'Anti-Spam',
    description: 'Remove mensagens com links/spam e avisa o usuário por DM',
    trigger: 'message_in_channel',
    triggerConfig: { ignoreBots: true, filters: { blockLinks: true } },
    actions: [
      { type: 'delete_message' },
      { type: 'send_dm', embed: { title: '⚠️ Mensagem Removida!', description: 'Links não são permitidos neste canal!', color: 'vermelho' } }
    ]
  },
  
  welcomeMessage: {
    name: 'Boas-vindas',
    description: 'Dá boas-vindas quando membro entra',
    trigger: 'member_join',
    actions: [
      { type: 'send_channel', channelId: 'CANAL_BOAS_VINDAS_ID', embed: { title: '👋 Bem-vindo(a)!', description: 'Olá {user}! Seja bem-vindo(a) ao {server}!', color: 'verde', thumbnail: '{user.avatar}' } }
    ]
  },
  
  farewellMessage: {
    name: 'Despedida',
    description: 'Envia mensagem quando membro sai do servidor',
    trigger: 'member_leave',
    actions: [
      { type: 'send_channel', channelId: 'CANAL_SAIDA_ID', embed: { title: '👋 Tchau!', description: '{user} saiu do servidor. Até mais!', color: 'amarelo' } }
    ]
  },
  
  boosterReward: {
    name: 'Recompensa de Boost',
    description: 'Dá cargo e agradece quando membro boosta o servidor',
    trigger: 'boost_add',
    actions: [
      { type: 'add_role', roleId: 'ID_CARGO_BOOSTER' },
      { type: 'send_dm', embed: { title: '💎 Obrigado pelo Boost!', description: 'Você recebeu o cargo Booster! Aproveite os benefícios!', color: 'rosa' } }
    ]
  },
  
  reactionRole: {
    name: 'Reaction Role',
    description: 'Dá cargo quando usuário reage com emoji específico',
    trigger: 'reaction_add',
    triggerConfig: { emoji: '✅', messageId: 'CONFIGURE' },
    actions: [
      { type: 'add_role', roleId: 'ROLE_ID' }
    ]
  },
  
  logEdit: {
    name: 'Log de Edições',
    description: 'Registra mensagens editadas em canal de logs',
    trigger: 'message_edit',
    triggerConfig: { ignoreBots: true },
    actions: [
      { type: 'log', logChannelId: 'CANAL_LOGS_ID', embed: { title: '✏️ Mensagem Editada', color: 'amarelo', fields: [{ name: '👤 Autor', value: '{user}', inline: true }, { name: '📝 Antes', value: '{oldMessage}' }, { name: '📝 Depois', value: '{message}' }] } }
    ]
  },
  
  logDelete: {
    name: 'Log de Mensagens Deletadas',
    description: 'Registra mensagens deletadas em canal de logs',
    trigger: 'message_delete',
    triggerConfig: { ignoreBots: true },
    actions: [
      { type: 'log', logChannelId: 'CANAL_LOGS_ID', embed: { title: '🗑️ Mensagem Deletada', color: 'vermelho', fields: [{ name: '👤 Autor', value: '{user}', inline: true }, { name: '📝 Conteúdo', value: '{message}' }] } }
    ]
  },
  
  announcementOnly: {
    name: 'Canal Restrito',
    description: 'Deleta mensagens de não-admins em canal de avisos',
    trigger: 'message_in_channel',
    triggerConfig: { channelId: 'CANAL_AVISOS_ID', ignoreRoles: ['ADMIN_ROLE_ID'] },
    actions: [
      { type: 'delete_message' },
      { type: 'send_dm', embed: { title: '⚠️ Canal Restrito', description: 'Apenas administradores podem enviar mensagens neste canal.', color: 'amarelo' } }
    ]
  },
  
  autoMute: {
    name: 'Mute Automático',
    description: 'Muta usuário que envia muitas mensagens rapidamente',
    trigger: 'message_in_channel',
    triggerConfig: { ignoreBots: true },
    conditions: [{ type: 'message_count_above', value: 5, timeframe: 10 }],
    actions: [
      { type: 'mute', duration: '10m', reason: 'Spam detectado' },
      { type: 'send_dm', embed: { title: '🔇 Você foi mutado', description: 'Spam detectado. Aguarde 10 minutos.', color: 'vermelho' } }
    ]
  }
};

// Exportar tudo
export { TRIGGER_TYPES, ACTION_TYPES, CONDITION_OPERATORS, PLACEHOLDERS, EventAutomation, AUTOMATION_TEMPLATES };

export default {
  createEventAutomation,
  getEventAutomation,
  listEventAutomations,
  deleteEventAutomation,
  toggleEventAutomation,
  editEventAutomation,
  loadGuildAutomations,
  processEvent,
  getEventAutomationStats,
  TRIGGER_TYPES,
  ACTION_TYPES,
  CONDITION_OPERATORS,
  PLACEHOLDERS,
  AUTOMATION_TEMPLATES,
  EventAutomation
};
