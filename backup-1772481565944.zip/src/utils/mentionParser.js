/**
 * RIAS GREMORY X AI - Sistema de Menções
 * Parser e resolvedor de menções do Discord
 * 
 * @version 1.0.0
 * @author MutanoX
 * 
 * Suporta:
 * - #canal ou <#ID>
 * - @cargo ou <@&ID>
 * - @usuario ou <@ID>
 * - categoria:nome
 * - everyone, here
 */

import { ChannelType } from 'discord.js';

/**
 * Resolve uma menção de canal
 * @param {Guild} guild - Servidor Discord
 * @param {string} input - Input do usuário (nome, ID ou menção)
 * @returns {Channel|null}
 */
export function resolveChannel(guild, input) {
  if (!input || !guild) return null;
  
  const cleanInput = input.trim().toLowerCase();
  
  // Remover formatação de menção
  const mentionMatch = input.match(/<#(\d+)>/);
  if (mentionMatch) {
    return guild.channels.cache.get(mentionMatch[1]);
  }
  
  // ID direto
  if (/^\d+$/.test(input)) {
    return guild.channels.cache.get(input);
  }
  
  // Buscar por nome (sem #)
  const nameWithoutHash = cleanInput.replace(/^#/, '');
  
  return guild.channels.cache.find(c => {
    const channelName = c.name.toLowerCase();
    return channelName === nameWithoutHash || 
           channelName.includes(nameWithoutHash) ||
           nameWithoutHash.includes(channelName);
  });
}

/**
 * Resolve uma menção de categoria
 * @param {Guild} guild - Servidor Discord
 * @param {string} input - Input do usuário
 * @returns {CategoryChannel|null}
 */
export function resolveCategory(guild, input) {
  if (!input || !guild) return null;
  
  const cleanInput = input.trim().toLowerCase();
  
  // Remover prefixo "categoria:" se existir
  const name = cleanInput.replace(/^categoria:?/i, '').trim();
  
  // Buscar por nome
  return guild.channels.cache.find(c => {
    if (c.type !== ChannelType.GuildCategory) return false;
    const catName = c.name.toLowerCase();
    return catName === name || catName.includes(name) || name.includes(catName);
  });
}

/**
 * Resolve uma menção de cargo
 * @param {Guild} guild - Servidor Discord
 * @param {string} input - Input do usuário
 * @returns {Role|null}
 */
export function resolveRole(guild, input) {
  if (!input || !guild) return null;
  
  const cleanInput = input.trim().toLowerCase();
  
  // Remover formatação de menção
  const mentionMatch = input.match(/<@&(\d+)>/);
  if (mentionMatch) {
    return guild.roles.cache.get(mentionMatch[1]);
  }
  
  // ID direto
  if (/^\d+$/.test(input)) {
    return guild.roles.cache.get(input);
  }
  
  // Remover @ do início
  const name = cleanInput.replace(/^@/, '');
  
  // Casos especiais
  if (name === 'everyone' || name === 'todos') {
    return guild.roles.everyone;
  }
  
  // Buscar por nome
  return guild.roles.cache.find(r => {
    const roleName = r.name.toLowerCase();
    return roleName === name || 
           roleName.includes(name) ||
           name.includes(roleName);
  });
}

/**
 * Resolve uma menção de membro/usuário
 * @param {Guild} guild - Servidor Discord
 * @param {string} input - Input do usuário
 * @returns {GuildMember|null}
 */
export function resolveMember(guild, input) {
  if (!input || !guild) return null;
  
  const cleanInput = input.trim();
  
  // Remover formatação de menção
  const mentionMatch = input.match(/<@!?(\d+)>/);
  if (mentionMatch) {
    return guild.members.cache.get(mentionMatch[1]);
  }
  
  // ID direto
  if (/^\d+$/.test(input)) {
    return guild.members.cache.get(input);
  }
  
  // Remover @ do início
  const name = cleanInput.replace(/^@/, '').toLowerCase();
  
  // Buscar por tag (nome#discriminator)
  if (input.includes('#')) {
    const member = guild.members.cache.find(m => m.user.tag.toLowerCase() === name);
    if (member) return member;
  }
  
  // Buscar por nome de usuário ou apelido
  return guild.members.cache.find(m => {
    const username = m.user.username.toLowerCase();
    const displayName = m.displayName?.toLowerCase() || '';
    const nickname = m.nickname?.toLowerCase() || '';
    
    return username === name ||
           displayName === name ||
           nickname === name ||
           username.includes(name) ||
           displayName.includes(name) ||
           nickname.includes(name);
  });
}

/**
 * Resolve múltiplas menções de uma vez
 * @param {Guild} guild - Servidor Discord
 * @param {Object} mentions - Objeto com tipos de menções
 * @returns {Object}
 */
export function resolveMentions(guild, mentions) {
  const result = {
    channels: [],
    categories: [],
    roles: [],
    members: [],
    errors: []
  };
  
  if (mentions.channels) {
    for (const ch of mentions.channels) {
      const resolved = resolveChannel(guild, ch);
      if (resolved) {
        result.channels.push(resolved);
      } else {
        result.errors.push(`Canal não encontrado: ${ch}`);
      }
    }
  }
  
  if (mentions.categories) {
    for (const cat of mentions.categories) {
      const resolved = resolveCategory(guild, cat);
      if (resolved) {
        result.categories.push(resolved);
      } else {
        result.errors.push(`Categoria não encontrada: ${cat}`);
      }
    }
  }
  
  if (mentions.roles) {
    for (const role of mentions.roles) {
      const resolved = resolveRole(guild, role);
      if (resolved) {
        result.roles.push(resolved);
      } else {
        result.errors.push(`Cargo não encontrado: ${role}`);
      }
    }
  }
  
  if (mentions.members) {
    for (const member of mentions.members) {
      const resolved = resolveMember(guild, member);
      if (resolved) {
        result.members.push(resolved);
      } else {
        result.errors.push(`Membro não encontrado: ${member}`);
      }
    }
  }
  
  return result;
}

/**
 * Formata uma menção de canal
 * @param {string} channelId - ID do canal
 * @returns {string}
 */
export function formatChannelMention(channelId) {
  return `<#${channelId}>`;
}

/**
 * Formata uma menção de cargo
 * @param {string} roleId - ID do cargo
 * @returns {string}
 */
export function formatRoleMention(roleId) {
  return `<@&${roleId}>`;
}

/**
 * Formata uma menção de usuário
 * @param {string} userId - ID do usuário
 * @returns {string}
 */
export function formatUserMention(userId) {
  return `<@${userId}>`;
}

/**
 * Extrai IDs de menções de um texto
 * @param {string} text - Texto com menções
 * @returns {Object}
 */
export function extractMentions(text) {
  return {
    channels: [...text.matchAll(/<#(\d+)>/g)].map(m => m[1]),
    roles: [...text.matchAll(/<@&(\d+)>/g)].map(m => m[1]),
    users: [...text.matchAll(/<@!?(\d+)>/g)].map(m => m[1])
  };
}

/**
 * Substitui menções por nomes legíveis
 * @param {Guild} guild - Servidor Discord
 * @param {string} text - Texto com menções
 * @returns {string}
 */
export function resolveMentionsInText(guild, text) {
  if (!text || !guild) return text;
  
  // Canais
  text = text.replace(/<#(\d+)>/g, (match, id) => {
    const channel = guild.channels.cache.get(id);
    return channel ? `#${channel.name}` : match;
  });
  
  // Cargos
  text = text.replace(/<@&(\d+)>/g, (match, id) => {
    const role = guild.roles.cache.get(id);
    return role ? `@${role.name}` : match;
  });
  
  // Usuários
  text = text.replace(/<@!?(\d+)>/g, (match, id) => {
    const member = guild.members.cache.get(id);
    return member ? `@${member.displayName || member.user.username}` : match;
  });
  
  return text;
}

export default {
  resolveChannel,
  resolveCategory,
  resolveRole,
  resolveMember,
  resolveMentions,
  formatChannelMention,
  formatRoleMention,
  formatUserMention,
  extractMentions,
  resolveMentionsInText
};
