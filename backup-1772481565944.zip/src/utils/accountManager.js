/**
 * Rias-Grimory-X - Sistema de Contas e Pagamentos
 * Gerencia contas de usuário, saldo, vinculações e planos
 * 
 * @version 3.0.0
 * @author MutanoX
 * 
 * FUNCIONALIDADES:
 * - Contas de usuário com saldo
 * - Sistema de vinculação (até 2 usuários)
 * - Planos: Semanal (R$20) e Mensal (R$29,59)
 * - Renovação automática
 * - Histórico de transações
 */

import fs from 'fs';
import path from 'path';

// Configurações
const CONFIG = {
  ACCOUNTS_FILE: '/tmp/rias-accounts.json',
  TRANSACTIONS_FILE: '/tmp/rias-transactions.json',
  BOT_OWNER_ID: '1387242867700924568',
  
  // Preços dos planos (em reais)
  PLAN_PRICES: {
    'semanal': 20.00,
    'mensal': 29.59
  },
  
  // Duração dos planos (em dias)
  PLAN_DAYS: {
    'semanal': 7,
    'mensal': 30
  },
  
  // Limites
  MAX_LINKED_USERS: 2,
  MIN_BALANCE: 0,
  
  // Cores
  COLORS: {
    active: '#10B981',
    expired: '#EF4444',
    pending: '#F59E0B',
    info: '#3B82F6'
  }
};

/**
 * @typedef {Object} UserAccount
 * @property {string} userId - ID do usuário
 * @property {string} username - Nome do usuário
 * @property {number} balance - Saldo disponível
 * @property {string} planType - Tipo do plano ativo (semanal/mensal)
 * @property {number} planExpiresAt - Timestamp de expiração do plano
 * @property {boolean} autoRenew - Se renovação automática está ativa
 * @property {string[]} linkedUsers - IDs dos usuários vinculados (máx 2)
 * @property {string|null} linkedTo - ID do usuário ao qual está vinculado
 * @property {number} createdAt - Timestamp de criação
 * @property {number} lastActivity - Última atividade
 */

/**
 * @typedef {Object} Transaction
 * @property {string} id - ID único da transação
 * @property {string} userId - ID do usuário
 * @property {string} type - Tipo (payment, renewal, deposit, unlink)
 * @property {number} amount - Valor
 * @property {string} description - Descrição
 * @property {string} status - Status (pending, completed, failed)
 * @property {number} createdAt - Timestamp de criação
 * @property {number|null} completedAt - Timestamp de conclusão
 */

// Estado do sistema
let accountsData = {
  accounts: {},
  pendingTransactions: {}
};

let transactionsData = {
  transactions: []
};

/**
 * Inicializa o sistema de contas
 */
export function initAccountSystem() {
  try {
    // Carregar contas
    if (fs.existsSync(CONFIG.ACCOUNTS_FILE)) {
      const data = fs.readFileSync(CONFIG.ACCOUNTS_FILE, 'utf8');
      accountsData = JSON.parse(data);
      console.log('✅ [Account] Sistema de contas carregado');
      console.log(`📊 [Account] ${Object.keys(accountsData.accounts).length} contas ativas`);
    } else {
      saveAccountsData();
      console.log('✅ [Account] Novo arquivo de contas criado');
    }
    
    // Carregar transações
    if (fs.existsSync(CONFIG.TRANSACTIONS_FILE)) {
      const data = fs.readFileSync(CONFIG.TRANSACTIONS_FILE, 'utf8');
      transactionsData = JSON.parse(data);
    } else {
      saveTransactionsData();
    }
    
    // Iniciar verificação de expirações
    startExpirationChecker();
    
  } catch (error) {
    console.error('❌ [Account] Erro ao inicializar:', error.message);
    saveAccountsData();
    saveTransactionsData();
  }
}

/**
 * Salva os dados das contas
 */
function saveAccountsData() {
  try {
    fs.writeFileSync(CONFIG.ACCOUNTS_FILE, JSON.stringify(accountsData, null, 2));
  } catch (error) {
    console.error('❌ [Account] Erro ao salvar contas:', error.message);
  }
}

/**
 * Salva os dados das transações
 */
function saveTransactionsData() {
  try {
    fs.writeFileSync(CONFIG.TRANSACTIONS_FILE, JSON.stringify(transactionsData, null, 2));
  } catch (error) {
    console.error('❌ [Account] Erro ao salvar transações:', error.message);
  }
}

/**
 * Obtém ou cria uma conta de usuário
 * @param {string} userId - ID do usuário
 * @param {string} username - Nome do usuário
 * @returns {UserAccount}
 */
export function getOrCreateAccount(userId, username = 'Unknown') {
  if (!accountsData.accounts[userId]) {
    accountsData.accounts[userId] = {
      userId: userId,
      username: username,
      balance: 0,
      planType: null,
      planExpiresAt: null,
      autoRenew: false,
      linkedUsers: [],
      linkedTo: null,
      createdAt: Date.now(),
      lastActivity: Date.now()
    };
    saveAccountsData();
  }
  return accountsData.accounts[userId];
}

/**
 * Obtém uma conta existente
 * @param {string} userId - ID do usuário
 * @returns {UserAccount|null}
 */
export function getAccount(userId) {
  return accountsData.accounts[userId] || null;
}

/**
 * Verifica se o usuário é dono do bot
 * @param {string} userId - ID do usuário
 * @returns {boolean}
 */
export function isBotOwner(userId) {
  return userId === CONFIG.BOT_OWNER_ID;
}

/**
 * Verifica se o usuário tem plano ativo
 * @param {string} userId - ID do usuário
 * @returns {boolean}
 */
export function hasActivePlan(userId) {
  // Dono do bot sempre tem acesso
  if (isBotOwner(userId)) return true;
  
  const account = getAccount(userId);
  if (!account) return false;
  
  // Se está vinculado a outra conta, verificar o plano do dono
  if (account.linkedTo) {
    const parentAccount = getAccount(account.linkedTo);
    if (parentAccount && parentAccount.planExpiresAt && parentAccount.planExpiresAt > Date.now()) {
      return true;
    }
  }
  
  // Verificar plano próprio
  if (account.planExpiresAt && account.planExpiresAt > Date.now()) {
    return true;
  }
  
  return false;
}

/**
 * Verifica se o usuário pode usar o bot em um servidor
 * @param {string} userId - ID do usuário
 * @param {string} guildId - ID do servidor
 * @param {boolean} isOwner - Se é dono do servidor
 * @param {boolean} isAdmin - Se é administrador
 * @returns {boolean}
 */
export function canUseBot(userId, guildId, isOwner, isAdmin) {
  // Dono do bot sempre pode usar
  if (isBotOwner(userId)) return true;
  
  // Precisa ser dono ou admin do servidor
  if (!isOwner && !isAdmin) return false;
  
  // Verificar se tem plano ativo
  return hasActivePlan(userId);
}

/**
 * Calcula o preço baseado na quantidade de dias
 * @param {number} days - Quantidade de dias
 * @returns {{price: number, type: string, days: number}}
 */
export function calculatePrice(days) {
  // Determinar melhor plano baseado nos dias
  let type = 'semanal';
  let planDays = 7;
  
  if (days >= 30) {
    type = 'mensal';
    planDays = 30;
  }
  
  // Calcular quantos planos são necessários
  const fullPlans = Math.floor(days / planDays);
  const remainingDays = days % planDays;
  
  let totalPrice = fullPlans * CONFIG.PLAN_PRICES[type];
  
  // Se sobrarem dias, adicionar mais um plano
  if (remainingDays > 0) {
    totalPrice += CONFIG.PLAN_PRICES[type];
  }
  
  // Ajustar para o preço proporcional se sobrarem dias
  if (remainingDays > 0 && fullPlans > 0) {
    // Usar preço proporcional
    const dailyRate = CONFIG.PLAN_PRICES[type] / planDays;
    totalPrice = (fullPlans * CONFIG.PLAN_PRICES[type]) + (remainingDays * dailyRate);
  }
  
  return {
    price: Math.round(totalPrice * 100) / 100,
    type: type,
    days: fullPlans > 0 ? (fullPlans * planDays) + (remainingDays > 0 ? planDays : 0) : planDays
  };
}

/**
 * Calcula preço específico para semanal ou mensal
 * @param {string} planType - 'semanal' ou 'mensal'
 * @param {number} quantity - Quantidade
 * @returns {number}
 */
export function calculatePlanPrice(planType, quantity = 1) {
  const price = CONFIG.PLAN_PRICES[planType.toLowerCase()] || CONFIG.PLAN_PRICES['semanal'];
  return Math.round(price * quantity * 100) / 100;
}

/**
 * Adiciona saldo à conta do usuário
 * @param {string} userId - ID do usuário
 * @param {number} amount - Valor a adicionar
 * @param {string} description - Descrição da transação
 * @returns {{success: boolean, newBalance: number, error?: string}}
 */
export function addBalance(userId, amount, description = 'Depósito') {
  if (amount <= 0) {
    return { success: false, error: 'Valor inválido' };
  }
  
  const account = getOrCreateAccount(userId);
  account.balance += amount;
  account.lastActivity = Date.now();
  
  // Registrar transação
  const transaction = {
    id: `TXN_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    userId: userId,
    type: 'deposit',
    amount: amount,
    description: description,
    status: 'completed',
    createdAt: Date.now(),
    completedAt: Date.now()
  };
  
  transactionsData.transactions.push(transaction);
  
  saveAccountsData();
  saveTransactionsData();
  
  console.log(`💰 [Account] Saldo adicionado: R$${amount.toFixed(2)} para ${userId}`);
  
  return { 
    success: true, 
    newBalance: account.balance,
    transactionId: transaction.id
  };
}

/**
 * Remove saldo da conta (uso interno)
 * @param {string} userId - ID do usuário
 * @param {number} amount - Valor a remover
 * @param {string} description - Descrição
 * @returns {{success: boolean, newBalance: number, error?: string}}
 */
function removeBalance(userId, amount, description = 'Pagamento') {
  const account = getAccount(userId);
  if (!account) {
    return { success: false, error: 'Conta não encontrada' };
  }
  
  if (account.balance < amount) {
    return { success: false, error: 'Saldo insuficiente' };
  }
  
  account.balance -= amount;
  account.lastActivity = Date.now();
  
  // Registrar transação
  const transaction = {
    id: `TXN_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    userId: userId,
    type: 'debit',
    amount: -amount,
    description: description,
    status: 'completed',
    createdAt: Date.now(),
    completedAt: Date.now()
  };
  
  transactionsData.transactions.push(transaction);
  
  saveAccountsData();
  saveTransactionsData();
  
  return { success: true, newBalance: account.balance };
}

/**
 * Ativa ou renova o plano de um usuário
 * @param {string} userId - ID do usuário
 * @param {string} planType - 'semanal' ou 'mensal'
 * @param {number} quantity - Quantidade de planos
 * @param {boolean} useBalance - Se deve usar o saldo
 * @returns {{success: boolean, account?: UserAccount, error?: string, price?: number}}
 */
export function activateOrRenewPlan(userId, planType, quantity = 1, useBalance = false) {
  const account = getOrCreateAccount(userId);
  const price = calculatePlanPrice(planType, quantity);
  const days = (CONFIG.PLAN_DAYS[planType] || 7) * quantity;
  
  // Se deve usar saldo
  if (useBalance) {
    if (account.balance < price) {
      return { 
        success: false, 
        error: `Saldo insuficiente. Necessário: R$${price.toFixed(2)}, Disponível: R$${account.balance.toFixed(2)}`,
        price: price
      };
    }
    
    const debitResult = removeBalance(userId, price, `Renovação ${planType} x${quantity}`);
    if (!debitResult.success) {
      return { success: false, error: debitResult.error, price: price };
    }
  }
  
  const now = Date.now();
  
  // Se já tem plano ativo, adicionar ao tempo restante
  // Se não tem ou expirou, começar do agora
  const baseTime = (account.planExpiresAt && account.planExpiresAt > now) 
    ? account.planExpiresAt 
    : now;
  
  account.planType = planType;
  account.planExpiresAt = baseTime + (days * 24 * 60 * 60 * 1000);
  account.lastActivity = now;
  
  saveAccountsData();
  
  console.log(`✅ [Account] Plano ativado: ${planType} x${quantity} para ${userId}`);
  console.log(`   Expira em: ${new Date(account.planExpiresAt).toISOString()}`);
  
  return {
    success: true,
    account: account,
    price: price,
    expiresAt: account.planExpiresAt
  };
}

/**
 * Ativa plano após pagamento (para uso pelo sistema de pagamento)
 * @param {string} userId - ID do usuário
 * @param {string} planType - 'semanal' ou 'mensal'
 * @param {number} quantity - Quantidade
 * @returns {{success: boolean, account?: UserAccount, error?: string}}
 */
export function activatePlanAfterPayment(userId, planType, quantity = 1) {
  const account = getOrCreateAccount(userId);
  const days = (CONFIG.PLAN_DAYS[planType] || 7) * quantity;
  
  const now = Date.now();
  
  // Se já tem plano ativo, adicionar ao tempo restante
  const baseTime = (account.planExpiresAt && account.planExpiresAt > now) 
    ? account.planExpiresAt 
    : now;
  
  account.planType = planType;
  account.planExpiresAt = baseTime + (days * 24 * 60 * 60 * 1000);
  account.lastActivity = now;
  
  saveAccountsData();
  
  console.log(`✅ [Account] Plano ativado após pagamento: ${planType} x${quantity} para ${userId}`);
  
  return {
    success: true,
    account: account,
    expiresAt: account.planExpiresAt
  };
}

/**
 * Vincula um usuário à conta de outro
 * @param {string} parentUserId - ID do usuário dono da conta
 * @param {string} linkedUserId - ID do usuário a ser vinculado
 * @param {string} linkedUsername - Nome do usuário vinculado
 * @returns {{success: boolean, error?: string}}
 */
export function linkUser(parentUserId, linkedUserId, linkedUsername) {
  // Não pode vincular a si mesmo
  if (parentUserId === linkedUserId) {
    return { success: false, error: 'Não pode vincular a si mesmo' };
  }
  
  const parentAccount = getOrCreateAccount(parentUserId);
  
  // Verificar limite de vinculações
  if (parentAccount.linkedUsers.length >= CONFIG.MAX_LINKED_USERS) {
    return { success: false, error: `Limite máximo de ${CONFIG.MAX_LINKED_USERS} usuários vinculados atingido` };
  }
  
  // Verificar se já está vinculado
  if (parentAccount.linkedUsers.includes(linkedUserId)) {
    return { success: false, error: 'Usuário já está vinculado à sua conta' };
  }
  
  // Verificar se o usuário a ser vinculado já tem conta
  const linkedAccount = getAccount(linkedUserId);
  
  // Se já está vinculado a outra conta, não pode
  if (linkedAccount && linkedAccount.linkedTo && linkedAccount.linkedTo !== parentUserId) {
    return { success: false, error: 'Este usuário já está vinculado a outra conta' };
  }
  
  // Se tem plano ativo próprio, não pode ser vinculado
  if (linkedAccount && linkedAccount.planExpiresAt && linkedAccount.planExpiresAt > Date.now()) {
    return { success: false, error: 'Este usuário possui um plano ativo próprio' };
  }
  
  // Criar conta para o usuário vinculado se não existir
  if (!linkedAccount) {
    getOrCreateAccount(linkedUserId, linkedUsername);
  }
  
  // Realizar vinculação
  const linkedAcc = getAccount(linkedUserId);
  linkedAcc.linkedTo = parentUserId;
  linkedAcc.lastActivity = Date.now();
  
  parentAccount.linkedUsers.push(linkedUserId);
  parentAccount.lastActivity = Date.now();
  
  saveAccountsData();
  
  console.log(`🔗 [Account] Usuário ${linkedUserId} vinculado a ${parentUserId}`);
  
  return { success: true };
}

/**
 * Desvincula um usuário da conta
 * @param {string} parentUserId - ID do dono da conta
 * @param {string} linkedUserId - ID do usuário vinculado
 * @returns {{success: boolean, error?: string}}
 */
export function unlinkUser(parentUserId, linkedUserId) {
  const parentAccount = getAccount(parentUserId);
  if (!parentAccount) {
    return { success: false, error: 'Conta não encontrada' };
  }
  
  // Verificar se está na lista
  if (!parentAccount.linkedUsers.includes(linkedUserId)) {
    return { success: false, error: 'Usuário não está vinculado à sua conta' };
  }
  
  // Remover vinculação
  parentAccount.linkedUsers = parentAccount.linkedUsers.filter(id => id !== linkedUserId);
  parentAccount.lastActivity = Date.now();
  
  // Atualizar conta do usuário vinculado
  const linkedAccount = getAccount(linkedUserId);
  if (linkedAccount) {
    linkedAccount.linkedTo = null;
    linkedAccount.lastActivity = Date.now();
  }
  
  saveAccountsData();
  
  console.log(`🔗 [Account] Usuário ${linkedUserId} desvinculado de ${parentUserId}`);
  
  return { success: true };
}

/**
 * Desvincula o próprio usuário de uma conta
 * @param {string} userId - ID do usuário que quer se desvincular
 * @returns {{success: boolean, error?: string}}
 */
export function selfUnlink(userId) {
  const account = getAccount(userId);
  if (!account || !account.linkedTo) {
    return { success: false, error: 'Você não está vinculado a nenhuma conta' };
  }
  
  const parentId = account.linkedTo;
  const parentAccount = getAccount(parentId);
  
  if (parentAccount) {
    parentAccount.linkedUsers = parentAccount.linkedUsers.filter(id => id !== userId);
    parentAccount.lastActivity = Date.now();
  }
  
  account.linkedTo = null;
  account.lastActivity = Date.now();
  
  saveAccountsData();
  
  console.log(`🔗 [Account] Usuário ${userId} se desvinculou de ${parentId}`);
  
  return { success: true, parentId: parentId };
}

/**
 * Obtém os usuários vinculados a uma conta
 * @param {string} userId - ID do dono
 * @returns {string[]}
 */
export function getLinkedUsers(userId) {
  const account = getAccount(userId);
  return account ? account.linkedUsers : [];
}

/**
 * Verifica se o usuário está vinculado a outra conta
 * @param {string} userId - ID do usuário
 * @returns {{isLinked: boolean, parentId?: string}}
 */
export function isLinked(userId) {
  const account = getAccount(userId);
  if (account && account.linkedTo) {
    return { isLinked: true, parentId: account.linkedTo };
  }
  return { isLinked: false };
}

/**
 * Registra uma transação pendente (para pagamentos)
 * @param {string} userId - ID do usuário
 * @param {string} transactionId - ID da transação do CashinPay
 * @param {Object} data - Dados da transação
 */
export function registerPendingTransaction(userId, transactionId, data) {
  accountsData.pendingTransactions[transactionId] = {
    userId: userId,
    ...data,
    createdAt: Date.now()
  };
  saveAccountsData();
}

/**
 * Obtém uma transação pendente
 * @param {string} transactionId - ID da transação
 * @returns {Object|null}
 */
export function getPendingTransaction(transactionId) {
  return accountsData.pendingTransactions[transactionId] || null;
}

/**
 * Remove uma transação pendente
 * @param {string} transactionId - ID da transação
 */
export function removePendingTransaction(transactionId) {
  if (accountsData.pendingTransactions[transactionId]) {
    delete accountsData.pendingTransactions[transactionId];
    saveAccountsData();
  }
}

/**
 * Lista todas as transações pendentes de um usuário
 * @param {string} userId - ID do usuário
 * @returns {Object[]}
 */
export function getUserPendingTransactions(userId) {
  return Object.entries(accountsData.pendingTransactions)
    .filter(([_, txn]) => txn.userId === userId)
    .map(([id, txn]) => ({ id, ...txn }));
}

/**
 * Obtém o tempo restante do plano
 * @param {string} userId - ID do usuário
 * @returns {{valid: boolean, remaining: number, formatted: string, expiresAt?: number}}
 */
export function getPlanTimeRemaining(userId) {
  // Dono do bot tem acesso permanente
  if (isBotOwner(userId)) {
    return { 
      valid: true, 
      remaining: Infinity, 
      formatted: 'Permanente (Dono)',
      isOwner: true
    };
  }
  
  const account = getAccount(userId);
  
  // Se está vinculado, verificar o plano do dono
  if (account && account.linkedTo) {
    const parentAccount = getAccount(account.linkedTo);
    if (parentAccount && parentAccount.planExpiresAt) {
      const remaining = parentAccount.planExpiresAt - Date.now();
      if (remaining > 0) {
        const days = Math.floor(remaining / (24 * 60 * 60 * 1000));
        const hours = Math.floor((remaining % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
        return {
          valid: true,
          remaining: remaining,
          formatted: `${days} dia(s) ${hours}h (via vinculação)`,
          expiresAt: parentAccount.planExpiresAt,
          isLinked: true,
          parentId: account.linkedTo
        };
      }
    }
  }
  
  // Verificar plano próprio
  if (!account || !account.planExpiresAt) {
    return { valid: false, remaining: 0, formatted: 'Sem plano' };
  }
  
  const remaining = account.planExpiresAt - Date.now();
  
  if (remaining <= 0) {
    return { valid: false, remaining: 0, formatted: 'Expirado' };
  }
  
  const days = Math.floor(remaining / (24 * 60 * 60 * 1000));
  const hours = Math.floor((remaining % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
  
  let formatted = '';
  if (days > 0) formatted += `${days} dia(s)`;
  if (hours > 0) formatted += ` ${hours}h`;
  
  return { 
    valid: true, 
    remaining: remaining, 
    formatted: formatted.trim() || 'Menos de 1 hora',
    expiresAt: account.planExpiresAt,
    isLinked: false
  };
}

/**
 * Ativa/desativa renovação automática
 * @param {string} userId - ID do usuário
 * @param {boolean} autoRenew - Estado desejado
 * @returns {{success: boolean, autoRenew: boolean, error?: string}}
 */
export function setAutoRenew(userId, autoRenew) {
  const account = getOrCreateAccount(userId);
  
  // Só pode ativar se tiver plano ativo
  if (autoRenew && (!account.planExpiresAt || account.planExpiresAt <= Date.now())) {
    return { success: false, error: 'Você precisa ter um plano ativo para ativar a renovação automática' };
  }
  
  account.autoRenew = autoRenew;
  account.lastActivity = Date.now();
  saveAccountsData();
  
  return { success: true, autoRenew: autoRenew };
}

/**
 * Verifica e executa renovações automáticas
 */
function checkAutoRenewals() {
  const now = Date.now();
  const renewalThreshold = 24 * 60 * 60 * 1000; // 24 horas antes
  
  Object.values(accountsData.accounts).forEach(account => {
    if (!account.autoRenew || !account.planExpiresAt) return;
    
    // Se está próximo de expirar (menos de 24h)
    const timeUntilExpiry = account.planExpiresAt - now;
    if (timeUntilExpiry > 0 && timeUntilExpiry <= renewalThreshold) {
      // Verificar se tem saldo suficiente
      const planType = account.planType || 'semanal';
      const price = CONFIG.PLAN_PRICES[planType];
      
      if (account.balance >= price) {
        // Renovar
        const result = activateOrRenewPlan(account.userId, planType, 1, true);
        if (result.success) {
          console.log(`🔄 [Account] Renovação automática executada para ${account.userId}`);
        }
      } else {
        console.log(`⚠️ [Account] Saldo insuficiente para renovação automática: ${account.userId}`);
        account.autoRenew = false; // Desativar se não tem saldo
        saveAccountsData();
      }
    }
  });
}

/**
 * Verifica expirações e notificações
 */
function startExpirationChecker() {
  // Verificar a cada hora
  setInterval(() => {
    checkAutoRenewals();
  }, 60 * 60 * 1000);
  
  console.log('✅ [Account] Verificador de expirações iniciado');
}

/**
 * Obtém estatísticas do sistema
 * @returns {Object}
 */
export function getStats() {
  const accounts = Object.values(accountsData.accounts);
  const now = Date.now();
  
  return {
    totalAccounts: accounts.length,
    activePlans: accounts.filter(a => a.planExpiresAt && a.planExpiresAt > now).length,
    expiredPlans: accounts.filter(a => a.planExpiresAt && a.planExpiresAt <= now).length,
    totalBalance: accounts.reduce((sum, a) => sum + a.balance, 0),
    linkedUsers: accounts.reduce((sum, a) => sum + a.linkedUsers.length, 0),
    pendingTransactions: Object.keys(accountsData.pendingTransactions).length
  };
}

/**
 * Obtém o histórico de transações de um usuário
 * @param {string} userId - ID do usuário
 * @param {number} limit - Limite de transações
 * @returns {Transaction[]}
 */
export function getUserTransactions(userId, limit = 10) {
  return transactionsData.transactions
    .filter(t => t.userId === userId)
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, limit);
}

/**
 * Obtém configurações de preços
 * @returns {Object}
 */
export function getPricingInfo() {
  return {
    semanal: {
      price: CONFIG.PLAN_PRICES.semanal,
      days: CONFIG.PLAN_DAYS.semanal
    },
    mensal: {
      price: CONFIG.PLAN_PRICES.mensal,
      days: CONFIG.PLAN_DAYS.mensal
    }
  };
}

// Exportar configurações
export { CONFIG };

// Exportar padrão
export default {
  initAccountSystem,
  getOrCreateAccount,
  getAccount,
  isBotOwner,
  hasActivePlan,
  canUseBot,
  calculatePrice,
  calculatePlanPrice,
  addBalance,
  activateOrRenewPlan,
  activatePlanAfterPayment,
  linkUser,
  unlinkUser,
  selfUnlink,
  getLinkedUsers,
  isLinked,
  registerPendingTransaction,
  getPendingTransaction,
  removePendingTransaction,
  getUserPendingTransactions,
  getPlanTimeRemaining,
  setAutoRenew,
  getStats,
  getUserTransactions,
  getPricingInfo,
  CONFIG
};
