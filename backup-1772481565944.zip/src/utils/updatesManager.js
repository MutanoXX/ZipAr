/**
 * RIAS GREMORY X AI - Updates Manager
 * Sistema de updates para o dono do bot enviar mensagens
 * 
 * @version 1.0.0
 * @author MutanoX
 */

import { EmbedBuilder } from 'discord.js';
import { getWebhooksData, addUpdate, getRecentUpdates } from './storageManager.js';

const BOT_OWNER_ID = '1387242867700924568';

/**
 * Verifica se o usuário é o dono do bot
 */
export function isBotOwner(userId) {
  return userId === BOT_OWNER_ID;
}

/**
 * Envia update para todos os servidores com canal de updates
 * @param {Client} client - Cliente Discord
 * @param {string} title - Título do update
 * @param {string} description - Descrição do update
 * @param {string} color - Cor do embed
 * @param {string} imageUrl - URL da imagem (opcional)
 */
export async function broadcastUpdate(client, title, description, color = '#8B5CF6', imageUrl = null) {
  const webhooksData = getWebhooksData();
  const results = {
    success: 0,
    failed: 0,
    servers: []
  };

  const embed = new EmbedBuilder()
    .setTitle(`🌹 ${title}`)
    .setDescription(description)
    .setColor(color)
    .setTimestamp()
    .setFooter({ text: 'Rias Gremory X AI - Update' });

  if (imageUrl) {
    embed.setImage(imageUrl);
  }

  // Adicionar ao histórico
  addUpdate({
    title,
    description,
    color,
    imageUrl
  });

  // Enviar para todos os webhooks de updates
  for (const [guildId, channels] of Object.entries(webhooksData.webhooks)) {
    for (const [channelId, webhook] of Object.entries(channels)) {
      if (webhook.type === 'updates') {
        try {
          const response = await fetch(webhook.url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              embeds: [embed.toJSON()],
              username: 'Rias Updates',
              avatar_url: client.user?.displayAvatarURL()
            })
          });

          if (response.ok) {
            results.success++;
            results.servers.push({ guildId, channelId, status: 'success' });
          } else {
            results.failed++;
            results.servers.push({ guildId, channelId, status: 'failed', error: response.statusText });
          }
        } catch (error) {
          results.failed++;
          results.servers.push({ guildId, channelId, status: 'error', error: error.message });
        }
      }
    }
  }

  console.log(`📢 [Updates] Enviado para ${results.success} servidores, ${results.failed} falhas`);
  return results;
}

/**
 * Envia update para um servidor específico
 */
export async function sendUpdateToServer(client, guildId, title, description, color = '#8B5CF6') {
  const webhooksData = getWebhooksData();
  const guildWebhooks = webhooksData.webhooks[guildId];

  if (!guildWebhooks) {
    return { success: false, error: 'Servidor não possui canal de updates configurado' };
  }

  const embed = new EmbedBuilder()
    .setTitle(`🌹 ${title}`)
    .setDescription(description)
    .setColor(color)
    .setTimestamp()
    .setFooter({ text: 'Rias Gremory X AI - Update' });

  for (const [channelId, webhook] of Object.entries(guildWebhooks)) {
    if (webhook.type === 'updates') {
      try {
        const response = await fetch(webhook.url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            embeds: [embed.toJSON()],
            username: 'Rias Updates',
            avatar_url: client.user?.displayAvatarURL()
          })
        });

        if (response.ok) {
          return { success: true };
        } else {
          return { success: false, error: response.statusText };
        }
      } catch (error) {
        return { success: false, error: error.message };
      }
    }
  }

  return { success: false, error: 'Webhook de updates não encontrado' };
}

/**
 * Obtém histórico de updates
 */
export function getUpdateHistory(limit = 10) {
  return getRecentUpdates(limit);
}

export default {
  isBotOwner,
  broadcastUpdate,
  sendUpdateToServer,
  getUpdateHistory
};
