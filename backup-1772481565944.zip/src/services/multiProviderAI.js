/**
 * RIAS GREMORY X AI - Multi-Provider AI System
 * Sistema de múltiplas fontes de IA com fallback automático
 * 
 * @version 1.0.0
 * @description Gerencia múltiplas fontes de IA com failover automático
 * 
 * PROVEDORES:
 * - Provider 1 (Primário): NVIDIA API (z-ai/glm5)
 * - Provider 2 (Secundário): G4F Space API (fallback gratuito)
 * 
 * CONFIGURAÇÃO (.env):
 * - IA_PROVIDER=1 (NVIDIA) ou 2 (G4F) ou 0 (auto-seleção)
 * - NVIDIA_API_KEY=xxx
 * - G4F_API_URL=https://g4f.space/api/nvidia/chat/completions
 */

import OpenAI from 'openai';
import https from 'https';

// Configuração dos provedores
const PROVIDERS = {
  NVIDIA: {
    name: 'NVIDIA API',
    baseURL: 'https://integrate.api.nvidia.com/v1',
    model: 'z-ai/glm5',
    timeout: 120000,
    maxRetries: 3,
    priority: 1,
    features: {
      streaming: true,
      thinking: true,
      maxTokens: 16384,
      supportsImages: false
    }
  },
  G4F: {
    name: 'G4F Space',
    baseURL: 'https://g4f.space/api/nvidia/chat/completions',
    model: 'z-ai/glm5',
    timeout: 60000,
    maxRetries: 5,
    priority: 2,
    features: {
      streaming: true,
      thinking: false,
      maxTokens: 8192,
      supportsImages: false
    }
  }
};

// Status dos provedores
const providerStatus = {
  NVIDIA: { available: true, lastError: null, consecutiveFailures: 0 },
  G4F: { available: true, lastError: null, consecutiveFailures: 0 }
};

// Estatísticas
const stats = {
  totalRequests: 0,
  nvidiaRequests: 0,
  g4fRequests: 0,
  fallbackCount: 0,
  errors: []
};

/**
 * Classe principal do Multi-Provider AI
 */
class MultiProviderAI {
  constructor() {
    this.nvidiaClient = null;
    this.g4fUrl = process.env.G4F_API_URL || PROVIDERS.G4F.baseURL;
    this.preferredProvider = parseInt(process.env.IA_PROVIDER) || 0; // 0 = auto
    this.initialized = false;
    
    // Configurações de assinante (serão setadas externamente)
    this.userTier = 'free'; // 'free', 'basic', 'premium', 'ultimate'
    this.tierConfig = this.getTierConfig('free');
  }

  /**
   * Configurações por tier de assinatura
   */
  getTierConfig(tier) {
    const configs = {
      free: {
        name: 'Gratuito',
        maxTokens: 4096,
        maxRequestsPerDay: 50,
        maxRequestsPerHour: 10,
        cooldownBetweenRequests: 5000, // 5 segundos
        priority: 'low',
        features: {
          advancedAgents: false,
          eventAutomations: 3,
          customEmbeds: 'basic',
          webhooks: false,
          priorityQueue: false,
          streamingResponses: false,
          imageGeneration: 5,
          concurrentTasks: 1
        },
        models: ['g4f'], // Usa apenas G4F por padrão
        responseDelay: 2000 // Delay artificial para incentivar assinatura
      },
      basic: {
        name: 'Básico',
        maxTokens: 8192,
        maxRequestsPerDay: 200,
        maxRequestsPerHour: 30,
        cooldownBetweenRequests: 2000,
        priority: 'medium',
        features: {
          advancedAgents: true,
          eventAutomations: 10,
          customEmbeds: 'advanced',
          webhooks: true,
          priorityQueue: false,
          streamingResponses: true,
          imageGeneration: 20,
          concurrentTasks: 2
        },
        models: ['nvidia', 'g4f'],
        responseDelay: 0
      },
      premium: {
        name: 'Premium',
        maxTokens: 16384,
        maxRequestsPerDay: 1000,
        maxRequestsPerHour: 100,
        cooldownBetweenRequests: 500,
        priority: 'high',
        features: {
          advancedAgents: true,
          eventAutomations: 50,
          customEmbeds: 'full',
          webhooks: true,
          priorityQueue: true,
          streamingResponses: true,
          imageGeneration: 100,
          concurrentTasks: 5
        },
        models: ['nvidia', 'g4f'],
        responseDelay: 0
      },
      ultimate: {
        name: 'Ultimate',
        maxTokens: 32768,
        maxRequestsPerDay: -1, // Ilimitado
        maxRequestsPerHour: -1,
        cooldownBetweenRequests: 0,
        priority: 'highest',
        features: {
          advancedAgents: true,
          eventAutomations: -1, // Ilimitado
          customEmbeds: 'full',
          webhooks: true,
          priorityQueue: true,
          streamingResponses: true,
          imageGeneration: -1, // Ilimitado
          concurrentTasks: 10
        },
        models: ['nvidia', 'g4f'],
        responseDelay: 0
      }
    };
    
    return configs[tier] || configs.free;
  }

  /**
   * Define o tier do usuário
   */
  setUserTier(tier) {
    this.userTier = tier;
    this.tierConfig = this.getTierConfig(tier);
    console.log(`👤 [MultiProvider] Tier definido: ${this.tierConfig.name}`);
  }

  /**
   * Inicializa os clientes
   */
  async initialize() {
    if (this.initialized) return;
    
    // Inicializar cliente NVIDIA
    const nvidiaKey = process.env.NVIDIA_API_KEY;
    if (nvidiaKey) {
      this.nvidiaClient = new OpenAI({
        baseURL: PROVIDERS.NVIDIA.baseURL,
        apiKey: nvidiaKey,
        timeout: PROVIDERS.NVIDIA.timeout,
        maxRetries: PROVIDERS.NVIDIA.maxRetries
      });
      console.log('✅ [MultiProvider] NVIDIA API inicializado');
    } else {
      providerStatus.NVIDIA.available = false;
      console.log('⚠️ [MultiProvider] NVIDIA API não configurada');
    }
    
    // G4F não precisa de inicialização
    console.log('✅ [MultiProvider] G4F Space pronto');
    
    this.initialized = true;
  }

  /**
   * Seleciona o melhor provedor disponível
   */
  selectProvider() {
    // Se tem preferência definida
    if (this.preferredProvider === 1 && providerStatus.NVIDIA.available) {
      return 'NVIDIA';
    }
    if (this.preferredProvider === 2 && providerStatus.G4F.available) {
      return 'G4F';
    }
    
    // Verificar se o tier permite NVIDIA
    if (!this.tierConfig.models.includes('nvidia')) {
      return 'G4F';
    }
    
    // Auto-seleção baseada em disponibilidade e prioridade
    if (providerStatus.NVIDIA.available && providerStatus.NVIDIA.consecutiveFailures < 3) {
      return 'NVIDIA';
    }
    
    if (providerStatus.G4F.available) {
      return 'G4F';
    }
    
    // Fallback final
    return providerStatus.NVIDIA.available ? 'NVIDIA' : 'G4F';
  }

  /**
   * Faz requisição de chat completion
   */
  async chatCompletion(messages, options = {}) {
    await this.initialize();
    
    const startTime = Date.now();
    stats.totalRequests++;
    
    // Aplicar delay para usuários gratuitos
    if (this.tierConfig.responseDelay > 0) {
      await this.sleep(this.tierConfig.responseDelay);
    }
    
    // Selecionar provedor
    let provider = this.selectProvider();
    let attempts = 0;
    const maxAttempts = 3;
    
    while (attempts < maxAttempts) {
      attempts++;
      
      try {
        console.log(`🔄 [MultiProvider] Tentativa ${attempts} - Provedor: ${provider}`);
        
        let response;
        
        if (provider === 'NVIDIA') {
          response = await this.nvidiaCompletion(messages, options);
          stats.nvidiaRequests++;
        } else {
          response = await this.g4fCompletion(messages, options);
          stats.g4fRequests++;
        }
        
        // Sucesso - resetar contador de falhas
        providerStatus[provider].consecutiveFailures = 0;
        providerStatus[provider].lastError = null;
        
        const elapsed = Date.now() - startTime;
        console.log(`✅ [MultiProvider] Sucesso em ${elapsed}ms (${provider})`);
        
        return response;
        
      } catch (error) {
        console.error(`❌ [MultiProvider] Erro no ${provider}:`, error.message);
        
        providerStatus[provider].lastError = error.message;
        providerStatus[provider].consecutiveFailures++;
        
        // Se muitas falhas consecutivas, marcar como indisponível temporariamente
        if (providerStatus[provider].consecutiveFailures >= 5) {
          providerStatus[provider].available = false;
          // Reativar após 5 minutos
          setTimeout(() => {
            providerStatus[provider].available = true;
            providerStatus[provider].consecutiveFailures = 0;
          }, 300000);
        }
        
        // Tentar fallback
        const fallbackProvider = provider === 'NVIDIA' ? 'G4F' : 'NVIDIA';
        
        if (providerStatus[fallbackProvider].available && 
            this.tierConfig.models.includes(fallbackProvider.toLowerCase())) {
          console.log(`🔄 [MultiProvider] Tentando fallback para ${fallbackProvider}...`);
          provider = fallbackProvider;
          stats.fallbackCount++;
          
          // Aguardar antes de tentar novamente (rate limit)
          await this.sleep(2000);
        } else {
          // Aguardar e tentar novamente com o mesmo provedor
          await this.sleep(3000 * attempts);
        }
      }
    }
    
    // Todas as tentativas falharam
    stats.errors.push({
      timestamp: new Date().toISOString(),
      provider,
      attempts,
      error: 'All providers failed'
    });
    
    throw new Error('Todos os provedores de IA falharam. Tente novamente em alguns instantes.');
  }

  /**
   * Completion via NVIDIA API
   */
  async nvidiaCompletion(messages, options = {}) {
    if (!this.nvidiaClient) {
      throw new Error('NVIDIA API não configurada');
    }
    
    const maxTokens = Math.min(
      options.maxTokens || this.tierConfig.maxTokens,
      PROVIDERS.NVIDIA.features.maxTokens
    );
    
    const completion = await this.nvidiaClient.chat.completions.create({
      model: options.model || PROVIDERS.NVIDIA.model,
      messages: messages,
      temperature: options.temperature ?? 1,
      top_p: options.topP ?? 1,
      max_tokens: maxTokens,
      stream: false,
      extra_body: {
        chat_template_kwargs: {
          enable_thinking: PROVIDERS.NVIDIA.features.thinking && this.tierConfig.features.advancedAgents,
          clear_thinking: false
        }
      }
    });
    
    return {
      content: completion.choices[0]?.message?.content || '',
      provider: 'NVIDIA',
      model: PROVIDERS.NVIDIA.model,
      tokens: {
        prompt: completion.usage?.prompt_tokens,
        completion: completion.usage?.completion_tokens,
        total: completion.usage?.total_tokens
      }
    };
  }

  /**
   * Completion via G4F Space API (adaptado do PowerShell)
   */
  async g4fCompletion(messages, options = {}) {
    const maxTokens = Math.min(
      options.maxTokens || this.tierConfig.maxTokens,
      PROVIDERS.G4F.features.maxTokens
    );
    
    const body = JSON.stringify({
      model: options.model || PROVIDERS.G4F.model,
      messages: messages,
      stream: false,
      max_tokens: maxTokens,
      temperature: options.temperature ?? 1
    });
    
    return new Promise((resolve, reject) => {
      const url = new URL(this.g4fUrl);
      
      const reqOptions = {
        hostname: url.hostname,
        port: url.port || 443,
        path: url.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(body)
        },
        timeout: PROVIDERS.G4F.timeout
      };
      
      let attempts = 0;
      const maxRetries = PROVIDERS.G4F.maxRetries;
      
      const makeRequest = () => {
        attempts++;
        
        const req = https.request(reqOptions, (res) => {
          let data = '';
          
          res.on('data', (chunk) => {
            data += chunk;
          });
          
          res.on('end', () => {
            if (res.statusCode === 429) {
              // Rate limit - aguardar e tentar novamente
              console.log(`⏳ [G4F] Rate limit. Aguardando 5s... (tentativa ${attempts}/${maxRetries})`);
              if (attempts < maxRetries) {
                setTimeout(makeRequest, 5000);
                return;
              }
              reject(new Error('Rate limit excedido'));
              return;
            }
            
            if (res.statusCode !== 200) {
              reject(new Error(`HTTP ${res.statusCode}: ${data}`));
              return;
            }
            
            try {
              const parsed = JSON.parse(data);
              const content = parsed.choices?.[0]?.message?.content || '';
              
              resolve({
                content,
                provider: 'G4F',
                model: PROVIDERS.G4F.model,
                tokens: {
                  prompt: parsed.usage?.prompt_tokens,
                  completion: parsed.usage?.completion_tokens,
                  total: parsed.usage?.total_tokens
                }
              });
            } catch (e) {
              // Tentar extrair conteúdo de streaming
              const contentMatch = data.match(/"content":"(.+?)"/g);
              if (contentMatch) {
                const content = contentMatch
                  .map(m => m.replace(/"content":"(.+?)"/, '$1'))
                  .join('');
                resolve({
                  content,
                  provider: 'G4F',
                  model: PROVIDERS.G4F.model
                });
              } else {
                reject(new Error('Falha ao parsear resposta'));
              }
            }
          });
        });
        
        req.on('error', (e) => {
          if (attempts < maxRetries) {
            console.log(`🔄 [G4F] Erro. Tentando novamente... (${attempts}/${maxRetries})`);
            setTimeout(makeRequest, 3000);
          } else {
            reject(e);
          }
        });
        
        req.on('timeout', () => {
          req.destroy();
          reject(new Error('Timeout'));
        });
        
        req.write(body);
        req.end();
      };
      
      makeRequest();
    });
  }

  /**
   * Streaming completion (apenas para assinantes)
   */
  async *streamCompletion(messages, options = {}) {
    if (!this.tierConfig.features.streamingResponses) {
      // Para gratuitos, retornar de uma vez
      const response = await this.chatCompletion(messages, options);
      yield response.content;
      return;
    }
    
    await this.initialize();
    
    const provider = this.selectProvider();
    
    if (provider === 'NVIDIA' && this.nvidiaClient) {
      const stream = await this.nvidiaClient.chat.completions.create({
        model: PROVIDERS.NVIDIA.model,
        messages: messages,
        temperature: options.temperature ?? 1,
        max_tokens: Math.min(options.maxTokens || this.tierConfig.maxTokens, PROVIDERS.NVIDIA.features.maxTokens),
        stream: true
      });
      
      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content;
        if (content) {
          yield content;
        }
      }
    } else {
      // G4F não suporta streaming da mesma forma
      const response = await this.g4fCompletion(messages, options);
      yield response.content;
    }
  }

  /**
   * Obtém estatísticas
   */
  getStats() {
    return {
      ...stats,
      providerStatus,
      currentTier: {
        name: this.tierConfig.name,
        features: this.tierConfig.features
      }
    };
  }

  /**
   * Verifica se o usuário pode usar um recurso
   */
  canUseFeature(feature) {
    return this.tierConfig.features[feature] !== false && 
           this.tierConfig.features[feature] !== 0;
  }

  /**
   * Obtém limite de um recurso
   */
  getFeatureLimit(feature) {
    return this.tierConfig.features[feature];
  }

  /**
   * Sleep utility
   */
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Singleton
const multiProviderAI = new MultiProviderAI();

export { MultiProviderAI, PROVIDERS, providerStatus, stats };
export default multiProviderAI;
