/**
 * Rias-Grimory-X - Serviço de Integração CashinPay
 * Gerencia pagamentos via PIX usando a API CashinPay
 * 
 * @version 3.0.0
 * @author MutanoX
 * 
 * API Base: https://api.cashinpaybr.com/api/v1
 */

// API Configuration
const API_BASE_URL = 'https://api.cashinpaybr.com/api/v1';
const API_KEY = process.env.CASHINPAY_API_KEY || 'sk_live_b81dbb21f62367d87f4401b22821899c4b108a0a';

/**
 * Headers padrão para requisições
 */
function getHeaders() {
  return {
    'Authorization': `Bearer ${API_KEY}`,
    'Content-Type': 'application/json'
  };
}

/**
 * Cria uma transação PIX
 * @param {Object} params - Parâmetros da transação
 * @param {number} params.amount - Valor em reais (min: 5.00, max: 10000.00)
 * @param {string} params.description - Descrição da transação
 * @param {Object} params.customer - Dados do cliente
 * @param {string} params.customer.name - Nome completo
 * @param {string} params.customer.email - Email
 * @param {string} params.customer.phone - Telefone (apenas números)
 * @param {string} params.customer.document - CPF (apenas números)
 * @param {string} [params.transaction_id] - ID único (opcional)
 * @returns {Promise<{success: boolean, data?: Object, error?: string}>}
 */
export async function createTransaction(params) {
  try {
    const { amount, description, customer, transaction_id } = params;
    
    // Validações
    if (!amount || amount < 5.00 || amount > 10000.00) {
      return { 
        success: false, 
        error: 'O valor deve estar entre R$ 5,00 e R$ 10.000,00' 
      };
    }
    
    if (!customer || !customer.name) {
      return { 
        success: false, 
        error: 'Nome do cliente é obrigatório' 
      };
    }
    
    const payload = {
      amount: parseFloat(amount.toFixed(2)),
      description: description || 'Pagamento Rias-Grimory-X',
      customer: {
        name: customer.name,
        email: customer.email || `${customer.name.toLowerCase().replace(/\s+/g, '.')}@temp.com`,
        phone: customer.phone || '11999999999',
        document: customer.document || '12345678900'
      }
    };
    
    if (transaction_id) {
      payload.transaction_id = transaction_id;
    }
    
    console.log(`🔄 [CashinPay] Criando transação: R$${amount.toFixed(2)}`);
    console.log(`📝 [CashinPay] Payload:`, JSON.stringify(payload, null, 2));
    
    const response = await fetch(`${API_BASE_URL}/transactions`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(payload)
    });
    
    let data;
    const contentType = response.headers.get('content-type');
    
    try {
      if (contentType && contentType.includes('application/json')) {
        data = await response.json();
      } else {
        const text = await response.text();
        console.error(`❌ [CashinPay] Resposta não é JSON. Status: ${response.status}`);
        console.error(`❌ [CashinPay] Corpo da resposta:`, text);
        return {
          success: false,
          error: `Erro ${response.status}: Resposta inválida da API`
        };
      }
    } catch (parseError) {
      console.error(`❌ [CashinPay] Erro ao fazer parse da resposta:`, parseError.message);
      return {
        success: false,
        error: `Erro ao processar resposta: ${parseError.message}`
      };
    }
    
    if (!response.ok) {
      console.error(`❌ [CashinPay] Erro ${response.status}:`, data);
      return {
        success: false,
        error: data.error?.message || `Erro ${response.status}: ${response.statusText}`
      };
    }
    
    console.log(`✅ [CashinPay] Transação criada: ${data.data?.id}`);
    
    return {
      success: true,
      data: data.data
    };
    
  } catch (error) {
    console.error('❌ [CashinPay] Erro ao criar transação:', error.message);
    return {
      success: false,
      error: `Erro de conexão: ${error.message}`
    };
  }
}

/**
 * Consulta uma transação pelo ID
 * @param {string} transactionId - ID da transação
 * @returns {Promise<{success: boolean, data?: Object, error?: string}>}
 */
export async function getTransaction(transactionId) {
  try {
    if (!transactionId) {
      return { success: false, error: 'ID da transação é obrigatório' };
    }
    
    console.log(`🔄 [CashinPay] Consultando transação: ${transactionId}`);
    
    const response = await fetch(`${API_BASE_URL}/transactions/${transactionId}`, {
      method: 'GET',
      headers: getHeaders()
    });
    
    let data;
    const contentType = response.headers.get('content-type');
    
    try {
      if (contentType && contentType.includes('application/json')) {
        data = await response.json();
      } else {
        const text = await response.text();
        console.error(`❌ [CashinPay] Resposta não é JSON. Status: ${response.status}`);
        console.error(`❌ [CashinPay] Corpo da resposta:`, text);
        return {
          success: false,
          error: `Erro ${response.status}: Resposta inválida da API`
        };
      }
    } catch (parseError) {
      console.error(`❌ [CashinPay] Erro ao fazer parse da resposta:`, parseError.message);
      return {
        success: false,
        error: `Erro ao processar resposta: ${parseError.message}`
      };
    }
    
    if (!response.ok) {
      console.error(`❌ [CashinPay] Erro ${response.status}:`, data);
      return {
        success: false,
        error: data.error?.message || `Erro ${response.status}: ${response.statusText}`
      };
    }
    
    return {
      success: true,
      data: data.data
    };
    
  } catch (error) {
    console.error('❌ [CashinPay] Erro ao consultar transação:', error.message);
    return {
      success: false,
      error: `Erro de conexão: ${error.message}`
    };
  }
}

/**
 * Verifica se uma transação foi paga
 * @param {string} transactionId - ID da transação
 * @returns {Promise<{success: boolean, paid: boolean, status?: string, data?: Object, error?: string}>}
 */
export async function checkTransactionPaid(transactionId) {
  const result = await getTransaction(transactionId);
  
  if (!result.success) {
    return {
      success: false,
      paid: false,
      error: result.error
    };
  }
  
  const status = result.data?.status;
  const paid = status === 'paid';
  
  return {
    success: true,
    paid: paid,
    status: status,
    data: result.data
  };
}

/**
 * Cria um link de pagamento
 * @param {Object} params - Parâmetros do link
 * @param {number} params.amount - Valor em reais
 * @param {string} params.product_name - Nome do produto
 * @param {string} [params.description] - Descrição
 * @param {number} [params.max_uses] - Limite de usos
 * @param {string} [params.expires_at] - Data de expiração (ISO 8601)
 * @returns {Promise<{success: boolean, data?: Object, error?: string}>}
 */
export async function createPaymentLink(params) {
  try {
    const { amount, product_name, description, max_uses, expires_at } = params;
    
    if (!amount || amount < 5.00 || amount > 10000.00) {
      return { 
        success: false, 
        error: 'O valor deve estar entre R$ 5,00 e R$ 10.000,00' 
      };
    }
    
    if (!product_name) {
      return { success: false, error: 'Nome do produto é obrigatório' };
    }
    
    const payload = {
      amount: parseFloat(amount.toFixed(2)),
      product_name: product_name
    };
    
    if (description) payload.description = description;
    if (max_uses) payload.max_uses = max_uses;
    if (expires_at) payload.expires_at = expires_at;
    
    console.log(`🔄 [CashinPay] Criando link de pagamento: ${product_name}`);
    
    const response = await fetch(`${API_BASE_URL}/payment-links`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(payload)
    });
    
    let data;
    const contentType = response.headers.get('content-type');
    
    try {
      if (contentType && contentType.includes('application/json')) {
        data = await response.json();
      } else {
        const text = await response.text();
        console.error(`❌ [CashinPay] Resposta não é JSON. Status: ${response.status}`);
        console.error(`❌ [CashinPay] Corpo da resposta:`, text);
        return {
          success: false,
          error: `Erro ${response.status}: Resposta inválida da API`
        };
      }
    } catch (parseError) {
      console.error(`❌ [CashinPay] Erro ao fazer parse da resposta:`, parseError.message);
      return {
        success: false,
        error: `Erro ao processar resposta: ${parseError.message}`
      };
    }
    
    if (!response.ok) {
      console.error(`❌ [CashinPay] Erro ${response.status}:`, data);
      return {
        success: false,
        error: data.error?.message || `Erro ${response.status}: ${response.statusText}`
      };
    }
    
    console.log(`✅ [CashinPay] Link criado: ${data.data?.id}`);
    
    return {
      success: true,
      data: data.data
    };
    
  } catch (error) {
    console.error('❌ [CashinPay] Erro ao criar link:', error.message);
    return {
      success: false,
      error: `Erro de conexão: ${error.message}`
    };
  }
}

/**
 * Consulta o saldo da conta
 * @returns {Promise<{success: boolean, data?: Object, error?: string}>}
 */
export async function getBalance() {
  try {
    console.log(`🔄 [CashinPay] Consultando saldo`);
    
    const response = await fetch(`${API_BASE_URL}/balance`, {
      method: 'GET',
      headers: getHeaders()
    });
    
    let data;
    const contentType = response.headers.get('content-type');
    
    try {
      if (contentType && contentType.includes('application/json')) {
        data = await response.json();
      } else {
        const text = await response.text();
        console.error(`❌ [CashinPay] Resposta não é JSON. Status: ${response.status}`);
        console.error(`❌ [CashinPay] Corpo da resposta:`, text);
        return {
          success: false,
          error: `Erro ${response.status}: Resposta inválida da API`
        };
      }
    } catch (parseError) {
      console.error(`❌ [CashinPay] Erro ao fazer parse da resposta:`, parseError.message);
      return {
        success: false,
        error: `Erro ao processar resposta: ${parseError.message}`
      };
    }
    
    if (!response.ok) {
      console.error(`❌ [CashinPay] Erro ${response.status}:`, data);
      return {
        success: false,
        error: data.error?.message || `Erro ${response.status}: ${response.statusText}`
      };
    }
    
    return {
      success: true,
      data: data.data
    };
    
  } catch (error) {
    console.error('❌ [CashinPay] Erro ao consultar saldo:', error.message);
    return {
      success: false,
      error: `Erro de conexão: ${error.message}`
    };
  }
}

/**
 * Cria uma transação de pagamento de plano
 * @param {string} userId - ID do usuário Discord
 * @param {string} username - Nome do usuário
 * @param {string} planType - 'semanal' ou 'mensal'
 * @param {number} quantity - Quantidade
 * @returns {Promise<{success: boolean, transaction?: Object, error?: string}>}
 */
export async function createPlanPayment(userId, username, planType, quantity = 1) {
  // Preços dos planos
  const PLAN_PRICES = {
    'semanal': 20.00,
    'mensal': 29.59
  };
  
  const price = PLAN_PRICES[planType] || PLAN_PRICES['semanal'];
  const totalAmount = price * quantity;
  
  const transaction_id = `RIAS_${userId}_${Date.now()}`;
  
  const result = await createTransaction({
    amount: totalAmount,
    description: `Plano ${planType} x${quantity} - ${username}`,
    customer: {
      name: username,
      email: `user_${userId}@rias-bot.discord`,
      phone: '11999999999',
      document: '12345678900'
    },
    transaction_id: transaction_id
  });
  
  if (!result.success) {
    return { success: false, error: result.error };
  }
  
  return {
    success: true,
    transaction: {
      id: result.data.id,
      amount: totalAmount,
      planType: planType,
      quantity: quantity,
      qrcode: result.data.pix?.qrcode,
      copyPaste: result.data.pix?.copy_paste,
      expirationDate: result.data.pix?.expiration_date,
      status: result.data.status
    }
  };
}

/**
 * Cria uma transação para adicionar saldo
 * @param {string} userId - ID do usuário Discord
 * @param {string} username - Nome do usuário
 * @param {number} amount - Valor a adicionar
 * @returns {Promise<{success: boolean, transaction?: Object, error?: string}>}
 */
export async function createDepositPayment(userId, username, amount) {
  const transaction_id = `DEPOSIT_${userId}_${Date.now()}`;
  
  const result = await createTransaction({
    amount: amount,
    description: `Adicionar saldo - ${username}`,
    customer: {
      name: username,
      email: `user_${userId}@rias-bot.discord`,
      phone: '11999999999',
      document: '12345678900'
    },
    transaction_id: transaction_id
  });
  
  if (!result.success) {
    return { success: false, error: result.error };
  }
  
  return {
    success: true,
    transaction: {
      id: result.data.id,
      amount: amount,
      type: 'deposit',
      qrcode: result.data.pix?.qrcode,
      copyPaste: result.data.pix?.copy_paste,
      expirationDate: result.data.pix?.expiration_date,
      status: result.data.status
    }
  };
}

/**
 * Verifica o status de múltiplas transações
 * @param {string[]} transactionIds - IDs das transações
 * @returns {Promise<{success: boolean, results?: Object[], error?: string}>}
 */
export async function checkMultipleTransactions(transactionIds) {
  try {
    const results = [];
    
    for (const id of transactionIds) {
      const result = await checkTransactionPaid(id);
      if (result.success) {
        results.push({
          id: id,
          paid: result.paid,
          status: result.status
        });
      }
    }
    
    return {
      success: true,
      results: results
    };
    
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}

/**
 * Formata o QR Code para exibição (converte para URL de imagem se necessário)
 * @param {string} qrcode - String do QR Code
 * @returns {string}
 */
export function formatQRCode(qrcode) {
  // Se já é uma URL, retornar como está
  if (qrcode.startsWith('http')) {
    return qrcode;
  }
  
  // Se é o conteúdo bruto do PIX, retornar para uso com copy-paste
  return qrcode;
}

/**
 * Obtém informações sobre os planos disponíveis
 * @returns {Object}
 */
export function getPlansInfo() {
  return {
    semanal: {
      name: 'Semanal',
      price: 20.00,
      days: 7,
      description: 'Acesso por 7 dias'
    },
    mensal: {
      name: 'Mensal',
      price: 29.59,
      days: 30,
      description: 'Acesso por 30 dias - Melhor custo-benefício'
    }
  };
}

// Exportar serviço
export default {
  createTransaction,
  getTransaction,
  checkTransactionPaid,
  createPaymentLink,
  getBalance,
  createPlanPayment,
  createDepositPayment,
  checkMultipleTransactions,
  formatQRCode,
  getPlansInfo
};
