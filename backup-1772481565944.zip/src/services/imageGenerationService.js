/**
 * RIAS GREMORY X AI - Image Generation Service
 * Serviço de Geração de Imagens usando API própria
 * 
 * @version 1.0.0
 * @description Integração com API de geração de imagens
 * 
 * API: https://rias-x.discloud.app/v1/images/generations
 * Modelos: flux, etc
 */

import https from 'https';

// Configuração da API
const IMAGE_API_CONFIG = {
  baseURL: 'https://rias-x.discloud.app',
  endpoint: '/v1/images/generations',
  authorization: 'Bearer MutanoX3397',
  defaultModel: 'flux',
  timeout: 60000
};

// Modelos disponíveis
const AVAILABLE_MODELS = {
  flux: {
    name: 'Flux',
    description: 'Modelo de alta qualidade para imagens fotorrealistas',
    maxResolution: '1024x1024',
    styles: ['photorealistic', 'anime', 'artistic', '3d']
  },
  'flux-pro': {
    name: 'Flux Pro',
    description: 'Modelo premium com maior qualidade',
    maxResolution: '1344x768',
    styles: ['photorealistic', 'anime', 'artistic', '3d', 'fantasy']
  },
  'flux-anime': {
    name: 'Flux Anime',
    description: 'Especializado em estilo anime',
    maxResolution: '1024x1024',
    styles: ['anime', 'manga', 'chibi']
  }
};

// Estilos predefinidos
const IMAGE_STYLES = {
  photorealistic: {
    suffix: ', photorealistic, highly detailed, 8k resolution, professional photography',
    description: 'Fotorrealista'
  },
  anime: {
    suffix: ', anime style, high quality, detailed, vibrant colors',
    description: 'Anime'
  },
  artistic: {
    suffix: ', artistic, digital art, detailed illustration, masterpiece',
    description: 'Artístico'
  },
  fantasy: {
    suffix: ', fantasy art, magical, ethereal, detailed, epic',
    description: 'Fantasia'
  },
  '3d': {
    suffix: ', 3D render, highly detailed, octane render, cinema 4d',
    description: '3D Render'
  },
  minimalist: {
    suffix: ', minimalist, clean, simple, elegant',
    description: 'Minimalista'
  },
  cinematic: {
    suffix: ', cinematic, movie scene, dramatic lighting, epic composition',
    description: 'Cinematográfico'
  },
  rias: {
    suffix: ', Rias Gremory from High School DxD, anime style, beautiful, red hair, detailed',
    description: 'Estilo Rias'
  }
};

// Tamanhos disponíveis
const IMAGE_SIZES = {
  '1024x1024': { width: 1024, height: 1024, name: 'Quadrado' },
  '1344x768': { width: 1344, height: 768, name: 'Paisagem' },
  '768x1344': { width: 768, height: 1344, name: 'Retrato' },
  '1152x864': { width: 1152, height: 864, name: 'Paisagem HD' },
  '864x1152': { width: 864, height: 1152, name: 'Retrato HD' }
};

/**
 * Classe principal do serviço de imagens
 */
class ImageGenerationService {
  constructor() {
    this.apiKey = process.env.IMAGE_API_KEY || IMAGE_API_CONFIG.authorization;
    this.baseURL = process.env.IMAGE_API_URL || IMAGE_API_CONFIG.baseURL;
    this.defaultModel = process.env.IMAGE_MODEL || IMAGE_API_CONFIG.defaultModel;
    this.requestCount = 0;
    this.errorCount = 0;
  }

  /**
   * Gera uma imagem usando a API
   * @param {Object} options - Opções de geração
   * @returns {Promise<Object>} - Resultado com URL da imagem
   */
  async generateImage(options) {
    const {
      prompt,
      model = this.defaultModel,
      style = null,
      size = '1024x1024',
      n = 1,
      negative = null,
      enhance = true
    } = options;

    // Construir prompt final
    let finalPrompt = prompt;
    
    // Adicionar estilo se especificado
    if (style && IMAGE_STYLES[style]) {
      finalPrompt += IMAGE_STYLES[style].suffix;
    }
    
    // Melhorar prompt automaticamente se habilitado
    if (enhance) {
      finalPrompt = this.enhancePrompt(finalPrompt);
    }

    // Adicionar prompt negativo se especificado
    let fullPrompt = finalPrompt;
    if (negative) {
      fullPrompt = `${finalPrompt} --negative ${negative}`;
    }

    console.log(`🖼️ [ImageService] Gerando imagem: "${prompt.substring(0, 50)}..."`);
    console.log(`📊 [ImageService] Modelo: ${model}, Tamanho: ${size}`);

    const requestBody = {
      model: model,
      prompt: fullPrompt,
      n: Math.min(n, 4), // Máximo 4 imagens
      response_format: 'url'
    };

    try {
      const startTime = Date.now();
      
      const response = await this.makeRequest(requestBody);
      
      const elapsed = Date.now() - startTime;
      console.log(`✅ [ImageService] Imagem gerada em ${elapsed}ms`);
      
      this.requestCount++;
      
      return {
        success: true,
        images: response.data.map(img => ({
          url: img.url,
          prompt: finalPrompt
        })),
        model: model,
        created: response.created,
        elapsed: elapsed
      };
      
    } catch (error) {
      this.errorCount++;
      console.error(`❌ [ImageService] Erro:`, error.message);
      
      return {
        success: false,
        error: error.message,
        fallback: await this.getFallbackImage(prompt)
      };
    }
  }

  /**
   * Faz a requisição HTTP para a API
   */
  async makeRequest(body) {
    return new Promise((resolve, reject) => {
      const url = new URL(`${this.baseURL}${IMAGE_API_CONFIG.endpoint}`);
      
      const options = {
        hostname: url.hostname,
        port: url.port || 443,
        path: url.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': this.apiKey
        },
        timeout: IMAGE_API_CONFIG.timeout
      };

      const req = https.request(options, (res) => {
        let data = '';
        
        res.on('data', (chunk) => {
          data += chunk;
        });
        
        res.on('end', () => {
          if (res.statusCode !== 200) {
            reject(new Error(`HTTP ${res.statusCode}: ${data}`));
            return;
          }
          
          try {
            const parsed = JSON.parse(data);
            resolve(parsed);
          } catch (e) {
            reject(new Error('Resposta inválida da API'));
          }
        });
      });

      req.on('error', (e) => {
        reject(e);
      });

      req.on('timeout', () => {
        req.destroy();
        reject(new Error('Timeout na geração de imagem'));
      });

      req.write(JSON.stringify(body));
      req.end();
    });
  }

  /**
   * Melhora o prompt automaticamente
   */
  enhancePrompt(prompt) {
    // Adicionar qualidade se não tiver
    const qualityKeywords = ['high quality', 'detailed', 'masterpiece', 'best quality'];
    const hasQuality = qualityKeywords.some(k => prompt.toLowerCase().includes(k));
    
    if (!hasQuality) {
      prompt += ', high quality, detailed';
    }
    
    return prompt;
  }

  /**
   * Imagem de fallback (pollinations)
   */
  async getFallbackImage(prompt) {
    const encodedPrompt = encodeURIComponent(prompt);
    return {
      url: `https://image.pollinations.ai/prompt/${encodedPrompt}?width=1024&height=1024`,
      isFallback: true
    };
  }

  /**
   * Gera múltiplas variações de uma imagem
   */
  async generateVariations(basePrompt, count = 4, style = null) {
    const variations = [];
    
    for (let i = 0; i < count; i++) {
      // Adicionar variação ao prompt
      const variationSuffixes = [
        ', dramatic lighting',
        ', soft lighting',
        ', vibrant colors',
        ', dark atmosphere'
      ];
      
      const variedPrompt = basePrompt + (variationSuffixes[i % variationSuffixes.length]);
      
      const result = await this.generateImage({
        prompt: variedPrompt,
        style: style,
        n: 1
      });
      
      if (result.success) {
        variations.push(result.images[0]);
      }
      
      // Pequeno delay entre requisições
      if (i < count - 1) {
        await new Promise(r => setTimeout(r, 1000));
      }
    }
    
    return variations;
  }

  /**
   * Gera imagem no estilo Rias Gremory
   */
  async generateRiasImage(options = {}) {
    const {
      scene = 'portrait',
      outfit = 'default',
      expression = 'confident',
      background = 'elegant',
      additional = ''
    } = options;

    const scenes = {
      portrait: 'beautiful portrait, upper body, looking at viewer',
      fullbody: 'full body shot, standing pose, elegant pose',
      action: 'dynamic action pose, magical energy',
      casual: 'casual setting, relaxed pose, everyday scene',
      formal: 'formal setting, elegant dress, sophisticated'
    };

    const outfits = {
      default: 'school uniform, Kuoh Academy uniform',
      casual: 'casual modern clothes',
      elegant: 'elegant evening dress',
      battle: 'battle outfit, magical armor elements',
      swimsuit: 'beautiful swimsuit, beach setting'
    };

    const expressions = {
      confident: 'confident smile, self-assured expression',
      playful: 'playful expression, teasing smile',
      serious: 'serious expression, determined look',
      gentle: 'gentle smile, caring expression',
      mysterious: 'mysterious expression, enigmatic smile'
    };

    const backgrounds = {
      elegant: 'elegant mansion interior, luxurious background',
      school: 'Kuoh Academy grounds, school setting',
      nature: 'beautiful garden, cherry blossoms',
      night: 'night sky, moonlight, stars',
      magical: 'magical atmosphere, ethereal glow'
    };

    const prompt = `Rias Gremory from High School DxD, anime style, ${scenes[scene]}, ${outfits[outfit]}, ${expressions[expression]}, ${backgrounds[background]}, ${additional}, highly detailed, beautiful, red hair, blue eyes, voluptuous, masterpiece, best quality`;

    return await this.generateImage({
      prompt,
      model: 'flux-anime',
      style: 'anime',
      enhance: false
    });
  }

  /**
   * Gera logo/banner para servidor
   */
  async generateServerAsset(options) {
    const {
      type = 'logo', // 'logo', 'banner', 'icon'
      theme = 'gaming',
      name = 'Server',
      colors = [],
      style = 'modern'
    } = options;

    const prompts = {
      logo: `${theme} themed server logo for "${name}", professional design, clean, modern, ${colors.length > 0 ? `${colors.join(' and ')} color scheme` : 'vibrant colors'}, suitable for Discord server, high quality`,
      banner: `${theme} themed server banner for "${name}", wide format, eye-catching design, ${style} style, professional, ${colors.length > 0 ? `${colors.join(' and ')} colors` : 'dynamic colors'}, detailed background`,
      icon: `${theme} themed icon for "${name}", square format, simple but striking design, ${style} style, ${colors.length > 0 ? `${colors.join(' and ')} colors` : 'bold colors'}, clean lines, high contrast`
    };

    const sizes = {
      logo: '1024x1024',
      banner: '1344x768',
      icon: '1024x1024'
    };

    return await this.generateImage({
      prompt: prompts[type],
      model: 'flux',
      size: sizes[type],
      style: 'artistic'
    });
  }

  /**
   * Obtém modelos disponíveis
   */
  getAvailableModels() {
    return Object.entries(AVAILABLE_MODELS).map(([id, model]) => ({
      id,
      ...model
    }));
  }

  /**
   * Obtém estilos disponíveis
   */
  getAvailableStyles() {
    return Object.entries(IMAGE_STYLES).map(([id, style]) => ({
      id,
      name: style.description,
      suffix: style.suffix
    }));
  }

  /**
   * Obtém tamanhos disponíveis
   */
  getAvailableSizes() {
    return Object.entries(IMAGE_SIZES).map(([id, size]) => ({
      id,
      ...size
    }));
  }

  /**
   * Estatísticas do serviço
   */
  getStats() {
    return {
      totalRequests: this.requestCount,
      errors: this.errorCount,
      successRate: this.requestCount > 0 
        ? ((this.requestCount - this.errorCount) / this.requestCount * 100).toFixed(2) + '%'
        : 'N/A'
    };
  }
}

// Singleton
const imageGenerationService = new ImageGenerationService();

export { 
  ImageGenerationService, 
  AVAILABLE_MODELS, 
  IMAGE_STYLES, 
  IMAGE_SIZES,
  imageGenerationService 
};

export default imageGenerationService;
