/**
 * Rias-Grimory-X - Gerenciador de Pagamentos
 * Coordena pagamentos com CashinPay e ativação de planos
 *
 * @version 1.0.0
 * @author MutanoX
 *
 * FUNCIONALIDADES:
 * - Criar pagamentos para renovação de plano
 * - Criar pagamentos para adicionar saldo
 * - Confirmar e processar pagamentos
 * - Integração com accountManager
 */

import cashinPayService from './cashinPayService.js';
import accountManager from '../utils/accountManager.js';

const CONFIG = {
  // Preços
  PLAN_PRICES: {
    'semanal': 20.00,
    'mensal': 29.59
  },
  
  // Duração
  PLAN_DAYS: {
    'semanal': 7,
    'mensal': 30
  },
  
  // Mínimo para depósito
  MIN_DEPOSIT: 5.00
};

/**
 * Cria um pagamento de renovação de plano
 * @param {string} userId - ID do usuário Discord
 * @param {string} username - Nome do usuário
 * @param {string} planType - 'semanal' ou 'mensal'
 * @param {number} quantity - Quantidade de planos (padrão: 1)
 * @returns {Promise<{success: boolean, payment?: Object, error?: string}>}
 */
export async function createPlanPayment(userId, username, planType, quantity = 1) {
  try {
    // Validar plano
    if (!CONFIG.PLAN_PRICES[planType]) {
      return {
        success: false,
        error: `Tipo de plano inválido: ${planType}`
      };
    }

    // Validar quantidade
    if (quantity < 1 || quantity > 12) {
      return {
        success: false,
        error: 'Quantidade deve estar entre 1 e 12'
      };
    }

    // Calcular valor
    const unitPrice = CONFIG.PLAN_PRICES[planType];
    const totalAmount = unitPrice * quantity;

    console.log(`💳 [Payment] Criando pagamento: ${username} - ${planType} x${quantity} = R$${totalAmount.toFixed(2)}`);

    // Criar transação PIX com CashinPay
    const result = await cashinPayService.createPlanPayment(
      userId,
      username,
      planType,
      quantity
    );

    if (!result.success) {
      return {
        success: false,
        error: result.error
      };
    }

    // Registrar transação pendente na conta
    accountManager.registerPendingTransaction(
      userId,
      result.transaction.id,
      {
        type: 'plan_renewal',
        planType: planType,
        quantity: quantity,
        amount: totalAmount,
        status: 'pending',
        createdAt: Date.now()
      }
    );

    return {
      success: true,
      payment: {
        transactionId: result.transaction.id,
        amount: totalAmount,
        planType: planType,
        quantity: quantity,
        qrcode: result.transaction.qrcode,
        copyPaste: result.transaction.copyPaste,
        expirationDate: result.transaction.expirationDate,
        pricePerUnit: unitPrice
      }
    };

  } catch (error) {
    console.error('❌ [Payment] Erro ao criar pagamento:', error.message);
    return {
      success: false,
      error: `Erro ao criar pagamento: ${error.message}`
    };
  }
}

/**
 * Cria um pagamento para adicionar saldo
 * @param {string} userId - ID do usuário Discord
 * @param {string} username - Nome do usuário
 * @param {number} amount - Valor em reais
 * @returns {Promise<{success: boolean, payment?: Object, error?: string}>}
 */
export async function createDepositPayment(userId, username, amount) {
  try {
    // Validar valor
    if (amount < CONFIG.MIN_DEPOSIT) {
      return {
        success: false,
        error: `Valor mínimo para depósito é R$ ${CONFIG.MIN_DEPOSIT.toFixed(2)}`
      };
    }

    if (amount > 10000.00) {
      return {
        success: false,
        error: 'Valor máximo para depósito é R$ 10.000,00'
      };
    }

    console.log(`💳 [Payment] Criando depósito: ${username} - R$${amount.toFixed(2)}`);

    // Criar transação PIX com CashinPay
    const result = await cashinPayService.createDepositPayment(
      userId,
      username,
      amount
    );

    if (!result.success) {
      return {
        success: false,
        error: result.error
      };
    }

    // Registrar transação pendente na conta
    accountManager.registerPendingTransaction(
      userId,
      result.transaction.id,
      {
        type: 'deposit',
        amount: amount,
        status: 'pending',
        createdAt: Date.now()
      }
    );

    return {
      success: true,
      payment: {
        transactionId: result.transaction.id,
        amount: amount,
        qrcode: result.transaction.qrcode,
        copyPaste: result.transaction.copyPaste,
        expirationDate: result.transaction.expirationDate,
        type: 'deposit'
      }
    };

  } catch (error) {
    console.error('❌ [Payment] Erro ao criar depósito:', error.message);
    return {
      success: false,
      error: `Erro ao criar depósito: ${error.message}`
    };
  }
}

/**
 * Confirma um pagamento e ativa o plano ou saldo
 * @param {string} userId - ID do usuário
 * @param {string} transactionId - ID da transação do CashinPay
 * @returns {Promise<{success: boolean, message?: string, account?: Object, error?: string}>}
 */
export async function confirmPayment(userId, transactionId) {
  try {
    // Buscar transação pendente
    const pendingTxn = accountManager.getPendingTransaction(transactionId);
    
    if (!pendingTxn) {
      return {
        success: false,
        error: 'Transação não encontrada'
      };
    }

    if (pendingTxn.userId !== userId) {
      return {
        success: false,
        error: 'Esta transação não pertence a você'
      };
    }

    console.log(`🔍 [Payment] Confirmando pagamento: ${transactionId}`);

    // Verificar status da transação no CashinPay
    const checkResult = await cashinPayService.checkTransactionPaid(transactionId);

    if (!checkResult.success) {
      return {
        success: false,
        error: `Erro ao verificar transação: ${checkResult.error}`
      };
    }

    if (!checkResult.paid) {
      return {
        success: false,
        error: `Transação ainda não foi paga. Status: ${checkResult.status}`
      };
    }

    // Remover transação pendente
    accountManager.removePendingTransaction(transactionId);

    // Processar baseado no tipo
    let account;
    const account_obj = accountManager.getOrCreateAccount(userId);

    if (pendingTxn.type === 'plan_renewal') {
      // Ativar plano
      const activateResult = accountManager.activatePlanAfterPayment(
        userId,
        pendingTxn.planType,
        pendingTxn.quantity
      );

      if (!activateResult.success) {
        return {
          success: false,
          error: 'Erro ao ativar plano'
        };
      }

      account = activateResult.account;
      console.log(`✅ [Payment] Plano ativado: ${pendingTxn.planType} x${pendingTxn.quantity} para ${userId}`);

      return {
        success: true,
        message: `Plano ${pendingTxn.planType} ativado com sucesso!`,
        account: {
          planType: account.planType,
          expiresAt: account.planExpiresAt,
          balance: account.balance
        }
      };

    } else if (pendingTxn.type === 'deposit') {
      // Adicionar saldo
      const addResult = accountManager.addBalance(
        userId,
        pendingTxn.amount,
        'Depósito via PIX'
      );

      if (!addResult.success) {
        return {
          success: false,
          error: 'Erro ao adicionar saldo'
        };
      }

      account = accountManager.getAccount(userId);
      console.log(`✅ [Payment] Saldo adicionado: R$${pendingTxn.amount.toFixed(2)} para ${userId}`);

      return {
        success: true,
        message: `R$ ${pendingTxn.amount.toFixed(2)} adicionado ao seu saldo!`,
        account: {
          balance: account.balance,
          planType: account.planType,
          expiresAt: account.planExpiresAt
        }
      };
    }

    return {
      success: false,
      error: 'Tipo de transação desconhecido'
    };

  } catch (error) {
    console.error('❌ [Payment] Erro ao confirmar pagamento:', error.message);
    return {
      success: false,
      error: `Erro ao processar pagamento: ${error.message}`
    };
  }
}

/**
 * Obtém informações de uma transação pendente
 * @param {string} transactionId - ID da transação
 * @returns {Object|null}
 */
export function getPendingTransactionInfo(transactionId) {
  return accountManager.getPendingTransaction(transactionId);
}

/**
 * Lista todas as transações pendentes de um usuário
 * @param {string} userId - ID do usuário
 * @returns {Array}
 */
export function getUserPendingTransactions(userId) {
  return accountManager.getUserPendingTransactions(userId);
}

/**
 * Obtém informações sobre os planos e preços
 * @returns {Object}
 */
export function getPlansInfo() {
  return {
    semanal: {
      name: 'Semanal',
      price: CONFIG.PLAN_PRICES.semanal,
      days: CONFIG.PLAN_DAYS.semanal,
      description: 'Acesso por 7 dias'
    },
    mensal: {
      name: 'Mensal',
      price: CONFIG.PLAN_PRICES.mensal,
      days: CONFIG.PLAN_DAYS.mensal,
      description: 'Acesso por 30 dias - Melhor custo-benefício'
    }
  };
}

/**
 * Calcula o preço total para uma quantidade de planos
 * @param {string} planType - 'semanal' ou 'mensal'
 * @param {number} quantity - Quantidade
 * @returns {{unitPrice: number, totalPrice: number, days: number}}
 */
export function calculatePlanPrice(planType, quantity = 1) {
  const unitPrice = CONFIG.PLAN_PRICES[planType] || CONFIG.PLAN_PRICES.semanal;
  const totalPrice = unitPrice * quantity;
  const days = (CONFIG.PLAN_DAYS[planType] || 7) * quantity;

  return {
    unitPrice,
    totalPrice,
    days,
    formatted: `R$ ${totalPrice.toFixed(2)}`
  };
}

/**
 * Valida se um valor é entre min e max
 * @param {number} amount - Valor
 * @returns {{valid: boolean, error?: string}}
 */
export function validateDepositAmount(amount) {
  if (amount < CONFIG.MIN_DEPOSIT) {
    return {
      valid: false,
      error: `Valor mínimo: R$ ${CONFIG.MIN_DEPOSIT.toFixed(2)}`
    };
  }

  if (amount > 10000.00) {
    return {
      valid: false,
      error: 'Valor máximo: R$ 10.000,00'
    };
  }

  return { valid: true };
}

export default {
  createPlanPayment,
  createDepositPayment,
  confirmPayment,
  getPendingTransactionInfo,
  getUserPendingTransactions,
  getPlansInfo,
  calculatePlanPrice,
  validateDepositAmount,
  CONFIG
};
