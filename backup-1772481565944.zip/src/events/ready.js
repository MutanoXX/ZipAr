/**
 * Rias-Grimory-X - Evento Ready
 * VERSÃO 2.2 - Inicialização de Automações + Client Global
 * 
 * @description Executado quando o bot está conectado ao Discord
 * @author MutanoX
 */

import automationManager from '../utils/automationManager.js';
import { setClient as setMessageCreateClient } from './messageCreat.js';

export const name = 'clientReady';
export const once = true;

/**
 * Executado quando o bot está pronto
 * @async
 * @param {import('discord.js').Client} client - Cliente Discord
 */
export async function execute(client) {
  if (!client || !client.user) {
    console.error('❌ [Ready] Cliente ou usuário não definido');
    return;
  }

  // 🔧 CORREÇÃO: Definir client globalmente para uso nas automações
  setMessageCreateClient(client);
  console.log('🔧 [Ready] Client definido globalmente para automações');

  console.log('');
  console.log('╔════════════════════════════════════════════╗');
  console.log('║     💎  RIAS GRIMORY X AI  💎              ║');
  console.log('║        Bot Discord em Node.js              ║');
  console.log('║        Criado por: MutanoX                 ║');
  console.log('╠════════════════════════════════════════════╣');
  console.log(`║  Bot: ${client.user.tag.padEnd(35)}║`);
  console.log(`║  Servidores: ${String(client.guilds.cache.size).padEnd(31)}║`);
  console.log(`║  Usuários: ${String(client.users.cache.size).padEnd(33)}║`);
  console.log(`║  Ping: ${String(client.ws.ping + 'ms').padEnd(35)}║`);
  console.log('╚════════════════════════════════════════════╝');
  console.log('');

  // Definir status do bot
  try {
    client.user.setPresence({
      activities: [
        {
          name: '🌹 Rias Gremory | /ask',
          type: 0 // Watching
        }
      ],
      status: 'online'
    });
  } catch (error) {
    console.error('❌ [Ready] Erro ao definir presença:', error.message);
  }

  console.log('✅ [Ready] Rias-Grimory-X conectada e pronta!');
  
  // 🤖 Carregar e iniciar automações de todos os servidores
  await loadAllAutomations(client);
}

/**
 * Carrega todas as automações salvas
 * @async
 * @param {import('discord.js').Client} client - Cliente Discord
 */
async function loadAllAutomations(client) {
  console.log('🤖 [Automação] Carregando automações salvas...');
  
  let totalAutomations = 0;
  let errors = 0;
  
  for (const guild of client.guilds.cache.values()) {
    try {
      automationManager.startGuildAutomations(guild.id, client);
      
      const stats = automationManager.getAutomationStats(guild.id);
      if (stats.total > 0) {
        totalAutomations += stats.total;
        console.log(`   📁 ${guild.name}: ${stats.total} automação(ões)`);
      }
    } catch (error) {
      console.error(`   ❌ Erro ao carregar automações de ${guild.name}:`, error.message);
      errors++;
    }
  }
  
  if (totalAutomations > 0) {
    console.log(`✅ [Automação] ${totalAutomations} automação(ões) carregada(s) e ativa(s)!`);
  } else {
    console.log('ℹ️ [Automação] Nenhuma automação ativa no momento.');
  }
  
  if (errors > 0) {
    console.log(`⚠️ [Automação] ${errors} erro(s) durante carregamento`);
  }
}

// Exportar client para uso em outros módulos
let botClient = null;

/**
 * Obtém o cliente do bot
 * @returns {import('discord.js').Client|null}
 */
export function getClient() {
  return botClient;
}

/**
 * Define o cliente do bot
 * @param {import('discord.js').Client} client - Cliente Discord
 */
export function setClient(client) {
  botClient = client;
}

export default { name, once, execute, getClient, setClient };
