/**
 * RIAS GREMORY X AI - Event Automation Handler
 * Monitora eventos do Discord e dispara automações
 * 
 * @description Este módulo integra o EventAutomationEngine com os eventos do Discord
 */

import {
  loadGuildAutomations,
  processEvent
} from '../utils/eventAutomationEngine.js';

// Referência global ao client
let discordClient = null;

// Nome do evento (formato esperado pelo loader)
export const name = 'ready';

// Executar apenas uma vez
export const once = true;

/**
 * Executa quando o bot está pronto
 */
export async function execute(client) {
  discordClient = client;
  
  console.log('🤖 [AutomationHandler] Inicializando handler de automações...');
  
  // Carregar automações de todos os servidores
  for (const guild of client.guilds.cache.values()) {
    loadGuildAutomations(guild.id);
  }
  
  // Registrar listeners de eventos
  setupEventListeners(client);
  
  console.log('✅ [AutomationHandler] Handler de automações ativo');
}

/**
 * Inicializa o handler de automações (função exportada para uso externo)
 */
export function initAutomationHandler(client) {
  discordClient = client;
  
  console.log('🤖 [AutomationHandler] Inicializando handler de automações...');
  
  // Carregar automações de todos os servidores
  for (const guild of client.guilds.cache.values()) {
    loadGuildAutomations(guild.id);
  }
  
  // Registrar listeners de eventos
  setupEventListeners(client);
  
  console.log('✅ [AutomationHandler] Handler de automações ativo');
}

/**
 * Configura os listeners de eventos
 */
function setupEventListeners(client) {
  
  // ==========================================
  // MESSAGE EVENTS
  // ==========================================
  
  /**
   * Quando uma mensagem é enviada
   */
  client.on('messageCreate', async (message) => {
    if (!message.guild || message.author.bot) return;
    
    await processEvent(client, 'message_in_channel', {
      message,
      guild: message.guild,
      user: message.author,
      member: message.member
    });
  });
  
  /**
   * Quando uma mensagem é editada
   */
  client.on('messageUpdate', async (oldMessage, newMessage) => {
    if (!newMessage.guild) return;
    if (oldMessage.content === newMessage.content) return; // Ignorar edits sem mudança de conteúdo
    
    await processEvent(client, 'message_edit', {
      oldMessage,
      newMessage,
      message: newMessage,
      guild: newMessage.guild,
      user: newMessage.author,
      member: newMessage.member
    });
  });
  
  /**
   * Quando uma mensagem é deletada
   */
  client.on('messageDelete', async (message) => {
    if (!message.guild) return;
    
    await processEvent(client, 'message_delete', {
      message,
      guild: message.guild,
      user: message.author,
      member: message.member
    });
  });
  
  // ==========================================
  // REACTION EVENTS
  // ==========================================
  
  /**
   * Quando uma reação é adicionada
   */
  client.on('messageReactionAdd', async (reaction, user) => {
    if (!reaction.message.guild) return;
    
    // Fetch partial
    if (reaction.partial) {
      try {
        await reaction.fetch();
      } catch (e) {
        return;
      }
    }
    
    await processEvent(discordClient, 'reaction_add', {
      reaction,
      user,
      message: reaction.message,
      guild: reaction.message.guild,
      member: reaction.message.guild.members.cache.get(user.id)
    });
  });
  
  /**
   * Quando uma reação é removida
   */
  client.on('messageReactionRemove', async (reaction, user) => {
    if (!reaction.message.guild) return;
    
    if (reaction.partial) {
      try {
        await reaction.fetch();
      } catch (e) {
        return;
      }
    }
    
    await processEvent(discordClient, 'reaction_remove', {
      reaction,
      user,
      message: reaction.message,
      guild: reaction.message.guild,
      member: reaction.message.guild.members.cache.get(user.id)
    });
  });
  
  // ==========================================
  // MEMBER EVENTS
  // ==========================================
  
  /**
   * Quando um membro entra
   */
  client.on('guildMemberAdd', async (member) => {
    await processEvent(discordClient, 'member_join', {
      member,
      user: member.user,
      guild: member.guild
    });
  });
  
  /**
   * Quando um membro sai
   */
  client.on('guildMemberRemove', async (member) => {
    await processEvent(discordClient, 'member_leave', {
      member,
      user: member.user,
      guild: member.guild
    });
  });
  
  /**
   * Quando um membro é atualizado (cargo, apelido, etc)
   */
  client.on('guildMemberUpdate', async (oldMember, newMember) => {
    // Verificar mudança de cargos
    const addedRoles = newMember.roles.cache.filter(r => !oldMember.roles.cache.has(r.id));
    const removedRoles = oldMember.roles.cache.filter(r => !newMember.roles.cache.has(r.id));
    
    // Processar cargos adicionados
    for (const role of addedRoles.values()) {
      await processEvent(discordClient, 'role_add', {
        role,
        member: newMember,
        user: newMember.user,
        guild: newMember.guild
      });
    }
    
    // Processar cargos removidos
    for (const role of removedRoles.values()) {
      await processEvent(discordClient, 'role_remove', {
        role,
        member: newMember,
        user: newMember.user,
        guild: newMember.guild
      });
    }
    
    // Verificar mudança de boost
    const wasBoosting = oldMember.premiumSince;
    const isBoosting = newMember.premiumSince;
    
    if (!wasBoosting && isBoosting) {
      await processEvent(discordClient, 'boost_add', {
        member: newMember,
        user: newMember.user,
        guild: newMember.guild
      });
    }
    
    if (wasBoosting && !isBoosting) {
      await processEvent(discordClient, 'boost_remove', {
        member: newMember,
        user: newMember.user,
        guild: newMember.guild
      });
    }
  });
  
  /**
   * Quando um membro é desbanido
   */
  client.on('guildBanRemove', async (ban) => {
    await processEvent(discordClient, 'member_unban', {
      user: ban.user,
      guild: ban.guild
    });
  });
  
  // ==========================================
  // VOICE EVENTS
  // ==========================================
  
  /**
   * Quando alguém muda de estado de voz
   */
  client.on('voiceStateUpdate', async (oldState, newState) => {
    const guild = newState.guild || oldState.guild;
    
    // Entrou em voz
    if (!oldState.channelId && newState.channelId) {
      await processEvent(discordClient, 'voice_join', {
        oldState,
        newState,
        member: newState.member,
        user: newState.member?.user,
        guild
      });
    }
    
    // Saiu de voz
    if (oldState.channelId && !newState.channelId) {
      await processEvent(discordClient, 'voice_leave', {
        oldState,
        newState,
        member: oldState.member,
        user: oldState.member?.user,
        guild
      });
    }
    
    // Mudou de canal de voz
    if (oldState.channelId && newState.channelId && oldState.channelId !== newState.channelId) {
      await processEvent(discordClient, 'voice_switch', {
        oldState,
        newState,
        member: newState.member,
        user: newState.member?.user,
        guild,
        oldChannel: oldState.channel,
        newChannel: newState.channel
      });
    }
  });
  
  // ==========================================
  // CHANNEL EVENTS
  // ==========================================
  
  /**
   * Quando um canal é criado
   */
  client.on('channelCreate', async (channel) => {
    if (!channel.guild) return;
    
    await processEvent(discordClient, 'channel_create', {
      channel,
      guild: channel.guild
    });
  });
  
  /**
   * Quando um canal é deletado
   */
  client.on('channelDelete', async (channel) => {
    if (!channel.guild) return;
    
    await processEvent(discordClient, 'channel_delete', {
      channel,
      guild: channel.guild
    });
  });
  
  // ==========================================
  // GUILD EVENTS
  // ==========================================
  
  /**
   * Quando o bot entra em um novo servidor
   */
  client.on('guildCreate', async (guild) => {
    // Carregar automações do novo servidor
    loadGuildAutomations(guild.id);
  });
  
  /**
   * Quando o bot sai de um servidor
   */
  client.on('guildDelete', async (guild) => {
    // As automações ficam salvas, mas não são carregadas
    console.log(`👋 [AutomationHandler] Bot removido de ${guild.name}`);
  });
  
  console.log('🎧 [AutomationHandler] Listeners de eventos registrados');
}

/**
 * Obtém o client do Discord
 */
export function getClient() {
  return discordClient;
}

export default {
  name,
  once,
  execute,
  initAutomationHandler,
  getClient
};
