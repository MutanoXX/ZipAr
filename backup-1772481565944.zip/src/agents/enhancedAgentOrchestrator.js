/**
 * RIAS GREMORY X AI - Enhanced Agent System v2.0
 * Sistema de Agentes Avançado com Colaboração e Memória
 * 
 * @version 2.0.0
 * @description Agentes com memória, colaboração e capacidades expandidas
 */

import multiProviderAI from '../services/multiProviderAI.js';
import subscriptionManager from '../utils/subscriptionManager.js';
import imageGenerationService from '../services/imageGenerationService.js';
import { buildPromptDefault } from '../utils/promptDefault.js';

// ============================================
// DEFINIÇÃO DE AGENTES AVANÇADOS
// ============================================

const AGENTS = {
  // === AGENTES DE NÍVEL 1 (GRATUITO) ===
  
  CHANNEL_MASTER: {
    id: 'channel_master',
    name: 'Mestre de Canais',
    emoji: '📺',
    tier: 'free',
    priority: 1,
    description: 'Especialista em criar, editar e gerenciar canais e categorias',
    
    tools: [
      'criar_canal', 'criar_categoria', 'editar_canal', 'deletar_canal',
      'listar_canais', 'clonar_canal', 'trancar_canal', 'esconder_canal',
      'permissao_canal', 'criar_thread', 'deletar_thread', 'arquivar_thread',
      'set_slowmode', 'criar_webhook', 'listar_webhooks', 'criar_convite'
    ],
    
    keywords: {
      primary: ['canal', 'canais', 'categoria', 'categorias'],
      secondary: ['chat', 'voz', 'thread', 'webhook', 'convite', 'slowmode']
    },
    
    // Capacidades especiais
    capabilities: {
      multiOperation: true, // Pode operar em múltiplos itens
      batchCreate: true,    // Pode criar vários de uma vez
      templates: ['gaming', 'community', 'business', 'support', 'music']
    },
    
    // Contexto que o agente mantém
    contextMemory: ['lastCreatedChannel', 'lastCreatedCategory', 'recentOperations'],
    
    // Perguntas que o agente pode fazer
    clarifyingQuestions: [
      'Qual o nome do canal?',
      'É de texto ou voz?',
      'Em qual categoria?',
      'Precisa de slowmode?',
      'É NSFW?'
    ]
  },
  
  ROLE_MASTER: {
    id: 'role_master',
    name: 'Mestre de Cargos',
    emoji: '🎭',
    tier: 'free',
    priority: 1,
    description: 'Especialista em criar e gerenciar cargos e permissões',
    
    tools: [
      'criar_cargo', 'editar_cargo', 'deletar_cargo', 'clonar_cargo',
      'adicionar_cargo', 'remover_cargo', 'listar_cargos', 'membros_cargo',
      'reorder_roles', 'criar_hierarquia'
    ],
    
    keywords: {
      primary: ['cargo', 'cargos', 'role', 'roles'],
      secondary: ['permissão', 'permissões', 'rank', 'hierarquia', 'staff']
    },
    
    capabilities: {
      multiOperation: true,
      batchCreate: true,
      templates: ['staff', 'moderators', 'vip', 'boosters', 'levels']
    },
    
    contextMemory: ['lastCreatedRole', 'recentAssignments'],
    
    clarifyingQuestions: [
      'Qual o nome do cargo?',
      'Qual cor?',
      'É mencionável?',
      'Deve aparecer separado na lista?',
      'Quais permissões?'
    ]
  },
  
  MODERATOR: {
    id: 'moderator',
    name: 'Moderador Supremo',
    emoji: '⚖️',
    tier: 'free',
    priority: 1,
    description: 'Especialista em moderação e punições',
    
    tools: [
      'expulsar', 'banir', 'desbanir', 'mutar', 'desmutar',
      'apelido', 'info_membro', 'deletar_mensagens', 'advertir',
      'ver_advertencias', 'trancar_servidor', 'destravar_servidor',
      'limpar_chat', 'slowmode_all', 'config_automod'
    ],
    
    keywords: {
      primary: ['ban', 'kick', 'mute', 'mutar', 'expulsar', 'banir', 'moderar'],
      secondary: ['punição', 'advertir', 'limpar', 'mod', 'admin']
    },
    
    capabilities: {
      multiOperation: true,
      batchCreate: false,
      templates: []
    },
    
    contextMemory: ['recentModerations', 'warnedUsers'],
    
    clarifyingQuestions: [
      'Qual o motivo?',
      'Por quanto tempo?',
      'Deletar mensagens também?',
      'Enviar DM avisando?'
    ]
  },
  
  EMBED_ARTIST: {
    id: 'embed_artist',
    name: 'Artista de Embeds',
    emoji: '🎨',
    tier: 'free',
    priority: 2,
    description: 'Cria embeds bonitos e decorados',
    
    tools: [
      'enviar_embed', 'enviar_embed_avancado', 'criar_enquete', 
      'enviar_com_botões', 'enviar_com_menu', 'enviar_webhook'
    ],
    
    keywords: {
      primary: ['embed', 'decorado', 'mensagem bonita', 'anúncio'],
      secondary: ['banner', 'card', 'painel', 'card']
    },
    
    capabilities: {
      multiOperation: false,
      batchCreate: false,
      templates: ['announcement', 'welcome', 'rules', 'shop', 'profile', 'giveaway']
    },
    
    contextMemory: ['lastEmbedConfig', 'favoriteColors'],
    
    clarifyingQuestions: [
      'Qual o título?',
      'Qual a descrição?',
      'Qual cor?',
      'Quer thumbnail?',
      'Quer imagem?',
      'Quer campos extras?'
    ]
  },
  
  IMAGE_CREATOR: {
    id: 'image_creator',
    name: 'Criador de Imagens',
    emoji: '🖼️',
    tier: 'free',
    priority: 2,
    description: 'Gera e busca imagens usando IA',
    
    tools: [
      'gerar_imagem', 'google_image', 'gerar_logo', 'gerar_banner',
      'gerar_variacoes', 'gerar_rias'
    ],
    
    keywords: {
      primary: ['imagem', 'foto', 'gerar', 'criar imagem', 'dalle'],
      secondary: ['picture', 'render', 'logo', 'banner', 'arte']
    },
    
    capabilities: {
      multiOperation: true,
      batchCreate: true,
      templates: ['logo', 'banner', 'profile', 'thumbnail', 'wallpaper']
    },
    
    contextMemory: ['lastGeneratedImages', 'favoriteStyles'],
    
    clarifyingQuestions: [
      'O que quer na imagem?',
      'Qual estilo? (realista, anime, arte)',
      'Tamanho específico?',
      'Quer múltiplas variações?'
    ]
  },
  
  CONVERSATIONALIST: {
    id: 'conversationalist',
    name: 'Conversador',
    emoji: '💬',
    tier: 'free',
    priority: 10, // Menor prioridade = agente padrão
    description: 'Conversação natural e ajuda geral',
    
    tools: ['message', 'ajuda', 'info'],
    
    keywords: {
      primary: [],
      secondary: []
    },
    
    capabilities: {
      multiOperation: false,
      batchCreate: false,
      templates: []
    },
    
    contextMemory: ['conversationTopics', 'userPreferences']
  },
  
  // === AGENTES DE NÍVEL 2 (BASIC) ===
  
  AUTOMATION_ARCHITECT: {
    id: 'automation_architect',
    name: 'Arquiteto de Automações',
    emoji: '🤖',
    tier: 'basic',
    priority: 2,
    description: 'Cria automações avançadas baseadas em eventos',
    
    tools: [
      'criar_event_automation', 'listar_event_automations',
      'editar_event_automation', 'toggle_event_automation',
      'deletar_event_automation', 'ver_templates_automation',
      'criar_reacao_cargo', 'criar_boas_vindas', 'criar_despedida'
    ],
    
    keywords: {
      primary: ['automação', 'trigger', 'evento', 'quando'],
      secondary: ['automático', 'auto', 'configurar', 'setup']
    },
    
    capabilities: {
      multiOperation: false,
      batchCreate: false,
      templates: ['anti_link', 'anti_spam', 'welcome', 'goodbye', 'reaction_role', 
                  'boost_reward', 'auto_role', 'log_messages', 'auto_thread']
    },
    
    contextMemory: ['activeAutomations', 'recentConfigs'],
    
    clarifyingQuestions: [
      'Quando deve acontecer?',
      'O que deve fazer quando acontecer?',
      'Em qual canal?',
      'Quer aviso por DM?'
    ]
  },
  
  SERVER_ARCHITECT: {
    id: 'server_architect',
    name: 'Arquiteto de Servidor',
    emoji: '🏗️',
    tier: 'basic',
    priority: 2,
    description: 'Cria estruturas completas de servidor',
    
    tools: [
      'tarefa_complexa', 'clonar_estrutura', 'aplicar_template',
      'criar_servidor_completo', 'setup_categoria'
    ],
    
    keywords: {
      primary: ['criar servidor', 'estruturar', 'arquitetura', 'template'],
      secondary: ['montar', 'setup', 'estrutura', 'organizar']
    },
    
    capabilities: {
      multiOperation: true,
      batchCreate: true,
      templates: ['gaming', 'community', 'business', 'support', 'music', 'art', 'roleplay']
    },
    
    contextMemory: ['lastStructure', 'appliedTemplates']
  },
  
  // === AGENTES DE NÍVEL 3 (PREMIUM) ===
  
  INTEGRATION_MASTER: {
    id: 'integration_master',
    name: 'Mestre de Integrações',
    emoji: '🔗',
    tier: 'premium',
    priority: 2,
    description: 'Gerencia webhooks e integrações externas',
    
    tools: [
      'criar_webhook', 'listar_webhooks', 'editar_webhook',
      'deletar_webhook', 'enviar_webhook', 'info_webhook',
      'configurar_api', 'testar_integração'
    ],
    
    keywords: {
      primary: ['webhook', 'integração', 'api'],
      secondary: ['notificação', 'conexão', 'externo']
    },
    
    capabilities: {
      multiOperation: true,
      batchCreate: false,
      templates: []
    }
  },
  
  ANALYTICS_EXPERT: {
    id: 'analytics_expert',
    name: 'Especialista em Analytics',
    emoji: '📊',
    tier: 'premium',
    priority: 3,
    description: 'Análises e estatísticas avançadas',
    
    tools: [
      'server_stats', 'member_analytics', 'activity_report',
      'growth_chart', 'exportar_dados', 'dashboards'
    ],
    
    keywords: {
      primary: ['analytics', 'estatística', 'relatório', 'dados'],
      secondary: ['métricas', 'crescimento', 'análise']
    },
    
    capabilities: {
      multiOperation: false,
      batchCreate: false,
      templates: ['weekly_report', 'monthly_report', 'growth_analysis']
    }
  },
  
  // === AGENTES DE NÍVEL 4 (ULTIMATE) ===
  
  API_DEVELOPER: {
    id: 'api_developer',
    name: 'Desenvolvedor de API',
    emoji: '🔌',
    tier: 'ultimate',
    priority: 3,
    description: 'Integrações customizadas via API',
    
    tools: [
      'http_request', 'set_variable', 'get_variable',
      'criar_endpoint', 'configurar_callback', 'webhook_custom'
    ],
    
    keywords: {
      primary: ['api', 'endpoint', 'callback'],
      secondary: ['request', 'post', 'get', 'integrar']
    }
  }
};

// ============================================
// SISTEMA DE COLABORAÇÃO ENTRE AGENTES
// ============================================

/**
 * Gerencia colaboração entre múltiplos agentes
 */
class AgentCollaboration {
  constructor() {
    this.activeSessions = new Map(); // Sessões de colaboração ativas
    this.results = new Map(); // Resultados parciais
  }

  /**
   * Inicia uma sessão colaborativa
   */
  startSession(sessionId, agents, goal) {
    const session = {
      id: sessionId,
      agents: agents,
      goal: goal,
      startedAt: Date.now(),
      status: 'active',
      contributions: {}
    };
    
    this.activeSessions.set(sessionId, session);
    return session;
  }

  /**
   * Registra contribuição de um agente
   */
  addContribution(sessionId, agentId, contribution) {
    const session = this.activeSessions.get(sessionId);
    if (!session) return;
    
    if (!session.contributions[agentId]) {
      session.contributions[agentId] = [];
    }
    
    session.contributions[agentId].push({
      ...contribution,
      timestamp: Date.now()
    });
  }

  /**
   * Consolida resultados de todos os agentes
   */
  consolidateResults(sessionId) {
    const session = this.activeSessions.get(sessionId);
    if (!session) return null;
    
    const consolidated = {
      sessionId,
      goal: session.goal,
      contributions: session.contributions,
      finalResult: null,
      duration: Date.now() - session.startedAt
    };
    
    // Marcar sessão como completa
    session.status = 'completed';
    
    return consolidated;
  }
}

// ============================================
// SISTEMA DE MEMÓRIA DE CONTEXTO
// ============================================

/**
 * Gerencia memória e contexto dos agentes
 */
class AgentMemory {
  constructor() {
    this.shortTerm = new Map(); // Memória de curto prazo
    this.longTerm = new Map(); // Memória de longo prazo
    this.context = new Map(); // Contexto ativo
  }

  /**
   * Adiciona item à memória
   */
  remember(guildId, agentId, key, value, duration = 'short') {
    const memoryStore = duration === 'short' ? this.shortTerm : this.longTerm;
    const mapKey = `${guildId}_${agentId}_${key}`;
    
    memoryStore.set(mapKey, {
      value,
      timestamp: Date.now(),
      expiresAt: duration === 'short' ? Date.now() + 3600000 : null // 1h para short term
    });
  }

  /**
   * Recupera da memória
   */
  recall(guildId, agentId, key) {
    const mapKey = `${guildId}_${agentId}_${key}`;
    
    // Tentar short term primeiro
    let item = this.shortTerm.get(mapKey);
    if (item && (!item.expiresAt || item.expiresAt > Date.now())) {
      return item.value;
    }
    
    // Tentar long term
    item = this.longTerm.get(mapKey);
    return item?.value || null;
  }

  /**
   * Define contexto ativo
   */
  setContext(guildId, agentId, context) {
    const key = `${guildId}_${agentId}`;
    this.context.set(key, {
      ...context,
      updatedAt: Date.now()
    });
  }

  /**
   * Obtém contexto
   */
  getContext(guildId, agentId) {
    const key = `${guildId}_${agentId}`;
    return this.context.get(key) || {};
  }

  /**
   * Limpa memória expirada
   */
  cleanup() {
    const now = Date.now();
    
    for (const [key, item] of this.shortTerm.entries()) {
      if (item.expiresAt && item.expiresAt < now) {
        this.shortTerm.delete(key);
      }
    }
  }
}

// ============================================
// ORCHESTRATOR PRINCIPAL MELHORADO
// ============================================

class EnhancedAgentOrchestrator {
  constructor() {
    this.initialized = false;
    this.conversationHistory = new Map();
    this.collaboration = new AgentCollaboration();
    this.memory = new AgentMemory();
    this.stats = {
      totalRequests: 0,
      errors: 0,
      agentUsage: {}
    };
    
    // Inicializar contadores por agente
    Object.keys(AGENTS).forEach(key => {
      this.stats.agentUsage[key] = 0;
    });
  }

  /**
   * Inicializa o sistema
   */
  async initialize() {
    if (this.initialized) return;
    
    await multiProviderAI.initialize();
    
    // Limpar memória periodicamente
    setInterval(() => this.memory.cleanup(), 300000); // 5 min
    
    this.initialized = true;
    console.log('🤖 [Orchestrator v2.0] Sistema avançado inicializado');
  }

  /**
   * Detecta agente(s) necessário(s)
   */
  detectAgents(message, userId) {
    const lower = message.toLowerCase();
    const userTier = subscriptionManager.getUserTier(userId);
    const tierLevel = { free: 0, basic: 1, premium: 2, ultimate: 3 };
    const userLevel = tierLevel[userTier] || 0;
    
    const scores = {};
    const detectedAgents = [];
    
    for (const [key, agent] of Object.entries(AGENTS)) {
      // Verificar tier
      const agentLevel = tierLevel[agent.tier] || 0;
      if (userLevel < agentLevel) {
        scores[key] = -1000;
        continue;
      }
      
      scores[key] = 0;
      
      // Keywords primárias (peso maior)
      for (const kw of agent.keywords.primary || []) {
        if (lower.includes(kw)) {
          scores[key] += 5;
        }
      }
      
      // Keywords secundárias
      for (const kw of agent.keywords.secondary || []) {
        if (lower.includes(kw)) {
          scores[key] += 2;
        }
      }
      
      // Ferramentas mencionadas
      for (const tool of agent.tools) {
        if (lower.includes(tool.replace(/_/g, ' '))) {
          scores[key] += 3;
        }
      }
    }
    
    // Encontrar melhor agente
    let maxScore = 0;
    let primaryAgent = 'CONVERSATIONALIST';
    
    for (const [key, score] of Object.entries(scores)) {
      if (score > maxScore) {
        maxScore = score;
        primaryAgent = key;
      }
    }
    
    detectedAgents.push(primaryAgent);
    
    // Se score alto, pode precisar de colaboração
    if (maxScore > 10) {
      // Verificar se precisa de segundo agente
      const secondaryThreshold = maxScore * 0.6;
      for (const [key, score] of Object.entries(scores)) {
        if (key !== primaryAgent && score > secondaryThreshold && score > 5) {
          detectedAgents.push(key);
          break; // Apenas um secundário
        }
      }
    }
    
    return {
      primary: primaryAgent,
      collaborators: detectedAgents.slice(1),
      confidence: Math.min(maxScore / 15, 1),
      scores
    };
  }

  /**
   * Processa mensagem com agente(s)
   */
  async processMessage(message, guild, channel, userId) {
    await this.initialize();
    
    const guildId = guild.id;
    const startTime = Date.now();
    
    // Verificar limites
    const limitResult = await subscriptionManager.useFeature(userId, 'requestsPerDay');
    if (!limitResult.success) {
      const tier = subscriptionManager.getUserTier(userId);
      const tierConfig = subscriptionManager.getTierConfig(tier);
      
      return JSON.stringify({
        type: 'message',
        content: `⚠️ **Limite de requisições atingido!**\n\n${tierConfig.upgradeMessage || 'Tente novamente amanhã.'}`
      });
    }
    
    // Detectar agentes
    const detection = this.detectAgents(message.content || message, userId);
    const primaryAgent = AGENTS[detection.primary];
    
    console.log(`🎯 [Orchestrator] Agente: ${primaryAgent.emoji} ${primaryAgent.name} (${(detection.confidence * 100).toFixed(0)}%)`);
    
    if (detection.collaborators.length > 0) {
      console.log(`🤝 [Orchestrator] Colaboradores: ${detection.collaborators.map(c => AGENTS[c]?.name).join(', ')}`);
    }
    
    // Atualizar estatísticas
    this.stats.totalRequests++;
    this.stats.agentUsage[detection.primary]++;
    
    // Construir prompt
    const systemPrompt = this.buildEnhancedPrompt(primaryAgent, guild, channel, userId, detection);
    
    // Histórico
    this.addToHistory(guildId, 'user', message.content || message);
    
    // Mensagens
    const messages = [
      { role: 'system', content: systemPrompt }
    ];
    
    const tier = subscriptionManager.getUserTier(userId);
    const tierConfig = subscriptionManager.getTierConfig(tier);
    const history = this.getHistory(guildId).slice(-tierConfig.limits.maxContextMessages);
    
    for (const msg of history) {
      if (msg.role !== 'system') {
        messages.push({ role: msg.role, content: msg.content });
      }
    }
    
    // Chamar IA
    try {
      const response = await multiProviderAI.chatCompletion(messages, {
        maxTokens: tierConfig.limits.maxTokens
      });
      
      const content = response.content || '';
      
      this.addToHistory(guildId, 'assistant', content);
      
      // Lembrar contexto
      this.memory.setContext(guildId, primaryAgent.id, {
        lastMessage: message.content,
        lastResponse: content,
        agent: primaryAgent.id
      });
      
      console.log(`✅ [Orchestrator] Concluído em ${Date.now() - startTime}ms`);
      
      return content;
      
    } catch (error) {
      this.stats.errors++;
      console.error('❌ [Orchestrator] Erro:', error.message);
      return this.getFallback(message.content);
    }
  }

  /**
   * Constrói prompt avançado
   */
  buildEnhancedPrompt(agent, guild, channel, userId, detection) {
    const base = buildPromptDefault(guild, channel);
    const tier = subscriptionManager.getUserTier(userId);
    const tierConfig = subscriptionManager.getTierConfig(tier);
    
    // Recuperar contexto
    const context = this.memory.getContext(guild.id, agent.id);
    
    // Templates de ferramentas do agente
    const toolDocs = this.getToolDocumentation(agent);
    
    return `
${base}

# ══════════════════════════════════════════════════════════════
# ${agent.emoji} AGENTE: ${agent.name}
# ══════════════════════════════════════════════════════════════

## 📋 Especialidade:
${agent.description}

## 🔧 Ferramentas Disponíveis:
${toolDocs}

## 💎 Seu Plano: ${tierConfig.emoji} ${tierConfig.name}
- Tokens: ${tierConfig.limits.maxTokens}
- Streaming: ${tierConfig.limits.streaming ? '✅' : '❌'}

${context.lastMessage ? `## 📝 Contexto da Última Interação:
"${context.lastMessage.substring(0, 200)}..."` : ''}

${detection.collaborators.length > 0 ? `
## 🤝 Agentes Colaboradores:
${detection.collaborators.map(c => `- ${AGENTS[c]?.emoji} ${AGENTS[c]?.name}`).join('\n')}
` : ''}

${tierConfig.upgradeMessage ? `## ⬆️ ${tierConfig.upgradeMessage}` : ''}

---
`;
  }

  /**
   * Obtém documentação das ferramentas
   */
  getToolDocumentation(agent) {
    const docs = {
      'gerar_imagem': `
### 🖼️ gerar_imagem
Gera imagens usando IA
\`\`\`json
{
  "type": "gerar_imagem",
  "prompt": "descrição detalhada",
  "model": "flux", // flux, flux-anime, flux-pro
  "style": "anime", // photorealistic, anime, artistic, fantasy, 3d, cinematic
  "size": "1024x1024" // 1024x1024, 1344x768, 768x1344
}
\`\`\``,
      'enviar_embed': `
### 🎨 enviar_embed
Envia embed decorado
\`\`\`json
{
  "type": "enviar_embed",
  "title": "Título",
  "description": "Descrição bonita!",
  "color": "roxo",
  "thumbnail": "url",
  "image": "url",
  "fields": [{"name": "Campo", "value": "Valor", "inline": true}]
}
\`\`\``,
      'criar_canal': `
### 📺 criar_canal
Cria canal novo
\`\`\`json
{
  "type": "criar_canal",
  "name": "nome-do-canal",
  "tipo": "texto", // texto, voz, anuncio
  "categoria": "Nome da Categoria",
  "slowmode": 5
}
\`\`\``,
      'criar_event_automation': `
### 🤖 criar_event_automation
Cria automação baseada em evento
\`\`\`json
{
  "type": "criar_event_automation",
  "name": "Nome da Automação",
  "trigger": "message_in_channel", // member_join, reaction_add, etc
  "triggerConfig": {"channelId": "ID"},
  "actions": [{"type": "delete_message"}]
}
\`\`\``
    };
    
    return agent.tools.map(t => docs[t] || `• \`${t}\``).join('\n\n');
  }

  /**
   * Histórico
   */
  addToHistory(guildId, role, content) {
    if (!this.conversationHistory.has(guildId)) {
      this.conversationHistory.set(guildId, []);
    }
    
    const history = this.conversationHistory.get(guildId);
    if (history.length >= 50) history.shift();
    
    history.push({ role, content, timestamp: Date.now() });
  }

  getHistory(guildId) {
    return this.conversationHistory.get(guildId) || [];
  }

  /**
   * Fallback
   */
  getFallback(msg) {
    return JSON.stringify({
      type: 'message',
      content: '💔 Desculpe, tive um probleminha! Pode tentar novamente? 🌹'
    });
  }

  /**
   * Estatísticas
   */
  getStats() {
    return {
      ...this.stats,
      aiProvider: multiProviderAI.getStats(),
      agents: Object.keys(AGENTS).length
    };
  }

  /**
   * Info dos agentes
   */
  getAgentsInfo() {
    return Object.values(AGENTS).map(a => ({
      id: a.id,
      name: a.name,
      emoji: a.emoji,
      tier: a.tier,
      priority: a.priority,
      tools: a.tools.length,
      capabilities: a.capabilities
    }));
  }
}

// Singleton
const enhancedAgentOrchestrator = new EnhancedAgentOrchestrator();

export {
  AGENTS,
  AgentCollaboration,
  AgentMemory,
  EnhancedAgentOrchestrator,
  enhancedAgentOrchestrator
};

export default enhancedAgentOrchestrator;
