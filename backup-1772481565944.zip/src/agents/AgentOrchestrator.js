/**
 * RIAS GREMORY X AI - Sistema Multi-Agente
 * Orchestrator que gerencia múltiplos agentes especializados
 * 
 * @version 3.0.0 - Com Multi-Provider AI e Sistema de Assinaturas
 * @author MutanoX
 * 
 * MELHORIAS v3.0:
 * - Integração com Multi-Provider AI (NVIDIA + G4F)
 * - Sistema de Tiers (Free/Basic/Premium/Ultimate)
 * - Fallback automático entre provedores
 * - Agentes especializados com workflow
 * - Limites por assinatura
 */

import multiProviderAI from '../services/multiProviderAI.js';
import subscriptionManager from '../utils/subscriptionManager.js';
import { buildPromptDefault, getBasePrompt } from '../utils/promptDefault.js';

// Configurações
const CONFIG = {
  TIMEOUT: 120000,
  MAX_RETRIES: 3,
  DEFAULT_TEMPERATURE: 1
};

/**
 * Definição dos agentes especializados
 */
const AGENTS = {
  // === NÍVEL 1: GRATUITO ===
  CHANNEL_MANAGER: {
    id: 'channel_manager',
    name: 'Gerenciador de Canais',
    emoji: '📺',
    specialty: 'Gerenciamento de Canais e Categorias',
    tools: [
      'criar_canal', 'criar_categoria', 'editar_canal', 'deletar_canal',
      'listar_canais', 'clonar_canal', 'trancar_canal', 'esconder_canal',
      'permissao_canal', 'criar_thread', 'deletar_thread'
    ],
    keywords: ['canal', 'canais', 'categoria', 'categorias', 'chat', 'voz', 'thread'],
    tierRequired: 'free',
    priority: 1
  },
  
  ROLE_MANAGER: {
    id: 'role_manager',
    name: 'Gerenciador de Cargos',
    emoji: '🎭',
    specialty: 'Gerenciamento de Cargos e Permissões',
    tools: [
      'criar_cargo', 'editar_cargo', 'deletar_cargo', 'clonar_cargo',
      'adicionar_cargo', 'remover_cargo', 'listar_cargos', 'membros_cargo'
    ],
    keywords: ['cargo', 'cargos', 'role', 'roles', 'permissão', 'rank'],
    tierRequired: 'free',
    priority: 1
  },
  
  MODERATOR: {
    id: 'moderator',
    name: 'Moderador',
    emoji: '⚖️',
    specialty: 'Moderação e Gerenciamento de Membros',
    tools: [
      'expulsar', 'banir', 'desbanir', 'mutar', 'desmutar',
      'apelido', 'info_membro', 'deletar_mensagens', 'advertir'
    ],
    keywords: ['ban', 'kick', 'mute', 'mutar', 'expulsar', 'banir', 'moderar'],
    tierRequired: 'free',
    priority: 1
  },
  
  EMBED_DESIGNER: {
    id: 'embed_designer',
    name: 'Designer de Embeds',
    emoji: '🎨',
    specialty: 'Criação de Embeds Avançados',
    tools: ['enviar_embed', 'criar_enquete', 'enviar_webhook'],
    keywords: ['embed', 'decorado', 'mensagem bonita', 'anúncio'],
    tierRequired: 'free',
    priority: 2
  },
  
  MEDIA_SPECIALIST: {
    id: 'media_specialist',
    name: 'Especialista em Mídia',
    emoji: '🖼️',
    specialty: 'Busca e Geração de Imagens',
    tools: ['google_image', 'dalle', 'gerar_imagem'],
    keywords: ['imagem', 'foto', 'gerar', 'buscar', 'dalle'],
    tierRequired: 'free',
    priority: 3
  },
  
  CONVERSATIONALIST: {
    id: 'conversationalist',
    name: 'Conversador',
    emoji: '💬',
    specialty: 'Conversação Natural e Ajuda',
    tools: ['message'],
    keywords: [],
    tierRequired: 'free',
    priority: 5
  },
  
  // === NÍVEL 2: BÁSICO ===
  AUTOMATION_ENGINEER: {
    id: 'automation_engineer',
    name: 'Engenheiro de Automações',
    emoji: '🤖',
    specialty: 'Criação de Automações Event-Driven',
    tools: [
      'criar_event_automation', 'listar_event_automations',
      'editar_event_automation', 'toggle_event_automation',
      'deletar_event_automation', 'ver_templates_automation'
    ],
    keywords: ['automação', 'trigger', 'evento', 'quando', 'automático'],
    tierRequired: 'basic',
    priority: 2
  },
  
  ARCHITECT: {
    id: 'architect',
    name: 'Arquiteto de Servidor',
    emoji: '🏗️',
    specialty: 'Estrutura Completa de Servidor',
    tools: ['tarefa_complexa', 'criar_canal', 'criar_categoria', 'criar_cargo'],
    keywords: ['criar servidor', 'estruturar', 'arquitetura', 'template'],
    tierRequired: 'basic',
    priority: 2
  },
  
  // === NÍVEL 3: PREMIUM ===
  WEBHOOK_MANAGER: {
    id: 'webhook_manager',
    name: 'Gerenciador de Webhooks',
    emoji: '🔗',
    specialty: 'Criação e Gerenciamento de Webhooks',
    tools: [
      'criar_webhook', 'listar_webhooks', 'editar_webhook',
      'deletar_webhook', 'enviar_webhook', 'info_webhook'
    ],
    keywords: ['webhook', 'integração', 'notificação'],
    tierRequired: 'premium',
    priority: 2
  },
  
  // === NÍVEL 4: ULTIMATE ===
  API_INTEGRATOR: {
    id: 'api_integrator',
    name: 'Integrador de API',
    emoji: '🔌',
    specialty: 'Integrações Customizadas e API',
    tools: ['http_request', 'set_variable', 'get_variable'],
    keywords: ['api', 'integração', 'webhook', 'request'],
    tierRequired: 'ultimate',
    priority: 3
  }
};

/**
 * Classe AgentOrchestrator - Gerencia múltiplos agentes
 */
class AgentOrchestrator {
  constructor() {
    this.initialized = false;
    this.conversationHistory = new Map();
    this.agentContext = new Map();
    this.requestCount = 0;
    this.errorCount = 0;
  }

  /**
   * Inicializa o sistema
   */
  async initialize() {
    if (this.initialized) {
      return;
    }

    try {
      await multiProviderAI.initialize();
      
      this.initialized = true;
      console.log('🤖 [Orchestrator] Sistema Multi-Agente v3.0 inicializado');
      console.log(`📊 [Orchestrator] ${Object.keys(AGENTS).length} agentes especializados`);
      console.log(`💎 [Orchestrator] Provedores: ${multiProviderAI.preferredProvider === 0 ? 'Auto' : `Provider ${multiProviderAI.preferredProvider}`}`);
      
    } catch (error) {
      console.error('❌ [Orchestrator] Erro ao inicializar:', error.message);
      throw error;
    }
  }

  /**
   * Detecta qual agente deve lidar com a solicitação
   */
  detectAgent(message, userId) {
    const lowerMessage = message.toLowerCase();
    const userTier = subscriptionManager.getUserTier(userId);
    const tierLevel = { free: 0, basic: 1, premium: 2, ultimate: 3 };
    const userLevel = tierLevel[userTier] || 0;
    
    // Pontuação para cada agente
    const scores = {};
    
    for (const [key, agent] of Object.entries(AGENTS)) {
      // Verificar se o tier do usuário permite este agente
      const agentTierLevel = tierLevel[agent.tierRequired] || 0;
      if (userLevel < agentTierLevel) {
        scores[key] = -100; // Não disponível
        continue;
      }
      
      scores[key] = 0;
      
      // Verificar keywords
      for (const keyword of agent.keywords) {
        if (lowerMessage.includes(keyword)) {
          scores[key] += 2;
        }
      }
      
      // Verificar ferramentas mencionadas
      for (const tool of agent.tools) {
        if (lowerMessage.includes(tool.replace(/_/g, ' '))) {
          scores[key] += 3;
        }
      }
      
      // Bonus de prioridade (menor número = maior prioridade)
      scores[key] -= (agent.priority || 5) * 0.1;
    }
    
    // Encontrar o agente com maior pontuação
    let maxScore = 0;
    let selectedAgent = 'CONVERSATIONALIST';
    
    for (const [key, score] of Object.entries(scores)) {
      if (score > maxScore) {
        maxScore = score;
        selectedAgent = key;
      }
    }
    
    // Se pontuação muito baixa, é conversa geral
    if (maxScore < 2) {
      return 'CONVERSATIONALIST';
    }
    
    return selectedAgent;
  }

  /**
   * Constrói o prompt do sistema para o agente selecionado
   */
  buildAgentPrompt(agentKey, guild, channel, userId) {
    const basePrompt = buildPromptDefault(guild, channel);
    const tier = subscriptionManager.getUserTier(userId);
    const tierConfig = subscriptionManager.getTierConfig(tier);
    
    if (agentKey === 'CONVERSATIONALIST') {
      return `${basePrompt}

## 💎 Seu Plano Atual: ${tierConfig.emoji} ${tierConfig.name}
${tierConfig.upgradeMessage || 'Aproveite todos os recursos!'}

## 📊 Limites:
- Requests/dia: ${tierConfig.limits.requestsPerDay === -1 ? 'Ilimitado' : tierConfig.limits.requestsPerDay}
- Tokens: ${tierConfig.limits.maxTokens}
`;
    }
    
    const agent = AGENTS[agentKey];
    
    return `
${basePrompt}

# ══════════════════════════════════════════════════════════════
# ${agent.emoji} AGENTE ESPECIALISTA: ${agent.name}
# ══════════════════════════════════════════════════════════════

## 📋 Especialidade: ${agent.specialty}

## 🔧 Ferramentas Disponíveis:
${agent.tools.map(t => `• \`${t}\``).join('\n')}

## 💎 Plano: ${tierConfig.emoji} ${tierConfig.name}
- Requests restantes hoje: ${tierConfig.limits.requestsPerDay === -1 ? '∞' : tierConfig.limits.requestsPerDay}
- Max tokens: ${tierConfig.limits.maxTokens}
- Streaming: ${tierConfig.limits.streaming ? '✅' : '❌'}

${tierConfig.upgradeMessage ? `## ⬆️ ${tierConfig.upgradeMessage}` : ''}

---
`;
  }

  /**
   * Adiciona mensagem ao histórico
   */
  addToHistory(guildId, role, content) {
    if (!this.conversationHistory.has(guildId)) {
      this.conversationHistory.set(guildId, []);
    }
    
    const history = this.conversationHistory.get(guildId);
    
    if (history.length >= 20) {
      history.shift();
    }
    
    history.push({ role, content, timestamp: Date.now() });
  }

  /**
   * Obtém histórico de conversa
   */
  getHistory(guildId) {
    return this.conversationHistory.get(guildId) || [];
  }

  /**
   * Processa uma mensagem usando o sistema multi-agente
   */
  async processMessage(message, guild, channel, userId) {
    await this.initialize();

    const guildId = guild.id;
    const userMessage = message.content || message;

    // Verificar limites
    const limitCheck = await subscriptionManager.useFeature(userId, 'requestsPerDay');
    
    if (!limitCheck.success) {
      const tier = subscriptionManager.getUserTier(userId);
      const tierConfig = subscriptionManager.getTierConfig(tier);
      
      return JSON.stringify({
        type: 'message',
        content: `⚠️ Limite de requisições atingido!\n\n${tierConfig.upgradeMessage || 'Tente novamente amanhã.'}`
      });
    }

    // Detectar agente apropriado
    const detectedAgent = this.detectAgent(userMessage, userId);
    console.log(`🎯 [Orchestrator] Agente: ${AGENTS[detectedAgent]?.name || detectedAgent}`);

    // Construir prompt do sistema
    const systemPrompt = this.buildAgentPrompt(detectedAgent, guild, channel, userId);

    // Adicionar mensagem ao histórico
    this.addToHistory(guildId, 'user', userMessage);

    // Construir mensagens para a API
    const messages = [
      { role: 'system', content: systemPrompt }
    ];

    // Adicionar histórico recente (limitado pelo tier)
    const tier = subscriptionManager.getUserTier(userId);
    const tierConfig = subscriptionManager.getTierConfig(tier);
    const maxContext = tierConfig.limits.maxContextMessages || 5;
    
    const history = this.getHistory(guildId).slice(-maxContext);
    for (const msg of history) {
      if (msg.role !== 'system') {
        messages.push({ role: msg.role, content: msg.content });
      }
    }

    console.log('🔄 [Orchestrator] Enviando requisição...');

    try {
      const startTime = Date.now();
      
      // Usar multi-provider AI
      const response = await multiProviderAI.chatCompletion(messages, {
        temperature: CONFIG.DEFAULT_TEMPERATURE,
        maxTokens: tierConfig.limits.maxTokens
      });

      const elapsed = Date.now() - startTime;
      console.log(`✅ [Orchestrator] Resposta em ${elapsed}ms (${response.provider})`);

      const content = response.content || '';

      if (!content || content.trim() === '') {
        console.error('❌ [Orchestrator] Resposta vazia');
        return this.getFallbackResponse(userMessage);
      }

      // Adicionar resposta ao histórico
      this.addToHistory(guildId, 'assistant', content);

      this.requestCount++;
      
      return content;

    } catch (error) {
      this.errorCount++;
      console.error('❌ [Orchestrator] Erro:', error.message);
      return this.getFallbackResponse(userMessage);
    }
  }

  /**
   * Resposta de fallback quando há erro
   */
  getFallbackResponse(message) {
    const lower = message.toLowerCase();
    
    if (lower.includes('criar') || lower.includes('faça') || lower.includes('crie')) {
      return JSON.stringify({
        type: 'message',
        content: 'Desculpe, amor! 💔 Tive um probleminha técnico. Pode tentar novamente? 🌹✨'
      });
    }
    
    return JSON.stringify({
      type: 'message',
      content: 'Ah, me desculpe! 💔 Tive uma falha momentânea. Pode repetir, meu bem? 🌹✨'
    });
  }

  /**
   * Verifica se o serviço está pronto
   */
  isReady() {
    return this.initialized;
  }

  /**
   * Obtém estatísticas
   */
  getStats() {
    const aiStats = multiProviderAI.getStats();
    
    return {
      initialized: this.initialized,
      requestCount: this.requestCount,
      errorCount: this.errorCount,
      activeConversations: this.conversationHistory.size,
      agentsAvailable: Object.keys(AGENTS).length,
      aiProvider: aiStats
    };
  }

  /**
   * Obtém informações dos agentes
   */
  getAgentsInfo() {
    return Object.values(AGENTS).map(a => ({
      id: a.id,
      name: a.name,
      emoji: a.emoji,
      specialty: a.specialty,
      toolsCount: a.tools.length,
      tierRequired: a.tierRequired
    }));
  }

  /**
   * Reseta o serviço
   */
  reset() {
    this.conversationHistory.clear();
    this.agentContext.clear();
    this.requestCount = 0;
    this.errorCount = 0;
    console.log('🔄 [Orchestrator] Reset completo');
  }
}

// Singleton
const agentOrchestrator = new AgentOrchestrator();

export { AGENTS, agentOrchestrator };
export default agentOrchestrator;
