/**
 * RIAS GREMORY X AI - Agent Workflow System
 * Sistema de Fluxo de Trabalho dos Agentes Especializados
 * 
 * @version 1.0.0
 * @description Coordena a execução dos agentes com priorização por assinatura
 * 
 * FLUXO DE TRABALHO:
 * 1. Recebe mensagem do usuário
 * 2. Analisa intenção e detecta agente(s) necessário(s)
 * 3. Valida permissões e tier do usuário
 * 4. Executa agente(s) em paralelo ou sequencial
 * 5. Consolida resultados
 * 6. Executa ferramentas se necessário
 * 7. Retorna resposta
 */

import multiProviderAI from '../services/multiProviderAI.js';
import { buildPromptDefault, getBasePrompt } from '../utils/promptDefault.js';

// Definição dos agentes especializados
const AGENTS = {
  CHANNEL_MANAGER: {
    id: 'channel_manager',
    name: 'Gerenciador de Canais',
    emoji: '📺',
    description: 'Cria, edita, deleta e gerencia canais e categorias',
    tools: [
      'criar_canal', 'criar_categoria', 'editar_canal', 'deletar_canal',
      'listar_canais', 'clonar_canal', 'trancar_canal', 'esconder_canal',
      'permissao_canal', 'criar_thread', 'deletar_thread'
    ],
    keywords: ['canal', 'canais', 'categoria', 'categorias', 'chat', 'voz', 'thread'],
    priority: 1,
    tierRequired: 'free' // Disponível para todos
  },
  
  ROLE_MANAGER: {
    id: 'role_manager',
    name: 'Gerenciador de Cargos',
    emoji: '🎭',
    description: 'Cria, edita, deleta e atribui cargos',
    tools: [
      'criar_cargo', 'editar_cargo', 'deletar_cargo', 'clonar_cargo',
      'adicionar_cargo', 'remover_cargo', 'listar_cargos', 'membros_cargo'
    ],
    keywords: ['cargo', 'cargos', 'role', 'roles', 'permissão', 'rank'],
    priority: 1,
    tierRequired: 'free'
  },
  
  MODERATOR: {
    id: 'moderator',
    name: 'Moderador',
    emoji: '⚖️',
    description: 'Modera membros e mantém a ordem',
    tools: [
      'expulsar', 'banir', 'desbanir', 'mutar', 'desmutar',
      'apelido', 'info_membro', 'deletar_mensagens', 'advertir',
      'ver_advertencias', 'trancar_servidor', 'destravar_servidor'
    ],
    keywords: ['ban', 'kick', 'mute', 'mutar', 'expulsar', 'banir', 'moderar', 'advertir'],
    priority: 1,
    tierRequired: 'free'
  },
  
  AUTOMATION_ENGINEER: {
    id: 'automation_engineer',
    name: 'Engenheiro de Automações',
    emoji: '🤖',
    description: 'Cria e gerencia automações baseadas em eventos',
    tools: [
      'criar_event_automation', 'listar_event_automations',
      'editar_event_automation', 'toggle_event_automation',
      'deletar_event_automation', 'ver_templates_automation',
      'aplicar_template_automation'
    ],
    keywords: ['automação', 'trigger', 'evento', 'quando', 'automático', 'auto'],
    priority: 2,
    tierRequired: 'basic' // Requer assinatura básica
  },
  
  EMBED_DESIGNER: {
    id: 'embed_designer',
    name: 'Designer de Embeds',
    emoji: '🎨',
    description: 'Cria embeds avançados e decorados',
    tools: [
      'enviar_embed', 'enviar_com_botões', 'enviar_com_menu',
      'criar_enquete', 'enviar_webhook'
    ],
    keywords: ['embed', 'decorado', 'mensagem bonita', 'anúncio', 'banner'],
    priority: 2,
    tierRequired: 'free'
  },
  
  MEDIA_SPECIALIST: {
    id: 'media_specialist',
    name: 'Especialista em Mídia',
    emoji: '🖼️',
    description: 'Busca e gera imagens',
    tools: [
      'google_image', 'dalle', 'gerar_imagem'
    ],
    keywords: ['imagem', 'foto', 'gerar', 'buscar', 'dalle', 'google'],
    priority: 3,
    tierRequired: 'free'
  },
  
  ARCHITECT: {
    id: 'architect',
    name: 'Arquiteto de Servidor',
    emoji: '🏗️',
    description: 'Cria estruturas completas de servidor',
    tools: [
      'tarefa_complexa', 'criar_canal', 'criar_categoria', 'criar_cargo',
      'clonar_estrutura', 'template_servidor'
    ],
    keywords: ['criar servidor', 'estruturar', 'arquitetura', 'montar servidor', 'template'],
    priority: 2,
    tierRequired: 'basic'
  },
  
  ECONOMY_MANAGER: {
    id: 'economy_manager',
    name: 'Gerenciador de Economia',
    emoji: '💰',
    description: 'Gerencia sistema de moedas e loja',
    tools: [
      'saldo', 'adicionar_moedas', 'transferir', 'daily', 'trabalhar',
      'ver_loja', 'criar_item', 'comprar', 'ranking_economia'
    ],
    keywords: ['moedas', 'dinheiro', 'saldo', 'loja', 'economia', 'daily'],
    priority: 3,
    tierRequired: 'basic'
  },
  
  LEVEL_MANAGER: {
    id: 'level_manager',
    name: 'Gerenciador de Níveis',
    emoji: '📊',
    description: 'Gerencia sistema de XP e níveis',
    tools: [
      'nivel', 'adicionar_xp', 'ranking_nivel', 'recompensa_nivel'
    ],
    keywords: ['nivel', 'level', 'xp', 'rank', 'experiência'],
    priority: 3,
    tierRequired: 'free'
  },
  
  FUN_AGENT: {
    id: 'fun_agent',
    name: 'Agente de Diversão',
    emoji: '🎮',
    description: 'Comandos divertidos e interativos',
    tools: [
      '8ball', 'roleta_russa', 'rps', 'casar', 'divorciar',
      'ship', 'meme', 'piada', 'verdade_desafio'
    ],
    keywords: ['brincar', 'jogo', 'diversão', 'casar', 'piada'],
    priority: 4,
    tierRequired: 'free'
  },
  
  UTILITY_AGENT: {
    id: 'utility_agent',
    name: 'Agente Utilitário',
    emoji: '🔧',
    description: 'Ferramentas úteis e consultas',
    tools: [
      'clima', 'traduzir', 'wiki', 'filme', 'crypto', 'qrcode',
      'consulta_cnpj', 'consulta_cpf'
    ],
    keywords: ['clima', 'traduzir', 'wiki', 'consulta', 'filme'],
    priority: 4,
    tierRequired: 'free'
  },
  
  WEBHOOK_MANAGER: {
    id: 'webhook_manager',
    name: 'Gerenciador de Webhooks',
    emoji: '🔗',
    description: 'Cria e gerencia webhooks',
    tools: [
      'criar_webhook', 'listar_webhooks', 'editar_webhook',
      'deletar_webhook', 'enviar_webhook', 'info_webhook'
    ],
    keywords: ['webhook', 'integração', 'notificação'],
    priority: 2,
    tierRequired: 'premium' // Recurso avançado
  },
  
  CONVERSATIONALIST: {
    id: 'conversationalist',
    name: 'Conversador',
    emoji: '💬',
    description: 'Conversação natural e ajuda geral',
    tools: ['message'],
    keywords: [], // Agente padrão
    priority: 5,
    tierRequired: 'free'
  }
};

// Mapeamento de ferramentas para agentes
const TOOL_TO_AGENT = {};
for (const [key, agent] of Object.entries(AGENTS)) {
  for (const tool of agent.tools) {
    TOOL_TO_AGENT[tool] = agent.id;
  }
}

/**
 * Classe de Fluxo de Trabalho dos Agentes
 */
class AgentWorkflow {
  constructor() {
    this.conversationHistory = new Map(); // guildId -> messages[]
    this.agentContext = new Map(); // guildId -> currentAgent
    this.executionLog = new Map(); // guildId -> executions[]
  }

  /**
   * Processa uma mensagem através do fluxo de trabalho
   */
  async processMessage(message, guild, channel, userId, userTier = 'free') {
    const guildId = guild.id;
    const startTime = Date.now();
    
    // Definir tier do usuário
    multiProviderAI.setUserTier(userTier);
    
    // Verificar limites do tier
    const tierConfig = multiProviderAI.tierConfig;
    
    console.log(`\n${'═'.repeat(50)}`);
    console.log(`🚀 [Workflow] Iniciando processamento`);
    console.log(`👤 Tier: ${tierConfig.name} | 📍 Guild: ${guild.name}`);
    console.log(`${'═'.repeat(50)}`);
    
    // Passo 1: Detectar intenção e agentes necessários
    const intent = this.detectIntent(message.content || message);
    const requiredAgents = this.selectAgents(intent, userTier);
    
    console.log(`🎯 [Workflow] Intenção detectada: ${intent.type}`);
    console.log(`🤖 [Workflow] Agentes: ${requiredAgents.map(a => a.name).join(', ')}`);
    
    // Passo 2: Validar acesso aos agentes
    const accessValidation = this.validateAgentAccess(requiredAgents, userTier);
    if (!accessValidation.valid) {
      return {
        success: false,
        error: accessValidation.message,
        requiredTier: accessValidation.requiredTier
      };
    }
    
    // Passo 3: Construir contexto
    const context = this.buildContext(guild, channel, requiredAgents);
    
    // Passo 4: Adicionar ao histórico
    this.addToHistory(guildId, 'user', message.content || message);
    
    // Passo 5: Executar agentes
    let response;
    
    if (requiredAgents.length === 1) {
      // Agente único
      response = await this.executeSingleAgent(requiredAgents[0], message, context, guildId);
    } else {
      // Múltiplos agentes (tarefa complexa)
      response = await this.executeMultipleAgents(requiredAgents, message, context, guildId);
    }
    
    // Passo 6: Registrar execução
    this.logExecution(guildId, {
      agents: requiredAgents.map(a => a.id),
      intent: intent.type,
      duration: Date.now() - startTime,
      success: true
    });
    
    // Passo 7: Adicionar resposta ao histórico
    if (response.content) {
      this.addToHistory(guildId, 'assistant', response.content);
    }
    
    console.log(`✅ [Workflow] Concluído em ${Date.now() - startTime}ms`);
    
    return {
      success: true,
      response,
      agents: requiredAgents.map(a => ({ id: a.id, name: a.name })),
      tier: tierConfig.name
    };
  }

  /**
   * Detecta a intenção da mensagem
   */
  detectIntent(messageContent) {
    const content = (typeof messageContent === 'string' ? messageContent : messageContent.content || '').toLowerCase();
    
    // Padrões de detecção de intenção
    const patterns = [
      // Criação
      { type: 'create_channel', pattern: /(criar?|faç[ao]|crie?|adicione?|new)\s+(um?a?\s+)?(canal|chat|voz|categoria|thread)/i },
      { type: 'create_role', pattern: /(criar?|faç[ao]|crie?|adicione?|new)\s+(um?a?\s+)?(cargo|role)/i },
      { type: 'create_automation', pattern: /(criar?|faç[ao]|crie?|configure?|quero).*automaç[ãa]o|quando.*fizer|trigger|evento/i },
      { type: 'create_embed', pattern: /(criar?|faç[ao]|crie?|mande?|envie?).*embed|mensagem.*decorad|an[úu]ncio/i },
      
      // Moderação
      { type: 'moderate', pattern: /(banir?|expulsar?|kick|ban|mute|mutar?|silenciar)/i },
      { type: 'clear', pattern: /(deletar?|limpar?|apagar?|clear|remover?)\s+(mensagem|mensagens)/i },
      
      // Informação
      { type: 'info', pattern: /(info|informação|detalhes?|estatística|stats)/i },
      { type: 'list', pattern: /(listar?|ver|mostrar?|quais).*?(canal|cargo|membro)/i },
      
      // Busca
      { type: 'search_image', pattern: /(buscar?|procurar?|imagem|foto|foto|gerar).*?imagem/i },
      
      // Conversa
      { type: 'conversation', pattern: /(ol[áa]|oi|hey|como (vai|está)|quem é|me (ajuda|ajude))/i },
      
      // Tarefa complexa
      { type: 'complex', pattern: /(criar?|montar?|estruturar?).*?(servidor|estrutura|setup)/i }
    ];
    
    // Verificar padrões
    for (const p of patterns) {
      if (p.pattern.test(content)) {
        return {
          type: p.type,
          confidence: 0.8,
          matches: content.match(p.pattern)
        };
      }
    }
    
    // Análise por palavras-chave
    const keywordScores = {};
    
    for (const [key, agent] of Object.entries(AGENTS)) {
      keywordScores[agent.id] = 0;
      
      for (const keyword of agent.keywords) {
        if (content.includes(keyword.toLowerCase())) {
          keywordScores[agent.id] += 2;
        }
      }
      
      // Verificar ferramentas mencionadas
      for (const tool of agent.tools) {
        if (content.includes(tool.replace(/_/g, ' '))) {
          keywordScores[agent.id] += 3;
        }
      }
    }
    
    // Encontrar maior pontuação
    let maxScore = 0;
    let detectedType = 'conversation';
    
    for (const [agentId, score] of Object.entries(keywordScores)) {
      if (score > maxScore) {
        maxScore = score;
        detectedType = agentId;
      }
    }
    
    return {
      type: maxScore > 2 ? detectedType : 'conversation',
      confidence: Math.min(maxScore / 10, 1),
      scores: keywordScores
    };
  }

  /**
   * Seleciona agentes necessários baseado na intenção
   */
  selectAgents(intent, userTier) {
    const agents = [];
    const tierLevel = { free: 0, basic: 1, premium: 2, ultimate: 3 };
    const userLevel = tierLevel[userTier] || 0;
    
    // Mapear tipo de intenção para agente
    const intentToAgent = {
      'create_channel': 'channel_manager',
      'create_role': 'role_manager',
      'create_automation': 'automation_engineer',
      'create_embed': 'embed_designer',
      'moderate': 'moderator',
      'clear': 'moderator',
      'info': 'utility_agent',
      'list': 'utility_agent',
      'search_image': 'media_specialist',
      'conversation': 'conversationalist',
      'complex': 'architect'
    };
    
    const primaryAgentId = intentToAgent[intent.type] || 'conversationalist';
    const primaryAgent = Object.values(AGENTS).find(a => a.id === primaryAgentId);
    
    if (primaryAgent) {
      agents.push(primaryAgent);
    }
    
    // Adicionar agente conversador como fallback
    if (agents.length === 0 || agents[0].id !== 'conversationalist') {
      // Sempre incluir contexto conversacional
    }
    
    // Filtrar por tier
    return agents.filter(agent => {
      const agentTierLevel = tierLevel[agent.tierRequired] || 0;
      return userLevel >= agentTierLevel;
    });
  }

  /**
   * Valida acesso do usuário aos agentes
   */
  validateAgentAccess(agents, userTier) {
    const tierLevel = { free: 0, basic: 1, premium: 2, ultimate: 3 };
    const userLevel = tierLevel[userTier] || 0;
    
    for (const agent of agents) {
      const agentLevel = tierLevel[agent.tierRequired] || 0;
      
      if (userLevel < agentLevel) {
        return {
          valid: false,
          message: `O recurso "${agent.name}" requer assinatura ${agent.tierRequired} ou superior.`,
          requiredTier: agent.tierRequired,
          agentId: agent.id
        };
      }
    }
    
    return { valid: true };
  }

  /**
   * Constrói contexto para o agente
   */
  buildContext(guild, channel, agents) {
    return {
      guild: {
        id: guild.id,
        name: guild.name,
        memberCount: guild.memberCount,
        iconURL: guild.iconURL(),
        premiumTier: guild.premiumTier
      },
      channel: {
        id: channel.id,
        name: channel.name,
        type: channel.type
      },
      agents: agents.map(a => ({
        id: a.id,
        name: a.name,
        tools: a.tools
      })),
      timestamp: new Date().toISOString()
    };
  }

  /**
   * Executa um único agente
   */
  async executeSingleAgent(agent, message, context, guildId) {
    console.log(`🤖 [Workflow] Executando agente: ${agent.name}`);
    
    // Construir prompt específico do agente
    const systemPrompt = this.buildAgentPrompt(agent, context.guild, context.channel);
    
    // Construir mensagens
    const messages = [
      { role: 'system', content: systemPrompt }
    ];
    
    // Adicionar histórico recente
    const history = this.getHistory(guildId).slice(-10);
    for (const msg of history) {
      if (msg.role !== 'system') {
        messages.push({ role: msg.role, content: msg.content });
      }
    }
    
    // Fazer requisição à IA
    const response = await multiProviderAI.chatCompletion(messages, {
      temperature: 1,
      maxTokens: multiProviderAI.tierConfig.maxTokens
    });
    
    return {
      content: response.content,
      provider: response.provider,
      agent: agent.name
    };
  }

  /**
   * Executa múltiplos agentes em sequência
   */
  async executeMultipleAgents(agents, message, context, guildId) {
    console.log(`🤖 [Workflow] Executando ${agents.length} agentes`);
    
    let combinedContent = '';
    let lastProvider = '';
    
    for (const agent of agents) {
      const response = await this.executeSingleAgent(agent, message, context, guildId);
      combinedContent += response.content + '\n';
      lastProvider = response.provider;
    }
    
    return {
      content: combinedContent,
      provider: lastProvider,
      agents: agents.map(a => a.name)
    };
  }

  /**
   * Constrói prompt específico do agente
   */
  buildAgentPrompt(agent, guild, channel) {
    const basePrompt = buildPromptDefault(guild, channel);
    
    return `
${basePrompt}

# ══════════════════════════════════════════════════════════════
# 🤖 AGENTE ESPECIALISTA ATIVO: ${agent.emoji} ${agent.name}
# ══════════════════════════════════════════════════════════════

## 📋 Descrição:
${agent.description}

## 🔧 Ferramentas Disponíveis:
${agent.tools.map(t => `• \`${t}\``).join('\n')}

## ⚡ Foco:
Use PRIMARIAMENTE estas ferramentas para resolver a solicitação do usuário.
Se precisar de ferramentas de outro agente, use \`tarefa_complexa\`.

## 💎 Tier do Usuário:
${multiProviderAI.tierConfig.name}

${multiProviderAI.tierConfig.features.advancedAgents ? 
  '✅ Recursos avançados de agente disponíveis!' : 
  '⚠️ Alguns recursos avançados requerem assinatura.'}

---
`;
  }

  /**
   * Gerencia histórico de conversa
   */
  addToHistory(guildId, role, content) {
    if (!this.conversationHistory.has(guildId)) {
      this.conversationHistory.set(guildId, []);
    }
    
    const history = this.conversationHistory.get(guildId);
    
    // Limitar histórico
    if (history.length >= 20) {
      history.shift();
    }
    
    history.push({ role, content, timestamp: Date.now() });
  }

  getHistory(guildId) {
    return this.conversationHistory.get(guildId) || [];
  }

  clearHistory(guildId) {
    this.conversationHistory.delete(guildId);
  }

  /**
   * Registra execução
   */
  logExecution(guildId, execution) {
    if (!this.executionLog.has(guildId)) {
      this.executionLog.set(guildId, []);
    }
    
    const log = this.executionLog.get(guildId);
    log.push(execution);
    
    // Manter últimas 100 execuções
    if (log.length > 100) {
      log.shift();
    }
  }

  /**
   * Obtém estatísticas
   */
  getStats(guildId) {
    const log = this.executionLog.get(guildId) || [];
    const history = this.conversationHistory.get(guildId) || [];
    
    return {
      totalExecutions: log.length,
      successRate: log.filter(e => e.success).length / Math.max(log.length, 1),
      averageDuration: log.reduce((sum, e) => sum + (e.duration || 0), 0) / Math.max(log.length, 1),
      historyLength: history.length,
      agents: Object.keys(AGENTS).length
    };
  }

  /**
   * Obtém informações dos agentes
   */
  getAgentsInfo() {
    return Object.values(AGENTS).map(a => ({
      id: a.id,
      name: a.name,
      emoji: a.emoji,
      description: a.description,
      toolsCount: a.tools.length,
      tierRequired: a.tierRequired
    }));
  }
}

// Singleton
const agentWorkflow = new AgentWorkflow();

export { AGENTS, TOOL_TO_AGENT, AgentWorkflow };
export default agentWorkflow;
