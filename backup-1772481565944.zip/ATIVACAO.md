# 🚀 Guia de Ativação do Novo Sistema de Pagamento

## ✅ Pré-requisitos

Antes de iniciar, certifique-se de que:

1. **Bot Discord** está funcionando com a última versão do código
2. **Node.js 18+** está instalado
3. **Discord.js 14.15+** está instalado
4. **Variáveis de ambiente** estão configuradas corretamente

---

## 🔧 Passo 1: Verificar Variáveis de Ambiente

Crie um arquivo `.env` na raiz do projeto com:

```env
DISCORD_TOKEN=seu_token_discord_aqui
DISCORD_CLIENT_ID=seu_client_id_aqui
BOT_PREFIX=/
CASHINPAY_API_KEY=sk_live_b81dbb21f62367d87f4401b22821899c4b108a0a
```

**Obtém os valores:**
- `DISCORD_TOKEN`: Discord Developer Portal → Applications → Your App → Bot
- `DISCORD_CLIENT_ID`: Mesmo lugar, copiar Application ID
- `CASHINPAY_API_KEY`: Já fornecido (não alterar em produção)

---

## 📦 Passo 2: Instalar Dependências

As dependências necessárias já estão no `package.json`:

```bash
npm install
# ou
bun install
```

**Dependências usadas:**
- `discord.js@^14.15.0` - API Discord
- `dotenv@^16.4.5` - Variáveis de ambiente
- `form-data@^4.0.5` - Multipart form data
- `openai@^4.70.0` - Integração com IA (já existente)
- `pdf-lib@^1.17.1` - Geração de PDFs

---

## 🎯 Passo 3: Iniciar o Bot

### Desenvolvimento (com Hot Reload)
```bash
npm run dev
# ou
bun --hot index.js
```

### Produção
```bash
npm start
# ou
bun index.js
```

### Esperado na Saída
```
═══════════════════════════════════════════
       🏗️  MUTANOX ARCHITECT AI  🏗️
       Bot Discord - Versão 2.2
       Sistema de Licenças e Permissões
═══════════════════════════════════════════

✅ Variáveis de ambiente validadas
🤖 Inicializando serviço de IA...
🎫 Inicializando sistema de licenças...
💰 Inicializando sistema de contas...

📂 Carregando comandos...
  ✅ /renov
  ✅ /minha-conta
  ✅ /vincular
  ✅ /desvincar
  ✅ /saldo
  ... (outros comandos)

🎯 Carregando eventos...
  ✅ clientReady
  ✅ interactionCreate
  ✅ messageCreate
  ... (outros eventos)

✅ [Accounts] Sistema de contas carregado
✅ [License] Sistema de licenças carregado

═══════════════════════════════════════════
       ✅ BOT INICIADO COM SUCESSO!
       📍 0 servidores
       👥 0 usuários
       ⚡ 50ms ping
═══════════════════════════════════════════
```

---

## 🧪 Passo 4: Testar o Sistema

### Teste 1: Comando /renov (básico)

1. Vai para um servidor onde o bot está
2. Execute: `/renov plano:semanal`
3. Esperado: Bot envia DM com QR code
4. **Resultado:** ✅ Comando funcionando

### Teste 2: Comando /minha-conta

1. Execute: `/minha-conta`
2. Esperado: Mostra embed com informações da conta
3. **Resultado:** ✅ Conta criada automaticamente

### Teste 3: Comando /saldo

1. Execute: `/saldo ver`
2. Esperado: Mostra saldo (deve ser R$ 0,00 no início)
3. **Resultado:** ✅ Sistema de saldo funcionando

### Teste 4: Vincular Usuário

1. Execute (como User A): `/vincular @userB`
2. Esperado: User B vinculado à conta
3. Execute (como User B): `/minha-conta`
4. Esperado: Mostra "Vinculado a User A"
5. **Resultado:** ✅ Sistema de vinculação funcionando

---

## 📊 Passo 5: Verificar Dados

Os dados são armazenados em JSON:

**Arquivo de Contas:**
```bash
cat /tmp/rias-accounts.json
```

**Deve conter:**
```javascript
{
  "accounts": {
    "userId": {
      "userId": "123456789",
      "username": "username",
      "balance": 0,
      "planType": null,
      "planExpiresAt": null,
      ...
    }
  },
  "pendingTransactions": {}
}
```

---

## 🔄 Passo 6: Migração de Usuários (OPCIONAL)

Se você tinha usuários no sistema antigo de licenças:

### Opção 1: Manter Ambos os Sistemas
- ✅ Sistema antigo continua funcionando
- ✅ Novos usuários usam novo sistema
- ✅ Usuários antigos podem continuar com licenças manuais

### Opção 2: Migrar para Novo Sistema
1. Registre os usuários licenciados
2. Execute manualmente para cada um:
   ```javascript
   const accountManager = require('./src/utils/accountManager.js');
   
   // Para cada usuário antigo
   accountManager.getOrCreateAccount(userId, username);
   accountManager.activatePlan(userId, 'mensal', 30);
   ```

### Opção 3: Desativar Sistema Antigo
Comentar em `index.js`:
```javascript
// console.log('🎫 Inicializando sistema de licenças...');
// licenseManager.initLicenseSystem();
```

---

## 🎨 Customizações Possíveis

### Alterar Preços

Arquivo: `src/utils/accountManager.js`

```javascript
PLAN_PRICES: {
  'semanal': 20.00,    // ← Alterar valor
  'mensal': 29.59      // ← Alterar valor
}
```

### Alterar Duração

Arquivo: `src/utils/accountManager.js`

```javascript
PLAN_DAYS: {
  'semanal': 7,   // ← Alterar para 5, 10, etc.
  'mensal': 30    // ← Alterar para 25, 35, etc.
}
```

### Alterar Limite de Usuários Vinculados

Arquivo: `src/utils/accountManager.js`

```javascript
MAX_LINKED_USERS: 2  // ← Mude para 1, 3, 4, etc.
```

### Alterar Intervalo de Renovação Automática

Arquivo: `src/utils/accountManager.js`

```javascript
RENEWAL_CHECK_INTERVAL: 6 * 60 * 60 * 1000  // ← Mude para 1h, 12h, etc.
```

---

## 🔐 Segurança

### Proteções Implementadas

✅ **API Key em Variável de Ambiente** - Nunca exposta em código  
✅ **Validação de Proprietário** - Apenas o dono pode gerenciar  
✅ **Historico de Transações** - Todas as operações registradas  
✅ **Permissões por Servidor** - Respeitam estrutura existente  
✅ **Validação de Valores** - Min R$ 5,00, Max R$ 10.000,00  

### Recomendações

- 🔒 Nunca compartilhe a API Key
- 🔒 Faça backup regular de `/tmp/rias-accounts.json`
- 🔒 Use HTTPS em produção
- 🔒 Monitore logs para atividades suspeitas

---

## 📱 Testes com CashinPay

### Teste de Transação (para debug)

```javascript
// src/services/cashinPayService.js
import * as cashinPay from './cashinPayService.js';

// Teste de criação de transação
const result = await cashinPay.createTransaction({
  amount: 10.00,
  description: 'Teste',
  customer: {
    name: 'Teste User',
    email: 'test@example.com'
  }
});

console.log(result);
```

### Verificar Saldo da CashinPay

```javascript
import * as cashinPay from './cashinPayService.js';

const balance = await cashinPay.getBalance();
console.log(balance);
// { success: true, data: { balance: { available: X, pending: Y } } }
```

---

## 🚨 Troubleshooting

### Erro: "CASHINPAY_API_KEY não definida"

**Solução:**
```bash
# Verificar se .env existe
cat .env | grep CASHINPAY

# Se não existir, adicionar
echo 'CASHINPAY_API_KEY=sk_live_b81dbb21f62367d87f4401b22821899c4b108a0a' >> .env
```

### Erro: "Comando /renov não aparece"

**Solução:**
```bash
# 1. Registrar comandos manualmente
npm run deploy-commands

# 2. Ou definir guild ID para teste rápido
echo 'DISCORD_GUILD_ID=seu_server_id' >> .env

# 3. Reiniciar bot
npm run dev
```

### Erro: "Arquivo de contas não encontrado"

**Solução:**
System criará automaticamente em `/tmp/rias-accounts.json`. Verifique:
```bash
ls -la /tmp/rias-accounts.json
```

### Erro: "QR code não aparece em DM"

**Solução:**
- Verificar permissões de DM do bot
- Desabilitar proteção de DM no servidor se houver
- Tentar comando de novo

---

## 📈 Monitoramento

### Ver Estatísticas

```javascript
import accountManager from './src/utils/accountManager.js';

const stats = accountManager.getStats();
console.log(stats);
// {
//   totalAccounts: 5,
//   activeAccounts: 3,
//   expiredAccounts: 2,
//   totalBalance: 150.50,
//   linkedUsers: 2,
//   pendingTransactions: 1
// }
```

### Logs Importantes

Procure por estas mensagens no console:

- ✅ `[Accounts] Sistema de contas carregado` - Sistema iniciado
- 🔄 `[Payment] Criando pagamento` - Pagamento solicitado
- ✅ `[Payment] Pagamento confirmado` - Pagamento validado
- 🔗 `[Accounts] Usuário vinculado` - Vinculação realizada
- 🔄 `[Accounts] Renovação automática executada` - Auto-renew ativo

---

## 📞 Suporte Rápido

| Problema | Verificar |
|----------|-----------|
| Bot não inicializa | `.env` configurado? Node 18+? |
| Comandos não aparecem | Execute `npm run deploy-commands` |
| QR code não aparece | Permissões de DM habilitadas? |
| Pagamento não valida | Aguardar 5+ segundos e tentar novamente |
| Dados sumiram | Backup de `/tmp/rias-accounts.json`? |

---

## ✨ Próximos Passos

Após ativação bem-sucedida:

1. **Comunicar aos usuários** - Explique o novo sistema
2. **Testar com usuários reais** - Faça teste com sua comunidade
3. **Configire preços corretos** - Se necessário alterar valores
4. **Monitore transações** - Acompanhe os primeiros pagamentos
5. **Coletar feedback** - Melhore conforme necessário

---

## 🎉 Pronto!

Se você chegou até aqui e tudo funcionou:

✅ Sistema de contas implementado  
✅ Pagamentos PIX funcionando  
✅ Vinculação de usuários operacional  
✅ Renovação automática ativa  
✅ Documentação completa  

**Parabéns! seu novo sistema de pagamento está vivo!** 🚀

---

**Desenvolvido com ❤️**  
**Versão: 1.0.0**  
**Última atualização: Fevereiro 2026**

