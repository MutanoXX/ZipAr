# 💳 Sistema de Pagamento PIX - Documentação Completa

## 📋 Visão Geral

O novo sistema de pagamento foi implementado para substituir o antigo sistema de licenças manual. Agora os usuários podem renovar seus planos automaticamente via PIX, adicionar saldo à conta, e gerenciar múltiplos usuários vinculados.

### Características Principais

✅ **Pagamento via PIX** - Integração com CashinPay para pagamentos PIX  
✅ **Contas de Usuário** - Cada usuário tem sua própria conta com saldo  
✅ **Vinculação de Usuários** - Até 2 pessoas por conta  
✅ **Renovação Automática** - O plano renova automaticamente quando expira se houver saldo  
✅ **Histórico de Transações** - Rastreie todos os pagamentos e depósitos  
✅ **Flexibilidade** - Usuários vinculados podem se desvincar e criar suas próprias contas  

---

## 💰 Estrutura de Preços

### Planos Disponíveis

| Plano | Duração | Preço |
|-------|---------|-------|
| **Semanal** | 7 dias | R$ 20,00 |
| **Mensal** | 30 dias | R$ 29,59 |

### Exemplo de Cálculos

- **1x Semanal** = R$ 20,00
- **2x Semanal** = R$ 40,00
- **1x Mensal** = R$ 29,59  
- **3x Mensal** = R$ 88,77

---

## 📁 Estrutura de Arquivos

### Novos Arquivos Criados

```
src/
├── services/
│   ├── paymentManager.js          # Gerencia pagamentos
│   └── cashinPayService.js        # ✅ Já existia (melhorado)
├── utils/
│   └── accountManager.js          # ✅ Já existia (Sistema de contas)
└── commands/
    ├── renov.js                   # Comando de renovação
    ├── minha-conta.js             # Visualizar conta
    ├── vincular.js                # Vincular usuários
    ├── desvincar.js               # Desvincar usuários
    └── saldo.js                   # Gerenciar saldo
```

---

## 🎮 Comandos Disponíveis

### `/renov` - Renovar o Plano

Permite ao usuário comprar um plano via PIX.

**Opções:**
- `plano` (obrigatório): Semanal ou Mensal
- `quantidade` (opcional): Quantos planos comprar (1-12)

**Fluxo:**
1. Usuário executa `/renov`
2. Bot envia QR code e código PIX via DM
3. Usuário faz o pagamento
4. Usuário clica no botão "✅ Já fiz o pagamento"
5. Bot confirma o pagamento com a CashinPay
6. Plano é ativado

**Exemplo:**
```
/renov plano:mensal quantidade:2
```

---

### `/minha-conta` - Visualizar Conta

Mostra informações detalhadas da conta do usuário.

**Informações Exibidas:**
- 💰 Saldo disponível
- 📅 Plano ativo e tempo restante
- 🔗 Usuários vinculados
- 🔄 Status de renovação automática
- 📊 Histórico de transações

---

### `/saldo` - Gerenciar Saldo

Permite adicionar dinheiro à conta para renovações automáticas.

**Subcomandos:**
- `ver` - Mostra saldo atual e últimas transações
- `adicionar <valor>` - Adiciona saldo via PIX

**Valor Mínimo:** R$ 5,00  
**Valor Máximo:** R$ 10.000,00

---

### `/vincular` - Vincular Usuários

Vincula outro usuário à sua conta.

**Limitações:**
- Máximo 2 usuários por conta
- Você precisa ter um plano ativo
- Não pode vincular a si mesmo
- Não pode vincular alguém que já tem conta própria

**Fluxo:**
1. Proprietário executa `/vincular @usuario`
2. Usuário é vinculado à conta
3. Usuário pode agora usar o bot enquanto houver plano ativo

---

### `/desvincar` - Desvincar Usuários

Desvincula um usuário de sua conta **OU** se desvincula de uma conta principal.

**Cenários:**

**Opção 1: Proprietário desvinculando outro usuário**
```
/desvincar usuario:@alguém
```

**Opção 2: Usuário se desviculando de uma conta**
```
/desvincar
```

---

## 🔄 Fluxo de Funcionamento

### Novo Usuário

```
1. Usuário executa /renov
   ↓
2. Bot cria transação PIX
   ↓
3. Bot envia QR code via DM
   ↓
4. Usuário faz pagamento
   ↓
5. Usuário clica "Pago"
   ↓
6. Bot valida com CashinPay
   ↓
7. Plano é ativado
   ↓
8. Conta criada automaticamente
```

### Renovação Automática

```
Plano ativo com 24h or menos restantes → Bot detecta 
↓
Verifica se tem saldo suficiente → Sim
↓
Deduz do saldo (R$ 20 ou R$ 29,59)
↓
Ativa novo plano
↓
Registra transação
↓
✅ Plano renovado automaticamente
```

### Sistema de Vinculação

```
User A (Dono)
├── /vincular @userB
│   └── User B (Vinculado)
│       └── Pode usar o bot enquanto User A tiver plano
└── /vincular @userC
    └── User C (Vinculado)
        └── Pode usar o bot

User B (Vinculado) deseja sua própria conta:
└── /desvincar
    └── Se desvincula
    └── Agora pode comprar seu próprio plano
```

---

## 💾 Dados Armazenados

### accountManager.js

Arquivo: `/tmp/rias-accounts.json`

```javascript
{
  "accounts": {
    "userId": {
      "userId": "string",
      "username": "string",
      "balance": 150.50,
      "planType": "mensal",
      "planExpiresAt": 1735689600000,
      "autoRenew": true,
      "linkedUsers": ["userId1", "userId2"],
      "linkedTo": null,
      "createdAt": 1735000000000,
      "lastActivity": 1735689500000,
      "transactions": []
    }
  },
  "pendingTransactions": {
    "txnId": {
      "userId": "string",
      "type": "plan_renewal",
      "amount": 29.59,
      "planType": "mensal",
      "quantity": 1,
      "status": "pending",
      "createdAt": 1735689400000
    }
  }
}
```

---

## 🛡️ Permissões e Acesso

### Quem pode usar o bot?

✅ **Pode usar:**
- Dono do bot (acesso permanente)
- Usuários com plano ativo
- Usuários vinculados a alguém com plano ativo
- Donos de servidor ou administradores (se tiverem plano)

❌ **Não pode usar:**
- Sem plano ativo
- Sem ser dono ou admin do servidor
- Vinculado a uma conta que expirou o plano

---

## 🔧 Integração CashinPay

### API Configurada

- **Base URL:** `https://api.cashinpay.online/api/v1`
- **API Key:** `sk_live_b81dbb21f62367d87f4401b22821899c4b108a0a`
- **Autenticação:** Bearer Token

### Endpoints Utilizados

| Endpoint | Uso |
|----------|-----|
| `POST /transactions` | Criar pagamento PIX |
| `GET /transactions/{id}` | Verificar status |
| `GET /balance` | Ver saldo disponível |

### Fluxo de Validação

Como **não há webhook automático**, o fluxo é:

1. Bot cria transação → Recebe ID
2. Usuário faz pagamento
3. Usuário clica botão "Pago"
4. Bot consulta API: `GET /transactions/{id}`
5. Se status = "paid" → Ativa plano
6. Se status != "paid" → Aguarde ou retentar

---

## 📊 Verificação de Status

### Verificar Plano Ativo

```javascript
import accountManager from './utils/accountManager.js';

const account = accountManager.getAccount(userId);
const planInfo = accountManager.getPlanTimeRemaining(userId);

console.log(planInfo.valid);        // true/false
console.log(planInfo.formatted);    // "15 dias 4h"
console.log(planInfo.expiresAt);    // timestamp
```

### Verificar Transações

```javascript
const transactions = accountManager.getUserTransactions(userId, 10);
// Últimas 10 transações
```

---

## ⚙️ Configurações

Arquivo: `src/utils/accountManager.js` (CONFIG)

```javascript
const CONFIG = {
  ACCOUNT_FILE: '/tmp/rias-accounts.json',
  BOT_OWNER_ID: '1387242867700924568',
  
  PLAN_PRICES: {
    'semanal': 20.00,
    'mensal': 29.59
  },
  
  PLAN_DAYS: {
    'semanal': 7,
    'mensal': 30
  },
  
  MAX_LINKED_USERS: 2,
  MIN_BALANCE: 0
};
```

---

## 🚀 Como Usar

### Para o Dono do Bot

1. **Inicializar o sistema** (automático ao iniciar o bot):
   ```
   - accountManager.initAccountSystem()
   - paymentManager está pronto
   ```

2. **Verificar stats:**
   ```javascript
   const stats = accountManager.getStats();
   console.log(stats); // Total de contas, planos ativos, etc.
   ```

### Para Usuários

1. **Comprar um plano:**
   ```
   /renov plano:mensal
   ```

2. **Ver sua conta:**
   ```
   /minha-conta
   ```

3. **Adicionar saldo:**
   ```
   /saldo adicionar 50
   ```

4. **Vincular um amigo:**
   ```
   /vincular @amigo
   ```

---

## 🐛 Troubleshooting

### "Erro ao criar pagamento"
- Verifique se a API Key está correta
- Verifique se a conexão com internet está ok
- Tente novamente em alguns momentos

### "Transação não foi validada"
- Pode levar alguns segundos para a CashinPay confirmar
- Clique em "Pago" novamente após alguns segundos
- Verifique se o pagamento foi realmente efetuado

### "Saldo insuficiente para renovar"
- Adicione saldo usando `/saldo adicionar`
- Desative renovação automática se não tiver saldo

### Usuário vinculado não consegue usar o bot
- Proprietário tem plano ativo?
- Proprietário deactivou não renovar automática?
- Plano expirou?

---

## 📝 Notas Importantes

⚠️ **Não há contato com CashinPay além de:**
- Criar transação (PIX)
- Verificar status (manual)

✅ **Todos os dados locais são:**
- Salvos em JSON (persistent)
- Sincronizados em tempo real
- Auditáveis e rastreáveis

📍 **Localização dos dados:**
- `/tmp/rias-accounts.json` - Contas e transações
- `/tmp/rias-transactions.json` - Histórico completo

---

## 🔐 Segurança

- ✅ API Key armazenada como variável de ambiente
- ✅ Cada usuário gerencia apenas sua própria conta
- ✅ Histórico completo de transações
- ✅ Validação em duas etapas para operações sensíveis
- ✅ Permissões por servidor mantidas

---

## 📞 Suporte

Para dúvidas ou problemas:
1. Verifique este documento
2. Consulte os logs do bot
3. Verifique o status da API CashinPay

---

**Desenvolvido com ❤️ por MutanoX**  
**Versão: 1.0.0**  
**Data: Fevereiro 2026**
