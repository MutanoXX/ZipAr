# 🌹 RIAS GREMORY X AI v5.0 - Sistema Turbinado

## 📚 Documentação Completa

---

## 🔄 FLUXO DE TRABALHO DOS AGENTES

```
┌─────────────────────────────────────────────────────────────────┐
│                    MENSAGEM DO USUÁRIO                           │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    1. VALIDAÇÃO DE TIER                          │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ SubscriptionManager.getUserTier(userId)                    │  │
│  │ • Verifica assinatura ativa                                │  │
│  │ • Retorna: free | basic | premium | ultimate               │  │
│  └────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    2. VERIFICAÇÃO DE LIMITES                     │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ SubscriptionManager.checkLimit(userId, 'requestsPerDay')   │  │
│  │ • Verifica se pode fazer a requisição                      │  │
│  │ • Registra uso se permitido                                │  │
│  └────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    3. DETECÇÃO DE INTENÇÃO                       │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ AgentWorkflow.detectIntent(message)                        │  │
│  │ • Analisa keywords                                         │  │
│  │ • Verifica ferramentas mencionadas                         │  │
│  │ • Retorna: tipo de intenção                                │  │
│  └────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    4. SELEÇÃO DE AGENTE                          │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ AgentWorkflow.selectAgents(intent, userTier)               │  │
│  │ • Seleciona agente baseado na intenção                     │  │
│  │ • Filtra por tier disponível                               │  │
│  │ • Valida acesso                                            │  │
│  └────────────────────────────────────────────────────────────┘  │
│                                                                   │
│  AGENTES:                                                        │
│  📺 ChannelManager    → Canais e Categorias                      │
│  🎭 RoleManager       → Cargos e Permissões                      │
│  ⚖️ Moderator         → Moderação                                │
│  🎨 EmbedDesigner     → Embeds Decorados                         │
│  🖼️ MediaSpecialist   → Imagens                                  │
│  🤖 AutomationEngineer→ Automações Event-Driven                  │
│  🏗️ Architect         → Estrutura de Servidor                    │
│  💬 Conversationalist → Conversação Geral                        │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    5. CONSTRUÇÃO DE PROMPT                       │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ buildAgentPrompt(agent, guild, channel)                    │  │
│  │ • Inclui contexto do servidor                              │  │
│  │ • Adiciona ferramentas do agente                           │  │
│  │ • Inclui informações do tier                               │  │
│  └────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    6. REQUISIÇÃO À IA                            │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ MultiProviderAI.chatCompletion(messages, options)          │  │
│  │                                                            │  │
│  │  ┌──────────────┐    ┌──────────────┐                     │  │
│  │  │ NVIDIA API   │───▶│ G4F Space    │                     │  │
│  │  │ (Primário)   │    │ (Fallback)   │                     │  │
│  │  └──────────────┘    └──────────────┘                     │  │
│  │         │                   │                              │  │
│  │         ▼                   ▼                              │  │
│  │    ✅ Sucesso         ✅ Fallback                          │  │
│  │    ❌ Erro ───────────▶ Tentar G4F                         │  │
│  └────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    7. PROCESSAMENTO DE RESPOSTA                  │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ parseResponse(content)                                     │  │
│  │ • Extrai JSON da resposta                                  │  │
│  │ • Identifica tipo de ação                                  │  │
│  │ • Retorna objeto de resposta                               │  │
│  └────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    8. EXECUÇÃO DE FERRAMENTAS                    │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ handleResponse(response)                                    │  │
│  │ • Executa ação apropriada                                  │  │
│  │ • Usa ferramentas do agente                                │  │
│  │ • Retorna resultado                                        │  │
│  └────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    9. RESPOSTA AO USUÁRIO                        │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ Envia embed/mensagem ao canal                              │  │
│  │ • Registra no histórico                                    │  │
│  │ • Atualiza estatísticas                                    │  │
│  └────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🤖 MULTI-PROVIDER AI SYSTEM

### Arquitetura de Fallback

```
┌─────────────────────────────────────────────────────────────────┐
│                    MULTI-PROVIDER AI                             │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │                   PROVIDER SELECTION                         │ │
│  │                                                               │ │
│  │   IA_PROVIDER=0 (Auto)  → Seleciona automaticamente          │ │
│  │   IA_PROVIDER=1 (NVIDIA)→ Força NVIDIA                       │ │
│  │   IA_PROVIDER=2 (G4F)   → Força G4F                         │ │
│  └─────────────────────────────────────────────────────────────┘ │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │                   PROVIDER 1: NVIDIA                          │ │
│  │   • Base URL: https://integrate.api.nvidia.com/v1           │ │
│  │   • Model: z-ai/glm5                                        │ │
│  │   • Max Tokens: 16384                                        │ │
│  │   • Features: Thinking, Streaming                           │ │
│  │   • Requires: NVIDIA_API_KEY                                │ │
│  └─────────────────────────────────────────────────────────────┘ │
│                              │                                    │
│                              │ On Error/Fail                     │
│                              ▼                                    │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │                   PROVIDER 2: G4F Space                       │ │
│  │   • Base URL: https://g4f.space/api/nvidia/chat/completions │ │
│  │   • Model: z-ai/glm5                                        │ │
│  │   • Max Tokens: 8192                                         │ │
│  │   • Features: Basic streaming                                │ │
│  │   • Requires: Nothing (Free)                                 │ │
│  │   • Retries: 5 com backoff                                   │ │
│  └─────────────────────────────────────────────────────────────┘ │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │                   ERROR HANDLING                              │ │
│  │   • Rate Limit (429) → Wait 5s, retry                        │ │
│  │   • Timeout → Retry with different provider                  │ │
│  │   • 5 consecutive failures → Mark provider unavailable       │ │
│  │   • Auto-recovery after 5 minutes                            │ │
│  └─────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

---

## 💎 SISTEMA DE ASSINATURAS

### Tiers Disponíveis

```
┌─────────────────────────────────────────────────────────────────┐
│  🆓 FREE                                                          │
├─────────────────────────────────────────────────────────────────┤
│  • Requests/dia: 50                                              │
│  • Max tokens: 4.096                                             │
│  • IA Provider: G4F apenas                                       │
│  • Event Automations: 3                                          │
│  • Image Gen: 5/dia                                              │
│  • Cooldown: 5 segundos                                          │
│  • Response delay: 2s (incentivo)                                │
│  • Suporte: Baixa prioridade                                     │
│                                                                   │
│  ✅ Básico: Canais, Cargos, Moderação, Embeds simples            │
│  ❌ Avançado: Webhooks, API, Automações avançadas                │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  ⭐ BASIC (R$ 9,90/mês)                                          │
├─────────────────────────────────────────────────────────────────┤
│  • Requests/dia: 500                                             │
│  • Max tokens: 8.192                                             │
│  • IA Provider: NVIDIA + G4F                                     │
│  • Event Automations: 15                                         │
│  • Scheduled Automations: 5                                      │
│  • Image Gen: 50/dia                                             │
│  • Cooldown: 1 segundo                                           │
│  • Streaming: ✅                                                  │
│  • Suporte: Média prioridade                                     │
│                                                                   │
│  ✅ Tudo do Free + Automações, Webhooks, Analytics               │
│  ❌ Não tem: White label, API custom                             │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  💎 PREMIUM (R$ 29,90/mês)                                       │
├─────────────────────────────────────────────────────────────────┤
│  • Requests/dia: 2.000                                           │
│  • Max tokens: 16.384                                            │
│  • IA Provider: NVIDIA + G4F                                     │
│  • Event Automations: 100                                        │
│  • Scheduled Automations: 20                                     │
│  • Image Gen: 200/dia                                            │
│  • Webhooks: 10                                                  │
│  • Cooldown: 0.5 segundos                                        │
│  • Streaming: ✅                                                  │
│  • Analytics: ✅                                                   │
│  • Backup: ✅                                                      │
│  • Suporte: Alta prioridade                                      │
│                                                                   │
│  ✅ Tudo do Basic + Dalle HD, Custom Bot, API                    │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  👑 ULTIMATE (R$ 99,90/mês)                                      │
├─────────────────────────────────────────────────────────────────┤
│  • Requests/dia: ILIMITADO                                       │
│  • Max tokens: 32.768                                            │
│  • IA Provider: NVIDIA + G4F                                     │
│  • Event Automations: ILIMITADO                                  │
│  • Scheduled Automations: ILIMITADO                              │
│  • Image Gen: ILIMITADO                                          │
│  • Webhooks: ILIMITADO                                           │
│  • Cooldown: 0                                                    │
│  • Contexto: 50 mensagens                                        │
│  • Tarefas concorrentes: 10                                      │
│  • Suporte: Máxima prioridade                                    │
│                                                                   │
│  ✅ TUDO ILIMITADO + White Label                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🎯 AGENTES E FERRAMENTAS POR TIER

### Tabela de Disponibilidade

| Agente | Ferramentas | Free | Basic | Premium | Ultimate |
|--------|-------------|------|-------|---------|----------|
| 📺 ChannelManager | criar_canal, criar_categoria, etc | ✅ | ✅ | ✅ | ✅ |
| 🎭 RoleManager | criar_cargo, adicionar_cargo, etc | ✅ | ✅ | ✅ | ✅ |
| ⚖️ Moderator | banir, mutar, expulsar, etc | ✅ | ✅ | ✅ | ✅ |
| 🎨 EmbedDesigner | enviar_embed, criar_enquete | ✅ | ✅ | ✅ | ✅ |
| 🖼️ MediaSpecialist | google_image, dalle | ✅ | ✅ | ✅ | ✅ |
| 🤖 AutomationEngineer | criar_event_automation | ❌ | ✅ | ✅ | ✅ |
| 🏗️ Architect | tarefa_complexa, templates | ❌ | ✅ | ✅ | ✅ |
| 🔗 WebhookManager | criar_webhook, enviar_webhook | ❌ | ❌ | ✅ | ✅ |
| 🔌 APIIntegrator | http_request, variables | ❌ | ❌ | ❌ | ✅ |

---

## ⚙️ CONFIGURAÇÃO (.env)

```env
# ══════════════════════════════════════════════════════════════
# 🤖 AI PROVIDER CONFIGURATION
# ══════════════════════════════════════════════════════════════

# 0 = Auto (NVIDIA com G4F fallback)
# 1 = NVIDIA apenas
# 2 = G4F apenas
IA_PROVIDER=0

# NVIDIA API Key (obrigatório para provider 0 e 1)
NVIDIA_API_KEY=nvapi-xxxxx

# G4F Space URL (opcional, tem default)
G4F_API_URL=https://g4f.space/api/nvidia/chat/completions
```

---

## 🚀 EXEMPLOS DE USO

### Criar Automação Event-Driven

```json
{
  "type": "criar_event_automation",
  "name": "Anti-Link no #publicidade",
  "trigger": "message_in_channel",
  "triggerConfig": {
    "channelId": "ID_DO_CANAL",
    "ignoreBots": true,
    "filters": { "blockLinks": true }
  },
  "actions": [
    { "type": "delete_message" },
    { "type": "send_dm", "embed": {
      "title": "⚠️ Link Removido!",
      "description": "Links não são permitidos neste canal, amor!",
      "color": "vermelho"
    }}
  ]
}
```

### Verificar Tier via Código

```javascript
import subscriptionManager from './utils/subscriptionManager.js';

// Obter tier do usuário
const tier = subscriptionManager.getUserTier(userId);

// Verificar feature
const hasFeature = subscriptionManager.hasFeature(userId, 'eventAutomations');

// Usar feature (com limite)
const result = await subscriptionManager.useFeature(userId, 'requestsPerDay');
if (!result.success) {
  // Limite atingido
}
```

### Multi-Provider AI

```javascript
import multiProviderAI from './services/multiProviderAI.js';

// Definir tier do usuário
multiProviderAI.setUserTier('premium');

// Fazer requisição
const response = await multiProviderAI.chatCompletion(messages, {
  temperature: 1,
  maxTokens: 8192
});

console.log(response.content);
console.log('Provider:', response.provider); // 'NVIDIA' ou 'G4F'
```

---

## 📁 ESTRUTURA DE ARQUIVOS

```
ZipAr/
├── index.js                          # Entrada principal
├── .env.example                      # Configuração de ambiente
├── Storage/
│   ├── event-automations/           # Automações salvas
│   └── subscriptions/               # Assinaturas salvas
├── src/
│   ├── agents/
│   │   ├── AgentOrchestrator.js     # Orchestrator v3.0
│   │   └── agentWorkflow.js         # Fluxo de trabalho
│   ├── services/
│   │   ├── multiProviderAI.js       # Multi-provider AI
│   │   └── apiService.js            # APIs externas
│   ├── utils/
│   │   ├── subscriptionManager.js   # Sistema de assinaturas
│   │   ├── eventAutomationEngine.js # Motor de automações
│   │   ├── advancedTools.js         # Ferramentas avançadas
│   │   └── promptDefault.js         # Prompt v25.0
│   ├── commands/
│   │   └── automations.js           # Comando /automations
│   └── events/
│       ├── messageCreat.js          # Handler de mensagens
│       ├── automationHandler.js     # Handler de automações
│       └── interactionCreate.js     # Handler de interações
```

---

## 💡 INCREMENTANDO ASSINATURAS

Para converter usuários gratuitos em assinantes:

1. **Delay artificial** - Gratuitos têm 2s de delay (incentiva upgrade)
2. **Limite de features** - Automações avançadas apenas para assinantes
3. **Mensagens de upgrade** - Mostradas quando recurso bloqueado
4. **Provider diferente** - Gratuitos usam G4F (mais lento), assinantes usam NVIDIA
5. **Contexto limitado** - Gratuitos têm histórico de 5 msgs, assinantes até 50
6. **Suporte prioritário** - Canais de suporte exclusivos para assinantes

---

🌹 **RIAS GREMORY X AI - Versão 5.0 TURBINADO**
