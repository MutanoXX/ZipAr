/**
 * MutanoX Architect - Evento MessageCreate
 * Fluxo Otimizado: IA1 (Contexto Full) -> Ferramenta -> IA2 (Contexto Zero/Instruções)
 * 
 * VERSÃO 2.0 - Sistema de permissões por servidor
 */

import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } from 'discord.js';
import OpenAI from 'openai';
import { checkServerPermission } from '../utils/permissions.js';
import { 
  isChannelActive, 
  getChannelContext, 
  addUserMessage,
  addAIMessage
} from '../utils/activeChannels.js';
import apiService from '../services/apiService.js';

const NVIDIA_KEY = process.env.NVIDIA_API_KEY || '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';

// Cliente Step-3.5-Flash
const client = new OpenAI({
  baseURL: 'https://integrate.api.nvidia.com/v1',
  apiKey: NVIDIA_KEY,
});

export const name = 'messageCreate';

export async function execute(message) {
  if (message.author.bot || !message.guild) return;

  const guild = message.guild;
  const channel = message.channel;

  // Verificar se o canal está ativo para este servidor específico
  if (!isChannelActive(guild.id, channel.id)) return;
  
  // Verificar permissão no servidor específico
  const permCheck = checkServerPermission(guild, { id: message.author.id }, message.member);
  
  if (!permCheck.authorized) {
    // Não responder se não tem permissão
    return;
  }

  channel.sendTyping().catch(() => {});

  try {
    let userContent = message.content;

    // Suporte a Arquivos (PDF/Imagens)
    if (message.attachments.size > 0) {
      const attachmentsInfo = [];
      for (const attachment of message.attachments.values()) {
        const isImage = attachment.contentType?.startsWith('image/');
        attachmentsInfo.push(`[ANEXO: ${attachment.name}]\nTipo: ${attachment.contentType}\nURL: ${attachment.url}`);
      }
      userContent += "\n\nANEXOS:\n" + attachmentsInfo.join("\n---\n");
    }

    addUserMessage(channel.id, userContent, message.author.tag);
    const messages = getChannelContext(channel.id);

    // 1. IA1: Step-3.5-Flash com Contexto Completo
    console.log(`🚀 [IA1] Processando mensagem de ${message.author.tag} no servidor ${guild.name}`);
    
    const completion1 = await client.chat.completions.create({
      model: 'stepfun-ai/step-3.5-flash',
      messages: messages,
      temperature: 0.7,
      max_tokens: 4000,
      stream: false
    });

    let content1 = completion1.choices[0]?.message?.content || '';
    let response1 = parseResponse(content1);

    // 2. Verificar Task Complexa ou Ferramenta Externa
    if (response1.type === 'complex_task') {
      await handleComplexTask(message, response1, guild, channel);
    } else if (isExternalTool(response1.type)) {
      const startTime = Date.now();
      console.log(`🛠️ [Ferramenta] Executando ${response1.type}...`);
      
      let toolResult;
      try {
        toolResult = await executeExternalTool(response1, message);
      } catch (err) {
        toolResult = { error: err.message };
      }
      const duration = ((Date.now() - startTime) / 1000).toFixed(2);

      console.log(`✅ [Ferramenta] Concluída em ${duration}s`);

      // 3. IA2: Step-3.5-Flash com Contexto Zero
      const nextSteps = response1.next_steps || "Finalize a resposta para o usuário.";
      
      let imageUrl = null;
      if (response1.type === 'google_image' && toolResult.success && toolResult.data) {
        imageUrl = toolResult.data.url;
      } else if (response1.type === 'dalle_nsfw' && toolResult.success && toolResult.data) {
        imageUrl = toolResult.data.result;
      }

      const completion2 = await client.chat.completions.create({
        model: 'stepfun-ai/step-3.5-flash',
        messages: [
          { 
            role: 'system', 
            content: `Você é o finalizador do MutanoX.
            
Instruções: "${nextSteps}"
Dados: ${JSON.stringify(toolResult)}
Tempo: ${duration}s
${imageUrl ? `URL da Imagem: ${imageUrl}` : ''}

IMPORTANTE:
- Responda SEMPRE em JSON válido.
- Para imagens: {"type":"send_embed","image":"${imageUrl || ''}"}
- Para arquivos: {"type":"send_file","filePath":"...","downloadUrl":"..."}` 
          }
        ],
        temperature: 0.7,
        max_tokens: 1000,
        stream: false
      });

      let content2 = completion2.choices[0]?.message?.content || '';
      let response2 = parseResponse(content2);
      
      addAIMessage(channel.id, content2);
      await executeAction(response2, message, guild, channel);
    } else {
      addAIMessage(channel.id, content1);
      await executeAction(response1, message, guild, channel);
    }

  } catch (error) {
    console.error('❌ [Erro] MessageCreate:', error.message);
    await message.reply({ content: '❌ Ocorreu um erro ao processar sua mensagem.' }).catch(() => {});
  }
}

function isExternalTool(type) {
  return ['consulta_cnpj', 'consulta_cpf', 'cosplay_video', 'google_image', 'server_stats', 'dalle_nsfw', 'generate_file'].includes(type);
}

async function executeExternalTool(action, message) {
  const toolNames = {
    'consulta_cnpj': '🔍 Consultando CNPJ',
    'consulta_cpf': '🔍 Consultando CPF',
    'cosplay_video': '🎬 Buscando Vídeo',
    'google_image': '🖼️ Buscando Imagem',
    'server_stats': '📊 Coletando Estatísticas',
    'dalle_nsfw': '🎨 Gerando Imagem',
    'generate_file': '📄 Gerando Arquivo'
  };
  
  if (toolNames[action.type]) {
    await message.channel.send({ 
      embeds: [createLoadingEmbed(`${toolNames[action.type]}...`)] 
    }).catch(() => {});
  }

  switch (action.type) {
    case 'consulta_cnpj': return await apiService.consultaCNPJ(action.value);
    case 'consulta_cpf': return await apiService.consultaCPF(action.value);
    case 'cosplay_video': return await apiService.getCosplayVideo();
    case 'google_image': return await apiService.searchGoogleImage(action.query);
    case 'server_stats': return await getServerStats(message.guild);
    case 'dalle_nsfw': return await apiService.dalleXlloraText2image(action.prompt, action.negative || 'low quality', action.apikey || 'freeApikey');
    case 'generate_file': return await handleFileGeneration(action);
    default: return { error: 'Ferramenta não reconhecida' };
  }
}

async function handleFileGeneration(action) {
  try {
    let filePath;
    if (action.fileType === 'pdf') {
      filePath = await apiService.generatePDF(action.filename, action.content);
    } else {
      filePath = await apiService.generateTextFile(action.filename, action.content);
    }

    const uploadResult = await apiService.uploadFile(filePath);
    return { 
      success: true, 
      filename: action.filename, 
      downloadUrl: uploadResult.success ? uploadResult.url : null,
      localPath: filePath 
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function getServerStats(guild) {
  try {
    await guild.fetch();
    const categories = guild.channels.cache.filter(c => c.type === 4);
    const textChannels = guild.channels.cache.filter(c => c.type === 0);
    const voiceChannels = guild.channels.cache.filter(c => c.type === 2);
    const roles = guild.roles.cache.filter(r => !r.managed);
    
    return {
      name: guild.name,
      id: guild.id,
      memberCount: guild.memberCount,
      categories: categories.map(c => ({ name: c.name, id: c.id })),
      textChannelsCount: textChannels.size,
      voiceChannelsCount: voiceChannels.size,
      rolesCount: roles.size,
      ownerId: guild.ownerId
    };
  } catch (error) {
    return { error: error.message };
  }
}

function parseResponse(content) {
  try {
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) return JSON.parse(jsonMatch[0]);
  } catch (e) {}
  return { type: 'message', content: content };
}

function createProfessionalEmbed(data, guild) {
  const embed = new EmbedBuilder();
  
  if (data.title) embed.setTitle(data.title);
  if (data.description || data.content) embed.setDescription(data.description || data.content);
  
  let color = data.color || '#8B5CF6';
  const colorMap = {
    'roxo': '#8B5CF6', 'purple': '#8B5CF6',
    'vermelho': '#EF4444', 'red': '#EF4444',
    'verde': '#10B981', 'green': '#10B981',
    'azul': '#3B82F6', 'blue': '#3B82F6',
    'amarelo': '#F59E0B', 'yellow': '#F59E0B',
    'laranja': '#F97316', 'orange': '#F97316',
    'rosa': '#EC4899', 'pink': '#EC4899',
    'dourado': '#FFD700', 'gold': '#FFD700',
    'branco': '#FFFFFF', 'white': '#FFFFFF',
    'preto': '#000000', 'black': '#000000'
  };
  
  if (colorMap[data.color?.toLowerCase()]) {
    color = colorMap[data.color.toLowerCase()];
  }
  embed.setColor(color);
  
  if (data.image) embed.setImage(data.image);
  if (data.thumbnail) embed.setThumbnail(data.thumbnail);
  
  if (data.author || data.authorName) {
    embed.setAuthor({
      name: data.author || data.authorName,
      iconURL: data.authorIcon || (guild?.iconURL ? guild.iconURL() : null),
      url: data.authorUrl
    });
  }
  
  const footerText = data.footer || '💎 MutanoX Architect AI';
  embed.setFooter({ text: footerText });
  embed.setTimestamp();
  
  if (data.fields && Array.isArray(data.fields)) {
    data.fields.forEach(field => {
      embed.addFields({
        name: field.name || 'Campo',
        value: field.value || 'Valor',
        inline: field.inline !== undefined ? field.inline : false
      });
    });
  }
  
  if (data.url) embed.setURL(data.url);
  
  return embed;
}

function createLoadingEmbed(text) {
  return new EmbedBuilder()
    .setDescription(`⏳ ${text}`)
    .setColor('#FBBF24')
    .setTimestamp();
}

async function resolveTargetChannel(guild, targetChannel, currentChannel) {
  if (!targetChannel) return currentChannel;
  
  if (/^\d+$/.test(targetChannel)) {
    const channel = guild.channels.cache.get(targetChannel);
    if (channel) return channel;
  }
  
  const mentionMatch = targetChannel.match(/<#(\d+)>/);
  if (mentionMatch) {
    const channel = guild.channels.cache.get(mentionMatch[1]);
    if (channel) return channel;
  }
  
  const channelByName = guild.channels.cache.find(c => 
    c.name.toLowerCase() === targetChannel.toLowerCase().replace(/[^\w\s]/g, '').trim() ||
    c.name.toLowerCase().includes(targetChannel.toLowerCase().replace(/[^\w\s]/g, '').trim())
  );
  if (channelByName) return channelByName;
  
  return currentChannel;
}

async function executeAction(response, message, guild, channel) {
  if (response.url && (response.url.endsWith('.mp4') || response.type === 'cosplay_video')) {
    return await sendSplitMessage(message, `${response.content || '✨ Aqui está o seu vídeo!'} \n${response.url}`);
  }

  switch (response.type) {
    case 'message':
      await sendSplitMessage(message, response.content);
      break;

    case 'multiple':
      for (const action of response.actions || []) {
        await executeSingleAction(action, guild, channel, message);
        await sleep(300);
      }
      break;

    case 'send_embed':
      await handleSendEmbed(message, response, guild, channel);
      break;

    case 'create_poll':
      await handleCreatePoll(message, response);
      break;

    case 'create_components':
      await handleCreateComponents(message, response);
      break;

    case 'send_file':
      await handleSendFile(message, response);
      break;

    default:
      await executeSingleAction(response, guild, channel, message);
  }
}

async function handleSendEmbed(message, response, guild, currentChannel) {
  try {
    const targetChannel = await resolveTargetChannel(guild, response.targetChannel || response.channel, currentChannel);
    const embed = createProfessionalEmbed(response, guild);
    
    const isDifferentChannel = targetChannel.id !== currentChannel.id;
    
    if (isDifferentChannel) {
      await targetChannel.send({ embeds: [embed] });
      await message.reply({ 
        content: `✅ Embed enviado para ${targetChannel} com sucesso!`,
        allowedMentions: { repliedUser: false }
      });
    } else {
      await message.reply({ embeds: [embed], allowedMentions: { repliedUser: false } });
    }
    
    console.log(`✅ [Embed] Enviado para: ${targetChannel.name}`);
  } catch (error) {
    console.error('❌ [Embed] Erro:', error.message);
    await message.reply(`❌ Erro ao enviar embed: ${error.message}`);
  }
}

async function handleSendFile(message, data) {
  try {
    const options = { content: data.content || 'Aqui está o seu arquivo!' };
    const files = [];

    if (data.filePath) {
      const fs = await import('fs');
      if (fs.default.existsSync(data.filePath)) {
        files.push(data.filePath);
      }
    }
    
    if (data.downloadUrl) {
      options.content += `\n\n📥 **Download:** ${data.downloadUrl}\n*(Expira em 60 minutos)*`;
    }

    if (files.length > 0) {
      options.files = files;
    }

    await message.reply(options);
  } catch (error) {
    console.error('Erro ao enviar arquivo:', error);
    await message.reply(`❌ Erro ao enviar arquivo: ${error.message}`);
  }
}

async function handleCreatePoll(message, data) {
  const embed = createProfessionalEmbed({
    title: `📊 Enquete: ${data.question}`,
    description: data.options.map((opt, i) => `**${i + 1}.** ${opt} (0 votos)`).join('\n'),
    color: '#8B5CF6',
    footer: 'Clique nos botões para votar!'
  }, message.guild);

  const row = new ActionRowBuilder();
  data.options.forEach((opt, i) => {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(`poll_vote_${i}`)
        .setLabel(`${i + 1}`)
        .setStyle(ButtonStyle.Primary)
    );
  });

  const pollMsg = await message.channel.send({ embeds: [embed], components: [row] });
  
  if (!global.activePolls) global.activePolls = {};
  global.activePolls[pollMsg.id] = {
    question: data.question,
    options: data.options,
    votes: data.options.map(() => []),
    creatorId: message.author.id
  };
}

async function handleCreateComponents(message, data) {
  const rows = [];
  let currentRow = new ActionRowBuilder();
  
  for (const comp of data.components) {
    if (comp.type === 'button') {
      if (currentRow.components.length >= 5) {
        rows.push(currentRow);
        currentRow = new ActionRowBuilder();
      }
      currentRow.addComponents(
        new ButtonBuilder()
          .setCustomId(comp.customId || `gen_btn_${Math.random().toString(36).substr(2, 9)}`)
          .setLabel(comp.label)
          .setStyle(ButtonStyle[comp.style] || ButtonStyle.Primary)
      );
    } else if (comp.type === 'select') {
      if (currentRow.components.length > 0) {
        rows.push(currentRow);
        currentRow = new ActionRowBuilder();
      }
      const select = new StringSelectMenuBuilder()
        .setCustomId(comp.customId || `gen_sel_${Math.random().toString(36).substr(2, 9)}`)
        .setPlaceholder(comp.placeholder || 'Selecione')
        .addOptions(comp.options.map(opt => ({
          label: opt.label,
          value: opt.value,
          description: opt.description
        })));
      currentRow.addComponents(select);
      rows.push(currentRow);
      currentRow = new ActionRowBuilder();
    }
  }
  
  if (currentRow.components.length > 0) rows.push(currentRow);

  const msgOptions = { content: data.content };
  if (data.embed) {
    msgOptions.embeds = [createProfessionalEmbed(data.embed, message.guild)];
  }
  msgOptions.components = rows;

  await message.channel.send(msgOptions);
}

async function handleComplexTask(message, data, guild, channel) {
  const totalStartTime = Date.now();
  const steps = data.steps || [];
  const results = [];

  await message.channel.send({
    embeds: [createProfessionalEmbed({
      title: '🧠 Task Complexa Ativada',
      description: `Iniciando **${steps.length} etapas**...`,
      color: '#8B5CF6'
    }, guild)]
  });

  for (let i = 0; i < steps.length; i++) {
    const step = steps[i];
    const stepStartTime = Date.now();
    
    await message.channel.send({
      embeds: [createProfessionalEmbed({
        title: `⚙️ Etapa ${i + 1}/${steps.length}`,
        description: `Executando: **${step.action || step.type}**...`,
        color: '#FBBF24'
      }, guild)]
    });

    let stepResult;
    try {
      if (isExternalTool(step.action || step.type)) {
        stepResult = await executeExternalTool({ type: step.action || step.type, ...step }, message);
      } else {
        stepResult = await executeSingleAction(step, guild, channel, message);
      }
    } catch (err) {
      stepResult = { error: err.message };
    }

    const stepDuration = ((Date.now() - stepStartTime) / 1000).toFixed(2);
    results.push({ step: i + 1, action: step.action || step.type, duration: stepDuration, result: stepResult });

    await message.channel.send({
      embeds: [createProfessionalEmbed({
        title: `✅ Etapa ${i + 1} Concluída`,
        description: `Tempo: **${stepDuration}s**`,
        color: '#10B981'
      }, guild)]
    });
    
    await sleep(500);
  }

  const totalDuration = ((Date.now() - totalStartTime) / 1000).toFixed(2);

  const completion = await client.chat.completions.create({
    model: 'stepfun-ai/step-3.5-flash',
    messages: [
      { 
        role: 'system', 
        content: `Você é o finalizador do MutanoX.
Tempo Total: ${totalDuration}s
Resultados: ${JSON.stringify(results)}

Apresente o resultado final de forma decorada.` 
      }
    ],
    temperature: 0.7
  });

  const finalContent = completion.choices[0]?.message?.content || 'Task Complexa finalizada!';
  const finalResponse = parseResponse(finalContent);
  
  addAIMessage(channel.id, finalContent);
  await executeAction(finalResponse, message, guild, channel);
}

async function sendSplitMessage(message, content) {
  if (!content) return;
  const limit = 1950;
  if (content.length <= limit) {
    return await message.reply({ content, allowedMentions: { repliedUser: false } });
  }

  const chunks = [];
  for (let i = 0; i < content.length; i += limit) {
    chunks.push(content.substring(i, i + limit));
  }

  for (const chunk of chunks) {
    await message.channel.send({ content: chunk });
    await sleep(200);
  }
}

async function executeSingleAction(action, guild, channel, message) {
  try {
    switch (action.type) {
      case 'create_category':
        const category = await guild.channels.create({ name: action.name, type: 4, reason: 'MutanoX Architect' });
        if (action.channels) {
          for (const ch of action.channels) {
            await guild.channels.create({ 
              name: ch.name, 
              type: ch.type || 0, 
              parent: category.id, 
              topic: ch.topic,
              reason: 'MutanoX Architect'
            });
            await sleep(200);
          }
        }
        await message.channel.send(`✅ Categoria "${action.name}" criada!`);
        break;
        
      case 'send_embed':
        await handleSendEmbed(message, action, guild, channel);
        break;
    }
  } catch (error) {
    console.error('Erro na ação:', error);
  }
}

function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

export default { name, execute };
