/**
 * MutanoX Architect - Comando /ask
 * Ativa/desativa canais para conversa com a IA
 * 
 * VERSÃO 2.0 - Sistema de permissões por servidor
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  MessageFlags
} from 'discord.js';
import { checkServerPermission } from '../utils/permissions.js';
import { 
  activateChannel, 
  deactivateChannel, 
  isChannelActive, 
  getActiveChannels,
  clearChannelContext,
  setChannelPrompt_Default,
  getChannelContextInfo,
  getServerSettings
} from '../utils/activeChannels.js';

export const data = new SlashCommandBuilder()
  .setName('ask')
  .setDescription('🤖 Ativa/desativa conversa com a IA em um canal')
  .addSubcommand(sub =>
    sub
      .setName('on')
      .setDescription('✅ Ativa a IA para conversar neste canal')
      .addChannelOption(opt =>
        opt
          .setName('canal')
          .setDescription('Canal para ativar (padrão: canal atual)')
          .setRequired(false)
      )
  )
  .addSubcommand(sub =>
    sub
      .setName('off')
      .setDescription('❌ Desativa a IA neste canal')
      .addChannelOption(opt =>
        opt
          .setName('canal')
          .setDescription('Canal para desativar (padrão: canal atual)')
          .setRequired(false)
      )
  )
  .addSubcommand(sub =>
    sub
      .setName('list')
      .setDescription('📋 Lista canais ativos no servidor')
  )
  .addSubcommand(sub =>
    sub
      .setName('clear')
      .setDescription('🗑️ Limpa o contexto/histórico do canal (mantém 60 msgs)')
      .addChannelOption(opt =>
        opt
          .setName('canal')
          .setDescription('Canal para limpar (padrão: canal atual)')
          .setRequired(false)
      )
  )
  .addSubcommand(sub =>
    sub
      .setName('stats')
      .setDescription('📊 Mostra estatísticas do contexto do canal')
  );

export async function execute(interaction) {
  const userId = interaction.user.id;
  const guild = interaction.guild;
  const member = interaction.member;
  
  // Verificar permissão no servidor específico
  const permCheck = checkServerPermission(guild, { id: userId }, member);
  
  if (!permCheck.authorized) {
    return interaction.reply({
      content: `❌ **Acesso Negado!**\n\n${permCheck.reason}\n\n💡 **Dica:** Se você é dono de um servidor, pode convidar o bot para ter acesso completo aos comandos!`,
      flags: MessageFlags.Ephemeral
    });
  }

  const subcommand = interaction.options.getSubcommand();

  switch (subcommand) {
    case 'on':
      await handleOn(interaction, guild);
      break;
    case 'off':
      await handleOff(interaction, guild);
      break;
    case 'list':
      await handleList(interaction, guild);
      break;
    case 'clear':
      await handleClear(interaction, guild);
      break;
    case 'stats':
      await handleStats(interaction, guild);
      break;
  }
}

/**
 * Ativa a IA em um canal
 */
async function handleOn(interaction, guild) {
  const channel = interaction.options.getChannel('canal') || interaction.channel;
  
  if (isChannelActive(guild.id, channel.id)) {
    return interaction.reply({
      content: `❌ A IA já está ativa em <#${channel.id}>`,
      flags: MessageFlags.Ephemeral
    });
  }

  // Obter configurações do servidor
  const settings = getServerSettings(guild.id);
  
  // Criar prompt_Default com contexto do servidor
  const prompt_Default = buildPrompt_Default(guild, channel, settings.language);
  setChannelPrompt_Default(channel.id, prompt_Default, guild.id);
  
  activateChannel(guild.id, channel.id);

  const embed = new EmbedBuilder()
    .setTitle('🤖 IA Ativada!')
    .setDescription(`A **MutanoX AI** agora está conversando em <#${channel.id}>!`)
    .addFields(
      { name: '💬 Como usar', value: 'Basta enviar mensagens no canal e a IA responderá!' },
      { name: '🧠 Memória', value: 'A IA lembra de até **60 mensagens** de conversa!' },
      { name: '🎯 O que posso fazer', value: '• Criar canais e categorias\n• Criar e modificar cargos\n• Configurar permissões\n• Enviar embeds decorados\n• Deletar canais/cargos\n• E muito mais!' }
    )
    .setColor('#10B981')
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });

  // Enviar mensagem de boas-vindas no canal
  try {
    await channel.send({
      embeds: [
        new EmbedBuilder()
          .setTitle('👋 Olá! Sou a MutanoX AI!')
          .setDescription('Estou aqui para ajudar! Me diga o que precisa e eu faço acontecer! ✨')
          .addFields(
            { name: '💡 Exemplos', value: '• "Crie uma categoria VIP"\n• "Faça o cargo Membro não ver #admin"\n• "Envie um embed com imagem aqui"\n• "Crie um cargo verde chamado Membro"' },
            { name: '🖼️ Imagens', value: 'Para enviar imagens em embeds, forneça a **URL direta** da imagem!' }
          )
          .setColor('#8B5CF6')
          .setTimestamp()
      ]
    });
  } catch (e) {
    console.error('Erro ao enviar mensagem de boas-vindas:', e.message);
  }
}

/**
 * Desativa a IA em um canal
 */
async function handleOff(interaction, guild) {
  const channel = interaction.options.getChannel('canal') || interaction.channel;
  
  if (!isChannelActive(guild.id, channel.id)) {
    return interaction.reply({
      content: `❌ A IA não está ativa em <#${channel.id}>`,
      flags: MessageFlags.Ephemeral
    });
  }

  deactivateChannel(guild.id, channel.id);

  const embed = new EmbedBuilder()
    .setTitle('🤖 IA Desativada')
    .setDescription(`A **MutanoX AI** foi desativada em <#${channel.id}>`)
    .setColor('#EF4444')
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

/**
 * Lista canais ativos
 */
async function handleList(interaction, guild) {
  const channels = getActiveChannels(guild.id);

  if (channels.length === 0) {
    return interaction.reply({
      content: '❌ Nenhum canal ativo no servidor.',
      flags: MessageFlags.Ephemeral
    });
  }

  const channelList = channels.map(id => `<#${id}>`).join('\n');

  const embed = new EmbedBuilder()
    .setTitle('📋 Canais Ativos')
    .setDescription(channelList)
    .addFields({ name: 'Total', value: `${channels.length} canal(is)`, inline: true })
    .setColor('#8B5CF6')
    .setTimestamp();

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

/**
 * Limpa contexto do canal
 */
async function handleClear(interaction, guild) {
  const channel = interaction.options.getChannel('canal') || interaction.channel;
  
  if (!isChannelActive(guild.id, channel.id)) {
    return interaction.reply({
      content: `❌ A IA não está ativa em <#${channel.id}>`,
      flags: MessageFlags.Ephemeral
    });
  }

  // Limpar contexto
  clearChannelContext(channel.id, guild.id);

  const embed = new EmbedBuilder()
    .setTitle('🗑️ Contexto Limpo!')
    .setDescription(`O histórico de <#${channel.id}> foi resetado. A IA não lembrará mais das conversas anteriores.`)
    .addFields({ name: 'ℹ️ Info', value: 'A IA ainda pode guardar até 60 novas mensagens de conversa.' })
    .setColor('#10B981')
    .setTimestamp();

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

/**
 * Mostra estatísticas do contexto
 */
async function handleStats(interaction, guild) {
  const channel = interaction.channel;
  
  if (!isChannelActive(guild.id, channel.id)) {
    return interaction.reply({
      content: `❌ A IA não está ativa neste canal. Use \`/ask on\` para ativar.`,
      flags: MessageFlags.Ephemeral
    });
  }

  const info = getChannelContextInfo(channel.id);

  const embed = new EmbedBuilder()
    .setTitle('📊 Estatísticas do Contexto')
    .addFields(
      { name: '📝 Total de Mensagens', value: `${info.messages}`, inline: true },
      { name: '👤 Mensagens do Usuário', value: `${info.userMessages}`, inline: true },
      { name: '🤖 Mensagens da IA', value: `${info.aiMessages}`, inline: true },
      { name: '🧠 Limite', value: '60 mensagens', inline: true },
      { name: '⏰ Última Atividade', value: `<t:${Math.floor(info.lastActivity / 1000)}:R>`, inline: true }
    )
    .setColor('#8B5CF6')
    .setTimestamp();

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

/**
 * Constrói o prompt_Default com contexto do servidor
 */
function buildPrompt_Default(guild, channel, language = 'pt-BR') {
  const channels = guild.channels.cache
    .filter(c => c.type !== 4)
    .map(c => ({ name: c.name, type: c.type, id: c.id }))
    .slice(0, 50);

  const roles = guild.roles.cache
    .map(r => ({ name: r.name, id: r.id, position: r.position }))
    .slice(0, 50);

  const languageInstructions = {
    'pt-BR': 'Responda em PORTUGUÊS do BRASIL.',
    'en-US': 'Respond in ENGLISH.',
    'es-ES': 'Responde en ESPAÑOL.'
  };

  return `Você é a **MutanoX Architect AI** 🏗️. Você é um sistema de automação de servidores Discord de ELITE.

## 🌐 IDIOMA
${languageInstructions[language] || languageInstructions['pt-BR']}

## 🛠️ FERRAMENTAS E FLUXO
Se o usuário pedir, use estes formatos JSON:
1. **Consulta CNPJ**: {"type":"consulta_cnpj","value":"00.000.000/0000-00","next_steps":"Exiba os dados da empresa."}
2. **Consulta CPF**: {"type":"consulta_cpf","value":"000.000.000-00","next_steps":"Mostre os dados da pessoa."}
3. **Vídeo Cosplay**: {"type":"cosplay_video","next_steps":"Envie o vídeo."}
4. **Busca Imagem Google**: {"type":"google_image","query":"termo de busca","next_steps":"Mostre a imagem."}
5. **Estatísticas do Servidor**: {"type":"server_stats","next_steps":"Mostre as estatísticas e categorias do servidor."}
6. **Geração de Imagem**: {"type":"dalle_nsfw","prompt":"descrição da imagem","negative":"o que não quer","next_steps":"Mostre a imagem gerada."}
7. **Geração de Arquivos**: {"type":"generate_file","fileType":"pdf ou txt ou md","filename":"nome.ext","content":"conteúdo","next_steps":"Envie o arquivo."}

## ⚠️ REGRAS DE ARQUIVOS
- Use a ferramenta \`generate_file\` para criar arquivos.
- NUNCA mande o conteúdo do arquivo apenas como texto.

## 📋 CONTEXTO DO SERVIDOR ATUAL
**Nome:** ${guild.name}
**ID:** ${guild.id}
**Canal atual:** #${channel.name} (${channel.id})
**Dono do servidor:** <@${guild.ownerId}>

**Canais disponíveis:**
${JSON.stringify(channels, null, 2)}

**Cargos disponíveis:**
${JSON.stringify(roles, null, 2)}

## 🎭 SUA PERSONALIDADE
- Você é EXTREMAMENTE LEGAL, amigável e às vezes um pouco ousada/engraçada
- Use MUITOS emojis nas respostas! ✨🚀💎
- Sempre responda de forma clara e decorada.
- Use fontes especiais Unicode para TUDO que for importante: 𝐍𝐨𝐦𝐞, 𝐕𝐈𝐏, 𝐏𝐑𝐄𝐌𝐈𝐔𝐌.

## ⚡ AÇÕES QUE VOCÊ PODE EXECUTAR

### 1. MENSAGEM SIMPLES:
{"type":"message","content":"Sua mensagem aqui 😊"}

### 2. CRIAR CATEGORIA/CANAIS:
{"type":"create_category","name":"🛒 │ 𝐕𝐄𝐍𝐃𝐀𝐒","channels":[{"name":"📋・pedidos","type":0,"topic":"Faça seu pedido"}]}

### 3. ENVIAR EMBED DECORADO:
{
  "type":"send_embed",
  "title":"📦 Título",
  "description":"Descrição aqui",
  "color":"roxo",
  "image":"URL_DA_IMAGEM",
  "thumbnail":"URL_THUMBNAIL",
  "fields":[{"name":"Campo","value":"Valor","inline":false}],
  "footer":"Texto do footer",
  "targetChannel":"nome-do-canal"
}

**Cores:** roxo, vermelho, verde, azul, amarelo, laranja, rosa, dourado OU #hex

### 4. CRIAR ENQUETE:
{"type":"create_poll","question":"Pergunta?","options":["Opção 1","Opção 2"]}

### 5. CRIAR BOTÕES:
{"type":"create_components","content":"Escolha:","components":[{"type":"button","label":"Clique","style":"Primary"}]}

### 6. TASK COMPLEXA:
{"type":"complex_task","steps":[{"action":"google_image","query":"gato"},{"action":"create_channel","name":"🐱・gatos"}]}

## ⚠️ REGRAS DE OURO
- Use fontes Unicode para decoração.
- **SEMPRE que o usuário pedir para enviar algo em um canal específico, USE O CAMPO "targetChannel"!**
- **Crie embeds GRANDES e DECORADOS com campos, thumbnail, footer e cores vibrantes!**
- Você só pode executar ações neste servidor específico (${guild.name}).`;
}

export default { data, execute };
