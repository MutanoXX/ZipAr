/**
 * Rias-Grimory-X - Evento Ready
 * VERSÃO 2.0 - Inicialização de Automações
 * 
 * Executado quando o bot está conectado ao Discord
 * Carrega e inicia todas as automações salvas
 */

import automationManager from '../utils/automationManager.js';

export const name = 'clientReady';
export const once = true;

export async function execute(client) {
  console.log('');
  console.log('╔════════════════════════════════════════════╗');
  console.log('║     💎  RIAS GRIMORY X AI  💎              ║');
  console.log('║        Bot Discord em Node.js              ║');
  console.log('║        Criado por: MutanoX                 ║');
  console.log('╠════════════════════════════════════════════╣');
  console.log(`║  Bot: ${client.user.tag.padEnd(35)}║`);
  console.log(`║  Servidores: ${String(client.guilds.cache.size).padEnd(31)}║`);
  console.log(`║  Usuários: ${String(client.users.cache.size).padEnd(33)}║`);
  console.log('╚════════════════════════════════════════════╝');
  console.log('');

  // Definir status do bot
  client.user.setPresence({
    activities: [
      {
        name: '🌹 Rias Gremory | /ask',
        type: 0 // Watching
      }
    ],
    status: 'online'
  });

  console.log('✅ [Ready] Rias-Grimory-X conectada e pronta!');
  
  // 🤖 Carregar e iniciar automações de todos os servidores
  console.log('🤖 [Automação] Carregando automações salvas...');
  
  let totalAutomations = 0;
  
  for (const guild of client.guilds.cache.values()) {
    try {
      automationManager.startGuildAutomations(guild.id, client);
      
      const stats = automationManager.getAutomationStats(guild.id);
      if (stats.total > 0) {
        totalAutomations += stats.total;
        console.log(`   📁 ${guild.name}: ${stats.total} automação(ões)`);
      }
    } catch (error) {
      console.error(`   ❌ Erro ao carregar automações de ${guild.name}:`, error.message);
    }
  }
  
  if (totalAutomations > 0) {
    console.log(`✅ [Automação] ${totalAutomations} automação(ões) carregada(s) e ativa(s)!`);
  } else {
    console.log('ℹ️ [Automação] Nenhuma automação ativa no momento.');
  }
}

// Exportar client para uso em outros módulos
let botClient = null;
export function getClient() {
  return botClient;
}
export function setClient(client) {
  botClient = client;
}
