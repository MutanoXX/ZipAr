/**
 * MutanoX Architect AI - Bot Discord
 * Ponto de entrada principal
 * 
 * VERSÃO 2.0 - Sistema de permissões por servidor
 * 
 * @description Bot Discord para análise e reestruturação de servidores usando IA
 * @version 2.0.0
 */

import { Client, GatewayIntentBits, Collection, REST, Routes } from 'discord.js';
import { config } from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import aiService from './src/services/aiService.js';
import { initServerConfig, removeServerConfig } from './src/utils/serverPermissions.js';

// Carregar variáveis de ambiente
config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Validar variáveis de ambiente obrigatórias
if (!process.env.DISCORD_TOKEN) {
  console.error('❌ DISCORD_TOKEN não definido nas variáveis de ambiente');
  process.exit(1);
}

if (!process.env.DISCORD_CLIENT_ID) {
  console.error('❌ DISCORD_CLIENT_ID não definido nas variáveis de ambiente');
  process.exit(1);
}

// Criar cliente Discord com todos os intents necessários
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ]
});

// Coleção para comandos
client.commands = new Collection();

// Armazenamento temporário de planos por servidor
global.mutanoxPlans = {};

// Array para armazenar dados dos comandos para registro
const commandsData = [];

/**
 * Carregar comandos dinamicamente
 */
async function loadCommands() {
  const commandsPath = path.join(__dirname, 'src', 'commands');
  const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

  console.log('');
  console.log('📂 Carregando comandos...');

  for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    try {
      const module = await import(filePath);
      const command = module.default || module;
      
      if (command.data && command.execute) {
        client.commands.set(command.data.name, command);
        commandsData.push(command.data.toJSON());
        console.log(`  ✅ /${command.data.name}`);
      } else {
        console.log(`  ⚠️ ${file} - Formato inválido (falta data ou execute)`);
      }
    } catch (error) {
      console.error(`  ❌ Erro ao carregar ${file}:`, error.message);
    }
  }
  
  console.log(`  📊 Total: ${client.commands.size} comandos carregados`);
}

/**
 * Carregar eventos dinamicamente
 */
async function loadEvents() {
  const eventsPath = path.join(__dirname, 'src', 'events');
  const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

  console.log('');
  console.log('🎯 Carregando eventos...');

  for (const file of eventFiles) {
    const filePath = path.join(eventsPath, file);
    try {
      const event = await import(filePath);
      
      if (event.name && event.execute) {
        if (event.once) {
          client.once(event.name, (...args) => event.execute(...args));
        } else {
          client.on(event.name, (...args) => event.execute(...args));
        }
        console.log(`  ✅ ${event.name}`);
      } else {
        console.log(`  ⚠️ ${file} - Formato inválido`);
      }
    } catch (error) {
      console.error(`  ❌ Erro ao carregar ${file}:`, error.message);
    }
  }
}

/**
 * Registrar comandos slash globalmente no Discord
 * 
 * IMPORTANTE: Comandos globais podem demorar até 1 hora para propagar
 * Para desenvolvimento, use DISCORD_GUILD_ID no .env para registro instantâneo
 */
async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

  console.log('');
  console.log('🔌 Registrando comandos slash...');

  try {
    if (process.env.DISCORD_GUILD_ID) {
      // Registro específico para um servidor (instantâneo - desenvolvimento)
      await rest.put(
        Routes.applicationGuildCommands(
          process.env.DISCORD_CLIENT_ID,
          process.env.DISCORD_GUILD_ID
        ),
        { body: commandsData }
      );
      console.log('  ✅ Comandos registrados no servidor de desenvolvimento!');
      console.log('  📍 Servidor ID:', process.env.DISCORD_GUILD_ID);
    } else {
      // Registro GLOBAL (pode demorar até 1 hora para aparecer em todos os servidores)
      await rest.put(
        Routes.applicationCommands(process.env.DISCORD_CLIENT_ID),
        { body: commandsData }
      );
      console.log('  ✅ Comandos registrados GLOBALMENTE!');
      console.log('  ⏳ Nota: Comandos globais podem demorar até 1 hora para propagar');
    }
  } catch (error) {
    console.error('  ❌ Erro ao registrar comandos:', error.message);
  }
}

/**
 * Inicializa configurações de todos os servidores onde o bot está
 */
async function initializeAllServers() {
  console.log('');
  console.log('📋 Inicializando configurações dos servidores...');
  
  let count = 0;
  for (const guild of client.guilds.cache.values()) {
    try {
      initServerConfig(guild);
      count++;
    } catch (error) {
      console.error(`  ❌ Erro ao inicializar ${guild.name}:`, error.message);
    }
  }
  
  console.log(`  ✅ ${count} servidores inicializados`);
}

/**
 * Evento: Bot entrou em um novo servidor
 */
client.on('guildCreate', async (guild) => {
  console.log('');
  console.log('🆕 [GuildCreate] Bot adicionado a um novo servidor!');
  console.log(`  📍 Nome: ${guild.name}`);
  console.log(`  🆔 ID: ${guild.id}`);
  console.log(`  👥 Membros: ${guild.memberCount}`);
  
  // Inicializar configuração do novo servidor
  initServerConfig(guild);
  
  // Tentar enviar mensagem no primeiro canal de texto disponível
  try {
    const channel = guild.channels.cache
      .filter(c => c.type === 0 && c.permissionsFor(guild.members.me).has('SendMessages'))
      .first();
    
    if (channel) {
      const { EmbedBuilder } = await import('discord.js');
      const welcomeEmbed = new EmbedBuilder()
        .setTitle('🏗️ MutanoX Architect AI')
        .setDescription('Olá! Sou o **MutanoX Architect**, uma IA avançada para gerenciar seu servidor Discord!')
        .addFields(
          { name: '🚀 Primeiros Passos', value: '1. Use `/server-config ver` para ver as configurações\n2. Use `/ask on` para ativar a IA em um canal\n3. Use `/help` para ver todas as funcionalidades' },
          { name: '🔐 Permissões', value: '• Apenas **Administradores** e o **Dono do servidor** podem usar a IA\n• O comando `/delete-server` é exclusivo do dono do servidor' },
          { name: '✨ O que posso fazer?', value: '• Criar canais e categorias\n• Gerenciar cargos\n• Enviar embeds decorados\n• Gerar imagens e arquivos\n• E muito mais!' }
        )
        .setColor('#8B5CF6')
        .setThumbnail(client.user.displayAvatarURL())
        .setTimestamp();
      
      await channel.send({ embeds: [welcomeEmbed] });
    }
  } catch (error) {
    console.log(`  ⚠️ Não foi possível enviar mensagem de boas-vindas: ${error.message}`);
  }
});

/**
 * Evento: Bot foi removido de um servidor
 */
client.on('guildDelete', async (guild) => {
  console.log('');
  console.log('👋 [GuildDelete] Bot removido de um servidor');
  console.log(`  📍 Nome: ${guild.name}`);
  console.log(`  🆔 ID: ${guild.id}`);
  
  // Limpar configurações do servidor
  removeServerConfig(guild.id);
});

/**
 * Inicialização do bot
 */
async function start() {
  console.log('');
  console.log('═══════════════════════════════════════════');
  console.log('       🏗️  MUTANOX ARCHITECT AI  🏗️');
  console.log('       Bot Discord - Versão 2.0');
  console.log('       Sistema de Permissões por Servidor');
  console.log('═══════════════════════════════════════════');
  console.log('');

  try {
    // Inicializar serviço de IA
    console.log('🤖 Inicializando serviço de IA...');
    await aiService.initialize();

    // Carregar comandos e eventos
    await loadCommands();
    await loadEvents();

    console.log('');
    console.log('🔌 Conectando ao Discord...');

    // Login no Discord
    await client.login(process.env.DISCORD_TOKEN);

    // Registrar comandos após conectar
    await registerCommands();
    
    // Inicializar configurações de todos os servidores
    await initializeAllServers();

    console.log('');
    console.log('═══════════════════════════════════════════');
    console.log('       ✅ BOT INICIADO COM SUCESSO!');
    console.log(`       📍 ${client.guilds.cache.size} servidores`);
    console.log(`       👥 ${client.users.cache.size} usuários`);
    console.log('═══════════════════════════════════════════');
    console.log('');

  } catch (error) {
    console.error('❌ Erro durante inicialização:', error);
    process.exit(1);
  }
}

// Tratamento de erros não capturados
process.on('unhandledRejection', error => {
  console.error('❌ Promise rejection não tratada:', error);
});

process.on('uncaughtException', error => {
  console.error('❌ Exceção não capturada:', error);
  process.exit(1);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n👋 Encerrando bot...');
  client.destroy();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n👋 Encerrando bot...');
  client.destroy();
  process.exit(0);
});

// Iniciar o bot
start();

export default client;
