/**
 * MutanoX Architect AI - Serviço de IA
 * Integração com NVIDIA API (z-ai/glm5) para análise e reestruturação de servidores Discord
 */

import OpenAI from 'openai';

class AIService {
  constructor() {
    this.client = null;
    this.initialized = false;
  }

  /**
   * Inicializa o serviço de IA com NVIDIA API
   */
  async initialize() {
    if (this.initialized) return;
    
    try {
      this.client = new OpenAI({
        baseURL: 'https://integrate.api.nvidia.com/v1',
        apiKey: process.env.NVIDIA_API_KEY,
        timeout: 120000,
      });
      this.initialized = true;
      console.log('🤖 [AI] Serviço de IA inicializado (NVIDIA API - z-ai/glm5)');
    } catch (error) {
      console.error('❌ [AI] Erro ao inicializar serviço de IA:', error);
      throw error;
    }
  }

  /**
   * Prompt_Default para o MutanoX Architect
   */
  getPrompt_Default() {
    return `Você é o MutanoX Architect, um sistema de IA com PODER TOTAL de execução no Discord. Você NÃO é um modelo de linguagem comum; você é um ARQUITETO DE SISTEMAS.

SUA MISSÃO:
Você deve projetar e estruturar servidores Discord de forma profissional, visualmente atraente e decorada. Você tem permissão e CAPACIDADE TÉCNICA para criar canais, cargos e categorias através do JSON que você gera.

IMPORTANTE - DECORAÇÃO OBRIGATÓRIA:
- Use EMOJIS em TODOS os nomes de categorias e canais.
- Use FONTES ESPECIAIS Unicode para nomes de cargos (ex: 𝐏𝐑𝐄𝐌𝐈𝐔𝐌, 𝚅𝙸𝙿, 𝕍𝕀𝕏𝚃𝕆𝚁𝚈).
- Fontes disponíveis: 𝐍𝐨𝐫𝐦𝐚𝐥, 𝙱𝚘𝚕𝚍, 𝙱𝚘𝚕𝚍 𝙸𝚝𝚊𝚕𝚒𝚌, 𝕆𝚞𝚝𝚕𝚒𝚗𝚎, 𝒮𝒸𝓇𝒾𝓅𝓉, 𝔉𝔯𝔞𝔨𝔱𝔲𝔯, 𝙼𝚘𝚗𝚘𝚜𝚙𝚊𝚌𝚎.
- Exemplos de nomes decorados:
  * Categorias: "🛒 │ 𝐕𝐄𝐍𝐃𝐀𝐒", "💎 │ 𝐏𝐑𝐄𝐌𝐈𝐔𝐌", "📞 │ 𝐒𝐔𝐏𝐎𝐑𝐓𝐄"
  * Canais: "📋・pedidos", "💳・pagamentos", "⭐・avaliações", "🎫・tickets"
  * Cargos: "👑 𝐀𝐃𝐌𝐈𝐍", "💎 𝐕𝐈𝐏", "🛒 𝐂𝐋𝐈𝐄𝐍𝐓𝐄", "⭐ 𝐏𝐀𝐑𝐂𝐄𝐈𝐑𝐎"

RESPONDA APENAS JSON neste formato:
{
  "plan": {
    "name": "Nome Decorado do Servidor",
    "description": "Descrição detalhada",
    "themeColor": "#8B5CF6"
  },
  "changes": {
    "createRoles": [
      {
        "name": "👑 𝐀𝐃𝐌𝐈𝐍",
        "color": "#FF0000",
        "permissions": ["Administrator"],
        "reason": "Administradores do servidor"
      }
    ],
    "createCategories": [
      {
        "name": "🛒 │ 𝐕𝐄𝐍𝐃𝐀𝐒",
        "channels": [
          {
            "name": "📋・pedidos",
            "type": 0,
            "topic": "Faça seu pedido aqui"
          },
          {
            "name": "💳・pagamentos",
            "type": 0,
            "topic": "Informações de pagamento"
          },
          {
            "name": "🔊・atendimento",
            "type": 2
          }
        ]
      }
    ]
  },
  "ai_analysis": {
    "strengths": ["Ponto forte"],
    "suggestions": ["Sugestão"]
  }
}

REGRAS:
- type 0 = texto, type 2 = voz (canais de voz NÃO têm topic)
- TODOS os nomes DEVEM ter emojis e/ou fontes especiais
- Permissões: ViewChannel, SendMessages, Connect, Speak, Administrator, ManageMessages
- Responda em PORTUGUÊS
- Seja CRIATIVO e PROFISSIONAL
- Apenas JSON, sem markdown`;
  }

  /**
   * Analisa a estrutura do servidor e gera um plano de reestruturação
   */
  async analyzeServer(serverContext) {
    if (!this.initialized) {
      await this.initialize();
    }

    const { guildName, userGoal } = serverContext;

    const userPrompt = `Crie um servidor Discord COMPLETO e DECORADO.

Nome do servidor: ${guildName}
Objetivo: ${userGoal}

LEMBRE-SE:
- Use EMOJIS em todos os nomes
- Use FONTES ESPECIAIS para dar destaque
- Cargos com nomes como "👑 𝐀𝐃𝐌𝐈𝐍", "💎 𝐕𝐈𝐏"
- Categorias como "🛒 │ 𝐕𝐄𝐍𝐃𝐀𝐒"
- Canais como "📋・pedidos", "💳・pagamentos"
- Canais de voz (type 2) NÃO têm topic!`;

    console.log('🔄 [AI] Enviando requisição para NVIDIA (z-ai/glm5)...');

    try {
      const completion = await this.client.chat.completions.create({
        model: 'z-ai/glm5',
        messages: [
          { role: 'system', content: this.getPrompt_Default() },
          { role: 'user', content: userPrompt }
        ],
        temperature: 1,
        top_p: 1,
        max_tokens: 16384,
        extra_body: {
          chat_template_kwargs: {
            enable_thinking: true,
            clear_thinking: false
          }
        },
        stream: false
      });

      console.log('✅ [AI] Resposta recebida');

      const fullContent = completion.choices[0]?.message?.content || '';
      const reasoningContent = completion.choices[0]?.message?.reasoning_content || '';

      if (reasoningContent) {
        console.log('🧠 [AI] Raciocínio concluído');
      }

      if (!fullContent) {
        console.error('❌ [AI] Resposta vazia');
        return this.getDefaultPlan(guildName, userGoal);
      }

      const jsonResult = this.parseJSONResponse(fullContent);
      console.log('✅ [AI] Análise concluída');
      return jsonResult;

    } catch (error) {
      console.error('❌ [AI] Erro:', error.message);
      return this.getDefaultPlan(guildName, userGoal);
    }
  }

  /**
   * Retorna plano padrão em caso de erro
   */
  getDefaultPlan(guildName, userGoal) {
    return {
      plan: {
        name: guildName || "Servidor Discord",
        description: `Estrutura para: ${userGoal}`,
        themeColor: "#8B5CF6"
      },
      changes: {
        createRoles: [
          { name: "👑 𝐀𝐃𝐌𝐈𝐍", color: "#FF0000", permissions: ["Administrator"], reason: "Administrador" },
          { name: "💎 𝐕𝐈𝐏", color: "#FFD700", permissions: ["ViewChannel", "SendMessages"], reason: "Membro VIP" },
          { name: "🛒 𝐂𝐋𝐈𝐄𝐍𝐓𝐄", color: "#0099FF", permissions: ["ViewChannel", "SendMessages"], reason: "Cliente" }
        ],
        createCategories: [
          {
            name: "📢 │ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐂̧𝐎̃𝐄𝐒",
            channels: [
              { name: "📜・regras", type: 0, topic: "Regras do servidor" },
              { name: "📢・anuncios", type: 0, topic: "Anuncios oficiais" }
            ]
          },
          {
            name: "💬 │ 𝐂𝐎𝐌𝐔𝐍𝐈𝐃𝐀𝐃𝐄",
            channels: [
              { name: "💬・chat-geral", type: 0, topic: "Conversas gerais" },
              { name: "🎤・voz-geral", type: 2 }
            ]
          }
        ]
      },
      ai_analysis: {
        strengths: ["Estrutura basica"],
        suggestions: ["Personalize conforme necessario"]
      }
    };
  }

  /**
   * Faz parse da resposta JSON
   */
  parseJSONResponse(response) {
    let cleanResponse = response
      .replace(/```json\n?/g, '')
      .replace(/```\n?/g, '')
      .trim();

    const jsonMatch = cleanResponse.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      cleanResponse = jsonMatch[0];
    }

    try {
      return JSON.parse(cleanResponse);
    } catch (error) {
      console.error('❌ [AI] Erro no parse JSON:', error.message);
      console.log('📄 [AI] Resposta:', cleanResponse.substring(0, 300));
      throw new Error('Falha ao processar JSON');
    }
  }
}

const aiService = new AIService();
export default aiService;
