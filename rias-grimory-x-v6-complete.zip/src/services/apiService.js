import fetch from 'node-fetch';
import FormData from 'form-data';
import fs from 'fs';
import path from 'path';
import { PDFDocument, rgb } from 'pdf-lib';
import { getSecureFilePath, initCache } from '../utils/cacheManager.js';

/**
 * MutanoX API Service - VERSÃO 3.0
 * APIs testadas e funcionando
 */
class APIService {
  constructor() {
    this.timeout = 20000;
    initCache();
  }

  async fetchWithTimeout(url, options = {}, timeout = this.timeout) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);
    
    try {
      const response = await fetch(url, { ...options, signal: controller.signal });
      clearTimeout(timeoutId);
      return response;
    } catch (error) {
      clearTimeout(timeoutId);
      if (error.name === 'AbortError') {
        throw new Error('Timeout: API demorou muito');
      }
      throw error;
    }
  }

  /**
   * Consulta CNPJ
   * API: https://mutano-x-v2.discloud.app/api/consultas?type=cnpj&value={cnpj}
   */
  async consultaCNPJ(cnpj) {
    console.log(`🔍 [CNPJ] Consultando: ${cnpj}`);
    try {
      const cnpjLimpo = cnpj.replace(/\D/g, '');
      const response = await this.fetchWithTimeout(
        `https://mutano-x-v2.discloud.app/api/consultas?type=cnpj&value=${cnpjLimpo}`
      );
      const data = await response.json();
      console.log(`✅ [CNPJ] Resposta completa:`, JSON.stringify(data, null, 2).substring(0, 500));
      return data;
    } catch (error) {
      console.error('❌ [CNPJ]:', error.message);
      return { status: 'error', error: error.message };
    }
  }

  /**
   * Consulta CPF
   * API: https://mutano-x-v2.discloud.app/api/consultas?type=cpf&value={cpf}&base=credlink
   */
  async consultaCPF(cpf) {
    console.log(`🔍 [CPF] Consultando: ${cpf}`);
    try {
      const cpfLimpo = cpf.replace(/\D/g, '');
      const response = await this.fetchWithTimeout(
        `https://mutano-x-v2.discloud.app/api/consultas?type=cpf&value=${cpfLimpo}&base=credlink`
      );
      const data = await response.json();
      console.log(`✅ [CPF] Resposta completa:`, JSON.stringify(data, null, 2).substring(0, 500));
      return data;
    } catch (error) {
      console.error('❌ [CPF]:', error.message);
      return { status: 'error', error: error.message };
    }
  }

  /**
   * Buscar Imagens Google
   * API: https://anabot.my.id/api/search/gimage?query={query}&apikey=freeApikey
   */
  async searchGoogleImage(query) {
    console.log(`🖼️ [Imagem] Buscando: ${query}`);
    try {
      const response = await this.fetchWithTimeout(
        `https://anabot.my.id/api/search/gimage?query=${encodeURIComponent(query)}&apikey=freeApikey`,
        {}, 25000
      );
      const data = await response.json();
      
      if (data.success && data.data?.result?.length > 0) {
        console.log(`✅ [Imagem] ${data.data.result.length} imagens encontradas`);
        return { success: true, data: data.data };
      }
      
      return { success: false, error: 'Nenhuma imagem encontrada' };
    } catch (error) {
      console.error('❌ [Imagem]:', error.message);
      return { success: false, error: error.message };
    }
  }

  /**
   * Vídeo Cosplay Anime
   * API: https://iyusztempest.my.id/api/anime?feature=jjcosplay
   */
  async getCosplayVideo() {
    console.log(`🎬 [Cosplay] Buscando vídeo...`);
    try {
      const response = await this.fetchWithTimeout(
        'https://iyusztempest.my.id/api/anime?feature=jjcosplay',
        {}, 25000
      );
      const data = await response.json();
      
      if (data.status === 'success' && data.media?.url) {
        console.log(`✅ [Cosplay] Vídeo encontrado`);
        return data;
      }
      
      return { status: 'error', error: 'Vídeo não encontrado' };
    } catch (error) {
      console.error('❌ [Cosplay]:', error.message);
      return { status: 'error', error: error.message };
    }
  }

  /**
   * Dalle Image Generation
   * API: https://anabot.my.id/api/ai/dalle3
   */
  async dalleXlloraText2image(prompt, negative = 'low quality', apikey = 'freeApikey') {
    console.log(`🎨 [Dalle] Gerando: ${prompt?.substring(0, 30)}...`);
    try {
      const response = await this.fetchWithTimeout(
        `https://anabot.my.id/api/ai/dalle3?prompt=${encodeURIComponent(prompt)}&negative=${encodeURIComponent(negative)}&apikey=${apikey}`,
        {}, 60000
      );
      const data = await response.json();
      
      if (data.success !== false && (data.result || data.data?.result)) {
        console.log(`✅ [Dalle] Imagem gerada`);
        return { success: true, data: { result: data.result || data.data?.result } };
      }
      
      return { success: false, error: data.error || 'Falha na geração' };
    } catch (error) {
      console.error('❌ [Dalle]:', error.message);
      return { success: false, error: error.message };
    }
  }

  /**
   * Upload arquivo para tmpfiles.org
   */
  async uploadFile(filePath) {
    console.log(`📤 [Upload] Enviando...`);
    try {
      if (!fs.existsSync(filePath)) {
        return { success: false, error: 'Arquivo não encontrado' };
      }

      const form = new FormData();
      form.append('file', fs.createReadStream(filePath));

      const response = await this.fetchWithTimeout('https://tmpfiles.org/api/v1/upload', {
        method: 'POST',
        body: form,
        headers: form.getHeaders(),
      }, 30000);

      const data = await response.json();
      if (data.status === 'success') {
        const downloadUrl = data.data.url.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
        console.log(`✅ [Upload] ${downloadUrl}`);
        return { success: true, url: downloadUrl };
      }
      
      return { success: false, error: data.message || 'Falha no upload' };
    } catch (error) {
      console.error('❌ [Upload]:', error.message);
      return { success: false, error: error.message };
    }
  }

  /**
   * Gerar PDF
   */
  async generatePDF(filename, content) {
    console.log(`📄 [PDF] Gerando: ${filename}`);
    try {
      initCache();
      
      const pdfDoc = await PDFDocument.create();
      let page = pdfDoc.addPage();
      const { width, height } = page.getSize();
      const fontSize = 11;
      const margin = 50;
      
      const lines = content.split('\n');
      let y = height - margin;

      for (const line of lines) {
        if (y < margin + fontSize) {
          page = pdfDoc.addPage();
          y = height - margin;
        }
        
        const safeLine = line.substring(0, 100);
        page.drawText(safeLine, { x: margin, y, size: fontSize, color: rgb(0, 0, 0) });
        y -= fontSize + 4;
      }

      const pdfBytes = await pdfDoc.save();
      const safeFilename = filename.endsWith('.pdf') ? filename : `${filename}.pdf`;
      const filePath = getSecureFilePath(safeFilename);
      
      fs.writeFileSync(filePath, pdfBytes);
      console.log(`✅ [PDF] Criado: ${filePath}`);
      return filePath;
      
    } catch (error) {
      console.error('❌ [PDF]:', error.message);
      
      try {
        const fallbackPath = path.join('/tmp', filename.endsWith('.pdf') ? filename : `${filename}.pdf`);
        const pdfDoc = await PDFDocument.create();
        const page = pdfDoc.addPage();
        page.drawText(content.substring(0, 2000), { x: 50, y: 750, size: 10, color: rgb(0, 0, 0) });
        fs.writeFileSync(fallbackPath, await pdfDoc.save());
        return fallbackPath;
      } catch (e) {
        throw new Error(`Falha ao criar PDF: ${error.message}`);
      }
    }
  }

  /**
   * Gerar arquivo de texto
   */
  async generateTextFile(filename, content) {
    console.log(`📝 [Arquivo] Gerando: ${filename}`);
    try {
      initCache();
      const filePath = getSecureFilePath(filename);
      fs.writeFileSync(filePath, content);
      console.log(`✅ [Arquivo] Criado: ${filePath}`);
      return filePath;
    } catch (error) {
      const fallbackPath = path.join('/tmp', filename);
      fs.writeFileSync(fallbackPath, content);
      return fallbackPath;
    }
  }
}

export default new APIService();
