/**
 * MutanoX Architect - Gerenciador de Canais Ativos
 * Controla quais canais a IA está monitorando para conversa
 * 
 * VERSÃO 2.0 - Contexto isolado por servidor
 * Cada servidor tem seu próprio contexto de IA
 */

// Canais ativos por servidor: { guildId: Set<channelId> }
const activeChannels = new Map();

// Contexto de conversa por canal: { channelId: { messages: [], lastActivity: timestamp, prompt_Default: string, guildId: string } }
const channelContexts = new Map();

// Configurações por servidor: { guildId: { settings: {} } }
const serverSettings = new Map();

// Limite de mensagens no contexto (60 mensagens)
const MAX_CONTEXT_MESSAGES = 60;

// Tempo de expiração do contexto (2 horas)
const CONTEXT_EXPIRE = 2 * 60 * 60 * 1000;

/**
 * Ativa um canal para conversa com a IA
 * @param {string} guildId - ID do servidor
 * @param {string} channelId - ID do canal
 * @returns {boolean}
 */
export function activateChannel(guildId, channelId) {
  if (!activeChannels.has(guildId)) {
    activeChannels.set(guildId, new Set());
  }
  
  const guildChannels = activeChannels.get(guildId);
  
  if (guildChannels.has(channelId)) {
    return false;
  }
  
  guildChannels.add(channelId);
  
  // Inicializar contexto do canal se não existir
  if (!channelContexts.has(channelId)) {
    channelContexts.set(channelId, {
      messages: [],
      lastActivity: Date.now(),
      guildId: guildId,
      prompt_Default: null
    });
  }
  
  console.log(`✅ [ActiveChannels] Canal ${channelId} ativado no servidor ${guildId}`);
  return true;
}

/**
 * Desativa um canal
 * @param {string} guildId - ID do servidor
 * @param {string} channelId - ID do canal
 * @returns {boolean}
 */
export function deactivateChannel(guildId, channelId) {
  const guildChannels = activeChannels.get(guildId);
  
  if (!guildChannels || !guildChannels.has(channelId)) {
    return false;
  }
  
  guildChannels.delete(channelId);
  channelContexts.delete(channelId);
  
  if (guildChannels.size === 0) {
    activeChannels.delete(guildId);
  }
  
  console.log(`❌ [ActiveChannels] Canal ${channelId} desativado no servidor ${guildId}`);
  return true;
}

/**
 * Verifica se um canal está ativo
 * @param {string} guildId - ID do servidor
 * @param {string} channelId - ID do canal
 * @returns {boolean}
 */
export function isChannelActive(guildId, channelId) {
  const guildChannels = activeChannels.get(guildId);
  return guildChannels ? guildChannels.has(channelId) : false;
}

/**
 * Obtém canais ativos de um servidor
 * @param {string} guildId - ID do servidor
 * @returns {string[]}
 */
export function getActiveChannels(guildId) {
  const guildChannels = activeChannels.get(guildId);
  return guildChannels ? Array.from(guildChannels) : [];
}

/**
 * Obtém todos os canais ativos de todos os servidores
 * @returns {Map}
 */
export function getAllActiveChannels() {
  return activeChannels;
}

/**
 * Adiciona mensagem do USUÁRIO ao contexto
 * @param {string} channelId - ID do canal
 * @param {string} content - Conteúdo da mensagem
 * @param {string} author - Nome do autor
 */
export function addUserMessage(channelId, content, author) {
  let context = channelContexts.get(channelId);
  
  if (!context) {
    context = { messages: [], lastActivity: Date.now(), prompt_Default: null, guildId: null };
    channelContexts.set(channelId, context);
  }
  
  context.messages.push({
    role: 'user',
    content: content,
    author: author,
    timestamp: Date.now()
  });
  
  context.lastActivity = Date.now();
  trimContext(context);
}

/**
 * Adiciona mensagem da IA ao contexto
 * @param {string} channelId - ID do canal
 * @param {string} content - Conteúdo da mensagem
 */
export function addAIMessage(channelId, content) {
  let context = channelContexts.get(channelId);
  
  if (!context) {
    context = { messages: [], lastActivity: Date.now(), prompt_Default: null, guildId: null };
    channelContexts.set(channelId, context);
  }
  
  context.messages.push({
    role: 'assistant',
    content: content,
    timestamp: Date.now()
  });
  
  context.lastActivity = Date.now();
  trimContext(context);
}

/**
 * Limita o contexto mantendo mensagens recentes
 * @param {Object} context - Contexto do canal
 */
function trimContext(context) {
  if (context.messages.length > MAX_CONTEXT_MESSAGES) {
    context.messages = context.messages.slice(-MAX_CONTEXT_MESSAGES);
  }
}

/**
 * Obtém contexto do canal formatado para a API
 * @param {string} channelId - ID do canal
 * @returns {Array}
 */
export function getChannelContext(channelId) {
  const context = channelContexts.get(channelId);
  
  if (!context) {
    return [];
  }
  
  // Verificar expiração
  if (Date.now() - context.lastActivity > CONTEXT_EXPIRE) {
    channelContexts.delete(channelId);
    return [];
  }
  
  // Formatar histórico de mensagens
  const history = context.messages.map(m => ({
    role: m.role,
    content: m.content
  }));

  // Construir a lista final: [System Prompt, ...Histórico]
  const result = [];
  
  if (context.prompt_Default) {
    result.push({ role: 'system', content: context.prompt_Default });
  } else {
    console.error(`⚠️ [Context] Canal ${channelId} sem prompt_Default!`);
  }
  
  return [...result, ...history];
}

/**
 * Limpa contexto de um canal
 * @param {string} channelId - ID do canal
 * @param {string} guildId - ID do servidor (opcional)
 */
export function clearChannelContext(channelId, guildId) {
  const context = channelContexts.get(channelId);
  if (context) {
    context.messages = [];
    context.lastActivity = Date.now();
  }
}

/**
 * Define prompt_Default do canal
 * @param {string} channelId - ID do canal
 * @param {string} prompt_Default - Prompt do sistema
 * @param {string} guildId - ID do servidor
 */
export function setChannelPrompt_Default(channelId, prompt_Default, guildId) {
  let context = channelContexts.get(channelId);
  if (!context) {
    context = { messages: [], guildId: guildId };
    channelContexts.set(channelId, context);
  }
  context.prompt_Default = prompt_Default;
  context.guildId = guildId;
  context.lastActivity = Date.now();
}

/**
 * Obtém info do contexto
 * @param {string} channelId - ID do canal
 * @returns {Object}
 */
export function getChannelContextInfo(channelId) {
  const context = channelContexts.get(channelId);
  
  if (!context) {
    return { exists: false, messages: 0, userMessages: 0, aiMessages: 0 };
  }
  
  const userMessages = context.messages.filter(m => m.role === 'user').length;
  const aiMessages = context.messages.filter(m => m.role === 'assistant').length;
  
  return {
    exists: true,
    messages: context.messages.length,
    userMessages: userMessages,
    aiMessages: aiMessages,
    lastActivity: context.lastActivity,
    guildId: context.guildId,
    hasPrompt: !!context.prompt_Default
  };
}

/**
 * Limpa todos os canais e contextos de um servidor
 * @param {string} guildId - ID do servidor
 */
export function clearServerContexts(guildId) {
  const guildChannels = activeChannels.get(guildId);
  
  if (guildChannels) {
    for (const channelId of guildChannels) {
      channelContexts.delete(channelId);
    }
    activeChannels.delete(guildId);
  }
  
  console.log(`🧹 [ActiveChannels] Contextos limpos para servidor ${guildId}`);
}

/**
 * Obtém estatísticas gerais
 * @returns {Object}
 */
export function getStats() {
  let totalChannels = 0;
  let totalMessages = 0;
  
  for (const [guildId, channels] of activeChannels) {
    totalChannels += channels.size;
  }
  
  for (const [channelId, context] of channelContexts) {
    totalMessages += context.messages.length;
  }
  
  return {
    totalServers: activeChannels.size,
    totalChannels: totalChannels,
    totalMessages: totalMessages,
    contextLimit: MAX_CONTEXT_MESSAGES,
    contextExpire: CONTEXT_EXPIRE
  };
}

/**
 * Define configurações específicas do servidor
 * @param {string} guildId - ID do servidor
 * @param {Object} settings - Configurações
 */
export function setServerSettings(guildId, settings) {
  serverSettings.set(guildId, {
    ...serverSettings.get(guildId),
    ...settings,
    updatedAt: Date.now()
  });
}

/**
 * Obtém configurações do servidor
 * @param {string} guildId - ID do servidor
 * @returns {Object}
 */
export function getServerSettings(guildId) {
  return serverSettings.get(guildId) || {
    language: 'pt-BR',
    theme: 'default',
    autoActivate: false
  };
}

export default {
  activateChannel,
  deactivateChannel,
  isChannelActive,
  getActiveChannels,
  getAllActiveChannels,
  addUserMessage,
  addAIMessage,
  getChannelContext,
  clearChannelContext,
  setChannelPrompt_Default,
  getChannelContextInfo,
  clearServerContexts,
  getStats,
  setServerSettings,
  getServerSettings
};
