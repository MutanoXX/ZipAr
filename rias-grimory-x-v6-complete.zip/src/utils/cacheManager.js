/**
 * MutanoX Architect - Gerenciador de Cache Seguro
 * Resolve problemas de permissão EACCES ao criar/acessar diretórios de cache
 * 
 * PROBLEMA RESOLVIDO:
 * - RateLimit persist: EACCES: permission denied, open '.cache/ratelimits.json'
 * - EACCES: permission denied, mkdir '.cache/files'
 * 
 * SOLUÇÃO:
 * - Usa diretório temporário do sistema (/tmp) como fallback
 * - Cria diretórios de forma segura com tratamento de erros
 * - Fornece caminhos absolutos para evitar problemas de permissão
 */

import fs from 'fs';
import path from 'path';
import os from 'os';

// Diretório base para cache (usar /tmp ou diretório temporário do sistema)
const CACHE_BASE_DIR = process.env.CACHE_DIR || path.join(os.tmpdir(), 'mutanox-cache');
const FILES_DIR = path.join(CACHE_BASE_DIR, 'files');
const RATELIMIT_FILE = path.join(CACHE_BASE_DIR, 'ratelimits.json');

// Flag para verificar se o cache foi inicializado
let cacheInitialized = false;

/**
 * Inicializa o sistema de cache de forma segura
 * Cria os diretórios necessários com tratamento de erros
 */
export function initCache() {
  if (cacheInitialized) return true;

  try {
    // Criar diretório base de cache
    if (!fs.existsSync(CACHE_BASE_DIR)) {
      fs.mkdirSync(CACHE_BASE_DIR, { recursive: true, mode: 0o755 });
      console.log(`✅ [CacheManager] Diretório de cache criado: ${CACHE_BASE_DIR}`);
    }

    // Criar diretório de arquivos
    if (!fs.existsSync(FILES_DIR)) {
      fs.mkdirSync(FILES_DIR, { recursive: true, mode: 0o755 });
      console.log(`✅ [CacheManager] Diretório de arquivos criado: ${FILES_DIR}`);
    }

    cacheInitialized = true;
    return true;

  } catch (error) {
    console.error(`❌ [CacheManager] Erro ao inicializar cache: ${error.message}`);
    
    // Tentar usar diretório temporário alternativo
    try {
      const altDir = path.join(os.tmpdir(), `mutanox-${Date.now()}`);
      fs.mkdirSync(altDir, { recursive: true, mode: 0o755 });
      fs.mkdirSync(path.join(altDir, 'files'), { recursive: true, mode: 0o755 });
      
      // Atualizar caminhos globais
      global.MUTANOX_CACHE_DIR = altDir;
      global.MUTANOX_FILES_DIR = path.join(altDir, 'files');
      
      cacheInitialized = true;
      console.log(`✅ [CacheManager] Usando cache alternativo: ${altDir}`);
      return true;
      
    } catch (altError) {
      console.error(`❌ [CacheManager] Erro crítico no cache alternativo: ${altError.message}`);
      return false;
    }
  }
}

/**
 * Obtém o caminho do diretório de arquivos
 * @returns {string} Caminho absoluto para o diretório de arquivos
 */
export function getFilesDir() {
  if (!cacheInitialized) initCache();
  return global.MUTANOX_FILES_DIR || FILES_DIR;
}

/**
 * Obtém o caminho do arquivo de rate limits
 * @returns {string} Caminho absoluto para o arquivo de rate limits
 */
export function getRatelimitFile() {
  if (!cacheInitialized) initCache();
  return global.MUTANOX_RATELIMIT_FILE || RATELIMIT_FILE;
}

/**
 * Obtém o caminho base do cache
 * @returns {string} Caminho absoluto para o diretório de cache
 */
export function getCacheDir() {
  if (!cacheInitialized) initCache();
  return global.MUTANOX_CACHE_DIR || CACHE_BASE_DIR;
}

/**
 * Gera um caminho de arquivo seguro para criação de arquivos
 * @param {string} filename - Nome do arquivo
 * @returns {string} Caminho absoluto seguro para o arquivo
 */
export function getSecureFilePath(filename) {
  if (!cacheInitialized) initCache();
  
  // Sanitizar nome do arquivo
  const safeName = filename
    .replace(/[<>:"/\\|?*]/g, '_')
    .replace(/\.\./g, '')
    .substring(0, 200);
  
  const filesDir = global.MUTANOX_FILES_DIR || FILES_DIR;
  return path.join(filesDir, safeName);
}

/**
 * Salva dados de rate limit de forma segura
 * @param {Object} data - Dados de rate limit
 * @returns {boolean} Sucesso da operação
 */
export function saveRatelimitData(data) {
  try {
    if (!cacheInitialized) initCache();
    
    const filePath = global.MUTANOX_RATELIMIT_FILE || RATELIMIT_FILE;
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error(`❌ [CacheManager] Erro ao salvar rate limits: ${error.message}`);
    return false;
  }
}

/**
 * Carrega dados de rate limit
 * @returns {Object|null} Dados de rate limit ou null se não existir
 */
export function loadRatelimitData() {
  try {
    if (!cacheInitialized) initCache();
    
    const filePath = global.MUTANOX_RATELIMIT_FILE || RATELIMIT_FILE;
    
    if (!fs.existsSync(filePath)) {
      return null;
    }
    
    const data = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`❌ [CacheManager] Erro ao carregar rate limits: ${error.message}`);
    return null;
  }
}

/**
 * Limpa arquivos antigos do cache
 * @param {number} maxAgeMs - Idade máxima em milissegundos (padrão: 1 hora)
 */
export function cleanOldFiles(maxAgeMs = 3600000) {
  try {
    if (!cacheInitialized) initCache();
    
    const filesDir = global.MUTANOX_FILES_DIR || FILES_DIR;
    const files = fs.readdirSync(filesDir);
    const now = Date.now();
    let cleaned = 0;
    
    for (const file of files) {
      const filePath = path.join(filesDir, file);
      try {
        const stats = fs.statSync(filePath);
        if (now - stats.mtimeMs > maxAgeMs) {
          fs.unlinkSync(filePath);
          cleaned++;
        }
      } catch (e) {
        // Ignorar erros de arquivos individuais
      }
    }
    
    if (cleaned > 0) {
      console.log(`🧹 [CacheManager] Limpos ${cleaned} arquivos antigos`);
    }
  } catch (error) {
    console.error(`❌ [CacheManager] Erro ao limpar cache: ${error.message}`);
  }
}

/**
 * Verifica se o sistema de cache está funcionando
 * @returns {boolean} Status do cache
 */
export function isCacheWorking() {
  try {
    if (!cacheInitialized) initCache();
    
    const testFile = path.join(global.MUTANOX_FILES_DIR || FILES_DIR, '.test');
    fs.writeFileSync(testFile, 'test');
    fs.unlinkSync(testFile);
    return true;
  } catch (error) {
    return false;
  }
}

// Inicializar cache ao carregar o módulo
initCache();

export default {
  initCache,
  getFilesDir,
  getRatelimitFile,
  getCacheDir,
  getSecureFilePath,
  saveRatelimitData,
  loadRatelimitData,
  cleanOldFiles,
  isCacheWorking
};
