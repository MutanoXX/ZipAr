/**
 * Rias-Grimory-X - Sistema de Imagens da Rias
 * Busca imagens da personagem Rias Gremory para usar nos embeds
 * 
 * A IA busca imagens baseada no "estado emocional" da resposta
 */

import apiService from '../services/apiService.js';

// Estados emocionais da Rias e termos de busca correspondentes
const RIAS_EMOTIONS = {
  // Estados positivos
  feliz: ['Rias Gremory happy smile', 'Rias Gremory smiling', 'Rias Gremory joy'],
  animada: ['Rias Gremory excited', 'Rias Gremory cheerful', 'Rias Gremory enthusiastic'],
  amor: ['Rias Gremory love heart', 'Rias Gremory affectionate', 'Rias Gremory blushing'],
  orgulhosa: ['Rias Gremory proud', 'Rias Gremory confident', 'Rias Gremory elegant'],
  surpresa: ['Rias Gremory surprised', 'Rias Gremory shocked', 'Rias Gremory amazed'],
  
  // Estados neutros
  neutra: ['Rias Gremory portrait', 'Rias Gremory anime', 'Rias Gremory beautiful'],
  pensativa: ['Rias Gremory thinking', 'Rias Gremory serious', 'Rias Gremory contemplative'],
  misteriosa: ['Rias Gremory mysterious', 'Rias Gremory elegant dress', 'Rias Gremory crimson hair'],
  
  // Estados negativos
  triste: ['Rias Gremory sad', 'Rias Gremory crying', 'Rias Gremory depressed'],
  brava: ['Rias Gremory angry', 'Rias Gremory mad', 'Rias Gremory fierce'],
  preocupada: ['Rias Gremory worried', 'Rias Gremory anxious', 'Rias Gremory concerned'],
  desapontada: ['Rias Gremory disappointed', 'Rias Gremory upset', 'Rias Gremory frustrated'],
  
  // Estados especiais
  poderosa: ['Rias Gremory power of destruction', 'Rias Gremory magic', 'Rias Gremory demon form'],
  sedutora: ['Rias Gremory beautiful', 'Rias Gremory elegant', 'Rias Gremory gorgeous'],
  trabalhando: ['Rias Gremory school uniform', 'Rias Gremory president', 'Rias Gremory elegant']
};

// Cache de imagens para evitar buscas repetidas
const imageCache = new Map();
const CACHE_DURATION = 30 * 60 * 1000; // 30 minutos

/**
 * Detecta o estado emocional baseado no tipo de resposta
 */
export function detectEmotion(response) {
  const type = (response.type || '').toLowerCase();
  const content = (response.content || '').toLowerCase();
  const combined = `${type} ${content}`;
  
  // Sucesso/criação -> feliz
  if (['criar_', 'sucesso', 'prontinho', 'concluído', 'feito', '✅', '🎉'].some(k => combined.includes(k))) {
    return 'feliz';
  }
  
  // Erro -> desapontada ou triste
  if (['erro', 'falha', '❌', 'não encontrado', 'problema'].some(k => combined.includes(k))) {
    return 'desapontada';
  }
  
  // Moderação/punição -> brava
  if (['ban', 'kick', 'mute', 'expulsar', 'advert', 'punir'].some(k => combined.includes(k))) {
    return 'brava';
  }
  
  // Amor/carinho -> amor
  if (['amor', 'querido', 'lindo', 'bb', '💕', '💖', '💗'].some(k => combined.includes(k))) {
    return 'amor';
  }
  
  // Informação -> neutra ou pensativa
  if (['info', 'listar', 'ver', 'stats', 'consulta'].some(k => combined.includes(k))) {
    return 'pensativa';
  }
  
  // Busca/mídia -> animada
  if (['image', 'imagem', 'foto', 'video', 'dalle'].some(k => combined.includes(k))) {
    return 'animada';
  }
  
  // Tickets -> trabalhando
  if (['ticket', 'suporte'].some(k => combined.includes(k))) {
    return 'trabalhando';
  }
  
  // Giveaway -> surpresa
  if (['giveaway', 'sorteio', 'prêmio'].some(k => combined.includes(k))) {
    return 'surpresa';
  }
  
  // Padrão -> neutra
  return 'neutra';
}

/**
 * Busca imagem da Rias baseada no estado emocional
 */
export async function getRiasImage(emotion = 'neutra') {
  const normalizedEmotion = emotion.toLowerCase();
  
  // Verificar cache
  const cacheKey = `rias_${normalizedEmotion}`;
  const cached = imageCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    console.log(`🖼️ [Rias] Usando imagem em cache: ${normalizedEmotion}`);
    return cached.url;
  }
  
  // Obter termos de busca
  const searchTerms = RIAS_EMOTIONS[normalizedEmotion] || RIAS_EMOTIONS.neutra;
  const randomTerm = searchTerms[Math.floor(Math.random() * searchTerms.length)];
  
  console.log(`🖼️ [Rias] Buscando imagem: ${randomTerm}`);
  
  try {
    const result = await apiService.searchGoogleImage(randomTerm);
    
    if (result.success && result.data?.result?.length > 0) {
      // Pegar uma imagem aleatória das primeiras 5
      const images = result.data.result.slice(0, 5);
      const randomImage = images[Math.floor(Math.random() * images.length)];
      
      if (randomImage?.url) {
        // Salvar no cache
        imageCache.set(cacheKey, {
          url: randomImage.url,
          timestamp: Date.now()
        });
        
        console.log(`✅ [Rias] Imagem encontrada para: ${normalizedEmotion}`);
        return randomImage.url;
      }
    }
  } catch (error) {
    console.error('❌ [Rias] Erro ao buscar imagem:', error.message);
  }
  
  // Fallback - URL de imagem padrão da Rias
  const fallbackImages = [
    'https://i.imgur.com/XYZ1234.png', // Substituir por URLs reais
    'https://i.imgur.com/ABC5678.png'
  ];
  return fallbackImages[Math.floor(Math.random() * fallbackImages.length)];
}

/**
 * Obtém URL da Rias para usar no footer/thumbnail
 * Analisa a resposta e escolhe a emoção apropriada
 */
export async function getRiasFooter(response) {
  const emotion = detectEmotion(response);
  return await getRiasImage(emotion);
}

/**
 * Obtém URL da Rias com emoção específica
 */
export async function getRiasByEmotion(emotion) {
  return await getRiasImage(emotion);
}

/**
 * Mapeia tipo de ação para emoção da Rias
 */
export function getEmotionByAction(actionType) {
  const emotionMap = {
    // Criação/Sucesso
    'criar_canal': 'feliz',
    'criar_categoria': 'feliz',
    'criar_cargo': 'feliz',
    'criar_webhook': 'feliz',
    'criar_automacao': 'animada',
    'criar_ticket': 'trabalhando',
    'criar_giveaway': 'surpresa',
    'criar_enquete': 'animada',
    
    // Sucesso
    'sucesso': 'orgulhosa',
    'concluído': 'feliz',
    
    // Erro
    'erro': 'desapontada',
    'falha': 'triste',
    
    // Moderação
    'banir': 'brava',
    'expulsar': 'brava',
    'mutar': 'seria',
    'advertir': 'preocupada',
    'config_automod': 'poderosa',
    
    // Informação
    'info': 'pensativa',
    'listar': 'neutra',
    'stats': 'pensativa',
    'consulta': 'pensativa',
    
    // Mídia
    'google_image': 'animada',
    'dalle': 'animada',
    'cosplay_video': 'sedutora',
    
    // Mensagem
    'message': 'amor',
    'enviar_embed': 'feliz',
    
    // Padrão
    'default': 'neutra'
  };
  
  return emotionMap[actionType] || emotionMap.default;
}

/**
 * Limpa o cache de imagens
 */
export function clearImageCache() {
  imageCache.clear();
  console.log('🧹 [Rias] Cache de imagens limpo');
}

export default {
  getRiasImage,
  getRiasFooter,
  getRiasByEmotion,
  detectEmotion,
  getEmotionByAction,
  clearImageCache,
  RIAS_EMOTIONS
};
