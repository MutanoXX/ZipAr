/**
 * Rias-Grimory-X - Sistema de Automação
 * VERSÃO 5.0 - Scripts automáticos por servidor
 * 
 * Cada servidor pode ter múltiplos scripts de automação
 * que executam tarefas em intervalos definidos.
 */

import fs from 'fs';
import path from 'path';
import { EmbedBuilder } from 'discord.js';
import OpenAI from 'openai';

// Diretório base para automações
const AUTOMATION_DIR = '/tmp/rias-automations';

// Garantir que o diretório existe
function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

ensureDir(AUTOMATION_DIR);

// Store de automações ativas
const activeAutomations = new Map();

// Cliente OpenAI para automações
const NVIDIA_KEY = process.env.NVIDIA_API_KEY || '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';

const aiClient = new OpenAI({
  baseURL: 'https://integrate.api.nvidia.com/v1',
  apiKey: NVIDIA_KEY,
  timeout: 30000,
  maxRetries: 1
});

/**
 * Classe que representa um Script de Automação
 */
class AutomationScript {
  constructor(guildId, config) {
    this.guildId = guildId;
    this.id = config.id || `${guildId}_${Date.now()}`;
    this.name = config.name;
    this.description = config.description;
    this.channelId = config.channelId;
    this.interval = config.interval || 60; // minutos
    this.task = config.task; // descrição da tarefa
    this.active = config.active !== false;
    this.lastRun = config.lastRun || null;
    this.runCount = config.runCount || 0;
    this.context = []; // Contexto da IA para este script
    this.intervalId = null;
    
    // Prompt específico para o script
    this.systemPrompt = this.buildSystemPrompt(config);
  }
  
  buildSystemPrompt(config) {
    return `# 🤖 Rias-Grimory-X - Script de Automação

Você é uma **Automação Automática** do Rias-Grimory-X!

## 📋 Script: ${this.name}
## 📝 Tarefa: ${this.task}

## 🎯 SEU TRABALHO:
Você deve executar a tarefa descrita acima automaticamente.
A cada execução, gere conteúdo novo e interessante!

## 📤 FORMATO DE RESPOSTA:
**SEMPRE retorne um JSON válido com o conteúdo a ser enviado:**

\`\`\`json
{
  "type": "enviar_embed",
  "title": "Título do Embed",
  "description": "Descrição bonita! ✨",
  "color": "roxo",
  "image": "URL_DA_IMAGEM (se houver)",
  "fields": []
}
\`\`\`

Ou para mensagem simples:
\`\`\`json
{
  "type": "message",
  "content": "Sua mensagem aqui! ✨"
}
\`\`\`

## 💖 DICAS:
- Seja criativa! Varie o conteúdo a cada execução
- Use emojis para decorar
- Mantenha o tema: ${this.task}
- Não repita o mesmo conteúdo`;
  }
  
  /**
   * Inicia o intervalo de execução
   */
  start(client) {
    if (!this.active) return;
    
    // Converter minutos para milissegundos
    const intervalMs = this.interval * 60 * 1000;
    
    console.log(`🤖 [Automação] Iniciando: ${this.name} (a cada ${this.interval} min)`);
    
    // Executar imediatamente
    this.execute(client);
    
    // Agendar próximas execuções
    this.intervalId = setInterval(() => {
      this.execute(client);
    }, intervalMs);
  }
  
  /**
   * Para o script
   */
  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.active = false;
    console.log(`⏹️ [Automação] Parado: ${this.name}`);
  }
  
  /**
   * Executa a automação
   */
  async execute(client) {
    try {
      console.log(`⚡ [Automação] Executando: ${this.name}`);
      
      const guild = client.guilds.cache.get(this.guildId);
      if (!guild) {
        console.error(`❌ [Automação] Servidor não encontrado: ${this.guildId}`);
        return;
      }
      
      const channel = guild.channels.cache.get(this.channelId);
      if (!channel) {
        console.error(`❌ [Automação] Canal não encontrado: ${this.channelId}`);
        return;
      }
      
      // Chamar IA para gerar conteúdo
      const messages = [
        { role: 'system', content: this.systemPrompt },
        { role: 'user', content: `Execute a automação agora! (${new Date().toLocaleString('pt-BR')})` }
      ];
      
      const completion = await aiClient.chat.completions.create({
        model: 'stepfun-ai/step-3.5-flash',
        messages: messages,
        temperature: 0.9,
        max_tokens: 2000
      });
      
      const content = completion.choices[0]?.message?.content || '';
      
      // Parse da resposta
      const response = this.parseResponse(content);
      
      // Enviar para o canal
      await this.sendToChannel(channel, response);
      
      // Atualizar estatísticas
      this.lastRun = new Date().toISOString();
      this.runCount++;
      this.save();
      
      console.log(`✅ [Automação] Executado: ${this.name} (Total: ${this.runCount})`);
      
    } catch (error) {
      console.error(`❌ [Automação] Erro em ${this.name}:`, error.message);
    }
  }
  
  parseResponse(content) {
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
    } catch (e) {}
    
    return { type: 'message', content: content };
  }
  
  async sendToChannel(channel, response) {
    try {
      if (response.type === 'enviar_embed' || response.type === 'send_embed') {
        const embed = new EmbedBuilder()
          .setTitle(response.title || response.titulo || this.name)
          .setDescription(response.description || response.descricao || '')
          .setColor(response.color || '#8B5CF6')
          .setFooter({ text: '🤖 Automação | Rias-Grimory-X' })
          .setTimestamp();
        
        if (response.image || response.imagem) {
          embed.setImage(response.image || response.imagem);
        }
        
        if (response.fields) {
          response.fields.forEach(f => {
            embed.addFields({ name: f.name || 'Campo', value: f.value || 'Valor', inline: f.inline || false });
          });
        }
        
        await channel.send({ embeds: [embed] });
      } else {
        await channel.send({ 
          content: response.content?.substring(0, 2000) || '🤖 Automação executada!' 
        });
      }
    } catch (error) {
      console.error(`❌ [Automação] Erro ao enviar:`, error.message);
    }
  }
  
  /**
   * Salva o script no disco
   */
  save() {
    const guildDir = path.join(AUTOMATION_DIR, this.guildId);
    ensureDir(guildDir);
    
    const filePath = path.join(guildDir, `${this.id}.json`);
    
    const data = {
      id: this.id,
      name: this.name,
      description: this.description,
      channelId: this.channelId,
      interval: this.interval,
      task: this.task,
      active: this.active,
      lastRun: this.lastRun,
      runCount: this.runCount
    };
    
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  }
  
  /**
   * Remove o script do disco
   */
  delete() {
    this.stop();
    
    const filePath = path.join(AUTOMATION_DIR, this.guildId, `${this.id}.json`);
    
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  }
  
  toObject() {
    return {
      id: this.id,
      name: this.name,
      description: this.description,
      channelId: this.channelId,
      channelMention: `<#${this.channelId}>`,
      interval: this.interval,
      task: this.task,
      active: this.active,
      lastRun: this.lastRun,
      runCount: this.runCount
    };
  }
}

// ============================================
// FUNÇÕES DE GERENCIAMENTO
// ============================================

/**
 * Cria uma nova automação
 */
export function createAutomation(guildId, config) {
  const script = new AutomationScript(guildId, config);
  script.save();
  
  // Adicionar ao store
  if (!activeAutomations.has(guildId)) {
    activeAutomations.set(guildId, new Map());
  }
  activeAutomations.get(guildId).set(script.id, script);
  
  return script;
}

/**
 * Obtém uma automação específica
 */
export function getAutomation(guildId, scriptId) {
  const guildAutomations = activeAutomations.get(guildId);
  if (!guildAutomations) return null;
  return guildAutomations.get(scriptId);
}

/**
 * Lista todas as automações de um servidor
 */
export function listAutomations(guildId) {
  const guildAutomations = activeAutomations.get(guildId);
  if (!guildAutomations) return [];
  
  return Array.from(guildAutomations.values()).map(s => s.toObject());
}

/**
 * Remove uma automação
 */
export function deleteAutomation(guildId, scriptId) {
  const script = getAutomation(guildId, scriptId);
  if (!script) return false;
  
  script.delete();
  
  const guildAutomations = activeAutomations.get(guildId);
  if (guildAutomations) {
    guildAutomations.delete(scriptId);
  }
  
  return true;
}

/**
 * Pausa uma automação
 */
export function pauseAutomation(guildId, scriptId) {
  const script = getAutomation(guildId, scriptId);
  if (!script) return false;
  
  script.stop();
  script.save();
  
  return true;
}

/**
 * Retoma uma automação
 */
export function resumeAutomation(guildId, scriptId, client) {
  const script = getAutomation(guildId, scriptId);
  if (!script) return false;
  
  script.active = true;
  script.start(client);
  script.save();
  
  return true;
}

/**
 * Edita uma automação
 */
export function editAutomation(guildId, scriptId, newConfig) {
  const script = getAutomation(guildId, scriptId);
  if (!script) return null;
  
  if (newConfig.name) script.name = newConfig.name;
  if (newConfig.description) script.description = newConfig.description;
  if (newConfig.interval) script.interval = newConfig.interval;
  if (newConfig.task) script.task = newConfig.task;
  if (newConfig.channelId) script.channelId = newConfig.channelId;
  
  script.save();
  
  return script.toObject();
}

/**
 * Inicia todas as automações de um servidor
 */
export function startGuildAutomations(guildId, client) {
  const guildDir = path.join(AUTOMATION_DIR, guildId);
  
  if (!fs.existsSync(guildDir)) return;
  
  const files = fs.readdirSync(guildDir).filter(f => f.endsWith('.json'));
  
  if (!activeAutomations.has(guildId)) {
    activeAutomations.set(guildId, new Map());
  }
  
  for (const file of files) {
    try {
      const filePath = path.join(guildDir, file);
      const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      
      const script = new AutomationScript(guildId, data);
      activeAutomations.get(guildId).set(script.id, script);
      
      if (script.active) {
        script.start(client);
      }
      
      console.log(`🤖 [Automação] Carregado: ${script.name}`);
    } catch (error) {
      console.error(`❌ [Automação] Erro ao carregar ${file}:`, error.message);
    }
  }
}

/**
 * Para todas as automações de um servidor
 */
export function stopGuildAutomations(guildId) {
  const guildAutomations = activeAutomations.get(guildId);
  if (!guildAutomations) return;
  
  for (const script of guildAutomations.values()) {
    script.stop();
  }
}

/**
 * Executa uma automação manualmente
 */
export async function runAutomationNow(guildId, scriptId, client) {
  const script = getAutomation(guildId, scriptId);
  if (!script) return false;
  
  await script.execute(client);
  return true;
}

/**
 * Obtém estatísticas de automação
 */
export function getAutomationStats(guildId) {
  const automations = listAutomations(guildId);
  
  return {
    total: automations.length,
    active: automations.filter(a => a.active).length,
    totalRuns: automations.reduce((sum, a) => sum + a.runCount, 0)
  };
}

export { AutomationScript };

export default {
  createAutomation,
  getAutomation,
  listAutomations,
  deleteAutomation,
  pauseAutomation,
  resumeAutomation,
  editAutomation,
  startGuildAutomations,
  stopGuildAutomations,
  runAutomationNow,
  getAutomationStats,
  AutomationScript
};
