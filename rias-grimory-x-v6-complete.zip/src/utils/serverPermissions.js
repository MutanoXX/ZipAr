/**
 * MutanoX Architect - Sistema de Permissões por Servidor
 * Gerencia permissões específicas para cada servidor
 * 
 * CARACTERÍSTICAS:
 * - Cada servidor tem suas próprias configurações
 * - Apenas admins e donos do servidor podem usar a IA
 * - Comando /delete-server restrito ao dono do servidor
 * - Usuários podem convidar o bot para seus servidores
 */

// ID do dono do bot (acesso global total)
const BOT_OWNER_ID = '1387242867700924568';

// Configurações por servidor: Map<guildId, ServerConfig>
const serverConfigs = new Map();

/**
 * Estrutura de configuração do servidor:
 * {
 *   guildId: string,
 *   ownerId: string,           // Dono do servidor
 *   allowedRoles: string[],    // Cargos permitidos além de admin
 *   activeChannels: Set<string>, // Canais com IA ativa
 *   createdAt: timestamp,
 *   updatedAt: timestamp
 * }
 */

/**
 * Inicializa ou atualiza a configuração de um servidor
 * @param {Guild} guild - Servidor Discord
 */
export function initServerConfig(guild) {
  const guildId = guild.id;
  
  if (!serverConfigs.has(guildId)) {
    serverConfigs.set(guildId, {
      guildId: guildId,
      ownerId: guild.ownerId,
      allowedRoles: [],
      activeChannels: new Set(),
      createdAt: Date.now(),
      updatedAt: Date.now()
    });
    console.log(`📋 [ServerPerms] Nova configuração criada para: ${guild.name}`);
  } else {
    // Atualizar ownerId caso tenha mudado
    const config = serverConfigs.get(guildId);
    if (config.ownerId !== guild.ownerId) {
      config.ownerId = guild.ownerId;
      config.updatedAt = Date.now();
      console.log(`📋 [ServerPerms] Dono atualizado para: ${guild.name}`);
    }
  }
  
  return serverConfigs.get(guildId);
}

/**
 * Verifica se o usuário tem permissão no servidor específico
 * @param {Guild} guild - Servidor Discord
 * @param {User} user - Usuário
 * @param {GuildMember} member - Membro do servidor
 * @returns {Object} { authorized: boolean, reason: string }
 */
export function checkServerPermission(guild, user, member) {
  // Dono do bot SEMPRE tem acesso total
  if (user.id === BOT_OWNER_ID) {
    return { authorized: true, reason: 'Dono do bot' };
  }
  
  // Verificar se o usuário está no servidor
  if (!member) {
    return { authorized: false, reason: 'Usuário não está no servidor' };
  }
  
  // Inicializar configuração do servidor se não existir
  const config = initServerConfig(guild);
  
  // Verificar se é o dono do servidor
  if (user.id === config.ownerId) {
    return { authorized: true, reason: 'Dono do servidor' };
  }
  
  // Verificar se tem cargo de Administrador
  if (member.permissions.has('Administrator')) {
    return { authorized: true, reason: 'Administrador' };
  }
  
  // Verificar se tem cargo permitido específico
  const memberRoles = member.roles.cache.map(r => r.id);
  const hasAllowedRole = config.allowedRoles.some(roleId => memberRoles.includes(roleId));
  
  if (hasAllowedRole) {
    return { authorized: true, reason: 'Cargo autorizado' };
  }
  
  return { 
    authorized: false, 
    reason: 'Você precisa ser Administrador ou Dono do servidor para usar a IA. Convide o bot para seu próprio servidor para ter acesso completo!' 
  };
}

/**
 * Verifica se o usuário é dono do servidor
 * @param {Guild} guild - Servidor Discord
 * @param {string} userId - ID do usuário
 * @returns {boolean}
 */
export function isServerOwner(guild, userId) {
  // Dono do bot pode tudo
  if (userId === BOT_OWNER_ID) return true;
  
  const config = serverConfigs.get(guild.id);
  if (!config) {
    // Se não tem config, usar o ownerId do guild
    return userId === guild.ownerId;
  }
  
  return userId === config.ownerId;
}

/**
 * Verifica se o usuário é administrador no servidor
 * @param {Guild} guild - Servidor Discord
 * @param {GuildMember} member - Membro do servidor
 * @returns {boolean}
 */
export function isServerAdmin(guild, member) {
  if (!member) return false;
  
  // Dono do bot
  if (member.user.id === BOT_OWNER_ID) return true;
  
  // Administrador
  if (member.permissions.has('Administrator')) return true;
  
  // Dono do servidor
  if (isServerOwner(guild, member.user.id)) return true;
  
  return false;
}

/**
 * Adiciona um cargo à lista de permitidos no servidor
 * @param {string} guildId - ID do servidor
 * @param {string} roleId - ID do cargo
 * @returns {boolean}
 */
export function addAllowedRole(guildId, roleId) {
  const config = serverConfigs.get(guildId);
  if (!config) return false;
  
  if (config.allowedRoles.includes(roleId)) return false;
  
  config.allowedRoles.push(roleId);
  config.updatedAt = Date.now();
  return true;
}

/**
 * Remove um cargo da lista de permitidos
 * @param {string} guildId - ID do servidor
 * @param {string} roleId - ID do cargo
 * @returns {boolean}
 */
export function removeAllowedRole(guildId, roleId) {
  const config = serverConfigs.get(guildId);
  if (!config) return false;
  
  const index = config.allowedRoles.indexOf(roleId);
  if (index === -1) return false;
  
  config.allowedRoles.splice(index, 1);
  config.updatedAt = Date.now();
  return true;
}

/**
 * Obtém a configuração do servidor
 * @param {string} guildId - ID do servidor
 * @returns {Object|null}
 */
export function getServerConfig(guildId) {
  return serverConfigs.get(guildId) || null;
}

/**
 * Lista todos os servidores configurados
 * @returns {Array}
 */
export function getAllServerConfigs() {
  return Array.from(serverConfigs.values());
}

/**
 * Remove configuração de um servidor (quando bot sai)
 * @param {string} guildId - ID do servidor
 */
export function removeServerConfig(guildId) {
  serverConfigs.delete(guildId);
  console.log(`📋 [ServerPerms] Configuração removida para servidor: ${guildId}`);
}

/**
 * Obtém o ID do dono do bot
 * @returns {string}
 */
export function getBotOwnerId() {
  return BOT_OWNER_ID;
}

/**
 * Verifica se o usuário é o dono do bot
 * @param {string} userId - ID do usuário
 * @returns {boolean}
 */
export function isBotOwner(userId) {
  return userId === BOT_OWNER_ID;
}

/**
 * Obtém informações resumidas do servidor para log
 * @param {string} guildId - ID do servidor
 * @returns {Object}
 */
export function getServerInfo(guildId) {
  const config = serverConfigs.get(guildId);
  if (!config) return null;
  
  return {
    guildId: config.guildId,
    ownerId: config.ownerId,
    allowedRolesCount: config.allowedRoles.length,
    activeChannelsCount: config.activeChannels.size,
    createdAt: new Date(config.createdAt).toISOString()
  };
}

export default {
  initServerConfig,
  checkServerPermission,
  isServerOwner,
  isServerAdmin,
  addAllowedRole,
  removeAllowedRole,
  getServerConfig,
  getAllServerConfigs,
  removeServerConfig,
  getBotOwnerId,
  isBotOwner,
  getServerInfo
};
