/**
 * MutanoX Architect - Deploy de Comandos
 * Registra comandos slash no Discord
 */

import { REST, Routes } from 'discord.js';
import { config } from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Carregar variáveis de ambiente
config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const commands = [];
const commandsPath = path.join(__dirname, '..', 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

// Carregar comandos
for (const file of commandFiles) {
  const filePath = path.join(commandsPath, file);
  try {
    const module = await import(filePath);
    const command = module.default || module;
    
    if (command.data) {
      commands.push(command.data.toJSON());
      console.log(`📄 Comando carregado: ${command.data.name}`);
    } else {
      console.log(`⚠️ Arquivo ignorado (sem export data): ${file}`);
    }
  } catch (error) {
    console.error(`❌ Erro ao carregar comando ${file}:`, error.message);
  }
}

// Configurar REST
const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

// Deploy
(async () => {
  try {
    console.log('');
    console.log('🚀 Iniciando deploy de comandos slash...');
    console.log(`📝 ${commands.length} comandos para registrar`);
    console.log('');

    // Registrar comandos globalmente (pode demorar até 1 hora para aparecer)
    // Para registro rápido em um servidor específico, use Routes.applicationGuildCommands
    
    if (process.env.DISCORD_GUILD_ID) {
      // Registro específico para um servidor (mais rápido)
      const data = await rest.put(
        Routes.applicationGuildCommands(
          process.env.DISCORD_CLIENT_ID,
          process.env.DISCORD_GUILD_ID
        ),
        { body: commands }
      );
      console.log(`✅ Comandos registrados no servidor: ${data.length} comandos`);
    } else {
      // Registro global
      const data = await rest.put(
        Routes.applicationCommands(process.env.DISCORD_CLIENT_ID),
        { body: commands }
      );
      console.log(`✅ Comandos registrados globalmente: ${data.length} comandos`);
      console.log('⏳ Nota: Comandos globais podem demorar até 1 hora para aparecer');
    }

    console.log('');
    console.log('🎉 Deploy concluído com sucesso!');

  } catch (error) {
    console.error('❌ Erro no deploy:', error);
  }
})();
