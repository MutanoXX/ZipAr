/**
 * MutanoX Architect AI - Configurações do Bot
 */

export const config = {
  // Discord
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.DISCORD_CLIENT_ID,
  
  // Bot Settings
  prefix: process.env.BOT_PREFIX || '!',
  language: process.env.DEFAULT_LANGUAGE || 'pt-BR',
  
  // Cores do tema MutanoX
  colors: {
    primary: '#8B5CF6', // Roxo MutanoX
    success: '#10B981',
    error: '#EF4444',
    warning: '#F59E0B',
    info: '#3B82F6'
  },
  
  // Emojis
  emojis: {
    success: '✅',
    error: '❌',
    warning: '⚠️',
    loading: '⏳',
    architecture: '🏗️',
    analysis: '🔍',
    roles: '👥',
    channels: '📢',
    settings: '⚙️'
  }
};

export default config;
