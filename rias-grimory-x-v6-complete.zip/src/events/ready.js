/**
 * Rias-Grimory-X - Evento Ready
 * Executado quando o bot está conectado ao Discord
 */

export const name = 'clientReady';
export const once = true;

export async function execute(client) {
  console.log('');
  console.log('╔════════════════════════════════════════════╗');
  console.log('║     💎  RIAS GRIMORY X AI  💎              ║');
  console.log('║        Bot Discord em Node.js              ║');
  console.log('║        Criado por: MutanoX                 ║');
  console.log('╠════════════════════════════════════════════╣');
  console.log(`║  Bot: ${client.user.tag.padEnd(35)}║`);
  console.log(`║  Servidores: ${String(client.guilds.cache.size).padEnd(31)}║`);
  console.log(`║  Usuários: ${String(client.users.cache.size).padEnd(33)}║`);
  console.log('╚════════════════════════════════════════════╝');
  console.log('');

  // Definir status do bot
  client.user.setPresence({
    activities: [
      {
        name: '💎 Rias-Grimory-X | /ask',
        type: 0 // Watching
      }
    ],
    status: 'online'
  });

  console.log('✅ [Ready] Rias-Grimory-X conectada e pronta!');
}
