# Rias-Grimory-X v5.0 - Correções e Melhorias

## 🎉 MUDANÇAS PRINCIPAIS

### 1. ✅ Nome Alterado
- **De:** MutanoX
- **Para:** Rias-Grimory-X
- Todos os arquivos, prompts e mensagens foram atualizados!

---

### 2. 🪝 Webhooks - MELHORADO COMPLETO

**Antes:** Mostrava apenas ID do webhook

**Agora:** Mostra URL COMPLETA e TOKEN!

#### Novas Ferramentas de Webhook:

| Ferramenta | Descrição |
|------------|-----------|
| `criar_webhook` | Cria webhook e mostra URL + token |
| `listar_webhooks` | Lista webhooks do canal com URLs |
| `listar_webhooks_servidor` | Lista TODOS webhooks do servidor |
| `info_webhook` | Mostra detalhes completos + URL + token |
| `editar_webhook` | Edita nome e avatar |
| `deletar_webhook` | Remove webhook |
| `enviar_webhook` | Envia mensagem via webhook |

#### Exemplo de Resposta:
```
🪝 Webhook Criado!
📝 Nome: Meu Webhook
🆔 ID: 123456789
📺 Canal: #geral
🔗 URL: https://discord.com/api/webhooks/123456789/abc123...
🔑 Token: abc123...
```

---

### 3. 📋 CPF/CNPJ - TODAS AS INFORMAÇÕES

**Antes:** Mostrava apenas 2 campos

**Agora:** Mostra TODAS as informações disponíveis!

#### Campos de CNPJ:
- Razão Social, Nome Fantasia
- CNPJ, Situação, Tipo, Porte
- Data de Abertura, Capital Social
- Natureza Jurídica
- Atividade Principal e Secundárias
- Endereço completo (Logradouro, Número, Bairro, Cidade, UF, CEP)
- Email, Telefone
- Quadro de Sócios (QSA)
- Data da Última Atualização

#### Campos de CPF:
- Nome completo
- CPF, Data de Nascimento, Idade, Signo
- Nome da Mãe, Nome do Pai
- RG, Órgão Emissor
- Estado Civil, Escolaridade
- Renda, Renda Presumida
- Endereço completo
- Email, Telefone
- Situação Cadastral

---

### 4. 🗑️ BulkDelete - CORRIGIDO

**Erro anterior:** `messages.slice is not a function`

**Correção:** Conversão de Collection para Array antes de usar slice

```javascript
// ANTES (errado)
messages.slice(0, limit);

// DEPOIS (corrigido)
const messagesArray = Array.from(messages.values());
const messagesToDelete = messagesArray.slice(0, limit);
```

---

### 5. 🤖 SISTEMA DE AUTOMAÇÃO - NOVO!

Sistema completo de scripts automáticos por servidor!

#### Estrutura:
```
/tmp/rias-automations/
├── {guild_id}/
│   ├── script_1.json
│   ├── script_2.json
│   └── ...
```

#### Ferramentas de Automação:

| Ferramenta | Descrição |
|------------|-----------|
| `criar_automacao` | Cria um novo script automático |
| `listar_automacoes` | Lista todos os scripts do servidor |
| `pausar_automacao` | Pausa um script |
| `retomar_automacao` | Retoma um script pausado |
| `deletar_automacao` | Remove um script |
| `executar_automacao` | Executa manualmente um script |

#### Como Criar uma Automação:
```json
{
  "type": "criar_automacao",
  "nome": "Imagens de Anime",
  "descricao": "Envia imagens de anime automaticamente",
  "canal": "#imagens",
  "intervalo": 60,
  "tarefa": "Gerar imagens de anime e enviar embeds decorados"
}
```

#### Características:
- ✅ Cada servidor tem sua própria pasta
- ✅ Cada script tem seu contexto de IA isolado
- ✅ Intervalo mínimo de 10 minutos
- ✅ Executa automaticamente em background
- ✅ Persiste entre reinicializações (salvo em JSON)
- ✅ Pode ser pausado/retomado

---

## 📁 ARQUIVOS MODIFICADOS

1. **src/utils/serverTools.js**
   - Webhooks melhorados com URL e token
   - BulkDelete corrigido
   - Novas funções: `listGuildWebhooks`, `getWebhook`, `editWebhook`, `sendWebhookByUrl`

2. **src/events/messageCreate.js**
   - Nome alterado para Rias-Grimory-X
   - CPF/CNPJ com todas informações
   - Sistema de automação integrado
   - BulkDelete corrigido

3. **src/commands/ask.js**
   - Nome alterado para Rias-Grimory-X
   - Prompt com documentação completa
   - Novas ferramentas documentadas

4. **src/utils/automationManager.js** (NOVO)
   - Sistema completo de automação
   - Scripts por servidor
   - Persistência em JSON

---

## 🚀 COMO USAR

### Criar Webhook:
```
"Cria um webhook chamado Notícias neste canal"
```

### Criar Automação:
```
"Cria uma automação que gera imagens de anime e envia no #imagens a cada 30 minutos"
```

### Consultar CNPJ/CPF:
```
"Consulta o CNPJ 00.000.000/0001-91"
"Consulta o CPF 000.000.000-00"
```

### Deletar Mensagens:
```
"Limpa 50 mensagens deste canal"
```

---

## 📊 RESUMO DE FERRAMENTAS

| Categoria | Quantidade |
|-----------|------------|
| 📁 Canais | 10 |
| 🎭 Cargos | 7 |
| 👥 Membros | 8 |
| 💬 Mensagens | 3 |
| 🪝 Webhooks | 8 |
| 📨 Convites | 3 |
| 😀 Emojis | 3 |
| 🤖 Automação | 6 |
| 🔍 Consultas | 2 |
| 🖼️ Mídia | 3 |
| 📄 Arquivos | 1 |
| 📨 Embeds | 2 |
| 📊 Info | 3 |
| **TOTAL** | **+60** |
