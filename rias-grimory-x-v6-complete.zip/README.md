# 🏗️ MutanoX Architect AI

Bot Discord para análise e reestruturação de servidores usando IA.

## 📋 Versão 2.0 - Sistema de Permissões por Servidor

### ✨ Novidades

#### 🔐 Sistema de Permissões por Servidor
- **Cada servidor tem suas próprias configurações**
- Apenas **Administradores** e o **Dono do servidor** podem usar a IA
- O comando `/delete-server` é **EXCLUSIVO** do dono do servidor
- Usuários podem convidar o bot para seus próprios servidores

#### 🌐 Contexto Isolado por Servidor
- A IA só pode agir no servidor onde está sendo acionada
- Cada servidor tem seu próprio histórico de conversa
- Configurações independentes para cada comunidade

#### ⚙️ Novo Comando `/server-config`
- Veja as configurações do servidor
- Adicione/remova cargos permitidos
- Configure o idioma da IA

### 🚀 Funcionalidades

#### 📁 Gestão de Canais
- Criar categorias e canais (texto/voz)
- Renomear e organizar estruturas
- Configurar tópicos e permissões

#### 👥 Gestão de Cargos
- Criar cargos com cores personalizadas
- Atribuir ou remover cargos de usuários
- Configurar hierarquias e permissões

#### 🎨 Estética e Decoração
- Aplicar fontes Unicode especiais (𝐍𝐨𝐦𝐞, 𝐕𝐈𝐏)
- Organizar nomes com Emojis temáticos
- Enviar Embeds profissionais com imagens

#### 🔧 Ferramentas
- Geração de imagens IA
- Busca de imagens no Google
- Geração de arquivos (PDF, TXT, MD)
- Estatísticas do servidor

### 📋 Comandos

| Comando | Descrição | Permissão |
|---------|-----------|-----------|
| `/ask on` | Ativa a IA em um canal | Admin/Dono |
| `/ask off` | Desativa a IA | Admin/Dono |
| `/ask list` | Lista canais ativos | Admin/Dono |
| `/architect analyze` | Analisa e reestrutura o servidor | Admin/Dono |
| `/architect quick` | Cria estrutura rápida | Admin/Dono |
| `/server-config ver` | Ver configurações | Admin/Dono |
| `/server-config add-cargo` | Adiciona cargo permitido | Admin/Dono |
| `/delete-server` | Deleta toda estrutura | **Dono do servidor** |
| `/help` | Guia de funcionalidades | Todos |
| `/info` | Informações do bot | Todos |

### 🔐 Sistema de Permissões

#### Níveis de Acesso:
1. **👑 Dono do Bot** - Acesso total em todos os servidores
2. **👑 Dono do Servidor** - Acesso total no seu servidor + comandos críticos
3. **⚙️ Administrador** - Pode usar a IA e comandos de gerenciamento
4. **📋 Cargos Permitidos** - Configuráveis via `/server-config`

#### Comandos Críticos:
- `/delete-server` - **EXCLUSIVO** para o dono do servidor

### 🛠️ Instalação

1. Clone o repositório
2. Instale as dependências: `bun install`
3. Configure o `.env`:
```env
DISCORD_TOKEN=seu_token
DISCORD_CLIENT_ID=seu_client_id
NVIDIA_API_KEY=sua_api_key
```
4. Execute: `bun run dev`

### 📦 Dependências

- discord.js ^14.15.0
- dotenv ^16.4.5
- openai ^4.70.0
- pdf-lib ^1.17.1
- form-data ^4.0.5

### 📝 Changelog

#### v2.0.0
- ✨ Sistema de permissões por servidor
- ✨ Contexto isolado por servidor
- ✨ Comando `/server-config`
- 🔒 `/delete-server` restrito ao dono do servidor
- 🔒 Verificação de permissões por servidor
- 🌐 Suporte a múltiplos idiomas
- 📋 Carregamento global de comandos
- 🤖 Mensagem de boas-vindas ao entrar em servidor

---

**Desenvolvido por MutanoX** 🏗️
