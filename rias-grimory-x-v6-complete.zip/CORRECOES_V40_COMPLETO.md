# MutanoX AI v4.0 - Sistema COMPLETO de Gestão

## 🎉 NOVIDADES DA VERSÃO 4.0

Esta versão traz **+50 FERRAMENTAS** de controle total do servidor Discord!

---

## ═══════════════════════════════════════
## 📁 CANAIS - 10 FERRAMENTAS
## ═══════════════════════════════════════

| Ferramenta | Tipo JSON | Descrição |
|------------|-----------|-----------|
| ➕ Criar Canal | `criar_canal` | Criar canais de texto, voz, anúncio ou stage |
| ✏️ Editar Canal | `editar_canal` | Editar nome, tópico, slowmode, NSFW |
| ❌ Deletar Canal | `deletar_canal` | Remover canais do servidor |
| 📋 Clonar Canal | `clonar_canal` | Duplicar canal existente |
| 🔒 Trancar Canal | `trancar_canal` | Impedir @everyone de enviar mensagens |
| 🙈 Esconder Canal | `esconder_canal` | Esconder/mostrar canal de cargos específicos |
| 🔐 Permissões | `permissao_canal` | Definir permissões granulares por cargo |
| 📂 Criar Categoria | `criar_categoria` | Criar categoria com múltiplos canais |
| 📋 Listar Canais | `listar_canais` | Ver todos os canais do servidor |

### Exemplos de Uso:

**Criar canal de texto:**
```json
{"type":"criar_canal","name":"chat-geral","tipo":"texto","topico":"Chat geral do servidor","slowmode":5}
```

**Criar canal de voz:**
```json
{"type":"criar_canal","name":"Sala de Reunião","tipo":"voz","bitrate":64000,"userLimit":10}
```

**Trancar canal:**
```json
{"type":"trancar_canal","canal":"chat-vip","trancar":true}
```

**Esconder canal de um cargo:**
```json
{"type":"esconder_canal","canal":"admin","cargo":"Membros","esconder":true}
```

**Criar categoria completa:**
```json
{"type":"criar_categoria","nome":"📁 Área VIP","canais":[{"name":"chat-vip","type":"texto"},{"name":"voz-vip","type":"voz"}],"permissoes":[{"role":"@everyone","deny":["view_channel"]}]}
```

---

## ═══════════════════════════════════════
## 🎭 CARGOS - 7 FERRAMENTAS
## ═══════════════════════════════════════

| Ferramenta | Tipo JSON | Descrição |
|------------|-----------|-----------|
| ➕ Criar Cargo | `criar_cargo` | Criar novo cargo com cor e permissões |
| ✏️ Editar Cargo | `editar_cargo` | Editar nome, cor, permissões |
| ❌ Deletar Cargo | `deletar_cargo` | Remover cargo do servidor |
| 📋 Clonar Cargo | `clonar_cargo` | Duplicar cargo existente |
| ➕ Adicionar Cargo | `adicionar_cargo` | Dar cargo a um membro |
| ➖ Remover Cargo | `remover_cargo` | Tirar cargo de um membro |
| 📋 Listar Cargos | `listar_cargos` | Ver todos os cargos |

### Cores Disponíveis:
`vermelho`, `verde`, `azul`, `roxo`, `amarelo`, `rosa`, `laranja`, `dourado`, `branco`, `preto`, `ciano`, `turquesa`, `cinza`

### Exemplos:

**Criar cargo VIP:**
```json
{"type":"criar_cargo","nome":"VIP","cor":"dourado","separado":true,"mencionavel":true}
```

**Criar cargo staff com permissões:**
```json
{"type":"criar_cargo","nome":"Moderador","cor":"verde","permissoes":["kick_members","ban_members","manage_messages"],"separado":true}
```

**Adicionar cargo a membro:**
```json
{"type":"adicionar_cargo","membro":"NomeDoUsuario","cargo":"VIP"}
```

---

## ═══════════════════════════════════════
## 👥 MEMBROS - 8 FERRAMENTAS
## ═══════════════════════════════════════

| Ferramenta | Tipo JSON | Descrição |
|------------|-----------|-----------|
| 👢 Expulsar | `expulsar` | Kick do servidor |
| 🔨 Banir | `banir` | Ban com opção de deletar mensagens |
| ✅ Desbanir | `desbanir` | Remover banimento |
| 🔇 Mutar | `mutar` | Timeout (até 28 dias) |
| 🔊 Desmutar | `desmutar` | Remover timeout |
| ✏️ Apelido | `apelido` | Mudar apelido do membro |
| 👤 Info Membro | `info_membro` | Ver informações detalhadas |
| 📋 Membros por Cargo | `membros_cargo` | Listar membros com cargo específico |

### Exemplos:

**Expulsar membro:**
```json
{"type":"expulsar","membro":"UsuarioProblematico","motivo":"Spam"}
```

**Banir com delete de mensagens:**
```json
{"type":"banir","membro":"Troll","motivo":"Toxicidade","deletar_dias":7}
```

**Mutar por 1 hora:**
```json
{"type":"mutar","membro":"Spammer","duracao":60,"motivo":"Spam em massa"}
```

**Mudar apelido:**
```json
{"type":"apelido","membro":"Usuario","apelido":"Novo Nome"}
```

**Ver info do membro:**
```json
{"type":"info_membro","membro":"Usuario"}
```

---

## ═══════════════════════════════════════
## 💬 MENSAGENS - 3 FERRAMENTAS
## ═══════════════════════════════════════

| Ferramenta | Tipo JSON | Descrição |
|------------|-----------|-----------|
| 🗑️ Deletar Mensagens | `deletar_mensagens` | Bulk delete (1-100 msgs) |
| 📌 Fixar Mensagem | `fixar_mensagem` | Pin message |
| 📌 Desfixar | `desfixar_mensagem` | Unpin message |

### Exemplos:

**Deletar 50 mensagens:**
```json
{"type":"deletar_mensagens","quantidade":50}
```

**Deletar mensagens de usuário específico:**
```json
{"type":"deletar_mensagens","quantidade":30,"usuario":"id-do-usuario"}
```

---

## ═══════════════════════════════════════
## 🪝 WEBHOOKS - 3 FERRAMENTAS
## ═══════════════════════════════════════

| Ferramenta | Tipo JSON | Descrição |
|------------|-----------|-----------|
| ➕ Criar Webhook | `criar_webhook` | Criar webhook no canal |
| 📋 Listar Webhooks | `listar_webhooks` | Ver webhooks do canal |
| ❌ Deletar Webhook | `deletar_webhook` | Remover webhook |

---

## ═══════════════════════════════════════
## 📨 CONVITES - 3 FERRAMENTAS
## ═══════════════════════════════════════

| Ferramenta | Tipo JSON | Descrição |
|------------|-----------|-----------|
| ➕ Criar Convite | `criar_convite` | Criar link de convite |
| 📋 Listar Convites | `listar_convites` | Ver todos os convites |
| ❌ Deletar Convite | `deletar_convite` | Revogar convite |

### Exemplos:

**Criar convite de 24h com 5 usos:**
```json
{"type":"criar_convite","tempo":86400,"usos":5}
```

**Criar convite permanente:**
```json
{"type":"criar_convite","tempo":0,"usos":0}
```

---

## ═══════════════════════════════════════
## 😀 EMOJIS - 3 FERRAMENTAS
## ═══════════════════════════════════════

| Ferramenta | Tipo JSON | Descrição |
|------------|-----------|-----------|
| ➕ Adicionar Emoji | `adicionar_emoji` | Adicionar emoji ao servidor |
| ❌ Deletar Emoji | `deletar_emoji` | Remover emoji |
| 📋 Listar Emojis | `listar_emojis` | Ver todos os emojis |

### Exemplo:
```json
{"type":"adicionar_emoji","nome":"banana","url":"https://url-da-imagem.png"}
```

---

## ═══════════════════════════════════════
## 🔄 TAREFA COMPLEXA
## ═══════════════════════════════════════

Execute múltiplas ações em sequência!

### Exemplo - Criar área VIP completa:
```json
{
  "type":"tarefa_complexa",
  "steps":[
    {"type":"criar_categoria","nome":"⭐ VIP","canais":[{"name":"chat-vip"},{"name":"voz-vip","type":"voz"}]},
    {"type":"criar_cargo","nome":"VIP","cor":"dourado","separado":true},
    {"type":"esconder_canal","canal":"chat-vip","cargo":"@everyone","esconder":true},
    {"type":"esconder_canal","canal":"voz-vip","cargo":"@everyone","esconder":true}
  ]
}
```

---

## ═══════════════════════════════════════
## 📊 RESUMO DE FERRAMENTAS
## ═══════════════════════════════════════

| Categoria | Quantidade |
|-----------|------------|
| 📁 Canais | 10 |
| 🎭 Cargos | 7 |
| 👥 Membros | 8 |
| 💬 Mensagens | 3 |
| 🪝 Webhooks | 3 |
| 📨 Convites | 3 |
| 😀 Emojis | 3 |
| 🔍 Consultas | 2 |
| 🖼️ Mídia | 3 |
| 📄 Arquivos | 1 |
| 📨 Embeds | 2 |
| 📊 Info | 1 |
| 🔄 Tarefas | 1 |
| **TOTAL** | **+50** |

---

## 🚀 COMO USAR

1. Use `/ask on` em um canal para ativar a IA
2. Envie mensagens pedindo o que precisa
3. A IA vai automaticamente usar a ferramenta correta!

**Exemplos de pedidos:**
- "Cria um canal chamado #anúncios"
- "Faz um cargo verde chamado Membro"
- "Muta o usuário X por 30 minutos"
- "Cria uma área VIP com chat e voz, e um cargo VIP dourado"
- "Mostra as estatísticas do servidor"

---

## 📝 ARQUIVOS MODIFICADOS

1. **src/utils/serverTools.js** (NOVO)
   - Módulo completo com +50 funções de gestão
   - Funções auxiliares para encontrar canais, cargos, membros
   - Parsing de cores e permissões

2. **src/events/messageCreate.js** (ATUALIZADO)
   - Handlers para todas as novas ferramentas
   - Melhor tratamento de erros
   - Embeds decorados para cada ação

3. **src/commands/ask.js** (ATUALIZADO)
   - Prompt completo documentando todas as ferramentas
   - Exemplos de uso embutidos
   - Contexto do servidor atualizado
