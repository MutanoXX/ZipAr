/**
 * Rias-Grimory-X - Comando /renov
 * Inicia o processo de renovação de plano ou compra inicial
 *
 * @version 1.0.0
 * @author MutanoX
 */

import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags
} from 'discord.js';
import paymentManager from '../services/paymentManager.js';
import accountManager from '../utils/accountManager.js';

export const data = new SlashCommandBuilder()
  .setName('renov')
  .setDescription('💳 Renovar ou ativar seu plano com pagamento PIX')
  .addStringOption(opt =>
    opt
      .setName('plano')
      .setDescription('Tipo de plano desejado')
      .setRequired(true)
      .addChoices(
        { name: '📅 Semanal (7 dias) - R$ 20,00', value: 'semanal' },
        { name: '📅 Mensal (30 dias) - R$ 29,59', value: 'mensal' }
      )
  )
  .addIntegerOption(opt =>
    opt
      .setName('quantidade')
      .setDescription('Quantos planos deseja comprar? (padrão: 1)')
      .setRequired(false)
      .setMinValue(1)
      .setMaxValue(12)
  );

export async function execute(interaction) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  try {
    const userId = interaction.user.id;
    const username = interaction.user.username;
    const planType = interaction.options.getString('plano');
    const quantity = interaction.options.getInteger('quantidade') || 1;

    // Obter ou criar conta
    const account = accountManager.getOrCreateAccount(userId, username);

    // Verificar se está vinculado e tentar criar própria conta
    const linkedInfo = accountManager.isLinked(userId);
    if (linkedInfo.isLinked) {
      const unlink = new ButtonBuilder()
        .setCustomId(`unlink_to_buy_${linkedInfo.parentId}`)
        .setLabel('❌ Desvincar e Comprar Meu Plano')
        .setStyle(ButtonStyle.Danger);

      const cancel = new ButtonBuilder()
        .setCustomId('cancel')
        .setLabel('Cancelar')
        .setStyle(ButtonStyle.Secondary);

      const row = new ActionRowBuilder().addComponents(unlink, cancel);

      const embed = new EmbedBuilder()
        .setTitle('⚠️ Você está vinculado a outra conta')
        .setDescription('Você precisa desvin cular antes de comprar seu próprio plano.')
        .setColor('#F59E0B')
        .addFields({
          name: '💡 Opção',
          value: 'Clique no botão abaixo para desvincar e criar sua própria assinatura',
          inline: false
        });

      return interaction.editReply({ embeds: [embed], components: [row] });
    }

    // Criar pagamento
    const paymentResult = await paymentManager.createPlanPayment(
      userId,
      username,
      planType,
      quantity
    );

    if (!paymentResult.success) {
      const errorEmbed = new EmbedBuilder()
        .setTitle('❌ Erro ao criar pagamento')
        .setDescription(paymentResult.error)
        .setColor('#EF4444');

      return interaction.editReply({ embeds: [errorEmbed] });
    }

    const priceInfo = paymentManager.calculatePlanPrice(planType, quantity);
    const payment = paymentResult.payment;

    // Criar embed com informações da transação
    const embed = new EmbedBuilder()
      .setTitle(`💳 Pagamento PIX - Plano ${planType === 'semanal' ? 'Semanal' : 'Mensal'}`)
      .setDescription('Escaneie o QR Code abaixo ou use o código PIX')
      .setColor('#8B5CF6')
      .addFields(
        {
          name: '📊 Resumo da Compra',
          value: `**Plano:** ${planType === 'semanal' ? '📅 Semanal (7 dias)' : '📅 Mensal (30 dias)'}
**Quantidade:** ${quantity}
**Total de dias:** ${priceInfo.days}
**Preço unitário:** R$ ${priceInfo.unitPrice.toFixed(2)}
**Total a pagar:** R$ ${priceInfo.totalPrice.toFixed(2)}`,
          inline: false
        },
        {
          name: '📋 Código PIX (Copiar e colar)',
          value: `\`\`\`${payment.copyPaste}\`\`\``,
          inline: false
        },
        {
          name: '⏰ QR Code expira em',
          value: new Date(payment.expirationDate).toLocaleString('pt-BR'),
          inline: false
        },
        {
          name: '🆔 ID da Transação',
          value: `\`${payment.transactionId}\``,
          inline: false
        }
      )
      .setImage(`https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(payment.copyPaste)}`)
      .setFooter({
        text: 'Após fazer a transferência PIX, clique no botão "Pago" para confirmar'
      })
      .setTimestamp();

    // Botões de ação
    const confirmButton = new ButtonBuilder()
      .setCustomId(`confirm_payment_${payment.transactionId}`)
      .setLabel('✅ Já fiz o pagamento')
      .setStyle(ButtonStyle.Success);

    const cancelButton = new ButtonBuilder()
      .setCustomId('cancel_payment')
      .setLabel('❌ Cancelar')
      .setStyle(ButtonStyle.Secondary);

    const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

    // Enviar mensagem via DM
    try {
      const dmChannel = await interaction.user.createDM();
      await dmChannel.send({
        embeds: [embed],
        components: [row]
      });

      // Responder na guild que a mensagem foi enviada por DM
      const confirmEmbed = new EmbedBuilder()
        .setTitle('✅ QR Code enviado por DM')
        .setDescription(`Um QR code foi enviado para seu DM com as instruções de pagamento.\n\n**Total a pagar:** R$ ${priceInfo.totalPrice.toFixed(2)}`)
        .setColor('#10B981');

      await interaction.editReply({ embeds: [confirmEmbed] });
    } catch (error) {
      console.error('❌ Erro ao enviar DM:', error.message);

      // Se não conseguir enviar DM, enviar na guild mesmo
      return interaction.editReply({
        embeds: [embed],
        components: [row]
      });
    }

  } catch (error) {
    console.error('❌ Erro no comando /renov:', error.message);

    const errorEmbed = new EmbedBuilder()
      .setTitle('❌ Erro ao processar comando')
      .setDescription('Ocorreu um erro ao processar sua solicitação. Tente novamente mais tarde.')
      .setColor('#EF4444');

    await interaction.editReply({ embeds: [errorEmbed] });
  }
}

export default { data, execute };
